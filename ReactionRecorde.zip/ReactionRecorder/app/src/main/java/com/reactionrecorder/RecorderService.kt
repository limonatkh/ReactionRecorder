package com.reactionrecorder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Size
import android.view.Display
import androidx.camera.core.CameraSelector
import androidx.camera.core.Camera
import androidx.camera.core.Preview
import androidx.camera.core.UseCaseGroup
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import java.util.concurrent.Executors
import kotlin.math.max

/**
 * خدمة المقدّمة (Foreground Service) التي تملك كل شيء أثناء التسجيل:
 * الكاميرا (CameraX) + MediaProjection + الـ Recorder. بهذا يستمر التسجيل عندما تنتقل إلى YouTube.
 */
class RecorderService : LifecycleService(), Scene.Host {
    companion object {
        const val ACTION_START = "rr.START"
        const val ACTION_STOP = "rr.STOP"
        const val ACTION_PAUSE = "rr.PAUSE"
        const val ACTION_RESUME = "rr.RESUME"
        const val ACTION_MUTE = "rr.MUTE"
        const val ACTION_SWITCH_CAMERA = "rr.SWITCH"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "recording"
        private const val NOTIF_ID = 1001
        private const val MIN_FREE_BYTES = 150L * 1024 * 1024
    }

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val camExec = Executors.newSingleThreadExecutor()

    private lateinit var cfg: RecordConfig
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var recorder: Recorder? = null
    private var camProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var preview: Preview? = null
    private var preview2: Preview? = null
    private var frontNow = true
    private var mirrorOn = true
    private var dualOn = false
    private var dualAvail = false
    private var dualToken = 0
    private var scene: Scene? = null
    private var stopping = false
    private var capW = 0
    private var capH = 0
    private var dpi = 320
    private var videoMode = false
    private var sourcePlayer: SourcePlayer? = null
    private var feed: PlayerAudioFeed? = null
    private var videoReady = false

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            if (displayId != Display.DEFAULT_DISPLAY) return
            val dm = getSystemService(DISPLAY_SERVICE) as DisplayManager
            val dr = dm.getDisplay(Display.DEFAULT_DISPLAY).rotation
            preview?.targetRotation = dr
            preview2?.targetRotation = dr
            applyCameraGeometry()
            if (videoMode) return // لا توجد شاشة ملتقطة في وضع Video file
            val (w, h) = captureSize()
            if (w != capW || h != capH) {
                capW = w; capH = h
                try { vd?.resize(w, h, dpi) } catch (_: Throwable) {}
                recorder?.compositor?.setSourceSize(w, h)
            }
        }
    }

    override fun onBind(intent: Intent): IBinder? { super.onBind(intent); return null }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_START -> startRecording(intent)
            ACTION_STOP -> stopRecording()
            ACTION_PAUSE -> pauseRecording()
            ACTION_RESUME -> resumeRecording()
            ACTION_MUTE -> toggleMute()
            ACTION_SWITCH_CAMERA -> switchCamera()
        }
        return START_NOT_STICKY
    }

    // ───────────────────────── start ─────────────────────────

    @Suppress("DEPRECATION")
    private fun startRecording(intent: Intent) {
        if (RecorderState.isBusy) return
        stopping = false
        RecorderState.lastUri = null
        RecorderState.lastError = null
        RecorderState.notes = emptyList()
        RecorderState.phase = RecorderState.Phase.STARTING
        RecorderState.changed()

        createChannel()
        cfg = ConfigStore.load(this)
        Playlist.load(this)
        // السيلفي (الأمامية) هي الكاميرا الأساسية دائمًا؛ الخلفية تُعرض مكان الفيديو عند الطلب.
        // نحاول تشغيل الكاميرتين معًا مباشرة، وإن لم يدعمهما الجهاز نكمل بالأمامية فقط.
        frontNow = true
        mirrorOn = cfg.mirrorFront
        dualOn = Build.VERSION.SDK_INT >= 30
        videoMode = cfg.mode == SourceMode.VIDEO
        videoReady = false

        // أنواع الخدمة: mediaProjection فقط عند تصوير الشاشة (وإلا يرفضها Android 14)، والميكروفون فقط إن مُنحت صلاحيته
        val micGranted = ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                var types = ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                if (micGranted) types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                if (!videoMode) types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                startForeground(NOTIF_ID, buildNotification("Preparing…"), types)
            } else {
                startForeground(NOTIF_ID, buildNotification("Preparing…"))
            }
        } catch (t: Throwable) {
            fail("Cannot start foreground service: ${t.message}"); return
        }

        if (videoMode) {
            if (Playlist.items.isEmpty()) { fail("No video selected"); return }
            feed = PlayerAudioFeed()
        } else {
            val code = intent.getIntExtra(EXTRA_CODE, 0)
            val data: Intent? = intent.getParcelableExtra(EXTRA_DATA)
            if (data == null) { fail("Screen capture permission missing"); return }
            try {
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                val p = mpm.getMediaProjection(code, data)
                p.registerCallback(object : MediaProjection.Callback() {
                    override fun onStop() { main.post { stopRecording() } }
                }, main)
                projection = p
            } catch (t: Throwable) {
                fail("Screen capture failed: ${t.message}"); return
            }
        }

        if (!videoMode) { val (cw, ch) = captureSize(); capW = cw; capH = ch }
        val firstItem = Playlist.current()

        worker.execute {
            try {
                if (StorageUtil.freeBytes() < MIN_FREE_BYTES) throw IllegalStateException("Not enough free storage")
                var w = capW
                var h = capH
                if (videoMode) {
                    val info = if (firstItem != null && !firstItem.image) VideoProbe.probe(this, firstItem.uri, false) else null
                    w = info?.width ?: 1920
                    h = info?.height ?: 1080
                }
                val rec = Recorder(this, cfg, projection, w, h, feed)
                rec.prepare()
                recorder = rec
                RecorderState.resolvedInfo = "${rec.resolved.w}x${rec.resolved.h} @ ${rec.resolved.fps}fps • " +
                    "${rec.resolved.bitrate / 1_000_000f} Mbps • " + if (rec.resolved.mime.contains("hevc")) "H.265" else "H.264"
                main.post { connectInputs(rec) }
            } catch (t: Throwable) {
                main.post { fail("Setup failed: ${t.message ?: t.javaClass.simpleName}") }
            }
        }
    }

    private fun connectVideo(rec: Recorder) {
        val f = feed ?: run { fail("Audio feed missing"); return }
        val sp = SourcePlayer(this, f)
        sourcePlayer = sp
        val sc = Scene(this, cfg, rec, sp, this)
        scene = sc
        RecorderState.scene = sc
        sc.applyInitial()
        sp.onVideoSize = { w, h -> rec.compositor.setSourceSize(w, h) }
        sp.onError = { msg -> main.post { if (!stopping) fail("Video playback error: $msg") } }
        sp.onEnded = { main.post { sc.onItemEnded() } }
        val proceed = {
            if (!videoReady && !stopping) {
                videoReady = true
                (getSystemService(DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(displayListener, main)
                bindCamera(rec) { ok ->
                    if (!ok) fail("Camera failed to open") else beginCountdown(rec)
                }
            }
        }
        sp.onReady = { proceed() }
        try {
            sp.init(rec.compositor.sourceSurface, cfg.silentPlayback)
            val cur = Playlist.current()
            if (cur == null) { fail("No video selected"); return }
            sc.loadInitial()
            // أول عنصر صورة: لا ننتظر المشغّل
            if (cur.image) main.post { proceed() }
        } catch (t: Throwable) {
            fail("Cannot open the video: ${t.message ?: t.javaClass.simpleName}"); return
        }
        main.postDelayed({
            if (!videoReady && !stopping) fail("The video took too long to load")
        }, 25_000)
    }

    private fun connectInputs(rec: Recorder) {
        if (stopping) return
        if (videoMode) { connectVideo(rec); return }
        try {
            val p = projection ?: throw IllegalStateException("no projection")
            vd = p.createVirtualDisplay(
                "ReactionRecorder", capW, capH, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                rec.compositor.sourceSurface, null, null,
            )
            (getSystemService(DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(displayListener, main)
            val sc = Scene(this, cfg, rec, null, this)
            scene = sc
            RecorderState.scene = sc
            sc.applyInitial()
        } catch (t: Throwable) {
            fail("Screen capture failed: ${t.message}"); return
        }
        bindCamera(rec) { ok ->
            if (!ok) { fail("Camera failed to open"); return@bindCamera }
            beginCountdown(rec)
        }
    }

    private fun beginCountdown(rec: Recorder) {
        var left = cfg.countdown
        val step = object : Runnable {
            override fun run() {
                if (stopping) return
                if (left > 0) {
                    RecorderState.phase = RecorderState.Phase.COUNTDOWN
                    RecorderState.countdownLeft = left
                    RecorderState.changed()
                    updateNotification("Recording starts in $left…")
                    left--
                    main.postDelayed(this, 1000)
                } else {
                    worker.execute {
                        try {
                            rec.begin()
                            main.post {
                                if (stopping) return@post
                                scene?.startPlayback()
                                RecorderState.markStarted()
                                RecorderState.countdownLeft = 0
                                RecorderState.phase = RecorderState.Phase.RECORDING
                                RecorderState.notes = rec.notes.toList()
                                RecorderState.changed()
                                updateNotification()
                                main.postDelayed(storageWatch, 5000)
                            }
                        } catch (t: Throwable) {
                            main.post { fail("Start failed: ${t.message ?: t.javaClass.simpleName}") }
                        }
                    }
                }
            }
        }
        step.run()
    }

    private val storageWatch = object : Runnable {
        override fun run() {
            if (stopping || !RecorderState.isBusy) return
            if (StorageUtil.freeBytes() < MIN_FREE_BYTES) {
                RecorderState.lastError = "Stopped: storage almost full (video saved)"
                stopRecording(); return
            }
            main.postDelayed(this, 5000)
        }
    }

    // ───────────────────────── camera ─────────────────────────

    private fun buildPreview(rs: ResolutionSelector, rotation: Int, rec: Recorder, idx: Int): Preview {
        val pv = Preview.Builder()
            .setResolutionSelector(rs)
            .setTargetRotation(rotation)
            .build()
        pv.setSurfaceProvider(camExec) { request ->
            val res = request.resolution
            rec.compositor.setCameraBufferSize(idx, res.width, res.height)
            request.provideSurface(rec.compositor.cameraSurfaceFor(idx), camExec) { /* السطح يبقى للـ Compositor */ }
            request.setTransformationInfoListener(camExec) { info ->
                rec.compositor.setCameraInfoRotation(idx, info.rotationDegrees)
            }
        }
        return pv
    }

    /** هل يدعم الجهاز تشغيل كاميرتين معًا؟ (واجهة CameraX للكاميرات المتزامنة، عبر reflection كي لا يتعطّل البناء إن تغيّرت) */
    private fun queryConcurrent(p: ProcessCameraProvider): Boolean {
        if (Build.VERSION.SDK_INT < 30) return false
        return try {
            val m = p.javaClass.getMethod("getAvailableConcurrentCameraInfos")
            val list = m.invoke(p) as? List<*>
            list != null && list.any { ((it as? List<*>)?.size ?: 0) >= 2 }
        } catch (_: Throwable) {
            false
        }
    }

    private fun bindDual(p: ProcessCameraProvider, pv1: Preview, pv2: Preview): Boolean {
        return try {
            val cfgCls = Class.forName("androidx.camera.core.ConcurrentCamera\$SingleCameraConfig")
            val ctor = cfgCls.getConstructor(CameraSelector::class.java, UseCaseGroup::class.java, androidx.lifecycle.LifecycleOwner::class.java)
            val primary = CameraSelector.DEFAULT_FRONT_CAMERA // الفهرس 0 = السيلفي
            val other = CameraSelector.DEFAULT_BACK_CAMERA // الفهرس 1 = الخلفية
            val c1 = ctor.newInstance(primary, UseCaseGroup.Builder().addUseCase(pv1).build(), this)
            val c2 = ctor.newInstance(other, UseCaseGroup.Builder().addUseCase(pv2).build(), this)
            val m = p.javaClass.getMethod("bindToLifecycle", List::class.java)
            m.invoke(p, listOf(c1, c2))
            true
        } catch (_: Throwable) {
            false
        }
    }

    /** اختيار الدقة لكل كاميرا (الضلع الطويل). CameraX يطلبها من المصدر مباشرة فيخفّ الحِمل */
    private fun rsFor(front: Boolean): ResolutionSelector {
        val long = if (front) cfg.camLongFront else cfg.camLongBack
        return ResolutionSelector.Builder()
            .setAspectRatioStrategy(AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY)
            .setResolutionStrategy(
                ResolutionStrategy(Size(long, long * 9 / 16), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
            ).build()
    }

    private fun notice(msg: String) {
        RecorderState.notice = msg
        RecorderState.changed()
    }

    private fun bindCamera(rec: Recorder, done: (Boolean) -> Unit) {
        val future = ProcessCameraProvider.getInstance(this)
        dualToken++
        future.addListener({
            try {
                val provider = future.get()
                camProvider = provider
                provider.unbindAll()
                rec.compositor.resetCameras()
                dualAvail = queryConcurrent(provider)
                val dm = getSystemService(DISPLAY_SERVICE) as DisplayManager
                val rot = dm.getDisplay(Display.DEFAULT_DISPLAY).rotation

                var dualBound = false
                if (dualOn) {
                    val a = buildPreview(rsFor(true), rot, rec, 0)
                    val b = buildPreview(rsFor(false), rot, rec, 1)
                    dualBound = bindDual(provider, a, b)
                    if (dualBound) {
                        preview = a; preview2 = b; camera = null; frontNow = true
                    } else {
                        provider.unbindAll()
                        dualOn = false
                        notice("Dual camera is not supported on this phone — using one camera. Use the Camera button to show the other one instead of the video.")
                    }
                }
                if (!dualBound) {
                    dualOn = false
                    val pv = buildPreview(rsFor(frontNow), rot, rec, 0)
                    preview = pv; preview2 = null
                    val sel = if (frontNow) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                    val cam = provider.bindToLifecycle(this, sel, pv)
                    camera = cam
                    try {
                        cam.cameraControl.setZoomRatio(cfg.zoom)
                        cam.cameraControl.setExposureCompensationIndex(cfg.exposureIndex)
                        cam.cameraControl.enableTorch(cfg.torch && cam.cameraInfo.hasFlashUnit())
                    } catch (_: Throwable) {}
                }
                rec.compositor.camera2Active = dualBound
                rec.compositor.cam0IsFront = frontNow
                applyMirror(rec)
                applyCameraGeometry()
                if (dualBound) verifyDual(rec)
                done(true)
            } catch (t: Throwable) {
                done(false)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    /** بعض الأجهزة تقبل ربط الكاميرتين لكن لا تُخرج إطارات من الاثنتين. نتحقق بعد ثوانٍ ونرجع لكاميرا واحدة إن لزم */
    private fun verifyDual(rec: Recorder) {
        val token = dualToken
        main.postDelayed({
            if (stopping || token != dualToken || !dualOn) return@postDelayed
            // الإطارات لا تُرسم قبل بدء التسجيل (العدّ التنازلي): ننتظر ثم نتحقق
            if (RecorderState.phase == RecorderState.Phase.STARTING || RecorderState.phase == RecorderState.Phase.COUNTDOWN) {
                verifyDual(rec); return@postDelayed
            }
            if (rec.compositor.hasFrame(0) && rec.compositor.hasFrame(1)) return@postDelayed
            scene?.exitCameraMode(true)
            dualOn = false
            notice("Dual camera did not start on this phone — using one camera. Use the Camera button to show the other one instead of the video.")
            bindCamera(rec) { }
        }, 3500)
    }

    private fun applyMirror(rec: Recorder) {
        rec.compositor.setCameraMirror(0, frontNow && mirrorOn)
        rec.compositor.setCameraMirror(1, false)
    }

    /** يمرّر دوران الشاشة الحالي للـ Compositor كي تبقى الكاميرا مستقيمة في الفيديو النهائي */
    private fun applyCameraGeometry() {
        val c = recorder?.compositor ?: return
        val dm = getSystemService(DISPLAY_SERVICE) as DisplayManager
        c.displayQuarter = dm.getDisplay(Display.DEFAULT_DISPLAY).rotation
    }

    private fun switchCamera() {
        val rec = recorder ?: return
        if (RecorderState.phase != RecorderState.Phase.RECORDING && RecorderState.phase != RecorderState.Phase.PAUSED) return
        if (dualOn) return // في وضع الكاميرتين: السيلفي أمامية دائمًا والخلفية تُعرض مكان الفيديو
        frontNow = !frontNow
        bindCamera(rec) { ok ->
            if (!ok) {
                frontNow = !frontNow
                RecorderState.lastError = "Camera switch failed"
                RecorderState.changed()
            }
        }
    }

    // ───────────────────────── controls ─────────────────────────

    private fun pauseRecording() {
        if (RecorderState.phase != RecorderState.Phase.RECORDING) return
        recorder?.pause()
        scene?.onRecPause()
        RecorderState.markPaused()
        RecorderState.phase = RecorderState.Phase.PAUSED
        RecorderState.changed(); updateNotification()
    }

    private fun resumeRecording() {
        if (RecorderState.phase != RecorderState.Phase.PAUSED) return
        recorder?.resume()
        scene?.onRecResume()
        RecorderState.markResumed()
        RecorderState.phase = RecorderState.Phase.RECORDING
        RecorderState.changed(); updateNotification()
    }

    private fun toggleMute() {
        val sc = scene
        if (sc != null) { sc.setMicMuted(!RecorderState.micMuted); return }
        RecorderState.micMuted = !RecorderState.micMuted
        recorder?.setMicMuted(RecorderState.micMuted)
        RecorderState.changed(); updateNotification()
    }

    // ───────────────────────── Scene.Host ─────────────────────────

    override fun camFront(): Boolean = frontNow
    override fun camMirror(): Boolean = mirrorOn
    override fun flipCamera() { switchCamera() }
    override fun toggleMirror() {
        mirrorOn = !mirrorOn
        recorder?.let { applyMirror(it) }
    }
    override fun dualAvailable(): Boolean = Build.VERSION.SDK_INT >= 30
    override fun dualActive(): Boolean = dualOn
    override fun setDual(on: Boolean, done: (Boolean) -> Unit) {
        val rec = recorder
        if (rec == null || (on && Build.VERSION.SDK_INT < 30)) { done(false); return }
        val prev = dualOn
        dualOn = on
        if (on) frontNow = true
        bindCamera(rec) { ok ->
            if (!ok) dualOn = prev
            done(ok && dualOn == on)
        }
    }

    /** يجهّز الكاميرا المطلوبة (أمامية/خلفية) كمصدر رئيسي ويعيد فهرسها في الـ Compositor، أو -1 عند الفشل */
    override fun ensureCamera(front: Boolean, done: (Int) -> Unit) {
        val rec = recorder
        if (rec == null) { done(-1); return }
        if (dualOn) { done(if (front) 0 else 1); return }
        if (frontNow == front) { done(0); return }
        frontNow = front
        bindCamera(rec) { ok ->
            if (!ok) { frontNow = !front; done(-1) } else done(0)
        }
    }
    override fun allFinished() {
        if (!stopping) main.postDelayed({ stopRecording() }, 1200) // ذيل قصير بعد آخر إطار
    }
    override fun refreshNotification() { if (!stopping) updateNotification() }

    private fun stopRecording() {
        if (stopping) return
        stopping = true
        main.removeCallbacksAndMessages(null)
        // إلغاء أثناء التجهيز/العدّ التنازلي ليس خطأ — لا نعرض رسالة
        val cancelled = RecorderState.phase == RecorderState.Phase.STARTING || RecorderState.phase == RecorderState.Phase.COUNTDOWN
        if (RecorderState.phase == RecorderState.Phase.RECORDING) RecorderState.markPaused()
        RecorderState.phase = RecorderState.Phase.FINISHING
        RecorderState.changed()
        updateNotification("Finishing video…")

        // 1) نوقف مصادر الإطارات
        try { (getSystemService(DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(displayListener) } catch (_: Throwable) {}
        try { camProvider?.unbindAll() } catch (_: Throwable) {}
        try { vd?.release() } catch (_: Throwable) {}
        vd = null
        try { scene?.release() } catch (_: Throwable) {}
        scene = null
        try { sourcePlayer?.release() } catch (_: Throwable) {}
        sourcePlayer = null
        val proj = projection
        projection = null

        // 2) نُنهي الترميز والكتابة في خيط خلفي (نفس الخيط الذي يجهّز الـ Recorder، فيُنفَّذ بعد انتهاء التجهيز)
        worker.execute {
            val rec = recorder
            var uri: android.net.Uri? = null
            try { uri = rec?.stop() } catch (_: Throwable) {}
            try { proj?.stop() } catch (_: Throwable) {}
            main.post {
                RecorderState.lastUri = uri
                if (uri == null && RecorderState.lastError == null && !cancelled) RecorderState.lastError = "No video was saved"
                recorder = null
                RecorderState.reset()
                RecorderState.changed()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    private fun fail(msg: String) {
        RecorderState.lastError = msg
        stopping = true
        main.removeCallbacksAndMessages(null)
        try { (getSystemService(DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(displayListener) } catch (_: Throwable) {}
        try { camProvider?.unbindAll() } catch (_: Throwable) {}
        try { vd?.release() } catch (_: Throwable) {}
        vd = null
        try { scene?.release() } catch (_: Throwable) {}
        scene = null
        try { sourcePlayer?.release() } catch (_: Throwable) {}
        sourcePlayer = null
        worker.execute {
            val rec = recorder
            recorder = null
            try { rec?.abort() } catch (_: Throwable) {}
            try { projection?.stop() } catch (_: Throwable) {}
            projection = null
            main.post {
                RecorderState.reset()
                RecorderState.changed()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { scene?.release() } catch (_: Throwable) {}
        try { sourcePlayer?.release() } catch (_: Throwable) {}
        worker.shutdown()
        camExec.shutdown()
    }

    // ───────────────────────── helpers ─────────────────────────

    @Suppress("DEPRECATION")
    private fun captureSize(): Pair<Int, Int> {
        val dm = DisplayMetrics()
        val display = (getSystemService(DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
        display.getRealMetrics(dm)
        dpi = dm.densityDpi
        // نلتقط بدقة قريبة من دقة الإخراج لتخفيف حِمل الـ GPU على M13 (بدون تكبير)
        val maxLong = if (cfg.shortSide >= 1080) 1920 else 1280
        val long = max(dm.widthPixels, dm.heightPixels)
        val s = if (long > maxLong) maxLong.toFloat() / long else 1f
        val w = ((dm.widthPixels * s).toInt() / 2) * 2
        val h = ((dm.heightPixels * s).toInt() / 2) * 2
        return Pair(w, h)
    }

    private fun createChannel() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun action(act: String, title: String, req: Int): NotificationCompat.Action {
        val pi = PendingIntent.getService(
            this, req, Intent(this, RecorderService::class.java).setAction(act),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Action.Builder(0, title, pi).build()
    }

    private fun buildNotification(text: String? = null): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val phase = RecorderState.phase
        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setContentTitle(getString(R.string.notif_title))
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
        when {
            text != null -> b.setContentText(text)
            phase == RecorderState.Phase.PAUSED -> b.setContentText("Paused")
            else -> {
                b.setContentText(if (RecorderState.micMuted) "Recording (mic muted)" else "Recording")
                b.setUsesChronometer(true).setWhen(System.currentTimeMillis() - RecorderState.elapsedMs())
            }
        }
        if (phase == RecorderState.Phase.RECORDING || phase == RecorderState.Phase.PAUSED) {
            b.addAction(action(ACTION_STOP, "Stop", 1))
            if (phase == RecorderState.Phase.PAUSED) b.addAction(action(ACTION_RESUME, "Resume", 2))
            else b.addAction(action(ACTION_PAUSE, "Pause", 2))
            b.addAction(action(ACTION_MUTE, if (RecorderState.micMuted) "Unmute" else "Mute", 3))
        } else if (phase == RecorderState.Phase.COUNTDOWN) {
            b.addAction(action(ACTION_STOP, "Cancel", 1))
        }
        return b.build()
    }

    private fun updateNotification(text: String? = null) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification(text))
    }
}
