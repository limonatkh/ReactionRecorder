package com.reactionrecorder

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.json.JSONObject

class PodEngineTest {
    /** يبني تحليلًا من فترات كلام لكل شخص */
    private fun analysis(duration: Double, vararg people: List<Pair<Double, Double>>): PodAnalysis {
        val fs = 0.05
        val n = (duration / fs).toInt()
        val act = Array(people.size) { p ->
            BooleanArray(n) { f -> val t = f * fs; people[p].any { t >= it.first && t < it.second } }
        }
        return PodAnalysis(fs, act, FloatArray(people.size) { -25f }, duration)
    }

    private fun st(intensity: String = "balanced") = ProjSettings.episodeDefaults().also { it.intensity = intensity }

    @Test fun shortBackchannelDoesNotSwitchCamera() {
        // أ يتكلم 20 ثانية، ب يقول "آه" نصف ثانية في المنتصف
        val an = analysis(20.0, listOf(0.0 to 20.0), listOf(8.0 to 8.5))
        val shots = PodEngine.autoShots(an, 2, false, true, st("balanced"), 0.0, 20.0)
        assertTrue("all shots should show person 0: " + shots.map { it.type to it.main }, shots.all { it.type == PodShot.FULL && it.main == 0 })
    }

    @Test fun realTurnSwitchesNearItsStart() {
        val an = analysis(20.0, listOf(0.0 to 10.0), listOf(10.5 to 20.0))
        val shots = PodEngine.autoShots(an, 2, false, false, st("balanced"), 0.0, 20.0)
        assertEquals(2, shots.size)
        assertEquals(0, shots[0].main)
        assertEquals(1, shots[1].main)
        assertTrue("cut at ~10.3: ${shots[1].start}", shots[1].start in 10.0..10.6)
        assertEquals(0.0, shots.first().start, 1e-6)
        assertEquals(20.0, shots.last().end, 1e-6)
    }

    @Test fun noTimerBasedSwitchDuringLongMonologue() {
        val an = analysis(120.0, listOf(0.0 to 120.0), listOf())
        val shots = PodEngine.autoShots(an, 2, true, true, st("balanced"), 0.0, 120.0)
        assertEquals(1, shots.size)
    }

    @Test fun overlapGivesSharedShot() {
        val an = analysis(20.0, listOf(0.0 to 12.0), listOf(8.0 to 20.0))
        val shots = PodEngine.autoShots(an, 2, false, false, st("balanced"), 0.0, 20.0)
        assertTrue(shots.any { it.type == PodShot.MULTI && it.start in 7.5..8.5 })
    }

    @Test fun lockedShotSurvivesRegeneration() {
        val an = analysis(30.0, listOf(0.0 to 30.0), listOf())
        val fresh = PodEngine.autoShots(an, 2, false, false, st(), 0.0, 30.0)
        val old = ArrayList(fresh.map { it.copy() })
        val lock = PodShot(10.0, 14.0, PodShot.FULL, 1, IntArray(0)).also { it.locked = true; it.tag = "manual" }
        val withLock = PodEngine.overlay(old, listOf(lock))
        val regen = PodEngine.regenerate(withLock, PodEngine.autoShots(an, 2, false, false, st("lively"), 0.0, 30.0), 0.0, 30.0)
        val l = regen.firstOrNull { it.locked }
        assertNotNull(l)
        assertEquals(10.0, l!!.start, 1e-6)
        assertEquals(14.0, l.end, 1e-6)
        assertEquals(1, l.main)
        assertEquals(0.0, regen.first().start, 1e-6)
        assertEquals(30.0, regen.last().end, 1e-6)
        for (i in 1 until regen.size) assertEquals(regen[i - 1].end, regen[i].start, 1e-6)
    }

    @Test fun partialRegenerationKeepsOutside() {
        val old = mutableListOf(
            PodShot(0.0, 10.0, PodShot.FULL, 1, IntArray(0)),
            PodShot(10.0, 20.0, PodShot.FULL, 1, IntArray(0)),
            PodShot(20.0, 30.0, PodShot.FULL, 1, IntArray(0)),
        )
        val fresh = listOf(PodShot(0.0, 30.0, PodShot.FULL, 0, IntArray(0)))
        val r = PodEngine.regenerate(old, fresh, 0.0, 30.0, 10.0, 20.0)
        assertEquals(1, r.first { it.start < 5 }.main)
        assertEquals(0, r.first { it.start <= 15 && it.end > 15 }.main)
        assertEquals(1, r.first { it.start <= 25 && it.end > 25 }.main)
    }

    @Test fun episodeAndReelSettingsAreIndependent() {
        val ep = PodProject("episode", PodProject.EPISODE)
        val reel = PodProject("reel_1", PodProject.REEL)
        assertEquals("off", ep.st.silence)
        assertEquals("balanced", reel.st.silence)
        reel.st.silence = "intense"
        reel.cuts.add(PCut(1.0, 2.0, PCut.SILENCE))
        assertEquals("off", ep.st.silence)
        assertTrue(ep.cuts.isEmpty())
        val back = PodProject.fromJson(JSONObject(reel.toJson().toString()))
        assertEquals("intense", back.st.silence)
        assertEquals(1, back.cuts.size)
        val copy = reel.copy()
        copy.st.silence = "light"
        assertEquals("intense", reel.st.silence)
    }

    @Test fun timeMapAfterCuts() {
        val segs = PodEngine.keepSegments(0.0, 10.0, listOf(PCut(2.0, 3.0, PCut.SILENCE), PCut(5.0, 6.0, PCut.TEXT)))
        val m = PodEngine.TimeMap(segs)
        assertEquals(8.0, m.outDur, 1e-6)
        assertEquals(3.0, m.toOut(4.0)!!, 1e-6)
        assertNull(m.toOut(2.5))
        assertEquals(4.5, m.toSession(3.5), 1e-6)
        assertEquals(7.5, m.toSession(5.5), 1e-6)
        val srt = PodEngine.srt(listOf(Triple(6.5, 7.0, "نص")), m)
        assertTrue(srt, srt.contains("00:00:04,500 --> 00:00:05,000"))
    }

    @Test fun silenceCutsKeepMargins() {
        val an = analysis(6.0, listOf(0.0 to 2.0, 4.0 to 6.0))
        val ts = PodEngine.markBackchannels(PodEngine.turns(an, 1))
        val cuts = PodEngine.silenceCuts(an, ts, "intense", 0.0, 6.0)
        assertEquals(1, cuts.size)
        assertTrue(cuts[0].a >= 2.0 + 0.09)
        assertTrue(cuts[0].b <= 4.0 - 0.07)
        assertTrue(PodEngine.silenceCuts(an, ts, "off", 0.0, 6.0).isEmpty())
    }

    @Test fun expressivePauseIsShortenedNotRemoved() {
        val an = analysis(8.0, listOf(0.0 to 3.0, 4.5 to 8.0))
        val ts = PodEngine.markBackchannels(PodEngine.turns(an, 1, joinGap = 0.5))
        val cuts = PodEngine.silenceCuts(an, ts, "balanced", 0.0, 8.0)
        assertEquals(1, cuts.size)
        val kept = 1.5 - (cuts[0].b - cuts[0].a)
        assertTrue("kept $kept", kept >= 0.55)
    }

    @Test fun zoomStaysOutOfSharedShotsAndIsSpaced() {
        val st = ProjSettings.reelDefaults().also { it.zoomMode = "auto"; it.intensity = "lively"; it.zoomMax = 1.12f }
        val shots = listOf(PodShot(0.0, 10.0, PodShot.MULTI, 0, intArrayOf(0, 1)), PodShot(10.0, 40.0, PodShot.FULL, 0, IntArray(0)))
        val keys = listOf(doubleArrayOf(2.0, 4.0), doubleArrayOf(12.0, 14.0), doubleArrayOf(15.0, 16.0))
        val z = PodEngine.autoZooms(shots, emptyList(), emptyList(), st, keys, 0.0, 40.0)
        assertTrue(z.none { it.a < 10.0 })
        for (i in 1 until z.size) assertTrue(z[i].a >= z[i - 1].b + 6.0)
        assertTrue(z.all { it.scale <= 1.12f })
        assertEquals(1f, PodEngine.zoomAt(z, 30.0), 1e-6f)
        assertTrue(PodEngine.zoomLimit(607.0, 1080.0, 1.15f) <= 1.24f)
        assertEquals(1f, PodEngine.zoomLimit(405.0, 1080.0, 1.15f), 1e-6f)
        assertTrue(PodEngine.autoZooms(shots, emptyList(), emptyList(), st.copy().also { it.zoomMode = "off" }, keys, 0.0, 40.0).isEmpty())
    }

    @Test fun lockedZoomIsKept() {
        val old = listOf(PZoom(5.0, 8.0, 1f, false, locked = true, auto = false, reason = "تثبيت"))
        val fresh = listOf(PZoom(6.0, 9.0, 1.1f, true), PZoom(20.0, 22.0, 1.1f, true))
        val r = PodEngine.mergeZooms(old, fresh)
        assertEquals(2, r.size)
        assertTrue(r.any { it.locked && it.a == 5.0 })
        assertTrue(r.none { it.a == 6.0 })
    }

    @Test fun captionChunksAreShortAndTimed() {
        val seg = TSeg(0, 10.0, 20.0, "مرحبا بكم في هذه الحلقة الجديدة، اليوم بدنا نحكي عن موضوع مهم جدا للناس كلها", 0, emptyList())
        val ch = PodEngine.captionChunks(listOf(seg), setOf("0:1"))
        assertTrue(ch.size >= 2)
        assertTrue(ch.all { it.text.length <= 50 })
        assertEquals(10.0, ch.first().a, 1e-6)
        assertEquals(20.0, ch.last().b, 1e-6)
        for (i in 1 until ch.size) assertEquals(ch[i - 1].b, ch[i].a, 1e-6)
        assertTrue(ch[0].emph.contains(1))
        assertTrue(ch[0].words.last().endsWith("،"))
    }

    @Test fun reelSuggestionFindsQuestionAndAnswer() {
        val an = analysis(120.0, listOf(10.0 to 14.0, 60.0 to 64.0), listOf(15.0 to 50.0, 65.0 to 110.0))
        val s = PodEngine.suggestReels(an, listOf("أحمد", "سارة"), emptyList(), 40.0, 5)
        assertTrue(s.isNotEmpty())
        assertTrue(s.any { it.type == "qa" && it.a <= 10.0 && it.b >= 49.0 })
    }

    @Test fun oopsMarkerLowersScore() {
        val an = analysis(120.0, listOf(10.0 to 14.0, 60.0 to 64.0), listOf(15.0 to 50.0, 65.0 to 100.0))
        val s = PodEngine.suggestReels(an, listOf("أ", "ب"), listOf(PMarker(30.0, "oops"), PMarker(80.0, "star")), 40.0, 5)
        val first = s.first { it.a <= 15 && it.b >= 30 }
        val second = s.first { it.a <= 65 && it.b >= 80 }
        assertTrue(second.score > first.score)
        assertTrue(first.reason.contains("غلطة"))
    }

    @Test fun undoRedo() {
        val u = UndoStack()
        u.push("a")
        u.push("b")
        assertEquals("b", u.undo("c"))
        assertEquals("a", u.undo("b"))
        assertFalse(u.canUndo())
        assertEquals("b", u.redo("a"))
    }
}
