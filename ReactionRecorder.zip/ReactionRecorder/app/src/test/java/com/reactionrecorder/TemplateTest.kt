package com.reactionrecorder

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TemplateTest {
    @Test fun jsonRoundTrip() {
        val t = PodTemplate().apply { id = "x"; name = "n"; pipPos = "custom"; pipX = 0.3f; pipShape = "alternate"; pipPlace = "person"; names = "first"; glowColor = 0xFF3D8BFF.toInt(); intensity = "lively" }
        val b = PodTemplate.fromJson(t.toJson())
        assertEquals("custom", b.pipPos); assertEquals(0.3f, b.pipX, 1e-4f); assertEquals("alternate", b.pipShape)
        assertEquals("person", b.pipPlace); assertEquals("first", b.names); assertEquals(0xFF3D8BFF.toInt(), b.glowColor); assertEquals("lively", b.intensity)
    }

    @Test fun applyCopiesDecisions() {
        val st = ProjSettings()
        TemplateStore.applyTo(PodTemplate().apply { id = "q"; intensity = "calm"; pip = false; fade = true; orient = "v" }, st)
        assertEquals("q", st.tpl); assertEquals("calm", st.intensity); assertEquals(false, st.pip); assertTrue(st.fade); assertEquals("v", st.orient)
        assertEquals("q", ProjSettings.fromJson(st.toJson()).tpl)
    }

    @Test fun pacingInfoHasNumbers() {
        val l = PodTemplate.pacingInfo("balanced", true)
        assertTrue(l.size >= 6)
        assertTrue(l.any { it.contains("2") })
    }

    @Test fun templateChangeReachesProjectButNotManualEdits() {
        val t = PodTemplate().apply { id = "q"; glow = true; zoomMode = "auto" }
        val st = ProjSettings()
        TemplateStore.applyTo(t, st)
        assertTrue(st.glow)
        // تعديل يدوي بالمشروع
        val before = st.copy(); st.applied = false
        st.zoomMode = "off"
        TemplateStore.trackOverrides(before, st)
        assertTrue("zoomMode" in st.ov)
        // المستخدم شال الإطار المضيء من القالب → لازم يختفي من المشروع (المعاينة = التصدير)
        t.glow = false; t.zoomMode = "auto"
        TemplateStore.sync(t, st)
        assertEquals(false, st.glow)
        assertEquals("off", st.zoomMode)
    }

    @Test fun oldProjectsKeepTheirOwnSettings() {
        val st = ProjSettings().apply { glow = true; zoomMode = "auto" } // sv = 0 (قديم)
        TemplateStore.sync(PodTemplate().apply { glow = false; zoomMode = "off" }, st)
        assertEquals(false, st.glow)        // كان بينسخ من القالب → بيتبع القالب
        assertEquals("auto", st.zoomMode)   // ما كان من القالب → تعديلك بيضل
    }

    @Test fun reelTemplatesHaveTheirOwnKind() {
        val reels = PodTemplate.builtIns().filter { it.kind == "reel" }
        assertTrue(reels.size >= 5)
        assertTrue(reels.all { it.orient == "v" })
        val b = PodTemplate.fromJson(reels.first { it.pipFace }.toJson())
        assertTrue(b.pipFace && b.avoidFace); assertEquals("reel", b.kind)
    }
}
