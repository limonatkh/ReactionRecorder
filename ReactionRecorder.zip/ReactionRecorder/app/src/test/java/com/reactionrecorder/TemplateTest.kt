package com.reactionrecorder

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TemplateTest {
    @Test fun jsonRoundTrip() {
        val t = PodTemplate().apply { id = "x"; name = "n"; pipPos = "custom"; pipX = 0.3f; pipShape = "alternate"; pipPlace = "person"; names = "first"; glowColor = 0xFF3D8BFF.toInt(); intensity = "lively" }
        val b = PodTemplate.fromJson(t.toJson())
        assertEquals("custom", b.pipPos); assertEquals(0.3f, b.pipX, 1e-4f); assertEquals("alternate", b.pipShape)
        assertEquals("person", b.pipPlace); assertEquals("first", b.names); assertEquals(0xFF3D8BFF.toInt(), b.glowColor); assertEquals("lively", b.intensity)
    }

    @Test fun applyCopiesDecisions() {
        val st = ProjSettings()
        TemplateStore.applyTo(PodTemplate().apply { id = "q"; intensity = "calm"; pip = false; fade = true; orient = "v" }, st)
        assertEquals("q", st.tpl); assertEquals("calm", st.intensity); assertEquals(false, st.pip); assertTrue(st.fade); assertEquals("v", st.orient)
        assertEquals("q", ProjSettings.fromJson(st.toJson()).tpl)
    }

    @Test fun pacingInfoHasNumbers() {
        val l = PodTemplate.pacingInfo("balanced", true)
        assertTrue(l.size >= 6)
        assertTrue(l.any { it.contains("2") })
    }
}
