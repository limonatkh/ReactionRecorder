package com.reactionrecorder

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.File
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/** إعدادات الخدمة الخارجية (اختيارية): أي خدمة متوافقة مع OpenAI. المفتاح يُحفظ على الجهاز فقط */
class AiCfg(var base: String, var key: String, var stt: String, var chat: String, var lang: String) {
    val ok get() = key.isNotBlank() && base.startsWith("http")
}

/**
 * التفريغ الزمني والتحليل الدلالي والترجمة عبر خدمة خارجية يختارها المستخدم (OpenAI أو Groq أو غيرها).
 * لا يُرفع شيء إلا بطلب صريح من المستخدم. المونتاج الأساسي يعمل بدونها.
 */
object PodAI {
    private const val P = "reaction_ai"

    fun cfg(ctx: Context): AiCfg {
        val s = ctx.getSharedPreferences(P, Context.MODE_PRIVATE)
        return AiCfg(
            s.getString("base", "https://api.openai.com/v1") ?: "", s.getString("key", "") ?: "",
            s.getString("stt", "whisper-1") ?: "whisper-1", s.getString("chat", "gpt-4o-mini") ?: "gpt-4o-mini",
            s.getString("lang", "ar") ?: "ar",
        )
    }

    fun save(ctx: Context, c: AiCfg) {
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putString("base", c.base.trim().trimEnd('/')).putString("key", c.key.trim())
            .putString("stt", c.stt.trim()).putString("chat", c.chat.trim()).putString("lang", c.lang.trim()).apply()
    }

    // ───── ملفات الجلسة ─────

    fun transcriptFile(ctx: Context, sid: String) = File(SessionStore.dir(ctx, sid), "transcript.json")
    fun semanticFile(ctx: Context, sid: String) = File(SessionStore.dir(ctx, sid), "semantic.json")

    fun loadTranscript(ctx: Context, sid: String): Transcript? = try {
        val f = transcriptFile(ctx, sid)
        if (f.exists()) Transcript.fromJson(JSONObject(f.readText())) else null
    } catch (_: Throwable) { null }

    fun saveTranscript(ctx: Context, sid: String, t: Transcript) {
        try { transcriptFile(ctx, sid).writeText(t.toJson().toString()) } catch (_: Throwable) {}
    }

    fun loadSemantic(ctx: Context, sid: String): Semantic? = try {
        val f = semanticFile(ctx, sid)
        if (f.exists()) Semantic.fromJson(JSONObject(f.readText())) else null
    } catch (_: Throwable) { null }

    // ───── التفريغ ─────

    /**
     * يخلط مايكات الأشخاص إلى صوت أحادي 16kHz، يقسّمه لأجزاء (~8 دقائق) عند أقرب صمت، ويرسله للتفريغ.
     * المتحدث لكل جملة يُحدَّد من توقيت المايكات المحلي (لا يحتاج الخدمة).
     */
    fun transcribe(ctx: Context, s: SessionInfo, setup: PodSetup, an: PodAnalysis, progress: (String, Float) -> Unit, cancelled: () -> Boolean): Transcript {
        val c = cfg(ctx)
        require(c.ok) { "أدخل عنوان الخدمة والمفتاح أولًا" }
        val dur = an.duration
        val srcs = setup.people.map { it.micDev }.filter { it.isNotEmpty() }.distinct().mapNotNull { PodAudioSrc.open(ctx, s, it) }
        require(srcs.isNotEmpty()) { "لا يوجد صوت مايكات في هذه الجلسة" }
        val segs = ArrayList<TSeg>()
        try {
            // حدود الأجزاء عند أقرب صمت
            val cuts = ArrayList<Double>()
            cuts.add(0.0)
            val target = 480.0
            var t = target
            val sil = PodEngine.silences(an, 0.0, dur, 0.4)
            while (t < dur - 30) {
                val best = sil.filter { abs((it[0] + it[1]) / 2 - t) < 25 }.minByOrNull { abs((it[0] + it[1]) / 2 - t) }
                val c0 = best?.let { (it[0] + it[1]) / 2 } ?: t
                cuts.add(c0)
                t = c0 + target
            }
            cuts.add(dur)
            for (k in 0 until cuts.size - 1) {
                if (cancelled()) throw InterruptedException("Cancelled")
                val a = cuts[k]; val b = cuts[k + 1]
                progress("تجهيز الصوت ${k + 1}/${cuts.size - 1}", k.toFloat() / (cuts.size - 1))
                val wav = File(ctx.cacheDir, "stt_${s.id}_$k.wav")
                writeMix16k(srcs, a, b, wav)
                progress("التفريغ ${k + 1}/${cuts.size - 1} (رفع وانتظار)", (k + 0.3f) / (cuts.size - 1))
                val o = try {
                    try { postTranscription(c, wav, 2) } catch (e: IllegalStateException) {
                        // بعض الخدمات/النماذج لا تدعم توقيت الكلمات أو verbose_json: نتراجع تدريجيًا
                        if (e.message?.contains("400") != true) throw e
                        try { postTranscription(c, wav, 1) } catch (e2: IllegalStateException) {
                            if (e2.message?.contains("400") != true) throw e2
                            postTranscription(c, wav, 0)
                        }
                    }
                } finally { wav.delete() }
                val arr = o.optJSONArray("segments") ?: JSONArray()
                val words = o.optJSONArray("words")
                val allWords = ArrayList<TWord>()
                if (words != null) for (i in 0 until words.length()) {
                    val w = words.getJSONObject(i)
                    allWords.add(TWord(a + w.optDouble("start"), a + w.optDouble("end"), w.optString("word")))
                }
                if (arr.length() == 0 && o.optString("text").isNotBlank()) {
                    segs.add(TSeg(segs.size, a, b, o.optString("text").trim(), -1, allWords))
                }
                for (i in 0 until arr.length()) {
                    val g = arr.getJSONObject(i)
                    val sa = a + g.optDouble("start"); val sb = a + g.optDouble("end")
                    val text = g.optString("text").trim()
                    if (text.isEmpty()) continue
                    val ws = allWords.filter { it.a >= sa - 0.05 && it.b <= sb + 0.05 }
                    segs.add(TSeg(segs.size, sa, min(sb, b), text, -1, ws))
                }
            }
        } finally {
            for (x in srcs) x.close()
        }
        // من المتحدث في كل جملة (من نشاط المايكات)
        for (g in segs) g.speaker = speakerOf(an, g.a, g.b)
        val tr = Transcript(segs, c.lang, "${c.base} / ${c.stt}")
        saveTranscript(ctx, s.id, tr)
        progress("تم التفريغ", 1f)
        return tr
    }

    fun speakerOf(an: PodAnalysis, a: Double, b: Double): Int {
        val f0 = max(0, (a / an.frameSec).toInt()); val f1 = min(an.frames, (b / an.frameSec).toInt())
        var best = -1; var bestN = 0
        for ((p, row) in an.active.withIndex()) {
            var n = 0
            for (f in f0 until f1) if (row[f]) n++
            if (n > bestN) { bestN = n; best = p }
        }
        return best
    }

    private fun writeMix16k(srcs: List<PodAudioSrc>, a: Double, b: Double, out: File) {
        val rate = 16000
        val total = ((b - a) * rate).toLong()
        RandomAccessFile(out, "rw").use { raf ->
            raf.setLength(0)
            raf.write(ByteArray(44))
            val block = 8000
            val buf = FloatArray(block * 3 + 64)
            val mix = FloatArray(block)
            val bytes = ByteArray(block * 2)
            var k = 0L
            while (k < total) {
                val n = min(block.toLong(), total - k).toInt()
                java.util.Arrays.fill(mix, 0, n, 0f)
                val t0 = a + k.toDouble() / rate
                val t1 = a + (k + n).toDouble() / rate
                for (src in srcs) {
                    val n0 = src.nAt(t0); val n1 = src.nAt(t1)
                    val st = floor(n0).toLong() - 1
                    val cnt = (Math.ceil(n1).toLong() + 2 - st).toInt()
                    if (cnt <= 0 || cnt > buf.size) continue
                    src.rd.readChannel(st, cnt, 0, buf)
                    for (i in 0 until n) {
                        val np = n0 + (n1 - n0) * i / n
                        val fl = floor(np)
                        val ix = (fl.toLong() - st).toInt()
                        if (ix < 0 || ix + 1 >= cnt) continue
                        val w = (np - fl).toFloat()
                        mix[i] += buf[ix] * (1 - w) + buf[ix + 1] * w
                    }
                }
                val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                for (i in 0 until n) bb.putShort((mix[i].coerceIn(-1f, 1f) * 32767f).toInt().toShort())
                raf.write(bytes, 0, n * 2)
                k += n
            }
            val data = total * 2
            val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray()); h.putInt((36 + data).toInt()); h.put("WAVE".toByteArray()); h.put("fmt ".toByteArray())
            h.putInt(16); h.putShort(1); h.putShort(1); h.putInt(rate); h.putInt(rate * 2); h.putShort(2); h.putShort(16)
            h.put("data".toByteArray()); h.putInt(data.toInt())
            raf.seek(0); raf.write(h.array())
        }
    }

    /** level: 2 = مقاطع + كلمات، 1 = مقاطع فقط، 0 = نص فقط (json) */
    private fun postTranscription(c: AiCfg, wav: File, level: Int): JSONObject {
        val boundary = "----rr" + System.currentTimeMillis()
        val conn = URL(c.base.trimEnd('/') + "/audio/transcriptions").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.connectTimeout = 30_000
        conn.readTimeout = 600_000
        conn.setRequestProperty("Authorization", "Bearer " + c.key)
        conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        conn.setChunkedStreamingMode(64 * 1024)
        DataOutputStream(conn.outputStream).use { out ->
            fun field(name: String, value: String) {
                out.writeBytes("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n")
                out.write(value.toByteArray(Charsets.UTF_8)); out.writeBytes("\r\n")
            }
            field("model", c.stt)
            if (c.lang.isNotBlank()) field("language", c.lang)
            field("response_format", if (level >= 1) "verbose_json" else "json")
            if (level >= 2) {
                field("timestamp_granularities[]", "segment")
                field("timestamp_granularities[]", "word")
            }
            out.writeBytes("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"audio.wav\"\r\nContent-Type: audio/wav\r\n\r\n")
            wav.inputStream().use { it.copyTo(out, 64 * 1024) }
            out.writeBytes("\r\n--$boundary--\r\n")
        }
        return readJson(conn)
    }

    private fun readJson(conn: HttpURLConnection): JSONObject {
        val code = conn.responseCode
        val body = (if (code in 200..299) conn.inputStream else conn.errorStream)?.use { s ->
            val bo = ByteArrayOutputStream(); s.copyTo(bo); bo.toString("UTF-8")
        } ?: ""
        conn.disconnect()
        if (code !in 200..299) {
            val msg = try { JSONObject(body).optJSONObject("error")?.optString("message") } catch (_: Throwable) { null }
            throw IllegalStateException("الخدمة رفضت الطلب ($code): ${msg ?: body.take(200)}")
        }
        return JSONObject(body)
    }

    private fun chat(c: AiCfg, system: String, user: String): JSONObject {
        val conn = URL(c.base.trimEnd('/') + "/chat/completions").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.connectTimeout = 30_000
        conn.readTimeout = 300_000
        conn.setRequestProperty("Authorization", "Bearer " + c.key)
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        val req = JSONObject().put("model", c.chat).put("temperature", 0.2)
            .put("response_format", JSONObject().put("type", "json_object"))
            .put("messages", JSONArray().put(JSONObject().put("role", "system").put("content", system)).put(JSONObject().put("role", "user").put("content", user)))
        conn.outputStream.use { it.write(req.toString().toByteArray(Charsets.UTF_8)) }
        val o = readJson(conn)
        val content = o.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content")
        val i = content.indexOf('{'); val j = content.lastIndexOf('}')
        if (i < 0 || j <= i) throw IllegalStateException("رد غير مفهوم من الخدمة")
        return JSONObject(content.substring(i, j + 1))
    }

    // ───── التحليل الدلالي ─────

    /**
     * يرسل النص بتوقيته (بدون صوت) لنموذج لغوي يصنّف أجزاء الحوار ويحدد الجمل المحورية ويقترح أفكار ريلز مكتملة.
     * النتائج تُتحقّق: الأوقات داخل الحلقة، والاقتراحات تُثبَّت على حدود الجمل.
     */
    fun semantic(ctx: Context, sid: String, tr: Transcript, names: List<String>, duration: Double, target: Double, progress: (String, Float) -> Unit, cancelled: () -> Boolean): Semantic {
        val c = cfg(ctx)
        require(c.ok) { "أدخل عنوان الخدمة والمفتاح أولًا" }
        val lines = tr.segs.map { g ->
            val who = names.getOrNull(g.speaker) ?: "?"
            "[${g.i}] (${String.format(java.util.Locale.US, "%.1f-%.1f", g.a, g.b)}) $who: ${g.text}"
        }
        val chunks = ArrayList<List<String>>()
        var cur = ArrayList<String>(); var len = 0
        for (l in lines) {
            if (len + l.length > 14000 && cur.isNotEmpty()) { chunks.add(cur); cur = ArrayList(); len = 0 }
            cur.add(l); len += l.length
        }
        if (cur.isNotEmpty()) chunks.add(cur)
        val system = """
            You analyse an Arabic (possibly Palestinian dialect) podcast transcript to help a video editor. Lines are "[segment_index] (start-end seconds) speaker: text".
            Return ONLY JSON with keys:
            "regions": [{"start":s,"end":e,"type":"qa|story|explain|debate|emotional|normal","confidence":0..1}] covering the conversation (types: question & answer, storytelling, explanation/information, fast debate, emotional/funny moment, normal).
            "key_sentences": [{"start":s,"end":e}] — pivotal sentences, conclusions, confessions or strong points (few, only real ones).
            "reel_ideas": [{"start":s,"end":e,"title":"short Arabic title","reason":"Arabic reason","type":"qa|story|explain|opinion"}] — self-contained ideas that make sense alone, start with an engaging understandable sentence and end after the idea is complete; target length about $target seconds but never cut an idea; do not reorder speech.
            "emphasis": [{"seg":i,"word":k}] — at most one important word per few sentences (k = 0-based word index in that segment text).
            Use only times that exist in the lines. If unsure, use lower confidence; do not invent laughter or emotions not evident in text.
        """.trimIndent()
        val regs = ArrayList<PodEngine.Region>()
        val keys = ArrayList<DoubleArray>()
        val ideas = ArrayList<PodEngine.Suggest>()
        val emph = HashSet<String>()
        for ((k, ch) in chunks.withIndex()) {
            if (cancelled()) throw InterruptedException("Cancelled")
            progress("فهم الحوار ${k + 1}/${chunks.size}", k.toFloat() / chunks.size)
            val o = chat(c, system, ch.joinToString("\n"))
            o.optJSONArray("regions")?.let { a ->
                for (i in 0 until a.length()) {
                    val r = a.getJSONObject(i)
                    val s0 = r.optDouble("start").coerceIn(0.0, duration); val s1 = r.optDouble("end").coerceIn(0.0, duration)
                    if (s1 - s0 > 2) regs.add(PodEngine.Region(s0, s1, r.optString("type", "normal"), r.optDouble("confidence", 0.6).coerceIn(0.0, 1.0), "ai"))
                }
            }
            o.optJSONArray("key_sentences")?.let { a ->
                for (i in 0 until a.length()) {
                    val r = a.getJSONObject(i)
                    val s0 = r.optDouble("start"); val s1 = r.optDouble("end")
                    if (s1 > s0 && s0 >= 0 && s1 <= duration + 1 && s1 - s0 < 30) keys.add(doubleArrayOf(s0, min(duration, s1)))
                }
            }
            o.optJSONArray("reel_ideas")?.let { a ->
                for (i in 0 until a.length()) {
                    val r = a.getJSONObject(i)
                    var s0 = r.optDouble("start"); var s1 = r.optDouble("end")
                    // تثبيت على حدود الجمل حتى لا يبدأ أو ينتهي في منتصف كلمة
                    tr.segs.filter { it.a <= s0 + 0.5 && it.b > s0 }.minByOrNull { abs(it.a - s0) }?.let { s0 = it.a }
                    tr.segs.filter { it.b >= s1 - 0.5 && it.a < s1 }.minByOrNull { abs(it.b - s1) }?.let { s1 = it.b }
                    s0 = max(0.0, s0 - 0.15); s1 = min(duration, s1 + 0.3)
                    if (s1 - s0 in 8.0..240.0) ideas.add(PodEngine.Suggest(s0, s1, 1.0 - i * 0.05, r.optString("title"), r.optString("reason"), r.optString("type", "idea")))
                }
            }
            o.optJSONArray("emphasis")?.let { a ->
                for (i in 0 until a.length()) { val r = a.getJSONObject(i); emph.add("${r.optInt("seg")}:${r.optInt("word")}") }
            }
        }
        val sem = Semantic(regs.sortedBy { it.a }, keys.sortedBy { it[0] }, ideas, emph)
        try { semanticFile(ctx, sid).writeText(sem.toJson().toString()) } catch (_: Throwable) {}
        progress("تم", 1f)
        return sem
    }

    // ───── الترجمة ─────

    fun translate(ctx: Context, texts: List<String>, toLang: String, progress: (Float) -> Unit, cancelled: () -> Boolean): List<String> {
        val c = cfg(ctx)
        require(c.ok) { "أدخل عنوان الخدمة والمفتاح أولًا" }
        val out = ArrayList<String>()
        var i = 0
        while (i < texts.size) {
            if (cancelled()) throw InterruptedException("Cancelled")
            val part = texts.subList(i, min(texts.size, i + 40))
            val o = chat(
                c,
                "Translate each subtitle line to $toLang. Keep meaning and tone, short and natural. Return JSON {\"lines\":[...]} with exactly the same number of lines in the same order.",
                JSONObject().put("lines", JSONArray(part)).toString(),
            )
            val a = o.optJSONArray("lines")
            for (k in part.indices) out.add(a?.optString(k) ?: part[k])
            i += part.size
            progress(i.toFloat() / texts.size)
        }
        return out
    }

    // ───── حفظ ملفات نصية في التنزيلات ─────

    fun saveToDownloads(ctx: Context, name: String, text: String): String? = try {
        val v = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "application/x-subrip")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ReactionRecorder")
        }
        val u = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
        if (u == null) null else {
            ctx.contentResolver.openOutputStream(u)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
            "Download/ReactionRecorder/$name"
        }
    } catch (_: Throwable) { null }
}
