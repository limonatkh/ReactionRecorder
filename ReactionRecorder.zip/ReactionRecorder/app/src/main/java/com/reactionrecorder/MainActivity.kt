package com.reactionrecorder

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private lateinit var cfg: RecordConfig
    private lateinit var editor: LayoutEditorView
    private lateinit var infoText: TextView
    private lateinit var statusText: TextView
    private lateinit var noteText: TextView
    private lateinit var recBtn: TextView
    private lateinit var flipChip: TextView
    private lateinit var pauseChip: TextView
    private lateinit var presetRow: LinearLayout
    private lateinit var quickRow: LinearLayout
    private lateinit var ratioRow: LinearLayout
    private lateinit var ratioLabel: TextView
    private lateinit var ratioSeek: SeekBar
    private val presetChips = ArrayList<TextView>()
    private lateinit var orientChip: TextView
    private lateinit var resChip: TextView
    private lateinit var fpsChip: TextView
    private lateinit var micChip: TextView
    private lateinit var srcChip: TextView
    private lateinit var shapeChip: TextView
    private lateinit var fitChip: TextView
    private lateinit var modeScreenChip: TextView
    private lateinit var modeVideoChip: TextView
    private lateinit var pickChip: TextView
    private lateinit var linkChip: TextView
    private lateinit var modeRow: LinearLayout
    private var videoThumb: android.graphics.Bitmap? = null
    private var videoAspect = 16f / 9f

    private val ui = Handler(Looper.getMainLooper())
    private var camera: Camera? = null
    private var wasBusy = false
    private val stateListener: () -> Unit = { onStateChanged() }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
        if (hasCamera()) bindPreview()
    }
    private val pickVideoLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onVideoPicked(uri)
    }
    private val projLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            val i = Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_START)
                .putExtra(RecorderService.EXTRA_CODE, r.resultCode).putExtra(RecorderService.EXTRA_DATA, data)
            ContextCompat.startForegroundService(this, i)
        } else {
            toast("Screen capture permission is required to record the video source")
            bindPreview()
        }
    }

    // ───────────────────────── lifecycle ─────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = ConfigStore.load(this)
        buildUi()
        if (cfg.mode == SourceMode.VIDEO) loadVideoInfoAsync()
        requestPermissionsIfNeeded()
        RecorderState.addListener(stateListener)
        render()
    }

    override fun onResume() {
        super.onResume()
        render()
        if (!RecorderState.isBusy) bindPreview()
        handleResult()
        ui.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(ticker)
        ConfigStore.save(this, cfg)
    }

    override fun onDestroy() {
        super.onDestroy()
        RecorderState.removeListener(stateListener)
    }

    private val ticker = object : Runnable {
        override fun run() {
            updateStatus()
            ui.postDelayed(this, 500)
        }
    }

    // ───────────────────────── permissions ─────────────────────────

    private fun hasCamera() = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    private fun hasMic() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun requestPermissionsIfNeeded() {
        val need = ArrayList<String>()
        if (!hasCamera()) need += Manifest.permission.CAMERA
        if (!hasMic()) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) permLauncher.launch(need.toTypedArray())
    }

    // ───────────────────────── camera preview (قبل التسجيل فقط) ─────────────────────────

    private fun bindPreview() {
        if (!hasCamera() || RecorderState.isBusy) return
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            try {
                if (RecorderState.isBusy) return@addListener
                val p = f.get()
                p.unbindAll()
                val pv = Preview.Builder().build()
                pv.setSurfaceProvider(editor.previewView.surfaceProvider)
                val sel = if (cfg.frontCamera) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                val cam = p.bindToLifecycle(this, sel, pv)
                camera = cam
                editor.previewView.scaleX = if (cfg.frontCamera && !cfg.mirrorFront) -1f else 1f
                applyCameraControls()
            } catch (t: Throwable) {
                statusText.text = "Camera error: ${t.message}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun unbindPreview() {
        try { ProcessCameraProvider.getInstance(this).get().unbindAll() } catch (_: Throwable) {}
        camera = null
    }

    private fun applyCameraControls() {
        val c = camera ?: return
        try {
            val zs = c.cameraInfo.zoomState.value
            if (zs != null) c.cameraControl.setZoomRatio(cfg.zoom.coerceIn(zs.minZoomRatio, zs.maxZoomRatio))
            c.cameraControl.setExposureCompensationIndex(cfg.exposureIndex)
            c.cameraControl.enableTorch(cfg.torch && c.cameraInfo.hasFlashUnit())
        } catch (_: Throwable) {}
    }

    // ───────────────────────── UI building ─────────────────────────

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun chip(text: String, onClick: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER
        setPadding(dp(12), dp(8), dp(12), dp(8))
        minWidth = dp(48)
        setOnClickListener { onClick() }
        setChipSelected(this, false)
    }

    private fun setChipSelected(v: TextView, sel: Boolean) {
        v.background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            setColor(if (sel) Color.parseColor("#FF3B30") else Color.parseColor("#2A2D36"))
        }
    }

    private fun lp(w: Int, h: Int, l: Int = 0, r: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply { setMargins(dp(l), 0, dp(r), 0) }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#101114"))
            setPadding(dp(10), dp(8), dp(10), dp(10))
        }
        setContentView(root)
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            v.setPadding(dp(10), b.top + dp(8), dp(10), b.bottom + dp(10)); insets
        }

        // الصف العلوي: التخزين + الإعدادات
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        infoText = TextView(this).apply { setTextColor(Color.parseColor("#AAB0BD")); textSize = 12f }
        top.addView(infoText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(chip("⚙ Settings") { showSettings() })
        root.addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // اختيار المصدر: تصوير الشاشة أو ملف/رابط فيديو
        modeRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        modeScreenChip = chip("📱 Screen") { setMode(SourceMode.SCREEN) }
        modeVideoChip = chip("🎞 Video file") { setMode(SourceMode.VIDEO) }
        pickChip = chip("📂 Choose") { pickVideoLauncher.launch(arrayOf("video/*")) }
        linkChip = chip("🔗 Link") { showLinkDialog() }
        for (c in listOf(modeScreenChip, modeVideoChip, pickChip, linkChip)) modeRow.addView(c, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 6))
        val modeScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(modeRow) }
        root.addView(modeScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6); bottomMargin = dp(6) })

        // المحرر/المعاينة
        editor = LayoutEditorView(this).apply {
            this.cfg = this@MainActivity.cfg
            onChanged = { ConfigStore.save(this@MainActivity, this@MainActivity.cfg); renderPresets() }
        }
        root.addView(editor, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // Presets
        presetRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        for (i in 0 until 5) {
            val c = chip(Presets.names[i]) { applyPreset(i + 1) }
            presetChips += c
            presetRow.addView(c, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 6))
        }
        val presetScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(presetRow) }
        root.addView(presetScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })

        // نسبة الفيديو/الكاميرا (للـ Presets المقسومة)
        ratioRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        ratioLabel = TextView(this).apply { setTextColor(Color.parseColor("#AAB0BD")); textSize = 12f }
        ratioSeek = SeekBar(this).apply {
            max = 50 // 30%..80%
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    val id = cfg.layout.presetId
                    if (id !in 2..4) return
                    Presets.build(id, cfg.portrait, (30 + p) / 100f, cfg.layout)
                    ratioLabel.text = "Video ${30 + p}%"
                    editor.refresh()
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) { ConfigStore.save(this@MainActivity, cfg) }
            })
        }
        ratioRow.addView(ratioLabel, LinearLayout.LayoutParams(dp(80), ViewGroup.LayoutParams.WRAP_CONTENT))
        ratioRow.addView(ratioSeek, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(ratioRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // أزرار سريعة: الاتجاه، الدقة، FPS، الصوت، الشكل
        quickRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        orientChip = chip("9:16") {
            cfg.portrait = !cfg.portrait
            val id = if (cfg.layout.presetId in 1..5) cfg.layout.presetId else 1
            cfg.layout = Presets.build(id, cfg.portrait, cfg.layout.ratio, cfg.layout)
            changed(true)
        }
        resChip = chip("1080p") { cfg.shortSide = if (cfg.shortSide == 1080) 720 else 1080; changed(false) }
        fpsChip = chip("30 fps") { cfg.fps = when (cfg.fps) { 30 -> 24; 24 -> 60; else -> 30 }; changed(false) }
        micChip = chip("Mic ON") { cfg.micOn = !cfg.micOn; changed(false) }
        srcChip = chip("Source audio ON") { cfg.srcAudioOn = !cfg.srcAudioOn; changed(false) }
        shapeChip = chip("Rounded") {
            cfg.layout.shape = CamShape.values()[(cfg.layout.shape.ordinal + 1) % 3]
            if (cfg.layout.presetId in 1..5) Presets.build(cfg.layout.presetId, cfg.portrait, cfg.layout.ratio, cfg.layout)
            changed(true)
        }
        fitChip = chip("Fit") {
            cfg.sourceFit = SourceFit.values()[(cfg.sourceFit.ordinal + 1) % 3]
            changed(true)
        }
        for (c in listOf(fitChip, orientChip, resChip, fpsChip, micChip, srcChip, shapeChip)) quickRow.addView(c, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 6))
        val quickScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(quickRow) }
        root.addView(quickScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })

        statusText = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER; typeface = Typeface.MONOSPACE }
        root.addView(statusText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        noteText = TextView(this).apply { setTextColor(Color.parseColor("#8A90A0")); textSize = 11f; gravity = Gravity.CENTER }
        root.addView(noteText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // شريط التحكم: تبديل الكاميرا | Record | Pause/Mute
        val ctl = LinearLayout(this).apply { gravity = Gravity.CENTER }
        flipChip = chip("⟲ Flip") { flipCamera() }
        recBtn = TextView(this).apply {
            text = "REC"; setTextColor(Color.WHITE); textSize = 16f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setOnClickListener { onRecordClicked() }
        }
        pauseChip = chip("⏸ Pause") { onPauseClicked() }
        ctl.addView(flipChip, lp(dp(96), ViewGroup.LayoutParams.WRAP_CONTENT, 0, 14))
        ctl.addView(recBtn, LinearLayout.LayoutParams(dp(84), dp(84)))
        ctl.addView(pauseChip, lp(dp(96), ViewGroup.LayoutParams.WRAP_CONTENT, 14, 0))
        root.addView(ctl, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
    }

    // ───────────────────────── render ─────────────────────────

    private fun changed(layoutChanged: Boolean) {
        ConfigStore.save(this, cfg)
        render()
        if (layoutChanged) editor.refresh()
    }

    private fun applyPreset(id: Int) {
        Presets.build(id, cfg.portrait, cfg.layout.ratio, cfg.layout)
        changed(true)
    }

    private fun renderPresets() {
        val id = cfg.layout.presetId
        for ((i, c) in presetChips.withIndex()) setChipSelected(c, id == i + 1)
        ratioRow.visibility = if (id in 2..4 && !RecorderState.isBusy) View.VISIBLE else View.GONE
        if (id in 2..4) {
            val pct = (cfg.layout.ratio * 100).toInt().coerceIn(30, 80)
            ratioSeek.progress = pct - 30
            ratioLabel.text = "Video $pct%"
        }
    }

    private fun render() {
        if (!::editor.isInitialized) return
        editor.cfg = cfg
        val dm = resources.displayMetrics
        val sh = min(dm.widthPixels, dm.heightPixels).toFloat(); val lo = max(dm.widthPixels, dm.heightPixels).toFloat()
        val videoMode = cfg.mode == SourceMode.VIDEO
        editor.screenAspect = if (videoMode) videoAspect else if (cfg.portrait) sh / lo else lo / sh
        val busy = RecorderState.isBusy
        editor.locked = busy
        editor.monitor = busy && videoMode
        editor.sourceThumb = if (videoMode) videoThumb else null
        editor.sourceLabel = if (!videoMode) "VIDEO / SCREEN" else if (cfg.videoName.isEmpty()) "Choose a video" else "🎞 " + cfg.videoName
        editor.invalidate()

        setChipSelected(modeScreenChip, !videoMode); setChipSelected(modeVideoChip, videoMode)
        pickChip.visibility = if (videoMode) View.VISIBLE else View.GONE
        linkChip.visibility = if (videoMode) View.VISIBLE else View.GONE
        (modeRow.parent as View).visibility = if (busy) View.GONE else View.VISIBLE
        fitChip.text = when (cfg.sourceFit) { SourceFit.FIT -> "Source: Fit"; SourceFit.FILL -> "Source: Fill"; SourceFit.STRETCH -> "Source: Stretch" }
        srcChip.text = if (videoMode) (if (cfg.srcAudioOn) "Video audio ON" else "Video audio OFF") else (if (cfg.srcAudioOn) "Source audio ON" else "Source audio OFF")

        orientChip.text = if (cfg.portrait) "9:16" else "16:9"
        resChip.text = if (cfg.shortSide == 1080) "1080p" else "720p"
        fpsChip.text = if (cfg.fps == 60) "60 fps ⚠" else "${cfg.fps} fps"
        micChip.text = if (cfg.micOn) "Mic ON" else "Mic OFF"
        shapeChip.text = when (cfg.layout.shape) { CamShape.RECT -> "Rectangle"; CamShape.ROUNDED -> "Rounded"; CamShape.CIRCLE -> "Circle" }
        setChipSelected(micChip, cfg.micOn); setChipSelected(srcChip, cfg.srcAudioOn)
        renderPresets()

        presetRow.parent.let { (it as View).visibility = if (busy) View.GONE else View.VISIBLE }
        quickRow.parent.let { (it as View).visibility = if (busy) View.GONE else View.VISIBLE }

        val phase = RecorderState.phase
        when (phase) {
            RecorderState.Phase.IDLE -> {
                recBtn.text = "REC"; styleRec(false); pauseChip.visibility = View.INVISIBLE
                flipChip.text = "⟲ Flip"; flipChip.visibility = View.VISIBLE
            }
            RecorderState.Phase.STARTING, RecorderState.Phase.COUNTDOWN -> {
                recBtn.text = "CANCEL"; styleRec(true); pauseChip.visibility = View.INVISIBLE; flipChip.visibility = View.INVISIBLE
            }
            RecorderState.Phase.RECORDING, RecorderState.Phase.PAUSED -> {
                recBtn.text = "■ STOP"; styleRec(true)
                pauseChip.visibility = View.VISIBLE; pauseChip.text = if (phase == RecorderState.Phase.PAUSED) "▶ Resume" else "⏸ Pause"
                flipChip.visibility = View.VISIBLE; flipChip.text = "⟲ Flip"
            }
            RecorderState.Phase.FINISHING -> {
                recBtn.text = "…"; styleRec(true); pauseChip.visibility = View.INVISIBLE; flipChip.visibility = View.INVISIBLE
            }
        }
        editor.overlayText = if (phase == RecorderState.Phase.COUNTDOWN && RecorderState.countdownLeft > 0) RecorderState.countdownLeft.toString() else ""
        updateStatus()
    }

    private fun styleRec(active: Boolean) {
        recBtn.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (active) Color.parseColor("#7A1F1A") else Color.parseColor("#FF3B30"))
            setStroke(dp(4), Color.WHITE)
        }
    }

    private fun updateStatus() {
        if (!::statusText.isInitialized) return
        val phase = RecorderState.phase
        when (phase) {
            RecorderState.Phase.IDLE -> {
                val rv = try { CodecSupport.resolve(cfg) } catch (_: Throwable) { null }
                val br = rv?.bitrate ?: cfg.effectiveBitrate()
                val est = StorageUtil.estimateSeconds(br, cfg.micOn || cfg.srcAudioOn)
                infoText.text = "Free ${StorageUtil.formatBytes(StorageUtil.freeBytes())} • ≈ ${StorageUtil.formatDuration(est)} at " +
                    "${rv?.w ?: cfg.outW}x${rv?.h ?: cfg.outH} ${rv?.fps ?: cfg.fps}fps"
                statusText.text = "Ready"
                noteText.text = if (cfg.mode == SourceMode.VIDEO)
                    "The video plays inside this app and is recorded with your camera — no screen capture. Use headphones."
                else "When Android asks, choose “Entire screen”, then open YouTube. Use headphones to avoid echo."
            }
            RecorderState.Phase.STARTING -> { statusText.text = "Preparing…"; noteText.text = "" }
            RecorderState.Phase.COUNTDOWN -> { statusText.text = "Starting in ${RecorderState.countdownLeft}…"; noteText.text = "You can switch to your video app now." }
            RecorderState.Phase.RECORDING, RecorderState.Phase.PAUSED -> {
                val s = RecorderState.elapsedMs() / 1000
                val t = String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
                statusText.text = (if (phase == RecorderState.Phase.PAUSED) "⏸ " else "● ") + t + if (RecorderState.micMuted) "  🎤✕" else ""
                infoText.text = RecorderState.resolvedInfo
                noteText.text = RecorderState.notes.joinToString("\n")
            }
            RecorderState.Phase.FINISHING -> { statusText.text = "Finishing video…"; noteText.text = "Please wait — do not close the app" }
        }
    }

    // ───────────────────────── actions ─────────────────────────

    private fun serviceCmd(action: String) {
        startService(Intent(this, RecorderService::class.java).setAction(action))
    }

    private fun flipCamera() {
        if (RecorderState.isBusy) { serviceCmd(RecorderService.ACTION_SWITCH_CAMERA); return }
        cfg.frontCamera = !cfg.frontCamera
        ConfigStore.save(this, cfg)
        bindPreview()
    }

    private fun onPauseClicked() {
        serviceCmd(if (RecorderState.phase == RecorderState.Phase.PAUSED) RecorderService.ACTION_RESUME else RecorderService.ACTION_PAUSE)
    }

    private fun onRecordClicked() {
        if (RecorderState.isBusy) {
            if (RecorderState.phase != RecorderState.Phase.FINISHING) serviceCmd(RecorderService.ACTION_STOP)
            return
        }
        if (!hasCamera() || (cfg.micOn && !hasMic())) {
            toast("Camera and microphone permissions are required")
            requestPermissionsIfNeeded(); return
        }
        if (cfg.mode == SourceMode.VIDEO && cfg.videoUri.isEmpty()) {
            toast("Choose a video file or paste a link first")
            return
        }
        ConfigStore.save(this, cfg)
        val rv = CodecSupport.resolve(cfg)
        val est = StorageUtil.estimateSeconds(rv.bitrate, cfg.micOn || cfg.srcAudioOn)
        val free = StorageUtil.freeBytes()
        if (free < 300L * 1024 * 1024) {
            AlertDialog.Builder(this).setTitle("Not enough storage")
                .setMessage("Only ${StorageUtil.formatBytes(free)} free. Free some space before recording.")
                .setPositiveButton("OK", null).show()
            return
        }
        if (est < 10 * 60) {
            AlertDialog.Builder(this).setTitle("Low storage")
                .setMessage("Free space allows only about ${StorageUtil.formatDuration(est)} of recording at this quality. Continue?")
                .setPositiveButton("Record") { _, _ -> launchCapture() }
                .setNegativeButton("Cancel", null).show()
            return
        }
        launchCapture()
    }

    private fun launchCapture() {
        unbindPreview() // الخدمة ستفتح الكاميرا
        if (cfg.mode == SourceMode.VIDEO) { // لا حاجة لإذن تصوير الشاشة
            ContextCompat.startForegroundService(this, Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_START))
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projLauncher.launch(mpm.createScreenCaptureIntent())
    }

    // ───────────────────────── مصدر الفيديو ─────────────────────────

    private fun setMode(m: SourceMode) {
        cfg.mode = m
        ConfigStore.save(this, cfg)
        if (m == SourceMode.VIDEO) {
            if (cfg.videoUri.isEmpty()) pickVideoLauncher.launch(arrayOf("video/*")) else loadVideoInfoAsync()
        }
        render(); editor.refresh()
    }

    private fun onVideoPicked(uri: Uri) {
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Throwable) {}
        cfg.mode = SourceMode.VIDEO
        cfg.videoUri = uri.toString()
        cfg.videoName = queryName(uri) ?: "video"
        ConfigStore.save(this, cfg)
        loadVideoInfoAsync()
        render(); editor.refresh()
    }

    private fun queryName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    } catch (_: Throwable) { null }

    /** يقرأ أبعاد الفيديو ولقطة مصغّرة في خيط خلفي ليعرضها المحرر كمعاينة */
    private fun loadVideoInfoAsync() {
        val u = cfg.videoUri
        if (u.isEmpty()) { videoThumb = null; videoAspect = 16f / 9f; return }
        Thread {
            val info = VideoProbe.probe(applicationContext, u, true)
            runOnUiThread {
                if (cfg.videoUri == u) {
                    videoThumb = info?.thumb
                    if (info != null) videoAspect = info.width.toFloat() / info.height
                    render(); editor.refresh()
                }
            }
        }.start()
    }

    private fun showLinkDialog() {
        val input = android.widget.EditText(this).apply {
            hint = "https://example.com/video.mp4"
            setText(if (cfg.videoUri.startsWith("http")) cfg.videoUri else "")
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine(true)
        }
        val box = LinearLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)) }
        AlertDialog.Builder(this)
            .setTitle("Direct video link")
            .setMessage("Paste a direct https link to a video file (for example …/clip.mp4). Only use videos you have the right to use.")
            .setView(box)
            .setPositiveButton("Use") { _, _ ->
                val t = input.text.toString().trim()
                val host = try { Uri.parse(t).host?.lowercase() ?: "" } catch (_: Throwable) { "" }
                when {
                    !t.startsWith("https://") -> toast("The link must start with https://")
                    host.contains("youtube.com") || host.contains("youtu.be") || host.contains("youtube-nocookie.com") ->
                        AlertDialog.Builder(this).setTitle("YouTube links can't be played here")
                            .setMessage("YouTube doesn't give other apps access to its video stream. To react to a YouTube video use Screen mode: open YouTube, and the app records the screen with your camera.")
                            .setPositiveButton("OK", null).show()
                    else -> {
                        cfg.mode = SourceMode.VIDEO
                        cfg.videoUri = t
                        cfg.videoName = Uri.parse(t).lastPathSegment ?: "link"
                        ConfigStore.save(this, cfg)
                        loadVideoInfoAsync()
                        render(); editor.refresh()
                    }
                }
            }
            .setNegativeButton("Cancel", null).show()
    }

    // ───────────────────────── state / result ─────────────────────────

    private fun onStateChanged() {
        val busy = RecorderState.isBusy
        render()
        if (wasBusy && !busy) { bindPreview(); handleResult() }
        wasBusy = busy
    }

    private fun handleResult() {
        val uri = RecorderState.lastUri
        val err = RecorderState.lastError
        if (RecorderState.isBusy) return
        if (uri != null) {
            RecorderState.lastUri = null
            RecorderState.lastError = null
            showReady(uri, err)
        } else if (err != null) {
            RecorderState.lastError = null
            AlertDialog.Builder(this).setTitle("Recording problem").setMessage(err).setPositiveButton("OK", null).show()
        }
    }

    private fun showReady(uri: Uri, warning: String?) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(4)) }
        box.addView(TextView(this).apply {
            text = "Saved to Movies/ReactionRecorder — it is already in your Gallery." + if (warning != null) "\n\n$warning" else ""
            setTextColor(Color.parseColor("#E6E8EE")); textSize = 14f
        })
        val d = AlertDialog.Builder(this).setTitle("Video Ready ✓").setView(box).setCancelable(true).create()
        fun btn(label: String, run: () -> Unit) = Button(this).apply {
            text = label; isAllCaps = false
            setOnClickListener { run(); }
        }
        box.addView(btn("▶  Play") {
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        })
        box.addView(btn("↗  Share") {
            val s = Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(s, "Share video"))
        })
        box.addView(btn("✓  Save") { toast("Saved in Movies/ReactionRecorder"); d.dismiss() })
        box.addView(btn("🗑  Delete") {
            AlertDialog.Builder(this).setTitle("Delete this video?")
                .setPositiveButton("Delete") { _, _ -> StorageUtil.delete(this, uri); toast("Deleted"); d.dismiss() }
                .setNegativeButton("Cancel", null).show()
        })
        d.show()
    }

    // ───────────────────────── settings dialog ─────────────────────────

    private fun showSettings() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(10), dp(18), dp(10)) }
        fun label(t: String) = TextView(this).apply { text = t; setTextColor(Color.parseColor("#E6E8EE")); textSize = 13f; setPadding(0, dp(12), 0, dp(2)) }
        fun spinnerRow(title: String, items: List<String>, sel: Int, onSel: (Int) -> Unit) {
            col.addView(label(title))
            val sp = android.widget.Spinner(this)
            sp.adapter = android.widget.ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
            sp.setSelection(sel)
            sp.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                var first = true
                override fun onItemSelected(p: android.widget.AdapterView<*>?, v: View?, pos: Int, id: Long) { if (first) { first = false; return }; onSel(pos) }
                override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
            }
            col.addView(sp)
        }
        fun switchRow(title: String, on: Boolean, onChange: (Boolean) -> Unit) {
            col.addView(Switch(this).apply { text = title; isChecked = on; setOnCheckedChangeListener { _, v -> onChange(v) } },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        }
        fun seekRow(title: String, maxV: Int, cur: Int, fmt: (Int) -> String, onChange: (Int) -> Unit) {
            val tv = label("$title: ${fmt(cur)}")
            col.addView(tv)
            col.addView(SeekBar(this).apply {
                max = maxV; progress = cur
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { tv.text = "$title: ${fmt(p)}"; if (u) onChange(p) }
                    override fun onStartTrackingTouch(s: SeekBar) {}
                    override fun onStopTrackingTouch(s: SeekBar) {}
                })
            })
        }

        val brs = listOf(0f, 4f, 6f, 8f, 10f, 12f)
        spinnerRow("Bitrate", brs.map { if (it == 0f) "Auto (recommended)" else "${it.toInt()} Mbps" }, brs.indexOf(cfg.bitrateMbps).coerceAtLeast(0)) { cfg.bitrateMbps = brs[it] }
        val hevcOk = CodecSupport.hevcSupported()
        spinnerRow("Codec", listOf("H.264 (recommended)", if (hevcOk) "H.265 / HEVC" else "H.265 (not supported)"), if (cfg.hevc && hevcOk) 1 else 0) { cfg.hevc = (it == 1) && hevcOk }
        val cds = listOf(0, 3, 5, 10)
        spinnerRow("Countdown", cds.map { if (it == 0) "Off" else "$it sec" }, cds.indexOf(cfg.countdown).coerceAtLeast(0)) { cfg.countdown = cds[it] }

        seekRow("Microphone volume", 200, (cfg.micVol * 100).toInt(), { "$it%" }) { cfg.micVol = it / 100f }
        seekRow("Source volume", 200, (cfg.srcVol * 100).toInt(), { "$it%" }) { cfg.srcVol = it / 100f }
        switchRow("Echo suppression (VOICE mode; headphones are still best)", cfg.echoSuppress) { cfg.echoSuppress = it }

        val camRes = listOf(640, 1280, 1920)
        spinnerRow("Camera resolution", listOf("360p (lightest)", "720p (recommended)", "1080p"), camRes.indexOf(cfg.cameraLong).coerceAtLeast(1)) { cfg.cameraLong = camRes[it]; ConfigStore.save(this, cfg); if (!RecorderState.isBusy) bindPreview() }
        switchRow("Mirror front camera", cfg.mirrorFront) { cfg.mirrorFront = it; ConfigStore.save(this, cfg); editor.previewView.scaleX = if (cfg.frontCamera && !cfg.mirrorFront) -1f else 1f }
        seekRow("Zoom", 30, ((cfg.zoom - 1f) * 10).toInt(), { String.format(Locale.US, "%.1fx", 1f + it / 10f) }) { cfg.zoom = 1f + it / 10f; applyCameraControls() }
        seekRow("Exposure", 8, cfg.exposureIndex + 4, { "${it - 4}" }) { cfg.exposureIndex = it - 4; applyCameraControls() }
        switchRow("Flash / torch (back camera)", cfg.torch) { cfg.torch = it; applyCameraControls() }

        switchRow("Video file mode: stop recording when the video ends", cfg.autoStop) { cfg.autoStop = it }
        seekRow("Video audio delay (fix sync)", 500, cfg.videoAudioDelayMs, { "$it ms" }) { cfg.videoAudioDelayMs = it }
        val rots = listOf(0, 90, 180, 270)
        spinnerRow("Camera rotation fix (if the camera looks sideways)", listOf("0° (auto)", "90°", "180°", "270°"), rots.indexOf(cfg.camRotAdjust).coerceAtLeast(0)) { cfg.camRotAdjust = rots[it] }
        seekRow("Camera border", 30, (cfg.layout.borderFrac * 1000).toInt(), { "${it / 10f}" }) { cfg.layout.borderFrac = it / 1000f; editor.refresh() }
        seekRow("Corner radius", 50, (cfg.layout.radiusFrac * 100).toInt(), { "$it%" }) { cfg.layout.radiusFrac = it / 100f; editor.refresh() }

        col.addView(TextView(this).apply {
            text = "Notes: 60 fps and 1080p may overheat or drop frames on Galaxy M13 — 1080p/30 is the stable default. " +
                "Source audio can only be captured from apps that allow it (Android rule); protected content stays silent. " +
                "If a screen-capture app blocks video, Android shows black — that is expected."
            setTextColor(Color.parseColor("#9AA0AA")); textSize = 11f; setPadding(0, dp(14), 0, 0)
        })

        val sv = ScrollView(this).apply { addView(col) }
        AlertDialog.Builder(this).setTitle("Settings").setView(sv)
            .setPositiveButton("Done") { _, _ -> ConfigStore.save(this, cfg); render() }
            .setOnDismissListener { ConfigStore.save(this, cfg); render() }
            .show()
    }
}
