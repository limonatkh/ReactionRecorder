package com.reactionrecorder

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.SurfaceTexture
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLUtils
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * يُخرج حلقة البودكاست من اللقطات: يفك فيديوهات الكاميرات المطلوبة فقط في كل لحظة،
 * يركّبها بـ OpenGL حسب نوع اللقطة، يرمّزها H.264، ثم يخلط صوت المايكات (مع تخفيض الساكت وتوحيد المستوى) ويدمج الكل.
 * لا يعمل بالزمن الحقيقي: كل إطار يُحسب بدقة، فلا يتأثر بسرعة الجهاز (فقط يأخذ وقتًا أطول).
 */
class PodcastRenderer(
    private val ctx: Context,
    private val s: SessionInfo,
    private val setup: PodSetup,
    private val shots: List<PodShot>,
    private val an: PodAnalysis?,
    private val progress: (String, Float) -> Unit,
    private val cancelled: () -> Boolean,
) {
    private val fps = 30
    private val outH = if (setup.height >= 1080) 1080 else 720
    private val outW = outH * 16 / 9
    private val dur = PodcastAnalyzer.duration(s)
    val warnings = ArrayList<String>()

    // ───────── EGL / GL ─────────
    private var dpy: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglCtx: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurf: EGLSurface = EGL14.EGL_NO_SURFACE

    private class Prog { var id = 0; var aPos = 0; var aTex = 0; var aLocal = 0; var uTexM = 0; var uTex = 0; var uSize = 0; var uRadius = 0; var uAlpha = 0; var uColor = 0 }
    private val pOes = Prog()
    private val p2d = Prog()
    private val pSolid = Prog()
    private val posBuf = fb(8)
    private val texBuf = fb(8)
    private val locBuf = fb(8).apply { put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)); position(0) }
    private val ident = floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)
    private val flip = floatArrayOf(1f, 0f, 0f, 0f, 0f, -1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 1f, 0f, 1f)
    private var bgTex = 0
    private var bgW = 1
    private var bgH = 1

    private val frameThread = HandlerThread("pod-frames").apply { start() }
    private val frameHandler = Handler(frameThread.looper)

    private fun fb(n: Int): FloatBuffer = ByteBuffer.allocateDirect(n * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()

    /** مصدر فيديو: ملف + تحويل زمن الجلسة إلى زمن الملف */
    private inner class VDec(val key: String, val file: File, val time: Finalizer.SatVideoTime) {
        var ex: MediaExtractor? = null
        var dec: MediaCodec? = null
        var st: SurfaceTexture? = null
        var surf: Surface? = null
        var tex = 0
        val mat = FloatArray(16)
        var w = 1
        var h = 1
        var durUs = 0L
        var curPts = Long.MIN_VALUE
        var hasFrame = false
        var inputDone = false
        var ended = false
        var failed = false
        private val lock = java.lang.Object()
        private var avail = false
        private val info = MediaCodec.BufferInfo()

        fun open(): Boolean {
            try {
                val e = MediaExtractor()
                e.setDataSource(file.absolutePath)
                var idx = -1
                for (i in 0 until e.trackCount) if (e.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true) { idx = i; break }
                if (idx < 0) { e.release(); failed = true; return false }
                e.selectTrack(idx)
                val f = e.getTrackFormat(idx)
                w = f.getInteger(MediaFormat.KEY_WIDTH)
                h = f.getInteger(MediaFormat.KEY_HEIGHT)
                durUs = if (f.containsKey(MediaFormat.KEY_DURATION)) f.getLong(MediaFormat.KEY_DURATION) else Long.MAX_VALUE
                val t = IntArray(1)
                GLES20.glGenTextures(1, t, 0)
                tex = t[0]
                GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
                GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
                GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
                GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
                GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
                val sTex = SurfaceTexture(tex)
                sTex.setOnFrameAvailableListener({ synchronized(lock) { avail = true; lock.notifyAll() } }, frameHandler)
                st = sTex
                val sf = Surface(sTex)
                surf = sf
                val d = MediaCodec.createDecoderByType(f.getString(MediaFormat.KEY_MIME)!!)
                d.configure(f, sf, null, 0)
                d.start()
                ex = e
                dec = d
                return true
            } catch (t: Throwable) {
                failed = true
                warnings += "Cannot open a video ($key): ${t.javaClass.simpleName}"
                close()
                return false
            }
        }

        private fun seek(us: Long) {
            val e = ex ?: return
            val d = dec ?: return
            e.seekTo(max(0L, us), MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            d.flush()
            inputDone = false
            ended = false
            curPts = Long.MIN_VALUE
        }

        /** يجعل النسيج يحمل الإطار المقابل للزمن المطلوب. يعيد false إن لم يتوفر فيديو في هذه اللحظة */
        fun frameAt(targetUs: Long): Boolean {
            if (failed) return false
            if (dec == null && !open()) return false
            val d = dec!!
            val e = ex!!
            if (targetUs < -100_000L || targetUs > durUs + 300_000L) return false
            val half = 1_000_000L / fps / 2
            if (hasFrame && targetUs <= curPts + half && targetUs >= curPts - 1_500_000L) return true
            if (curPts != Long.MIN_VALUE && (targetUs < curPts - half || targetUs > curPts + 3_000_000L)) seek(targetUs)
            else if (curPts == Long.MIN_VALUE && !hasFrame) seek(targetUs)
            var guard = 0
            while (guard++ < 2000) {
                if (!inputDone) {
                    val ii = d.dequeueInputBuffer(2000)
                    if (ii >= 0) {
                        val buf = d.getInputBuffer(ii)!!
                        val n = e.readSampleData(buf, 0)
                        if (n < 0) {
                            d.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            d.queueInputBuffer(ii, 0, n, e.sampleTime, 0)
                            e.advance()
                        }
                    }
                }
                val oi = d.dequeueOutputBuffer(info, 5000)
                if (oi >= 0) {
                    val eos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                    val render = info.size > 0 && (info.presentationTimeUs >= targetUs - half || eos)
                    d.releaseOutputBuffer(oi, render)
                    if (render) {
                        if (waitFrame()) {
                            st?.updateTexImage()
                            st?.getTransformMatrix(mat)
                            hasFrame = true
                        }
                        curPts = info.presentationTimeUs
                        return hasFrame
                    }
                    curPts = info.presentationTimeUs
                    if (eos) { ended = true; return hasFrame }
                } else if (inputDone && oi == MediaCodec.INFO_TRY_AGAIN_LATER && guard > 200) {
                    ended = true
                    return hasFrame
                }
            }
            return hasFrame
        }

        private fun waitFrame(): Boolean {
            synchronized(lock) {
                val until = System.currentTimeMillis() + 800
                while (!avail) {
                    val left = until - System.currentTimeMillis()
                    if (left <= 0) return false
                    lock.wait(left)
                }
                avail = false
                return true
            }
        }

        fun close() {
            try { dec?.stop() } catch (_: Throwable) {}
            try { dec?.release() } catch (_: Throwable) {}
            try { ex?.release() } catch (_: Throwable) {}
            try { surf?.release() } catch (_: Throwable) {}
            try { st?.release() } catch (_: Throwable) {}
            if (tex != 0) { GLES20.glDeleteTextures(1, intArrayOf(tex), 0); tex = 0 }
            dec = null; ex = null; surf = null; st = null
            hasFrame = false
            curPts = Long.MIN_VALUE
        }
    }

    private val sources = HashMap<String, VDec?>()

    private fun srcFor(key: String): VDec? {
        if (sources.containsKey(key)) return sources[key]
        val dev = when {
            key.startsWith("p") -> setup.people.getOrNull(key.substring(1).toInt())?.camDev
            else -> setup.wides.getOrNull(key.substring(1).toInt())
        }
        var v: VDec? = null
        if (!dev.isNullOrEmpty()) {
            val dv = s.devices[dev]
            val dd = SessionStore.devDir(ctx, s.id, dev)
            val vf = File(dd, "video.mp4")
            val mf = File(dd, "meta.json")
            if (dv != null && vf.exists() && mf.exists()) {
                try {
                    val vm = JSONObject(mf.readText()).optJSONObject("video")
                    if (vm != null) v = VDec(key, vf, Finalizer.SatVideoTime(s, dv, vm.optLong("startBoot")))
                } catch (_: Throwable) {}
            }
        }
        sources[key] = v
        return v
    }

    // ───────── رسم ─────────

    private fun buildProg(p: Prog, kind: Int) {
        val vs = """
            attribute vec2 aPos; attribute vec2 aTex; attribute vec2 aLocal;
            uniform mat4 uTexM; varying vec2 vTex; varying vec2 vLocal;
            void main(){ gl_Position = vec4(aPos,0.0,1.0); vTex = (uTexM*vec4(aTex,0.0,1.0)).xy; vLocal = aLocal; }
        """.trimIndent()
        val head = if (kind == 0) "#extension GL_OES_EGL_image_external : require\nprecision highp float;\nuniform samplerExternalOES uTex;\n"
        else "precision highp float;\nuniform sampler2D uTex;\n"
        val body = """
            uniform vec2 uSize; uniform float uRadius; uniform float uAlpha; uniform vec4 uColor;
            varying vec2 vTex; varying vec2 vLocal;
            float rr(vec2 p, vec2 b, float r){ vec2 q = abs(p) - b + vec2(r); return length(max(q,0.0)) + min(max(q.x,q.y),0.0) - r; }
            void main(){
              float a = 1.0;
              if (uRadius > 0.0) { a = clamp(0.5 - rr(vLocal*uSize*0.5, uSize*0.5, uRadius), 0.0, 1.0); }
              vec4 c = ${if (kind == 2) "uColor" else "texture2D(uTex, vTex)"};
              gl_FragColor = vec4(c.rgb, c.a*a*uAlpha);
            }
        """.trimIndent()
        val fs = if (kind == 2) "precision highp float;\n$body" else head + body
        p.id = link(vs, fs)
        p.aPos = GLES20.glGetAttribLocation(p.id, "aPos")
        p.aTex = GLES20.glGetAttribLocation(p.id, "aTex")
        p.aLocal = GLES20.glGetAttribLocation(p.id, "aLocal")
        p.uTexM = GLES20.glGetUniformLocation(p.id, "uTexM")
        p.uTex = GLES20.glGetUniformLocation(p.id, "uTex")
        p.uSize = GLES20.glGetUniformLocation(p.id, "uSize")
        p.uRadius = GLES20.glGetUniformLocation(p.id, "uRadius")
        p.uAlpha = GLES20.glGetUniformLocation(p.id, "uAlpha")
        p.uColor = GLES20.glGetUniformLocation(p.id, "uColor")
    }

    private fun link(vs: String, fs: String): Int {
        fun sh(type: Int, src: String): Int {
            val id = GLES20.glCreateShader(type)
            GLES20.glShaderSource(id, src)
            GLES20.glCompileShader(id)
            val ok = IntArray(1)
            GLES20.glGetShaderiv(id, GLES20.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) throw IllegalStateException("shader: " + GLES20.glGetShaderInfoLog(id))
            return id
        }
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, sh(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(p, sh(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw IllegalStateException("link: " + GLES20.glGetProgramInfoLog(p))
        return p
    }

    /** يرسم مستطيلًا (بكسل، الأصل أعلى اليسار) */
    private fun quad(p: Prog, target: Int, tex: Int, texM: FloatArray, x: Float, y: Float, w: Float, h: Float,
                     u0: Float, v0: Float, u1: Float, v1: Float, radius: Float, alpha: Float, color: Int = 0) {
        if (w < 1f || h < 1f) return
        val x0 = x / outW * 2f - 1f
        val x1 = (x + w) / outW * 2f - 1f
        val yt = 1f - y / outH * 2f
        val yb = 1f - (y + h) / outH * 2f
        posBuf.position(0); posBuf.put(floatArrayOf(x0, yb, x1, yb, x0, yt, x1, yt)); posBuf.position(0)
        texBuf.position(0); texBuf.put(floatArrayOf(u0, v0, u1, v0, u0, v1, u1, v1)); texBuf.position(0)
        GLES20.glUseProgram(p.id)
        GLES20.glUniformMatrix4fv(p.uTexM, 1, false, texM, 0)
        GLES20.glUniform2f(p.uSize, w, h)
        GLES20.glUniform1f(p.uRadius, radius)
        GLES20.glUniform1f(p.uAlpha, alpha)
        if (p.uColor >= 0) GLES20.glUniform4f(p.uColor, ((color shr 16) and 255) / 255f, ((color shr 8) and 255) / 255f, (color and 255) / 255f, ((color ushr 24) and 255) / 255f)
        if (tex != 0) {
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(target, tex)
            GLES20.glUniform1i(p.uTex, 0)
        }
        GLES20.glEnableVertexAttribArray(p.aPos)
        GLES20.glVertexAttribPointer(p.aPos, 2, GLES20.GL_FLOAT, false, 0, posBuf)
        if (p.aTex >= 0) { GLES20.glEnableVertexAttribArray(p.aTex); GLES20.glVertexAttribPointer(p.aTex, 2, GLES20.GL_FLOAT, false, 0, texBuf) }
        GLES20.glEnableVertexAttribArray(p.aLocal)
        GLES20.glVertexAttribPointer(p.aLocal, 2, GLES20.GL_FLOAT, false, 0, locBuf)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }

    private fun solid(x: Float, y: Float, w: Float, h: Float, color: Int, radius: Float, alpha: Float) =
        quad(pSolid, 0, 0, ident, x, y, w, h, 0f, 0f, 1f, 1f, radius, alpha, color)

    /** يملأ المستطيل بالمصدر مع قصّ الزائد (cover) */
    private fun drawSrc(key: String, t: Double, x: Float, y: Float, w: Float, h: Float, radius: Float, alpha: Float): Boolean {
        val v = srcFor(key)
        if (v == null || !v.frameAt((v.time.fileMs((t * 1e9).toLong()) * 1000.0).toLong())) {
            solid(x, y, w, h, 0xFF202228.toInt(), radius, alpha)
            return false
        }
        val sa = v.w.toFloat() / v.h
        val da = w / h
        var u0 = 0f; var u1 = 1f; var v0 = 0f; var v1 = 1f
        if (sa > da) { val k = da / sa; u0 = (1f - k) / 2f; u1 = 1f - u0 } else { val k = sa / da; v0 = (1f - k) / 2f; v1 = 1f - v0 }
        quad(pOes, GLES11Ext.GL_TEXTURE_EXTERNAL_OES, v.tex, v.mat, x, y, w, h, u0, v0, u1, v1, radius, alpha)
        return true
    }

    private fun grid(n: Int, x: Float, y: Float, w: Float, h: Float, gap: Float): List<FloatArray> {
        val cols = when (n) { 1 -> 1; 2 -> 2; 3 -> 3; else -> 2 }
        val rows = if (n >= 4) 2 else 1
        val cw = (w - gap * (cols - 1)) / cols
        val ch = (h - gap * (rows - 1)) / rows
        val res = ArrayList<FloatArray>()
        for (i in 0 until n) {
            val c = i % cols
            val r = i / cols
            res.add(floatArrayOf(x + c * (cw + gap), y + r * (ch + gap), cw, ch))
        }
        return res
    }

    private fun drawShot(sh: PodShot, t: Double, alpha: Float) {
        val W = outW.toFloat()
        val H = outH.toFloat()
        when (sh.type) {
            PodShot.FULL -> if (!drawSrc("p${sh.main}", t, 0f, 0f, W, H, 0f, alpha) && setup.wides.isNotEmpty()) drawSrc("w0", t, 0f, 0f, W, H, 0f, alpha)
            PodShot.WIDE -> drawSrc("w${sh.main}", t, 0f, 0f, W, H, 0f, alpha)
            PodShot.PIP -> {
                drawSrc("p${sh.main}", t, 0f, 0f, W, H, 0f, alpha)
                val pw = W * 0.28f
                val ph = pw * 9f / 16f
                val px = W - pw - W * 0.03f
                val py = H - ph - H * 0.05f
                val b = max(3f, H / 240f)
                val r = ph * 0.1f
                for ((i, o) in sh.others.withIndex()) {
                    val oy = py - i * (ph + H * 0.03f)
                    solid(px - b, oy - b, pw + 2 * b, ph + 2 * b, 0xFFFFFFFF.toInt(), r + b, alpha)
                    drawSrc("p$o", t, px, oy, pw, ph, r, alpha)
                }
            }
            else -> {
                val who = if (sh.others.isNotEmpty()) sh.others else intArrayOf(sh.main)
                if (setup.multiStyle == "boxes") {
                    if (bgTex != 0) {
                        val sa = bgW.toFloat() / bgH
                        val da = W / H
                        var u0 = 0f; var u1 = 1f; var v0 = 0f; var v1 = 1f
                        if (sa > da) { val k = da / sa; u0 = (1f - k) / 2f; u1 = 1f - u0 } else { val k = sa / da; v0 = (1f - k) / 2f; v1 = 1f - v0 }
                        quad(p2d, GLES20.GL_TEXTURE_2D, bgTex, flip, 0f, 0f, W, H, u0, v0, u1, v1, 0f, alpha)
                    } else solid(0f, 0f, W, H, setup.bgColor, 0f, alpha)
                    val pad = H * 0.08f
                    val cells = grid(who.size, pad, pad, W - 2 * pad, H - 2 * pad, H * 0.04f)
                    for ((i, c) in cells.withIndex()) drawSrc("p${who[i]}", t, c[0], c[1], c[2], c[3], H * 0.035f, alpha)
                } else {
                    solid(0f, 0f, W, H, 0xFF000000.toInt(), 0f, alpha)
                    val cells = grid(who.size, 0f, 0f, W, H, max(2f, H / 360f))
                    for ((i, c) in cells.withIndex()) drawSrc("p${who[i]}", t, c[0], c[1], c[2], c[3], 0f, alpha)
                }
            }
        }
    }

    private fun keysOf(sh: PodShot): List<String> = when (sh.type) {
        PodShot.FULL -> listOf("p${sh.main}")
        PodShot.WIDE -> listOf("w${sh.main}")
        PodShot.PIP -> listOf("p${sh.main}") + sh.others.map { "p$it" }
        else -> (if (sh.others.isNotEmpty()) sh.others.toList() else listOf(sh.main)).map { "p$it" }
    }

    // ───────── التنفيذ ─────────

    /** يعيد رسالة خطأ أو null عند النجاح، ويضع الناتج في [resultUri] */
    var resultUri: Uri? = null

    fun run(): String? {
        if (shots.isEmpty() || dur <= 0.5) return "Nothing to export"
        val tmp = File(ctx.cacheDir, "pod_${s.id}_video.mp4")
        tmp.delete()
        val err = renderVideo(tmp)
        if (err != null) { tmp.delete(); return err }
        val e2 = muxAudio(tmp)
        tmp.delete()
        return e2
    }

    private fun renderVideo(tmp: File): String? {
        var enc: MediaCodec? = null
        var mux: MediaMuxer? = null
        var muxStarted = false
        var inSurf: Surface? = null
        try {
            val f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, outW, outH)
            f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            f.setInteger(MediaFormat.KEY_BIT_RATE, if (outH >= 1080) 10_000_000 else 6_000_000)
            f.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
            val e = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            enc = e
            e.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val isf = e.createInputSurface()
            inSurf = isf
            e.start()
            val m = MediaMuxer(tmp.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            mux = m
            initEgl(isf)
            buildProg(pOes, 0)
            buildProg(p2d, 1)
            buildProg(pSolid, 2)
            loadBg()
            GLES20.glEnable(GLES20.GL_BLEND)
            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)

            var track = -1
            val info = MediaCodec.BufferInfo()
            fun drain(end: Boolean) {
                while (true) {
                    val i = e.dequeueOutputBuffer(info, if (end) 10_000 else 0)
                    if (i == MediaCodec.INFO_TRY_AGAIN_LATER) { if (!end) return else continue }
                    if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { track = m.addTrack(e.outputFormat); m.start(); muxStarted = true; continue }
                    if (i < 0) continue
                    val ob = e.getOutputBuffer(i)
                    if (ob != null && info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && muxStarted) {
                        ob.position(info.offset); ob.limit(info.offset + info.size)
                        m.writeSampleData(track, ob, info)
                    }
                    e.releaseOutputBuffer(i, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                }
            }

            val total = (dur * fps).toInt()
            val fade = if (setup.fade) 0.3 else 0.0
            var si = 0
            for (fi in 0 until total) {
                if (cancelled()) return "Cancelled"
                val t = fi.toDouble() / fps
                while (si < shots.size - 1 && t >= shots[si].end) si++
                val cur = shots[si]
                val prev = if (si > 0 && fade > 0 && t - cur.start < fade) shots[si - 1] else null

                // فتح/إغلاق المفكّكات: نُبقي فقط ما يظهر الآن أو خلال ثانيتين
                val need = HashSet<String>()
                need.addAll(keysOf(cur))
                if (prev != null) need.addAll(keysOf(prev))
                var k = si + 1
                while (k < shots.size && shots[k].start < t + 2.0) { need.addAll(keysOf(shots[k])); k++ }
                if (cur.type == PodShot.FULL && setup.wides.isNotEmpty()) need.add("w0")
                for ((key, v) in sources) if (v != null && key !in need && v.dec != null) v.close()

                GLES20.glViewport(0, 0, outW, outH)
                GLES20.glClearColor(0f, 0f, 0f, 1f)
                GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
                if (prev != null) {
                    drawShot(prev, t, 1f)
                    drawShot(cur, t, ((t - cur.start) / fade).toFloat().coerceIn(0f, 1f))
                } else drawShot(cur, t, 1f)

                EGLExt.eglPresentationTimeANDROID(dpy, eglSurf, (t * 1e9).toLong())
                EGL14.eglSwapBuffers(dpy, eglSurf)
                drain(false)
                if (fi % 15 == 0) progress("Rendering video", fi.toFloat() / total)
            }
            e.signalEndOfInputStream()
            drain(true)
            if (muxStarted) m.stop()
            return if (muxStarted) null else "Video encoder produced nothing"
        } catch (t: Throwable) {
            return "Render failed: ${t.message ?: t.javaClass.simpleName}"
        } finally {
            for (v in sources.values) try { v?.close() } catch (_: Throwable) {}
            sources.clear()
            if (bgTex != 0) try { GLES20.glDeleteTextures(1, intArrayOf(bgTex), 0) } catch (_: Throwable) {}
            releaseEgl()
            try { enc?.stop() } catch (_: Throwable) {}
            try { enc?.release() } catch (_: Throwable) {}
            try { inSurf?.release() } catch (_: Throwable) {}
            try { mux?.release() } catch (_: Throwable) {}
            frameThread.quitSafely()
        }
    }

    private fun loadBg() {
        if (setup.multiStyle != "boxes" || setup.bgImage.isEmpty()) return
        try {
            val bmp: Bitmap = ctx.contentResolver.openInputStream(Uri.parse(setup.bgImage))?.use { BitmapFactory.decodeStream(it) } ?: return
            val t = IntArray(1)
            GLES20.glGenTextures(1, t, 0)
            bgTex = t[0]
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, bgTex)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
            bgW = bmp.width; bgH = bmp.height
            bmp.recycle()
        } catch (_: Throwable) {
            warnings += "Background image could not be loaded"
        }
    }

    private fun initEgl(surface: Surface) {
        dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val ver = IntArray(2)
        check(EGL14.eglInitialize(dpy, ver, 0, ver, 1)) { "eglInitialize failed" }
        val attrs = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, 0x3142, 1, EGL14.EGL_NONE,
        )
        val cfgs = arrayOfNulls<EGLConfig>(1)
        val num = IntArray(1)
        check(EGL14.eglChooseConfig(dpy, attrs, 0, cfgs, 0, 1, num, 0) && num[0] > 0) { "no EGL config" }
        eglCtx = EGL14.eglCreateContext(dpy, cfgs[0], EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
        eglSurf = EGL14.eglCreateWindowSurface(dpy, cfgs[0], surface, intArrayOf(EGL14.EGL_NONE), 0)
        check(EGL14.eglMakeCurrent(dpy, eglSurf, eglSurf, eglCtx)) { "eglMakeCurrent failed" }
    }

    private fun releaseEgl() {
        if (dpy == EGL14.EGL_NO_DISPLAY) return
        EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
        if (eglSurf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, eglSurf)
        if (eglCtx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(dpy, eglCtx)
        EGL14.eglReleaseThread()
        EGL14.eglTerminate(dpy)
        dpy = EGL14.EGL_NO_DISPLAY
        eglCtx = EGL14.EGL_NO_CONTEXT
        eglSurf = EGL14.EGL_NO_SURFACE
    }

    // ───────── الصوت ─────────

    private class Mic(val src: PodAudioSrc, val people: List<Int>, var gain: Float) {
        var env = 1f
    }

    private fun muxAudio(videoFile: File): String? {
        val rate = 44100
        val total = (dur * rate).toLong()
        val mics = ArrayList<Mic>()
        val byDev = LinkedHashMap<String, MutableList<Int>>()
        for ((i, p) in setup.people.withIndex()) if (p.micDev.isNotEmpty()) byDev.getOrPut(p.micDev) { ArrayList() }.add(i)
        for ((dev, ppl) in byDev) {
            val src = PodAudioSrc.open(ctx, s, dev)
            if (src == null) { warnings += "Microphone of ${setup.people[ppl[0]].name} not received — skipped"; continue }
            var g = 1f
            if (setup.level && an != null) {
                val sp = ppl.map { an.speechDb.getOrElse(it) { -30f } }.maxOrNull() ?: -30f
                g = Math.pow(10.0, ((-20f - sp) / 20f).toDouble()).toFloat().coerceIn(0.5f, 8f)
            }
            mics.add(Mic(src, ppl, g))
        }
        if (mics.isEmpty()) warnings += "No microphone audio — the video will be silent"

        val block = 4096
        val sub = 256
        val tmpBuf = FloatArray(block + sub * 2 + 64)
        val bnd = DoubleArray(block / sub + 3)
        val envAt = FloatArray(block / sub + 2)
        val attack = 1f - Math.exp(-(sub.toDouble() / rate) / 0.05).toFloat()
        val release = 1f - Math.exp(-(sub.toDouble() / rate) / 0.30).toFloat()

        val res = AudioMux.writeWithAudio(ctx, videoFile, total, rate, outName(), { k0, n, L, R ->
            java.util.Arrays.fill(L, 0, n, 0f)
            java.util.Arrays.fill(R, 0, n, 0f)
            val nb = (n + sub - 1) / sub
            for (mic in mics) {
                // غلاف التخفيض: 1 إذا صاحب المايك يتكلم أو لا أحد يتكلم، وإلا قيمة التخفيض
                for (j in 0..nb) {
                    val tSec = (k0 + min(j * sub, n)).toDouble() / rate
                    var target = 1f
                    if (an != null && setup.duck < 0.999f) {
                        val f = (tSec / an.frameSec).toInt()
                        if (f in 0 until an.frames) {
                            val mine = mic.people.any { an.active.getOrNull(it)?.get(f) == true }
                            val anyone = an.active.any { it[f] }
                            if (!mine && anyone) target = setup.duck
                        }
                    }
                    mic.env += (target - mic.env) * (if (target > mic.env) attack else release)
                    envAt[j] = mic.env
                    bnd[j] = mic.src.nAt(tSec)
                }
                var lo = Double.MAX_VALUE
                var hi = -Double.MAX_VALUE
                for (j in 0..nb) { lo = min(lo, bnd[j]); hi = max(hi, bnd[j]) }
                if (hi < -2.0 || lo > mic.src.rd.frames + 2.0) continue
                val start = floor(lo).toLong() - 1L
                val cnt = (ceil(hi).toLong() + 3L - start).toInt()
                if (cnt <= 0 || cnt > tmpBuf.size) continue
                mic.src.rd.readChannel(start, cnt, 0, tmpBuf)
                for (i in 0 until n) {
                    val seg = i / sub
                    val fr = (i - seg * sub).toDouble() / sub
                    val np = bnd[seg] + (bnd[seg + 1] - bnd[seg]) * fr
                    val fl = floor(np)
                    val w = (np - fl).toFloat()
                    val ix = (fl.toLong() - start).toInt()
                    if (ix < 0 || ix + 1 >= cnt) continue
                    val g = mic.gain * (envAt[seg] + (envAt[seg + 1] - envAt[seg]) * fr.toFloat())
                    val v = (tmpBuf[ix] * (1f - w) + tmpBuf[ix + 1] * w) * g
                    L[i] += v; R[i] += v
                }
            }
        }, { p -> progress("Mixing audio", p) }, cancelled)
        for (m in mics) m.src.close()
        resultUri = res.first
        return res.second
    }

    private fun outName(): String = StorageUtil.newName().replace("Reaction_", "Podcast_").replace(".mp4", "_16x9.mp4")
}

/** دمج فيديو جاهز (بدون إعادة ترميز) مع صوت يُولَّد كتلة كتلة، وحفظ الناتج في المعرض */
object AudioMux {
    fun writeWithAudio(
        ctx: Context,
        videoFile: File,
        totalFrames: Long,
        rate: Int,
        name: String,
        fill: (Long, Int, FloatArray, FloatArray) -> Unit,
        progress: (Float) -> Unit,
        cancelled: () -> Boolean,
    ): Pair<Uri?, String?> {
        var ex: MediaExtractor? = null
        var enc: MediaCodec? = null
        var mux: MediaMuxer? = null
        var pfd: android.os.ParcelFileDescriptor? = null
        var outUri: Uri? = null
        var started = false
        var ok = false
        try {
            val extractor = MediaExtractor()
            ex = extractor
            extractor.setDataSource(videoFile.absolutePath)
            var vIdx = -1
            for (i in 0 until extractor.trackCount) if (extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true) { vIdx = i; break }
            if (vIdx < 0) return Pair(null, "No video track")
            val vFmt = extractor.getTrackFormat(vIdx)
            extractor.selectTrack(vIdx)
            val ou = StorageUtil.createPending(ctx, name) ?: return Pair(null, "Cannot create the output file")
            outUri = ou
            val pf = ctx.contentResolver.openFileDescriptor(ou, "rw") ?: return Pair(null, "Cannot open the output file")
            pfd = pf
            val m = MediaMuxer(pf.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            mux = m
            val vTrack = m.addTrack(vFmt)
            var aTrack = -1
            val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, 2)
            af.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            af.setInteger(MediaFormat.KEY_BIT_RATE, 192_000)
            af.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 32768)
            val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            enc = codec
            codec.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()

            val vBuf = ByteBuffer.allocateDirect(4 * 1024 * 1024)
            val vInfo = MediaCodec.BufferInfo()
            var vDone = false
            fun pumpVideo(upToUs: Long) {
                while (!vDone) {
                    val t = extractor.sampleTime
                    if (t < 0L) { vDone = true; break }
                    if (t > upToUs) break
                    vBuf.clear()
                    val n = extractor.readSampleData(vBuf, 0)
                    if (n < 0) { vDone = true; break }
                    vInfo.set(0, n, t, if ((extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                    m.writeSampleData(vTrack, vBuf, vInfo)
                    extractor.advance()
                }
            }
            val oInfo = MediaCodec.BufferInfo()
            var gotEos = false
            fun drain() {
                while (true) {
                    val i = codec.dequeueOutputBuffer(oInfo, 0)
                    when {
                        i == MediaCodec.INFO_TRY_AGAIN_LATER -> return
                        i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> { aTrack = m.addTrack(codec.outputFormat); m.start(); started = true }
                        i >= 0 -> {
                            val ob = codec.getOutputBuffer(i)
                            if (ob != null && oInfo.size > 0 && (oInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && started) {
                                pumpVideo(oInfo.presentationTimeUs)
                                ob.position(oInfo.offset); ob.limit(oInfo.offset + oInfo.size)
                                m.writeSampleData(aTrack, ob, oInfo)
                            }
                            codec.releaseOutputBuffer(i, false)
                            if ((oInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) { gotEos = true; return }
                        }
                    }
                }
            }
            var fed = 0L
            fun feed(pcm: ShortArray, frames: Int) {
                var off = 0
                while (off < frames) {
                    val idx = codec.dequeueInputBuffer(10_000)
                    if (idx < 0) { drain(); continue }
                    val ib = codec.getInputBuffer(idx)!!
                    ib.clear(); ib.order(ByteOrder.LITTLE_ENDIAN)
                    val c = min(frames - off, ib.capacity() / 4)
                    ib.asShortBuffer().put(pcm, off * 2, c * 2)
                    codec.queueInputBuffer(idx, 0, c * 4, fed * 1_000_000L / rate, 0)
                    fed += c; off += c
                    drain()
                }
            }
            val block = 4096
            val L = FloatArray(block)
            val R = FloatArray(block)
            val pcm = ShortArray(block * 2)
            var k0 = 0L
            while (k0 < totalFrames) {
                if (cancelled()) return Pair(null, "Cancelled")
                val n = min(block.toLong(), totalFrames - k0).toInt()
                fill(k0, n, L, R)
                for (i in 0 until n) { pcm[i * 2] = s16(L[i]); pcm[i * 2 + 1] = s16(R[i]) }
                feed(pcm, n)
                k0 += n
                if ((k0 / block) % 50 == 0L) progress(k0.toFloat() / totalFrames)
            }
            var sent = false
            while (!sent) {
                val idx = codec.dequeueInputBuffer(10_000)
                if (idx < 0) { drain(); continue }
                codec.queueInputBuffer(idx, 0, 0, fed * 1_000_000L / rate, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                sent = true
            }
            var guard = 0
            while (!gotEos && guard < 2000) { drain(); guard++; if (!gotEos) try { Thread.sleep(5) } catch (_: Throwable) {} }
            if (!started) return Pair(null, "Audio encoder produced nothing")
            pumpVideo(Long.MAX_VALUE)
            m.stop()
            started = false
            ok = true
            progress(1f)
        } catch (t: Throwable) {
            return Pair(null, "Saving failed: ${t.message ?: t.javaClass.simpleName}")
        } finally {
            try { enc?.stop() } catch (_: Throwable) {}
            try { enc?.release() } catch (_: Throwable) {}
            try { ex?.release() } catch (_: Throwable) {}
            if (started) try { mux?.stop() } catch (_: Throwable) {}
            try { mux?.release() } catch (_: Throwable) {}
            try { pfd?.close() } catch (_: Throwable) {}
            if (!ok) outUri?.let { StorageUtil.delete(ctx, it) }
        }
        outUri?.let { StorageUtil.publish(ctx, it) }
        return Pair(outUri, null)
    }

    private fun s16(x: Float): Short {
        var v = x
        val a = abs(v)
        if (a > 0.9f) {
            val e = 0.9f + 0.1f * kotlin.math.tanh((a - 0.9f) / 0.1f)
            v = if (v < 0f) -e else e
        }
        return (v * 32767f).toInt().coerceIn(-32768, 32767).toShort()
    }
}
