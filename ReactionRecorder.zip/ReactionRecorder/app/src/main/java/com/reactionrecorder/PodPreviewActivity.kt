package com.reactionrecorder

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.MediaController
import android.widget.TextView
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity

/** تشغيل ملف المعاينة (20 ثانية بنفس قرارات التصدير، بدقة خفيفة، مع أدلة المناطق الآمنة) */
class PodPreviewActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val path = intent.getStringExtra("file") ?: run { finish(); return }
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val vv = VideoView(this)
        root.addView(vv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        root.addView(TextView(this).apply {
            text = tx("معاينة بدقة خفيفة — المربعات الحمراء الشفافة = مناطق أزرار المنصات (لا تظهر في التصدير)", "Light preview — the transparent red boxes = platform button areas (not in the export)")
            setTextColor(Color.WHITE); textSize = 12f; setBackgroundColor(0x88000000.toInt()); setPadding(16, 12, 16, 12)
        }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))
        setContentView(root)
        vv.setMediaController(MediaController(this).also { it.setAnchorView(vv) })
        vv.setVideoPath(path)
        vv.setOnPreparedListener { it.isLooping = true; vv.start() }
    }
}
