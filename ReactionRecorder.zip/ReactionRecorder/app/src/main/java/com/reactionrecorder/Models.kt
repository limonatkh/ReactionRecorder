package com.reactionrecorder

import android.content.Context
import kotlin.math.min

/** مستطيل بإحداثيات مُطبَّعة (0..1) نسبةً إلى إطار الفيديو النهائي، الأصل أعلى اليسار. */
data class NRect(var x: Float, var y: Float, var w: Float, var h: Float) {
    fun copyRect() = NRect(x, y, w, h)
}

enum class CamShape { RECT, ROUNDED, CIRCLE }

/** كيف يُوضع فيديو المصدر داخل مستطيله: FIT = بدون اقتطاع (أشرطة سوداء)، FILL = ملء مع اقتطاع، STRETCH = ملء بالتمديد. */
enum class SourceFit { FIT, FILL, STRETCH }

/** مصدر الفيديو: تصوير شاشة الجوال، أو تشغيل ملف/رابط فيديو داخل التطبيق نفسه (بدون تصوير الشاشة). */
enum class SourceMode { SCREEN, VIDEO }

data class LayoutConfig(
    var source: NRect,
    var camera: NRect,
    var cameraOnTop: Boolean = true,
    var shape: CamShape = CamShape.ROUNDED,
    /** سمك الإطار كنسبة من عرض الفيديو (0 = بدون إطار) */
    var borderFrac: Float = 0.006f,
    /** نصف قطر الزوايا كنسبة من أصغر ضلع للكاميرا (0..0.5) */
    var radiusFrac: Float = 0.12f,
    var borderColor: Int = 0xFFFFFFFF.toInt(),
    var presetId: Int = 1,
    /** حصة الفيديو في الـ Presets المقسومة (0.3..0.8) */
    var ratio: Float = 0.7f,
)

object Presets {
    val names = listOf("Video + Cam", "70 / 30", "Side by Side", "Top / Bottom", "Cam Full", "Custom")

    /** يبني Preset رقم id (1..5) بحسب اتجاه الإطار. aspect = العرض/الارتفاع للفيديو النهائي. */
    fun build(id: Int, portrait: Boolean, ratio: Float, old: LayoutConfig? = null): LayoutConfig {
        val aspect = if (portrait) 9f / 16f else 16f / 9f
        val base = old ?: LayoutConfig(NRect(0f, 0f, 1f, 1f), NRect(0.6f, 0.7f, 0.35f, 0.2f))
        val r = ratio.coerceIn(0.3f, 0.8f)
        base.presetId = id
        base.ratio = r
        when (id) {
            1 -> { // فيديو كامل + كاميرا صغيرة في الزاوية
                base.source = NRect(0f, 0f, 1f, 1f)
                val w = if (portrait) 0.36f else 0.22f
                // الدائرة 1:1 بالبكسل، والمستطيل 4:3
                base.camera = squareish(NRect(1f - w - 0.04f, 0f, w, 0f), aspect, base.shape)
                base.camera.y = (1f - base.camera.h - 0.05f).coerceAtLeast(0f)
                base.cameraOnTop = true
            }
            2 -> { // فيديو r  + كاميرا (1-r)
                if (portrait) {
                    base.source = NRect(0f, 0f, 1f, r); base.camera = NRect(0f, r, 1f, 1f - r)
                } else {
                    base.source = NRect(0f, 0f, r, 1f); base.camera = NRect(r, 0f, 1f - r, 1f)
                }
                base.cameraOnTop = true
            }
            3 -> { // فيديو يسار + كاميرا يمين
                base.source = NRect(0f, 0f, r, 1f); base.camera = NRect(r, 0f, 1f - r, 1f)
                base.cameraOnTop = true
            }
            4 -> { // فيديو أعلى + كاميرا أسفل
                base.source = NRect(0f, 0f, 1f, r); base.camera = NRect(0f, r, 1f, 1f - r)
                base.cameraOnTop = true
            }
            5 -> { // كاميرا كاملة + فيديو صغير
                base.camera = NRect(0f, 0f, 1f, 1f)
                val w = if (portrait) 0.5f else 0.32f
                base.source = NRect(1f - w - 0.04f, if (portrait) 0.70f else 0.60f, w, 0.25f)
                base.cameraOnTop = false
            }
        }
        // في الـ Presets المقسومة نلغي الدائرة والإطار الجانبي كي لا تظهر فجوات غريبة
        if (id in 2..4 && base.shape == CamShape.CIRCLE) base.shape = CamShape.RECT
        return base
    }

    private fun squareish(r: NRect, aspect: Float, shape: CamShape): NRect {
        // نجعل الارتفاع بحيث تكون الدائرة 1:1 بالبكسل، والمستطيل 4:3
        val wPx = r.w * aspect // العرض بوحدات "الارتفاع"
        val hFrac = if (shape == CamShape.CIRCLE) wPx else wPx * 0.75f
        return NRect(r.x, r.y, r.w, hFrac.coerceIn(0.1f, 0.5f))
    }
}

data class RecordConfig(
    var portrait: Boolean = true,
    /** الضلع القصير: 720 أو 1080 */
    var shortSide: Int = 1080,
    var fps: Int = 30,
    /** Mbps — 0 = تلقائي حسب الدقة وFPS */
    var bitrateMbps: Float = 0f,
    var hevc: Boolean = false,
    var micOn: Boolean = true,
    var srcAudioOn: Boolean = true,
    var micVol: Float = 1.0f,
    var srcVol: Float = 0.8f,
    var echoSuppress: Boolean = false,
    var countdown: Int = 3,
    var frontCamera: Boolean = true,
    var mirrorFront: Boolean = true,
    /** دقة معاينة الكاميرا المطلوبة (الضلع الطويل): 640 / 1280 / 1920 */
    var cameraLong: Int = 1280,
    var cameraFps: Int = 30,
    var zoom: Float = 1f,
    var exposureIndex: Int = 0,
    var torch: Boolean = false,
    var mode: SourceMode = SourceMode.SCREEN,
    var videoUri: String = "",
    var videoName: String = "",
    var fitScreen: SourceFit = SourceFit.FILL,
    var fitVideo: SourceFit = SourceFit.FIT,
    /** إيقاف التسجيل تلقائيًا عند انتهاء الفيديو (وضع Video file) */
    var autoStop: Boolean = true,
    /** تأخير صوت الفيديو بالميلي ثانية لمعادلة تأخر السماعة (وضع Video file) */
    var videoAudioDelayMs: Int = 100,
    /** تصحيح يدوي لدوران الكاميرا: 0/90/180/270 */
    var camRotAdjust: Int = 0,
    var layout: LayoutConfig = Presets.build(1, true, 0.7f),
) {
    /** الملاءمة الحالية بحسب الوضع (للشاشة غير الفيديو لأن نسبتيهما مختلفتان) */
    var sourceFit: SourceFit
        get() = if (mode == SourceMode.VIDEO) fitVideo else fitScreen
        set(v) { if (mode == SourceMode.VIDEO) fitVideo = v else fitScreen = v }

    val outW: Int get() = if (portrait) shortSide else shortSide * 16 / 9 / 2 * 2
    val outH: Int get() = if (portrait) shortSide * 16 / 9 / 2 * 2 else shortSide

    /** البيتريت الفعلي بالبت/ثانية */
    fun effectiveBitrate(): Int {
        if (bitrateMbps > 0f) return (bitrateMbps * 1_000_000).toInt()
        val base = if (shortSide >= 1080) 8_000_000 else 5_000_000
        val scaled = base * fps / 30
        return if (hevc) (scaled * 0.65f).toInt() else scaled
    }
}

/** الحجم بالبكسل لمستطيل الكاميرا الفعلي (مع جعل الدائرة مربعة) */
fun effectiveCameraRect(l: LayoutConfig, outW: Int, outH: Int): NRect {
    val c = l.camera
    if (l.shape != CamShape.CIRCLE) return c
    val wPx = c.w * outW
    val hPx = c.h * outH
    val side = min(wPx, hPx)
    val w = side / outW
    val h = side / outH
    return NRect(c.x + (c.w - w) / 2f, c.y + (c.h - h) / 2f, w, h)
}

object ConfigStore {
    private const val P = "reaction_recorder"

    fun load(ctx: Context): RecordConfig {
        val s = ctx.getSharedPreferences(P, Context.MODE_PRIVATE)
        val portrait = s.getBoolean("portrait", true)
        val cfg = RecordConfig(
            portrait = portrait,
            shortSide = s.getInt("shortSide", 1080),
            fps = s.getInt("fps", 30),
            bitrateMbps = s.getFloat("bitrateMbps", 0f),
            hevc = s.getBoolean("hevc", false),
            micOn = s.getBoolean("micOn", true),
            srcAudioOn = s.getBoolean("srcAudioOn", true),
            micVol = s.getFloat("micVol", 1f),
            srcVol = s.getFloat("srcVol", 0.8f),
            echoSuppress = s.getBoolean("echo", false),
            countdown = s.getInt("countdown", 3),
            frontCamera = s.getBoolean("front", true),
            mirrorFront = s.getBoolean("mirror", true),
            cameraLong = s.getInt("camLong", 1280),
            cameraFps = s.getInt("camFps", 30),
            zoom = s.getFloat("zoom", 1f),
            exposureIndex = s.getInt("exp", 0),
            torch = false,
            mode = if (s.getInt("mode", 0) == 1) SourceMode.VIDEO else SourceMode.SCREEN,
            videoUri = s.getString("videoUri", "") ?: "",
            videoName = s.getString("videoName", "") ?: "",
            fitScreen = SourceFit.values()[s.getInt("fitS", SourceFit.FILL.ordinal).coerceIn(0, 2)],
            fitVideo = SourceFit.values()[s.getInt("fitV", SourceFit.FIT.ordinal).coerceIn(0, 2)],
            autoStop = s.getBoolean("autoStop", true),
            videoAudioDelayMs = s.getInt("vDelay", 100),
            camRotAdjust = s.getInt("camAdj", 0),
        )
        val shape = CamShape.values()[s.getInt("shape", CamShape.ROUNDED.ordinal).coerceIn(0, 2)]
        val preset = s.getInt("preset", 1)
        val ratio = s.getFloat("ratio", 0.7f)
        val l = Presets.build(1, portrait, ratio).also { it.shape = shape }
        if (preset == 6 && s.contains("sx")) {
            l.source = NRect(s.getFloat("sx", 0f), s.getFloat("sy", 0f), s.getFloat("sw", 1f), s.getFloat("sh", 1f))
            l.camera = NRect(s.getFloat("cx", .6f), s.getFloat("cy", .7f), s.getFloat("cw", .35f), s.getFloat("ch", .2f))
            l.cameraOnTop = s.getBoolean("camTop", true)
            l.presetId = 6
        } else {
            Presets.build(preset.coerceIn(1, 5), portrait, ratio, l)
        }
        l.borderFrac = s.getFloat("border", 0.006f)
        l.radiusFrac = s.getFloat("radius", 0.12f)
        l.ratio = ratio
        cfg.layout = l
        return cfg
    }

    fun save(ctx: Context, c: RecordConfig) {
        val l = c.layout
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).edit()
            .putBoolean("portrait", c.portrait).putInt("shortSide", c.shortSide).putInt("fps", c.fps)
            .putFloat("bitrateMbps", c.bitrateMbps).putBoolean("hevc", c.hevc)
            .putBoolean("micOn", c.micOn).putBoolean("srcAudioOn", c.srcAudioOn)
            .putFloat("micVol", c.micVol).putFloat("srcVol", c.srcVol).putBoolean("echo", c.echoSuppress)
            .putInt("countdown", c.countdown).putBoolean("front", c.frontCamera).putBoolean("mirror", c.mirrorFront)
            .putInt("camLong", c.cameraLong).putInt("camFps", c.cameraFps)
            .putFloat("zoom", c.zoom).putInt("exp", c.exposureIndex)
            .putInt("mode", if (c.mode == SourceMode.VIDEO) 1 else 0)
            .putString("videoUri", c.videoUri).putString("videoName", c.videoName)
            .putInt("fitS", c.fitScreen.ordinal).putInt("fitV", c.fitVideo.ordinal)
            .putBoolean("autoStop", c.autoStop).putInt("vDelay", c.videoAudioDelayMs).putInt("camAdj", c.camRotAdjust)
            .putInt("shape", l.shape.ordinal).putInt("preset", l.presetId).putFloat("ratio", l.ratio)
            .putFloat("border", l.borderFrac).putFloat("radius", l.radiusFrac)
            .putFloat("sx", l.source.x).putFloat("sy", l.source.y).putFloat("sw", l.source.w).putFloat("sh", l.source.h)
            .putFloat("cx", l.camera.x).putFloat("cy", l.camera.y).putFloat("cw", l.camera.w).putFloat("ch", l.camera.h)
            .putBoolean("camTop", l.cameraOnTop)
            .apply()
    }
}
