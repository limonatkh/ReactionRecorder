package com.reactionrecorder

import android.content.Context
import android.media.MediaMuxer
import android.media.projection.MediaProjection
import android.net.Uri
import android.os.ParcelFileDescriptor

/**
 * ينسّق كل أجزاء الخط:
 *   Compositor (GL) → VideoEncoder (Surface) ┐
 *   AudioEngine → AudioEncoder (AAC)          ├→ MuxerHolder → MediaStore (Movies/ReactionRecorder)
 */
class Recorder(
    private val ctx: Context,
    private val cfg: RecordConfig,
    private val projection: MediaProjection?,
    private val sourceW: Int,
    private val sourceH: Int,
    /** صوت المشغّل الداخلي في وضع Video file (null في وضع تصوير الشاشة) */
    private val feed: PlayerAudioFeed? = null,
) {
    lateinit var compositor: Compositor
        private set
    lateinit var resolved: ResolvedVideo
        private set
    var audio: AudioEngine? = null
        private set
    val notes = ArrayList<String>()

    private lateinit var video: VideoEncoder
    private lateinit var holder: MuxerHolder
    private var pfd: ParcelFileDescriptor? = null
    var uri: Uri? = null
        private set
    private var wantAudio = false
    private var startNs = 0L

    /** ينشئ الملف والمُرمِّز والـ Compositor. بعدها نوصل الكاميرا والمصدر ثم نستدعي [begin]. */
    fun prepare() {
        resolved = CodecSupport.resolve(cfg)
        notes.addAll(resolved.notes)

        uri = StorageUtil.createPending(ctx, StorageUtil.newName()) ?: error("MediaStore insert failed")
        pfd = ctx.contentResolver.openFileDescriptor(uri!!, "rw") ?: error("cannot open output file")
        val muxer = MediaMuxer(pfd!!.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        wantAudio = cfg.micOn || (cfg.srcAudioOn && (projection != null || feed != null))
        holder = MuxerHolder(muxer, if (wantAudio) 2 else 1)

        video = VideoEncoder(resolved, holder)
        video.prepare()

        compositor = Compositor(resolved.w, resolved.h, resolved.fps, video.inputSurface).also {
            it.layout = cfg.layout
            it.sourceFit = cfg.sourceFit
            it.mirrorCamera = cfg.frontCamera && cfg.mirrorFront
            it.cameraAdjust = cfg.camRotAdjust
            it.setup(sourceW, sourceH)
        }
        video.start()
    }

    /** يبدأ الرسم والصوت معًا بنفس الساعة المرجعية */
    fun begin() {
        startNs = System.nanoTime()
        if (wantAudio) {
            try {
                val enc = AudioEncoder(holder)
                val engine = AudioEngine(
                    micEnabled = cfg.micOn, sourceEnabled = cfg.srcAudioOn, projection = projection,
                    echoSuppress = cfg.echoSuppress, encoder = enc, startNs = startNs,
                    pausedNanos = { compositor.pausedNanos() },
                    feed = feed, feedDelayMs = cfg.videoAudioDelayMs,
                )
                engine.open()
                if (engine.hasMic || engine.hasSource || engine.hasFeed) {
                    engine.micVol = cfg.micVol
                    engine.srcVol = cfg.srcVol
                    enc.start()
                    engine.go()
                    audio = engine
                } else {
                    holder.lowerExpectedTracks(1)
                    notes += "No audio source available — recording video only"
                }
                if (cfg.srcAudioOn && (projection != null || feed != null) && engine.sourceStatus.isNotEmpty()) notes += engine.sourceStatus
                if (cfg.micOn && engine.micStatus.isNotEmpty() && !engine.hasMic) notes += engine.micStatus
            } catch (t: Throwable) {
                holder.lowerExpectedTracks(1)
                notes += "Audio failed: ${t.javaClass.simpleName}"
            }
        }
        compositor.begin(startNs)
    }

    fun pause() { compositor.pause(); audio?.paused = true }
    fun resume() { compositor.resume(); audio?.paused = false }
    fun setMicMuted(m: Boolean) { audio?.micMuted = m }

    /** يُنهي كل شيء. يُستدعى من خيط خلفي. يعيد Uri الفيديو الجاهز أو null عند الفشل. */
    fun stop(): Uri? {
        try { compositor.stopDrawing() } catch (_: Throwable) {}
        try { audio?.stop() } catch (_: Throwable) {}
        try { video.stop() } catch (_: Throwable) {}
        val ok = try { holder.finish() } catch (_: Throwable) { false }
        try { pfd?.close() } catch (_: Throwable) {}
        try { compositor.release() } catch (_: Throwable) {}
        val u = uri
        return if (ok && u != null) {
            StorageUtil.publish(ctx, u); u
        } else {
            if (u != null) StorageUtil.delete(ctx, u)
            null
        }
    }

    /** تنظيف عند فشل prepare/begin */
    fun abort() {
        try { compositor.stopDrawing() } catch (_: Throwable) {}
        try { video.stop() } catch (_: Throwable) {}
        try { holder.finish() } catch (_: Throwable) {}
        try { pfd?.close() } catch (_: Throwable) {}
        try { compositor.release() } catch (_: Throwable) {}
        uri?.let { StorageUtil.delete(ctx, it) }
    }
}
