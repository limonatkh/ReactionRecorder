package com.reactionrecorder

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.LinearLayout
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** تسجيلاتي: كل تسجيل ببطاقة واحدة — حالته واضحة (الملفات وصلت أم لا)، وفتحه للمونتاج أو التفاصيل */
class RecordingsActivity : BaseActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var list: LinearLayout
    private var sig = ""
    @Volatile private var cache: List<SessionInfo> = emptyList()
    @Volatile private var loading = false
    private var lastLoad = 0L

    private val pick = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        val c = applicationContext
        Thread {
            val r = DeviceImport.import(c, uris)
            ui.post {
                AlertDialog.Builder(this).setMessage(r.message).setPositiveButton(tx("تم", "OK"), null).show()
                lastLoad = 0L
            }
        }.start()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = UiKit.page(this, "📁 " + tx("تسجيلاتي", "My recordings"))
        val imp = UiKit.chip(this, "📥 " + tx("استيراد ملفات جهاز (بدون شبكة)", "Import a device's files (no network)")) {
            AlertDialog.Builder(this).setTitle(tx("استيراد يدوي", "Manual import"))
                .setMessage(tx("على الجوال الآخر: التسجيلات على هذا الجوال ← احفظ في التنزيلات. انقل المجلد لهذا الجوال، ثم اختر كل ملفاته (meta.json والصوت/الفيديو).", "On the other phone: Recordings on this phone ← Save to Downloads. Move the folder here, then pick all its files (meta.json and the audio/video)."))
                .setPositiveButton(tx("اختر الملفات", "Pick files")) { _, _ -> pick.launch(arrayOf("*/*")) }
                .setNegativeButton(tx("إلغاء", "Cancel"), null).show()
        }
        col.addView(imp, UiKit.full(this, imp, 4))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(list)
    }

    override fun onResume() { super.onResume(); lastLoad = 0L; ui.post(tick) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }

    private val tick = object : Runnable {
        override fun run() {
            val now = android.os.SystemClock.elapsedRealtime()
            if (!loading && now - lastLoad > 2500) {
                loading = true; lastLoad = now
                val c = applicationContext
                Thread {
                    val l = try { SessionStore.list(c).filter { it.kind == "podcast" || it.devices.isNotEmpty() } } catch (_: Throwable) { emptyList() }
                    ui.post { cache = l; loading = false; render() }
                }.start()
            }
            ui.postDelayed(this, 1000)
        }
    }

    private fun render() {
        val s = cache.joinToString("|") { x -> x.id + x.ended + x.mergedUri + x.devices.values.joinToString(",") { "${it.uploaded}" } } + PodRec.active
        if (s == sig) return
        sig = s
        list.removeAllViews()
        if (cache.isEmpty()) {
            list.addView(UiKit.text(this, tx("لا توجد تسجيلات بعد.\nتسجيلات الرياكشن العادية تُحفظ مباشرة في المعرض (Movies/ReactionRecorder)؛ هنا تظهر التسجيلات التي تحتاج دمجًا أو مونتاجًا.", "No recordings yet.\nPlain reaction videos go straight to the Gallery (Movies/ReactionRecorder); recordings that need merging or editing show up here."), 13f, UiKit.SUB).apply { setPadding(0, UiKit.dp(this@RecordingsActivity, 16), 0, 0) })
            return
        }
        for (x in cache) list.addView(card(x))
    }

    private fun card(s: SessionInfo): View {
        val c = UiKit.card(this, null, null)
        val pod = s.kind == "podcast"
        val dur = if (pod) PodcastAnalyzer.duration(s).toLong() else if (s.ended) ((s.endElapsedNs - s.startElapsedNs - s.pauses.sumOf { it[1] }) / 1_000_000_000L).coerceAtLeast(0L) else 0L
        val head = (if (pod) (if (s.extra.contains("\"vlog\":true")) "🎥 " else "🎙 ") else "🎞 ") + SimpleDateFormat("yyyy-MM-dd  HH:mm", Locale.US).format(Date(s.wallMs)) +
            (if (s.ended) "  •  " + String.format(Locale.US, "%d:%02d", dur / 60, dur % 60) else "")
        c.addView(UiKit.text(this, head, 15f, UiKit.TEXT, true))
        if (pod) {
            val st = PodcastAnalyzer.setupOf(s)
            c.addView(UiKit.text(this, st.people.joinToString("، ") { it.name }, 12.5f, UiKit.SUB))
        } else c.addView(UiKit.text(this, tx("رياكشن مع أجهزة مساعدة", "Reaction with remote devices"), 12.5f, UiKit.SUB))
        val waiting = s.devices.values.filter { it.started && !it.uploaded }
        val stTxt = when {
            !s.ended && PodRec.active == s.id -> "🔴 " + tx("قيد التسجيل", "Recording")
            !s.ended -> "⚠ " + tx("لم ينتهِ بشكل طبيعي", "Did not finish normally")
            waiting.isEmpty() -> "✓ " + tx("كل الملفات وصلت", "All files received")
            else -> "⏳ " + tx("بانتظار: ", "Waiting for: ") + waiting.joinToString("، ") { it.name }
        }
        c.addView(UiKit.text(this, stTxt, 12.5f, if (waiting.isEmpty() && s.ended) UiKit.GREEN else UiKit.ORANGE).apply { setPadding(0, UiKit.dp(this@RecordingsActivity, 4), 0, 0) })
        c.isClickable = true
        c.setOnClickListener { startActivity(Intent(this, SessionActivity::class.java).putExtra("session", s.id)) }
        val lp = UiKit.full(this, c, 10)
        c.layoutParams = lp
        return c
    }
}
