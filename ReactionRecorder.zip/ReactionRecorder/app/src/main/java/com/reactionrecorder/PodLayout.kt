package com.reactionrecorder

import kotlin.math.max
import kotlin.math.min

/**
 * هندسة المونتاج المشتركة بين الإخراج الحقيقي (PodcastRenderer) ونموذج القالب (LayoutDemoView):
 * مكان المربع العائم، شريط الكتابة، العناصر الثابتة، والمناطق الممنوعة بالريل.
 * عشان اللي بتشوفه بنموذج القالب هو نفس الترتيب اللي بيطلع بالفيديو.
 */
object PodLayout {
    /** مستطيل بسيط (مش android.graphics.RectF عشان الحساب ينفحص باختبارات عادية) */
    class Box(var left: Float, var top: Float, var right: Float, var bottom: Float) {
        fun width() = right - left
        fun height() = bottom - top
        fun centerX() = (left + right) / 2f
        fun centerY() = (top + bottom) / 2f
        fun offset(dx: Float, dy: Float) { left += dx; right += dx; top += dy; bottom += dy }
        fun inset(d: Float) = Box(left - d, top - d, right + d, bottom + d)
        fun toRectF() = android.graphics.RectF(left, top, right, bottom)
    }

    /** المناطق اللي بتغطيها واجهة المنصات بالريل: تحت (اسم الحساب والوصف)، يمين تحت (الأزرار)، فوق شوي */
    fun blocked(vertical: Boolean, W: Float, H: Float): List<Box> =
        if (vertical) listOf(Box(0f, H * 0.82f, W, H), Box(W * 0.86f, H * 0.45f, W, H), Box(0f, 0f, W, H * 0.07f))
        else listOf(Box(0f, H * 0.93f, W, H))

    /** مركز الكتابة عموديًا */
    fun capCenterY(tp: PodTemplate, vertical: Boolean, H: Float): Float = when (tp.capPos) {
        "top" -> if (vertical) H * 0.18f else H * 0.14f
        "middle" -> H * 0.5f
        else -> if (vertical) H * (if (tp.capStyle == "line") 0.70f else 0.68f) else H * 0.86f
    }

    /** حجم خط الكتابة بالبكسل */
    fun capTextSize(tp: PodTemplate, vertical: Boolean, H: Float, capSize: Float): Float {
        val base = if (tp.capStyle == "line") (if (vertical) 0.036f else 0.052f) else (if (vertical) 0.050f else 0.066f)
        return H * base * capSize
    }

    /** المنطقة التقريبية للكتابة (عشان المربع العائم والعناصر ما يغطوها) */
    fun capBand(tp: PodTemplate, vertical: Boolean, W: Float, H: Float, captionsOn: Boolean): Box? {
        if (!captionsOn) return null
        val cy = capCenterY(tp, vertical, H)
        val h = capTextSize(tp, vertical, H, tp.capSize) * (if (tp.capStyle == "line") 2.6f else 1.8f)
        return Box(W * 0.06f, cy - h / 2f, W * 0.94f, cy + h / 2f)
    }

    /** [عرض، ارتفاع] المربع العائم */
    fun pipSize(tp: PodTemplate, vertical: Boolean, W: Float, circle: Boolean): FloatArray {
        val pw = W * (if (vertical) min(0.6f, tp.pipSize * 1.45f) else tp.pipSize)
        val ph = when {
            circle -> pw
            tp.pipFace -> if (tp.faceAspect == "portrait") pw * 1.25f else pw
            vertical -> pw * 4f / 3f
            else -> pw * 9f / 16f
        }
        return floatArrayOf(pw, ph)
    }

    fun margin(tp: PodTemplate, W: Float, H: Float): Float =
        if (tp.avoidFace) max(min(W, H) * tp.pipMargin, min(W, H) * 0.05f) else min(W, H) * tp.pipMargin

    /**
     * أماكن المربعات العائمة (واحد لكل شخص قاطع). mirrorX = الجهة الثانية، flipY = فوق↔تحت.
     * بالريل: بتحترم المناطق الممنوعة وما بتغطي الكتابة.
     */
    fun pipRects(tp: PodTemplate, W: Float, H: Float, vertical: Boolean, n: Int, pw: Float, ph: Float,
                 mirrorX: Boolean, flipY: Boolean, captionsOn: Boolean): List<Box> {
        val m = margin(tp, W, H)
        val band = capBand(tp, vertical, W, H, captionsOn)
        var pos = tp.pipPos
        if (pos == "custom") {
            var cx = tp.pipX; var cy = tp.pipY
            if (mirrorX) cx = 1f - cx
            if (flipY) cy = 1f - cy
            return List(n) { i -> clamp(Box(cx * W - pw / 2f, cy * H - ph / 2f + i * (ph + H * 0.03f), 0f, 0f).also { it.right = it.left + pw; it.bottom = it.top + ph }, W, H, vertical, band, m) }
        }
        // الجهة
        var top = pos.startsWith("t")
        var hx = when { pos.endsWith("c") -> 0; pos.endsWith("l") -> -1; else -> 1 }
        if (mirrorX) hx = -hx
        if (flipY) top = !top
        val topY = if (vertical) H * 0.09f else m
        val bottomY = if (vertical) (min(H * 0.80f, band?.top ?: H * 0.80f) - m * 0.5f - ph) else H - ph - m
        val res = ArrayList<Box>()
        for (i in 0 until n) {
            val x: Float; val y: Float
            if (hx == 0) {
                // بالنص: المربعات جنب بعض
                val totalW = n * pw + (n - 1) * W * 0.03f
                x = (W - totalW) / 2f + i * (pw + W * 0.03f)
                y = if (top) topY else bottomY
            } else {
                x = if (hx < 0) m else W - pw - m
                y = if (top) topY + i * (ph + H * 0.03f) else bottomY - i * (ph + H * 0.03f)
            }
            res.add(clamp(Box(x, y, x + pw, y + ph), W, H, vertical, band, m))
        }
        return res
    }

    /** يدخّل المستطيل جوّا الصورة، وبره المناطق الممنوعة والكتابة */
    fun clamp(r: Box, W: Float, H: Float, vertical: Boolean, band: Box?, m: Float): Box {
        val w = r.width(); val h = r.height()
        var x = r.left.coerceIn(0f, max(0f, W - w)); var y = r.top.coerceIn(0f, max(0f, H - h))
        if (vertical) {
            y = y.coerceIn(H * 0.07f, max(H * 0.07f, H * 0.82f - h))
            if (y + h > H * 0.45f && x + w > W * 0.86f) x = max(0f, W * 0.86f - w)
        }
        if (band != null && y < band.bottom && y + h > band.top && h < H * 0.6f) {
            // فوق الكتابة إذا المربع بالنص التحتاني، وإلا تحتها
            y = if (y + h / 2f > band.centerY()) band.top - h - m * 0.4f else band.bottom + m * 0.4f
            y = y.coerceIn(0f, max(0f, H - h))
        }
        return Box(x, y, x + w, y + h)
    }

    fun overlap(a: Box, b: Box): Float {
        val ix = min(a.right, b.right) - max(a.left, b.left)
        val iy = min(a.bottom, b.bottom) - max(a.top, b.top)
        return if (ix > 0 && iy > 0) ix * iy else 0f
    }

    /** مكان عنصر ثابت حجمه w×h؛ index = ترتيبه بين العناصر بنفس المكان */
    fun itemRect(pos: String, w: Float, h: Float, W: Float, H: Float, vertical: Boolean, index: Int, band: Box?): Box {
        val m = min(W, H) * 0.04f
        val top = pos.startsWith("t")
        val x = when { pos.endsWith("c") -> (W - w) / 2f; pos.endsWith("l") -> m; else -> W - w - m }
        val step = h + m * 0.4f
        var y = if (top) (if (vertical) H * 0.075f else m) + index * step
        else (if (vertical) H * 0.80f - h else H - h - m * 1.6f) - index * step
        var r = Box(x, y, x + w, y + h)
        if (vertical && !top && band != null && r.bottom > band.top && r.top < band.bottom) {
            y = band.top - h - m * 0.3f - index * step; r = Box(x, y, x + w, y + h)
        }
        if (vertical && r.bottom > H * 0.45f && r.right > W * 0.86f) r.offset(W * 0.86f - r.right, 0f)
        return r
    }
}
