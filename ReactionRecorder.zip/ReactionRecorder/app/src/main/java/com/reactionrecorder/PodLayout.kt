package com.reactionrecorder

import kotlin.math.max
import kotlin.math.min

/**
 * هندسة المونتاج المشتركة بين الإخراج الحقيقي (PodcastRenderer) ونموذج القالب (LayoutDemoView):
 * مكان المربع العائم، شريط الكتابة، العناصر الثابتة، والمناطق الممنوعة بالريل.
 * عشان اللي بتشوفه بنموذج القالب هو نفس الترتيب اللي بيطلع بالفيديو.
 */
object PodLayout {
    /** مستطيل بسيط (مش android.graphics.RectF عشان الحساب ينفحص باختبارات عادية) */
    class Box(var left: Float, var top: Float, var right: Float, var bottom: Float) {
        fun width() = right - left
        fun height() = bottom - top
        fun centerX() = (left + right) / 2f
        fun centerY() = (top + bottom) / 2f
        fun offset(dx: Float, dy: Float) { left += dx; right += dx; top += dy; bottom += dy }
        fun inset(d: Float) = Box(left - d, top - d, right + d, bottom + d)
        fun toRectF() = android.graphics.RectF(left, top, right, bottom)
    }

    /** المناطق اللي بتغطيها واجهة المنصات بالريل: تحت (اسم الحساب والوصف)، يمين تحت (الأزرار)، فوق شوي */
    fun blocked(vertical: Boolean, W: Float, H: Float): List<Box> =
        if (vertical) listOf(Box(0f, H * 0.82f, W, H), Box(W * 0.86f, H * 0.45f, W, H), Box(0f, 0f, W, H * 0.07f))
        else listOf(Box(0f, H * 0.93f, W, H))

    /** مركز الكتابة عموديًا */
    fun capCenterY(tp: PodTemplate, vertical: Boolean, H: Float): Float = when (tp.capPos) {
        "top" -> if (vertical) H * 0.18f else H * 0.14f
        "middle" -> H * 0.5f
        else -> if (vertical) H * (if (tp.capStyle == "line") 0.70f else 0.68f) else H * 0.86f
    }

    /** حجم خط الكتابة بالبكسل */
    fun capTextSize(tp: PodTemplate, vertical: Boolean, H: Float, capSize: Float): Float {
        val base = if (tp.capStyle == "line") (if (vertical) 0.036f else 0.052f) else (if (vertical) 0.050f else 0.066f)
        return H * base * capSize
    }

    /** المنطقة التقريبية للكتابة (عشان المربع العائم والعناصر ما يغطوها) */
    fun capBand(tp: PodTemplate, vertical: Boolean, W: Float, H: Float, captionsOn: Boolean): Box? {
        if (!captionsOn) return null
        val cy = capCenterY(tp, vertical, H)
        val h = capTextSize(tp, vertical, H, tp.capSize) * (if (tp.capStyle == "line") 2.6f else 1.8f)
        return Box(W * 0.06f, cy - h / 2f, W * 0.94f, cy + h / 2f)
    }

    /** [عرض، ارتفاع] المربع العائم */
    fun pipSize(tp: PodTemplate, vertical: Boolean, W: Float, circle: Boolean): FloatArray {
        val pw = W * (if (vertical) min(0.95f, tp.pipSize * 1.45f) else min(0.9f, tp.pipSize))
        // الشكل: بالريل مربع افتراضيًا (مش طولي)، وبالحلقة بالعرض
        val asp = if (tp.pipAspect == "auto") (if (vertical) "square" else "169") else tp.pipAspect
        val ph = when {
            circle -> pw
            tp.pipFace -> if (tp.faceAspect == "portrait") pw * 1.25f else pw
            asp == "square" -> pw
            asp == "wide" -> pw * 0.75f
            asp == "tall" -> pw * 4f / 3f
            else -> pw * 9f / 16f
        }
        return floatArrayOf(pw, ph)
    }

    /** المربع على الوجه: الوجه بياخد قديش من ارتفاع المربع (خفيف/متوسط/قريب) — الزوم بيتغير مع قرب الشخص */
    fun faceTarget(faceZoom: Float): Float = when { faceZoom < 1.45f -> 0.35f; faceZoom < 1.9f -> 0.45f; else -> 0.6f }

    /** زوم بيخلي الوجه (حجمه fs من ارتفاع المصدر) ياخد target من ارتفاع المربع؛ kh = نسبة ارتفاع المصدر الظاهرة بدون زوم */
    fun adaptiveZoom(target: Float, fs: Float, kh: Float): Float = if (fs <= 0.01f) 1.6f else (target * kh / fs).coerceIn(1f, 4f)

    fun margin(tp: PodTemplate, W: Float, H: Float): Float =
        if (tp.avoidFace) max(min(W, H) * tp.pipMargin, min(W, H) * 0.05f) else min(W, H) * tp.pipMargin

    /**
     * أماكن المربعات العائمة (واحد لكل شخص قاطع). mirrorX = الجهة الثانية، flipY = فوق↔تحت.
     * حر بالكامل: مناطق أزرار المنصة بالريل تنبيه أحمر بالمعاينة بس، والكتابة هي اللي بتبعد عن المربع.
     */
    fun pipRects(tp: PodTemplate, W: Float, H: Float, vertical: Boolean, n: Int, pw: Float, ph: Float,
                 mirrorX: Boolean, flipY: Boolean, captionsOn: Boolean): List<Box> {
        val m = margin(tp, W, H)
        val pos = tp.pipPos
        if (pos == "custom") {
            var cx = tp.pipX; var cy = tp.pipY
            if (mirrorX) cx = 1f - cx
            if (flipY) cy = 1f - cy
            return List(n) { i ->
                val dy = if (cy > 0.5f) -i * (ph + H * 0.03f) else i * (ph + H * 0.03f)
                clamp(Box(cx * W - pw / 2f, cy * H - ph / 2f + dy, cx * W + pw / 2f, cy * H + ph / 2f + dy), W, H)
            }
        }
        var top = pos.startsWith("t")
        var hx = when { pos.endsWith("c") -> 0; pos.endsWith("l") -> -1; else -> 1 }
        if (mirrorX) hx = -hx
        if (flipY) top = !top
        val topY = if (vertical) H * 0.09f else m
        val bottomY = if (vertical) H * 0.79f - ph else H - ph - m
        val res = ArrayList<Box>()
        for (i in 0 until n) {
            val x: Float; val y: Float
            if (hx == 0) {
                // بالنص: المربعات جنب بعض
                val totalW = n * pw + (n - 1) * W * 0.03f
                x = (W - totalW) / 2f + i * (pw + W * 0.03f)
                y = if (top) topY else bottomY
            } else {
                x = if (hx < 0) m else W - pw - m
                y = if (top) topY + i * (ph + H * 0.03f) else bottomY - i * (ph + H * 0.03f)
            }
            res.add(clamp(Box(x, y, x + pw, y + ph), W, H))
        }
        return res
    }

    /** يدخّل المستطيل جوّا الصورة بس */
    fun clamp(r: Box, W: Float, H: Float): Box {
        val w = min(r.width(), W); val h = min(r.height(), H)
        val x = r.left.coerceIn(0f, max(0f, W - w)); val y = r.top.coerceIn(0f, max(0f, H - h))
        return Box(x, y, x + w, y + h)
    }

    fun overlap(a: Box, b: Box): Float {
        val ix = min(a.right, b.right) - max(a.left, b.left)
        val iy = min(a.bottom, b.bottom) - max(a.top, b.top)
        return if (ix > 0 && iy > 0) ix * iy else 0f
    }

    /** هل المستطيل داخل منطقة بتغطيها واجهة المنصة؟ (للتنبيه الأحمر) */
    fun inBlocked(r: Box, vertical: Boolean, W: Float, H: Float): Boolean = blocked(vertical, W, H).any { overlap(it, r) > r.width() * r.height() * 0.15f }

    /** مكان عنصر ثابت حجمه w×h؛ index = ترتيبه بين العناصر بنفس المكان. بعيد عن الحافة متل البودكاستات المعروفة */
    fun itemRect(pos: String, w: Float, h: Float, W: Float, H: Float, vertical: Boolean, index: Int, band: Box? = null): Box {
        val mx = W * 0.06f
        val top = pos.startsWith("t")
        val x = when { pos.endsWith("c") -> (W - w) / 2f; pos.endsWith("l") -> mx; else -> W - w - mx }
        val step = h + H * 0.012f
        val y = if (top) (if (vertical) H * 0.085f else H * 0.06f) + index * step
        else (if (vertical) H * 0.80f - h else H * 0.94f - h) - index * step
        return Box(x, y, x + w, y + h)
    }

    /**
     * مكان الكتابة (مركزها عموديًا): ما بتغطي وجه ولا مربع عائم ولا نص ثابت، وما بتلزق بالحافة.
     * divider = خط الفاصل لما يكونوا شخص فوق وشخص تحت (الكتابة بتروح عليه).
     */
    fun capPlace(tp: PodTemplate, vertical: Boolean, W: Float, H: Float, capH: Float, avoid: List<Box>, divider: Float?): Float {
        val lo = H * 0.07f + capH / 2f; val hi = H * 0.93f - capH / 2f
        if (divider != null && tp.capPos != "top") return divider.coerceIn(lo, hi)
        val def = capCenterY(tp, vertical, H)
        val cands = linkedSetOf(def, H * 0.72f, H * 0.80f, H * 0.64f, H * 0.86f, H * 0.28f, H * 0.18f, H * 0.5f)
        fun cost(c: Float): Float {
            val b = Box(W * 0.06f, c - capH / 2f, W * 0.94f, c + capH / 2f)
            return avoid.sumOf { overlap(it, b).toDouble() }.toFloat()
        }
        var best = def.coerceIn(lo, hi); var bestCost = Float.MAX_VALUE
        for (c0 in cands) {
            val c = c0.coerceIn(lo, hi)
            val k = cost(c) + kotlin.math.abs(c - def) * 0.01f
            if (k < bestCost) { best = c; bestCost = k }
            if (cost(c) == 0f && c0 == def) return c
        }
        return best
    }
}
