package com.reactionrecorder

import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * المركِّب (Compositor): يرسم فيديو المصدر (شاشة الهاتف عبر MediaProjection) وإطارات الكاميرا
 * على سطح الـ MediaCodec مباشرةً عبر OpenGL ES 2.0.
 *
 *   Camera  → SurfaceTexture(OES) ┐
 *                                  ├→ GL shader (crop/shape/border) → EGL window = encoder input Surface
 *   Screen  → SurfaceTexture(OES) ┘
 *
 * لا يوجد أي نسخ للـ Bitmap أو ByteBuffer على الـ CPU: الإطارات تبقى على الـ GPU من الالتقاط إلى الترميز.
 * الرسم يتم على إيقاع ثابت (fps) حتى لو كانت الشاشة ثابتة، لضمان فيديو بمعدل إطارات ثابت.
 */
class Compositor(
    private val outW: Int,
    private val outH: Int,
    private val fps: Int,
    private val encoderSurface: Surface,
) {
    @Volatile var layout: LayoutConfig = Presets.build(1, true, 0.7f)
    @Volatile var sourceFit: SourceFit = SourceFit.FIT
    @Volatile var mirrorCamera: Boolean = false
    /** الدوران (باتجاه عقارب الساعة) اللازم لجعل إطار الكاميرا مستقيمًا — يأتي من CameraX */
    @Volatile var cameraRotation: Int = 0
    @Volatile private var camW = 1280
    @Volatile private var camH = 720
    @Volatile private var srcW = 1080
    @Volatile private var srcH = 1920

    private val thread = HandlerThread("compositor").apply { start() }
    private val handler = Handler(thread.looper)

    private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE

    private var prog = 0
    private var aPos = 0; private var aTex = 0; private var aLocal = 0
    private var uTexMatrix = 0; private var uTex = 0; private var uHalf = 0
    private var uRadius = 0; private var uBorder = 0; private var uBorderColor = 0

    private val texIds = IntArray(2)
    private lateinit var camSt: SurfaceTexture
    private lateinit var srcSt: SurfaceTexture
    lateinit var cameraSurface: Surface
        private set
    lateinit var sourceSurface: Surface
        private set

    private val camDirty = AtomicBoolean(false)
    private val srcDirty = AtomicBoolean(false)
    private var hasCam = false
    private var hasSrc = false
    private val camMat = FloatArray(16)
    private val srcMat = FloatArray(16)

    private val posBuf: FloatBuffer = floatBuf(8)
    private val texBuf: FloatBuffer = floatBuf(8)
    private val locBuf: FloatBuffer = floatBuf(8).apply { put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)); position(0) }

    @Volatile private var running = false
    @Volatile private var paused = false
    private var startNs = 0L
    private var pausedAtNs = 0L
    private var pausedTotalNs = 0L
    private var nextNs = 0L
    @Volatile var framesDrawn = 0L
        private set

    /** تهيئة EGL وإنشاء أسطح الكاميرا والمصدر. تُستدعى مرة واحدة وتنتظر حتى الانتهاء. */
    fun setup(sourceW: Int, sourceH: Int) {
        srcW = sourceW; srcH = sourceH
        val latch = CountDownLatch(1)
        var error: Throwable? = null
        handler.post {
            try {
                initEgl()
                initGl()
                camSt = SurfaceTexture(texIds[0]).also {
                    it.setDefaultBufferSize(camW, camH)
                    it.setOnFrameAvailableListener({ camDirty.set(true) }, handler)
                }
                srcSt = SurfaceTexture(texIds[1]).also {
                    it.setDefaultBufferSize(srcW, srcH)
                    it.setOnFrameAvailableListener({ srcDirty.set(true) }, handler)
                }
                cameraSurface = Surface(camSt)
                sourceSurface = Surface(srcSt)
            } catch (t: Throwable) {
                error = t
            }
            latch.countDown()
        }
        if (!latch.await(10, TimeUnit.SECONDS)) throw IllegalStateException("Compositor init timeout")
        error?.let { throw it }
    }

    /** تُستدعى عندما تطلب CameraX سطحًا بحجم معيّن */
    fun setCameraBufferSize(w: Int, h: Int) {
        camW = w; camH = h
        val latch = CountDownLatch(1)
        handler.post { camSt.setDefaultBufferSize(w, h); latch.countDown() }
        latch.await(2, TimeUnit.SECONDS)
    }

    /** يُستدعى عند تدوير الشاشة/تغيير حجم الالتقاط */
    fun setSourceSize(w: Int, h: Int) {
        srcW = w; srcH = h
        handler.post { srcSt.setDefaultBufferSize(w, h) }
    }

    fun begin(startNanos: Long) {
        startNs = startNanos
        running = true
        nextNs = System.nanoTime()
        handler.post(tick)
    }

    /** يوقف الرسم فقط (قبل إرسال EOS للمُرمِّز). تحرير EGL يتم لاحقًا في release() */
    fun stopDrawing() {
        running = false
        val latch = CountDownLatch(1)
        handler.post { handler.removeCallbacks(tick); latch.countDown() }
        latch.await(2, TimeUnit.SECONDS)
    }

    fun pause() { if (!paused) { pausedAtNs = System.nanoTime(); paused = true } }
    fun resume() { if (paused) { pausedTotalNs += System.nanoTime() - pausedAtNs; paused = false } }

    /** إجمالي مدة الإيقاف المؤقت بالنانو ثانية (يستعملها الصوت لتبقى المسارات متزامنة) */
    fun pausedNanos(): Long = pausedTotalNs + if (paused) System.nanoTime() - pausedAtNs else 0L

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            try {
                renderFrame()
            } catch (t: Throwable) {
                // لا نوقف التسجيل بسبب إطار واحد
            }
            nextNs += 1_000_000_000L / fps
            val now = System.nanoTime()
            var delayMs = (nextNs - now) / 1_000_000L
            if (delayMs < 0) { nextNs = now; delayMs = 0 }
            handler.postAtTime(this, SystemClock.uptimeMillis() + delayMs)
        }
    }

    private fun renderFrame() {
        if (camDirty.getAndSet(false)) { camSt.updateTexImage(); camSt.getTransformMatrix(camMat); hasCam = true }
        if (srcDirty.getAndSet(false)) { srcSt.updateTexImage(); srcSt.getTransformMatrix(srcMat); hasSrc = true }
        if (paused) return

        GLES20.glViewport(0, 0, outW, outH)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)

        val l = layout
        if (l.cameraOnTop) { drawSource(l); drawCamera(l) } else { drawCamera(l); drawSource(l) }

        val ptsNs = System.nanoTime() - startNs - pausedTotalNs
        EGLExt.eglPresentationTimeANDROID(eglDisplay, eglSurface, ptsNs)
        EGL14.eglSwapBuffers(eglDisplay, eglSurface)
        framesDrawn++
    }

    private fun drawSource(l: LayoutConfig) {
        if (!hasSrc) return
        val r = l.source
        var x = r.x * outW; var y = r.y * outH; var w = r.w * outW; var h = r.h * outH
        val sw = srcW.toFloat(); val sh = srcH.toFloat()
        val tc: FloatArray
        if (sourceFit == SourceFit.FIT) {
            val s = min(w / sw, h / sh)
            val fw = sw * s; val fh = sh * s
            x += (w - fw) / 2f; y += (h - fh) / 2f; w = fw; h = fh
            tc = coverCoords(1f, 1f, 1f, 1f, 0, false) // الإطار كاملًا
        } else {
            tc = coverCoords(sw, sh, w, h, 0, false)
        }
        draw(texIds[1], srcMat, x, y, w, h, tc, 0f, 0f)
    }

    private fun drawCamera(l: LayoutConfig) {
        if (!hasCam) return
        val r = effectiveCameraRect(l, outW, outH)
        val x = r.x * outW; val y = r.y * outH; val w = r.w * outW; val h = r.h * outH
        val rot = cameraRotation
        val upW = if (rot % 180 == 0) camW.toFloat() else camH.toFloat()
        val upH = if (rot % 180 == 0) camH.toFloat() else camW.toFloat()
        val tc = coverCoords(upW, upH, w, h, rot, mirrorCamera)
        val radius = when (l.shape) {
            CamShape.RECT -> 0f
            CamShape.ROUNDED -> l.radiusFrac.coerceIn(0f, 0.5f) * min(w, h)
            CamShape.CIRCLE -> min(w, h) / 2f
        }
        val border = l.borderFrac * outW
        draw(texIds[0], camMat, x, y, w, h, tc, radius, border, l.borderColor)
    }

    /**
     * إحداثيات الـ texture بترتيب [BL, BR, TL, TR] بحيث يملأ المحتوى (upW×upH) المستطيل (rw×rh)
     * بقصّ مركزي (cover)، ثم يُطبَّق الانعكاس الأفقي ثم الدوران ليطابق اتجاه الـ buffer.
     */
    private fun coverCoords(upW: Float, upH: Float, rw: Float, rh: Float, rotation: Int, mirror: Boolean): FloatArray {
        var u0 = 0f; var u1 = 1f; var v0 = 0f; var v1 = 1f
        val texAspect = upW / upH
        val rectAspect = rw / rh
        if (texAspect > rectAspect) {
            val c = rectAspect / texAspect
            u0 = 0.5f - c / 2f; u1 = 0.5f + c / 2f
        } else if (texAspect < rectAspect) {
            val c = texAspect / rectAspect
            v0 = 0.5f - c / 2f; v1 = 0.5f + c / 2f
        }
        if (mirror) { val t = u0; u0 = u1; u1 = t }
        val pts = floatArrayOf(u0, v0, u1, v0, u0, v1, u1, v1)
        if (rotation == 0) return pts
        val a = Math.toRadians(rotation.toDouble())
        val ca = cos(a).toFloat(); val sa = sin(a).toFloat()
        val out = FloatArray(8)
        for (i in 0 until 4) {
            val cx = pts[i * 2] - 0.5f; val cy = pts[i * 2 + 1] - 0.5f
            out[i * 2] = cx * ca - cy * sa + 0.5f
            out[i * 2 + 1] = cx * sa + cy * ca + 0.5f
        }
        return out
    }

    private fun draw(
        tex: Int, texMat: FloatArray, x: Float, y: Float, w: Float, h: Float, tc: FloatArray,
        radius: Float, border: Float, borderColor: Int = 0xFFFFFFFF.toInt(),
    ) {
        val x0 = x / outW * 2f - 1f; val x1 = (x + w) / outW * 2f - 1f
        val yTop = 1f - y / outH * 2f; val yBot = 1f - (y + h) / outH * 2f
        posBuf.position(0); posBuf.put(floatArrayOf(x0, yBot, x1, yBot, x0, yTop, x1, yTop)); posBuf.position(0)
        texBuf.position(0); texBuf.put(tc); texBuf.position(0)
        locBuf.position(0)

        GLES20.glUseProgram(prog)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        GLES20.glUniform1i(uTex, 0)
        GLES20.glUniformMatrix4fv(uTexMatrix, 1, false, texMat, 0)
        GLES20.glUniform2f(uHalf, w / 2f, h / 2f)
        GLES20.glUniform1f(uRadius, radius)
        GLES20.glUniform1f(uBorder, border)
        GLES20.glUniform4f(
            uBorderColor,
            ((borderColor shr 16) and 0xFF) / 255f, ((borderColor shr 8) and 0xFF) / 255f,
            (borderColor and 0xFF) / 255f, ((borderColor ushr 24) and 0xFF) / 255f,
        )
        GLES20.glEnableVertexAttribArray(aPos); GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 8, posBuf)
        GLES20.glEnableVertexAttribArray(aTex); GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 8, texBuf)
        GLES20.glEnableVertexAttribArray(aLocal); GLES20.glVertexAttribPointer(aLocal, 2, GLES20.GL_FLOAT, false, 8, locBuf)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aPos)
        GLES20.glDisableVertexAttribArray(aTex)
        GLES20.glDisableVertexAttribArray(aLocal)
    }

    private fun initEgl() {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val ver = IntArray(2)
        check(EGL14.eglInitialize(eglDisplay, ver, 0, ver, 1)) { "eglInitialize failed" }
        val attribs = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL_RECORDABLE_ANDROID, 1,
            EGL14.EGL_NONE,
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val n = IntArray(1)
        check(EGL14.eglChooseConfig(eglDisplay, attribs, 0, configs, 0, 1, n, 0) && n[0] > 0) { "no EGL config" }
        eglContext = EGL14.eglCreateContext(
            eglDisplay, configs[0], EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0,
        )
        eglSurface = EGL14.eglCreateWindowSurface(eglDisplay, configs[0], encoderSurface, intArrayOf(EGL14.EGL_NONE), 0)
        check(EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)) { "eglMakeCurrent failed" }
    }

    private fun initGl() {
        prog = buildProgram(VERTEX, FRAGMENT)
        aPos = GLES20.glGetAttribLocation(prog, "aPos")
        aTex = GLES20.glGetAttribLocation(prog, "aTex")
        aLocal = GLES20.glGetAttribLocation(prog, "aLocal")
        uTexMatrix = GLES20.glGetUniformLocation(prog, "uTexMatrix")
        uTex = GLES20.glGetUniformLocation(prog, "uTex")
        uHalf = GLES20.glGetUniformLocation(prog, "uHalf")
        uRadius = GLES20.glGetUniformLocation(prog, "uRadius")
        uBorder = GLES20.glGetUniformLocation(prog, "uBorder")
        uBorderColor = GLES20.glGetUniformLocation(prog, "uBorderColor")
        GLES20.glGenTextures(2, texIds, 0)
        for (id in texIds) {
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, id)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        }
    }

    fun release() {
        running = false
        val latch = CountDownLatch(1)
        handler.post {
            handler.removeCallbacks(tick)
            try { cameraSurface.release() } catch (_: Throwable) {}
            try { sourceSurface.release() } catch (_: Throwable) {}
            try { camSt.release() } catch (_: Throwable) {}
            try { srcSt.release() } catch (_: Throwable) {}
            if (eglDisplay != EGL14.EGL_NO_DISPLAY) {
                EGL14.eglMakeCurrent(eglDisplay, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                if (eglSurface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(eglDisplay, eglSurface)
                if (eglContext != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(eglDisplay, eglContext)
                EGL14.eglReleaseThread()
                EGL14.eglTerminate(eglDisplay)
            }
            eglDisplay = EGL14.EGL_NO_DISPLAY
            eglContext = EGL14.EGL_NO_CONTEXT
            eglSurface = EGL14.EGL_NO_SURFACE
            latch.countDown()
        }
        latch.await(3, TimeUnit.SECONDS)
        thread.quitSafely()
    }

    companion object {
        private const val EGL_RECORDABLE_ANDROID = 0x3142

        private fun floatBuf(n: Int): FloatBuffer =
            ByteBuffer.allocateDirect(n * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()

        private const val VERTEX = """
            attribute vec4 aPos;
            attribute vec2 aTex;
            attribute vec2 aLocal;
            uniform mat4 uTexMatrix;
            varying vec2 vTex;
            varying vec2 vLocal;
            void main() {
                gl_Position = aPos;
                vTex = (uTexMatrix * vec4(aTex, 0.0, 1.0)).xy;
                vLocal = aLocal;
            }
        """

        // SDF لمستطيل بزوايا مدوّرة: يعطي الشكل (مستطيل/مدوّر/دائرة) والإطار داخل الـ Shader نفسه
        private const val FRAGMENT = """
            #extension GL_OES_EGL_image_external : require
            #ifdef GL_FRAGMENT_PRECISION_HIGH
            precision highp float;
            #else
            precision mediump float;
            #endif
            varying vec2 vTex;
            varying vec2 vLocal;
            uniform samplerExternalOES uTex;
            uniform vec2 uHalf;
            uniform float uRadius;
            uniform float uBorder;
            uniform vec4 uBorderColor;
            void main() {
                vec2 p = vLocal * uHalf;
                vec2 q = abs(p) - (uHalf - vec2(uRadius));
                float d = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - uRadius;
                float a = 1.0 - smoothstep(-1.0, 0.0, d);
                vec4 c = texture2D(uTex, vTex);
                float b = 0.0;
                if (uBorder > 0.0) { b = smoothstep(-uBorder - 1.0, -uBorder, d); }
                c.rgb = mix(c.rgb, uBorderColor.rgb, b * uBorderColor.a);
                gl_FragColor = vec4(c.rgb, a);
            }
        """

        private fun buildProgram(vs: String, fs: String): Int {
            val v = compile(GLES20.GL_VERTEX_SHADER, vs)
            val f = compile(GLES20.GL_FRAGMENT_SHADER, fs)
            val p = GLES20.glCreateProgram()
            GLES20.glAttachShader(p, v); GLES20.glAttachShader(p, f)
            GLES20.glLinkProgram(p)
            val st = IntArray(1)
            GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, st, 0)
            check(st[0] == GLES20.GL_TRUE) { "link failed: " + GLES20.glGetProgramInfoLog(p) }
            return p
        }

        private fun compile(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src.trimIndent())
            GLES20.glCompileShader(s)
            val st = IntArray(1)
            GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, st, 0)
            check(st[0] == GLES20.GL_TRUE) { "shader failed: " + GLES20.glGetShaderInfoLog(s) }
            return s
        }
    }
}
