package com.reactionrecorder

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import java.util.Locale

/** قوالب المونتاج: القائمة، الافتراضي، نسخ وحذف */
class TemplateActivity : BaseActivity() {
    private lateinit var list: LinearLayout
    private lateinit var tabs: LinearLayout
    private var kind = "episode"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = UiKit.page(this, tx("قوالب المونتاج", "Edit templates"), tx("القالب بيقرر كيف بيطلع الفيديو: مكان المربع العائم وشكله، الشاشة المقسومة، الأسماء، الإطار المضيء، والإيقاع. المونتاج التلقائي بيقرر مين يظهر وإمتى.", "A template decides how the video looks: the floating box's place and shape, split screen, names, glow and pacing. The automatic edit decides who appears and when."))
        val add = UiKit.primary(this, tx("قالب جديد", "New template")) {
            val t = TemplateStore.resolve(this, null, kind).copy().also { it.id = TemplateStore.newId(); it.name = if (kind == "reel") tx("ريلي", "My reel") else tx("قالبي", "My template") }
            TemplateStore.save(this, t)
            startActivity(Intent(this, TemplateEditActivity::class.java).putExtra("id", t.id))
        }.also { UiKit.withIcon(it, Ic.PLUS, "#FFFFFF", 20) }
        kind = intent.getStringExtra("kind") ?: "episode"
        tabs = LinearLayout(this)
        col.addView(tabs, UiKit.full(this, tabs, 10))
        col.addView(add, UiKit.full(this, add, 10))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(list)
    }

    override fun onResume() { super.onResume(); render() }

    private fun dp(v: Int) = UiKit.dp(this, v)

    private fun render() {
        tabs.removeAllViews()
        for ((k, n) in listOf("episode" to tx("الحلقة الكاملة (بالعرض)", "Full episode (landscape)"), "reel" to tx("ريلز (بالطول)", "Reels (portrait)")))
            tabs.addView(UiKit.chip(this, n, kind == k) { kind = k; render() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        list.removeAllViews()
        val def = TemplateStore.defaultId(this, kind)
        for (t in TemplateStore.ofKind(this, kind)) {
            val c = UiKit.card(this, null, list)
            val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            head.addView(UiKit.text(this, t.name, 17f, UiKit.TEXT, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            if (t.id == def) head.addView(UiKit.badge(this, tx("الافتراضي", "Default"), UiKit.BLUE))
            else if (t.builtIn) head.addView(UiKit.badge(this, tx("جاهز", "Built-in"), UiKit.SUB))
            c.addView(head)
            c.addView(UiKit.text(this, summary(t), 13.5f, UiKit.SUB))
            val demo = LayoutDemoView(this).apply { tpl = t; names = listOf(tx("شخص ١", "Person 1"), tx("شخص ٢", "Person 2")); landscape = t.kind != "reel" }
            if (t.kind == "reel") {
                val w = LinearLayout(this).apply { gravity = Gravity.CENTER }
                w.addView(demo, LinearLayout.LayoutParams(dp(170), ViewGroup.LayoutParams.WRAP_CONTENT))
                c.addView(w, UiKit.full(this, w, 8))
            } else c.addView(demo, UiKit.full(this, demo, 8))
            val r = LinearLayout(this)
            fun btn(label: String, run: () -> Unit) = r.addView(UiKit.chip(this, label) { run() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(3), dp(8), dp(3), 0) })
            if (t.id != def) btn(tx("اجعله الافتراضي", "Make default")) { TemplateStore.setDefault(this, t.id); render() }
            btn(if (t.builtIn) tx("انسخ وعدّل", "Copy & edit") else tx("عدّل", "Edit")) {
                val id = if (t.builtIn) t.copy().also { it.id = TemplateStore.newId(); it.name = t.name + tx(" (نسختي)", " (mine)"); TemplateStore.save(this, it) }.id else t.id
                startActivity(Intent(this, TemplateEditActivity::class.java).putExtra("id", id))
            }
            if (!t.builtIn) btn(tx("احذف", "Delete")) {
                AlertDialog.Builder(this).setMessage(tx("تحذف القالب «${t.name}»؟ المشاريع اللي بتستعمله بترجع للافتراضي.", "Delete “${t.name}”? Projects using it go back to the default."))
                    .setPositiveButton(tx("احذف", "Delete")) { _, _ -> TemplateStore.delete(this, t.id); render() }
                    .setNegativeButton(tx("إلغاء", "Cancel"), null).show()
            }
            c.addView(r)
        }
    }

    companion object {
        fun summary(t: PodTemplate): String {
            val pace = when (t.intensity) { "calm" -> tx("هادئ", "Calm"); "lively" -> tx("حيوي", "Lively"); else -> tx("متوازن", "Balanced") }
            val box = if (!t.pip) tx("المقاطِع: شاشة مقسومة", "Interrupter: split screen") else
                tx("مربع عائم ", "Floating box ") + when (t.pipShape) { "circle" -> tx("دائري", "circle"); "rect" -> tx("مستطيل", "rectangle"); "alternate" -> tx("دائري/مربع بالتناوب", "circle/square alternating"); else -> tx("زوايا دائرية", "rounded") } +
                    when (t.pipPlace) { "person" -> tx("، حسب الشخص", ", by person"); "alternate" -> tx("، يمين/يسار بالتناوب", ", alternating sides"); else -> "" }
            if (t.layout == "grid") return tx("الكل ظاهر طول الوقت", "Everyone on screen") + (if (t.glow) tx(" · إطار مضيء", " · glow") else "") + (if (t.captions) tx(" · كتابة", " · captions") else "")
            return "$pace · $box" + (if (t.pipFace) tx(" · على الوجه", " · on the face") else "") + (if (t.avoidFace) tx(" · ما بيغطي الوجه", " · avoids faces") else "") +
                (if (t.breakEvery > 0) tx(" · كسر الملل كل ${t.breakEvery}ث", " · break every ${t.breakEvery}s") else "") +
                (if (t.names != "never") tx(" · أسماء", " · names") else "") + (if (t.glow) tx(" · إطار مضيء", " · glow") else "") +
                (if (t.kind == "reel") (if (t.captions) tx(" · كتابة", " · captions") else "") + (if (t.zoomMode == "auto") tx(" · زوم", " · zoom") else "") else "")
        }
    }
}

/** محرر قالب: معاينة متحركة فوق (اسحب المربع وكبّره بإصبعين) وخيارات واسعة تحت */
class TemplateEditActivity : BaseActivity() {
    private lateinit var t: PodTemplate
    private lateinit var demo: LayoutDemoView
    private lateinit var cap: TextView
    private lateinit var opts: LinearLayout
    private lateinit var modeRow: LinearLayout
    private var editing = false

    private fun dp(v: Int) = UiKit.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra("id")
        val found = TemplateStore.get(this, id)
        if (found == null) { finish(); return }
        t = if (found.builtIn) found.copy().also { it.id = TemplateStore.newId() } else found
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor(UiKit.BG)) }
        setContentView(root)
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars() or androidx.core.view.WindowInsetsCompat.Type.ime())
            v.setPadding(0, b.top, 0, b.bottom); insets
        }
        // المعاينة ثابتة فوق
        val top = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(4), dp(16), dp(8)) }
        top.addView(UiKit.header(this, tx("تعديل القالب", "Edit template")))
        demo = LayoutDemoView(this).apply { tpl = t; names = listOf(tx("شخص ١", "Person 1"), tx("شخص ٢", "Person 2")); onTplChanged = { syncOpts() }; landscape = t.kind != "reel" }
        if (t.kind == "reel") {
            val w = LinearLayout(this).apply { gravity = Gravity.CENTER }
            w.addView(demo, LinearLayout.LayoutParams(dp(150), ViewGroup.LayoutParams.WRAP_CONTENT))
            top.addView(w)
        } else top.addView(demo)
        cap = UiKit.text(this, "", 13.5f, UiKit.TEXT, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0) }
        top.addView(cap)
        demo.onCaption = { s -> cap.post { cap.text = s } }
        modeRow = LinearLayout(this)
        top.addView(modeRow)
        renderMode()
        root.addView(top)
        root.addView(View(this).apply { setBackgroundColor(Color.parseColor("#26282E")) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))
        opts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(4), dp(16), dp(20)) }
        root.addView(ScrollView(this).apply { addView(opts) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val bottom = LinearLayout(this).apply { setPadding(dp(16), dp(10), dp(16), dp(12)) }
        bottom.addView(UiKit.chip(this, tx("احفظ", "Save")) { save(false) }, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginEnd = dp(8) })
        bottom.addView(UiKit.primary(this, tx("احفظ واجعله الافتراضي", "Save as default")) { save(true) }, LinearLayout.LayoutParams(0, dp(54), 1.4f))
        root.addView(bottom)
        build()
    }

    private fun save(asDefault: Boolean) {
        TemplateStore.save(this, t)
        if (asDefault) TemplateStore.setDefault(this, t.id)
        Toast.makeText(this, if (asDefault) tx("انحفظ وصار الافتراضي", "Saved as the default") else tx("انحفظ", "Saved"), Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun renderMode() {
        modeRow.removeAllViews()
        fun add(label: String, sel: Boolean, run: () -> Unit) = modeRow.addView(UiKit.chip(this, label, sel) { run(); renderMode() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(2), dp(6), dp(2), 0) })
        add(tx("شغّل النموذج", "Play sample"), !editing) { editing = false; demo.hold = -1; demo.editable = false }
        add(tx("حرّك المربع", "Move the box"), editing) {
            if (!t.pip) { Toast.makeText(this, tx("شغّل «اللي بيقاطع بمربع عائم» أولًا", "Turn on “interrupter in a floating box” first"), Toast.LENGTH_SHORT).show(); return@add }
            editing = true; demo.hold = 2; demo.editable = true
        }
        if (t.kind != "reel") {
            add("16:9", demo.landscape) { demo.landscape = true; demo.requestLayout() }
            add("9:16", !demo.landscape) { demo.landscape = false; demo.requestLayout() }
        }
    }

    private var lastSig = ""
    /** بعد السحب: نحدّث أرقام الخيارات بدون ما نعيد البناء كل حركة */
    private fun syncOpts() {
        val s = "${t.pipPos}${(t.pipSize * 100).toInt()}"
        if (s != lastSig) { lastSig = s; opts.removeCallbacks(rebuild); opts.postDelayed(rebuild, 250) }
    }
    private val rebuild = Runnable { build() }

    // ───────── عناصر ─────────

    private fun chips(parent: LinearLayout, items: List<Pair<String, String>>, cur: String, set: (String) -> Unit) {
        var row: LinearLayout? = null
        for ((i, p) in items.withIndex()) {
            if (i % 3 == 0) { row = LinearLayout(this); parent.addView(row) }
            row!!.addView(UiKit.chip(this, p.second, p.first == cur) { set(p.first); build() }.apply { textSize = 13.5f; setPadding(dp(6), 0, dp(6), 0) },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) })
        }
        val left = items.size % 3
        if (left != 0) repeat(3 - left) { row!!.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) }
    }

    private fun label(parent: LinearLayout, s: String) = parent.addView(UiKit.text(this, s, 14.5f, UiKit.TEXT, true).apply { setPadding(0, dp(12), 0, dp(2)) })
    private fun note(parent: LinearLayout, s: String) = parent.addView(UiKit.text(this, s, 13f, UiKit.SUB))

    private fun toggle(parent: LinearLayout, on: Boolean, yes: String, no: String, set: (Boolean) -> Unit) {
        val b = UiKit.chip(this, if (on) yes else no, on) { set(!on); build() }
        parent.addView(b, UiKit.full(this, b, 6))
    }

    private fun swatches(parent: LinearLayout, colors: List<Int>, cur: Int, set: (Int) -> Unit) {
        val r = LinearLayout(this)
        for (c in colors) {
            r.addView(View(this).apply {
                background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(c); setStroke(dp(if (c == cur) 3 else 1), Color.parseColor(if (c == cur) UiKit.BLUE else UiKit.LINE)) }
                contentDescription = String.format("#%06X", c and 0xFFFFFF)
                setOnClickListener { set(c); build() }
            }, LinearLayout.LayoutParams(dp(40), dp(40)).apply { setMargins(0, dp(6), dp(10), 0) })
        }
        parent.addView(r)
    }

    private fun slider(parent: LinearLayout, title: String, min: Float, max: Float, cur: Float, fmt: (Float) -> String, set: (Float) -> Unit) {
        val tv = UiKit.text(this, "$title: ${fmt(cur)}", 14f, UiKit.TEXT)
        parent.addView(tv.apply { setPadding(0, dp(10), 0, 0) })
        parent.addView(SeekBar(this).apply {
            this.max = 100; progress = (((cur - min) / (max - min)) * 100).toInt().coerceIn(0, 100)
            minimumHeight = dp(40)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (!u) return; val v = min + (max - min) * p / 100f; set(v); tv.text = "$title: ${fmt(v)}" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }

    private fun pct(v: Float) = "${(v * 100).toInt()}%"

    private val palette = listOf(0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFF3D8BFF.toInt(), 0xFFFFD60A.toInt(), 0xFFFF453A.toInt(), 0xFF32D74B.toInt(), 0xFFB45CE0.toInt(), 0xFF1B1D24.toInt())

    // ───────── الخيارات ─────────

    private fun build() {
        lastSig = "${t.pipPos}${(t.pipSize * 100).toInt()}"
        opts.removeAllViews()
        val nameEt = EditText(this).apply {
            setText(t.name); setSingleLine(); textSize = 17f; setTextColor(Color.parseColor(UiKit.TEXT)); hint = tx("اسم القالب", "Template name")
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(e: android.text.Editable?) { t.name = e?.toString()?.ifBlank { tx("قالبي", "My template") } ?: t.name }
            })
        }
        opts.addView(UiKit.text(this, tx("اسم القالب", "Template name"), 13f, UiKit.SUB).apply { setPadding(0, dp(10), 0, 0) })
        opts.addView(nameEt)

        opts.addView(UiKit.text(this, tx("أي تعديل هون بيتطبق على كل المشاريع اللي بتستعمل هالقالب (المعاينة والتصدير)، إلا الإعدادات اللي غيّرتها بإيدك جوّا مشروع.", "Changes here apply to every project using this template (preview and export), except settings you changed by hand inside a project."), 12.5f, UiKit.SUB).apply { setPadding(0, dp(8), 0, 0) })

        // ── الإيقاع
        val p = UiKit.section(this, opts, "tpl_pace", tx("الإيقاع: كيف بتتنقل الكاميرا تلقائيًا", "Pacing: how the camera switches automatically"), if (t.layout == "grid") tx("الكل ظاهر", "Everyone") else when (t.intensity) { "calm" -> tx("هادئ", "Calm"); "lively" -> tx("حيوي", "Lively"); else -> tx("متوازن", "Balanced") }, openByDefault = true)
        label(p, tx("التخطيط", "Layout"))
        chips(p, listOf("auto" to tx("الكاميرا بتلحق اللي بيحكي", "Camera follows the speaker"), "grid" to tx("الكل ظاهر طول الوقت", "Everyone all the time")), t.layout) { t.layout = it }
        if (t.layout != "grid") {
            label(p, tx("الأسلوب", "Style"))
            chips(p, listOf("calm" to tx("هادئ", "Calm"), "balanced" to tx("متوازن", "Balanced"), "lively" to tx("حيوي", "Lively")), t.intensity) { t.intensity = it }
            toggle(p, t.pip, tx("اللي بيقاطع بمربع عائم: نعم", "Interrupter in a floating box: yes"), tx("اللي بيقاطع بمربع عائم: لا (شاشة مقسومة)", "Interrupter in a floating box: no (split)")) { t.pip = it }
            label(p, tx("كسر الملل وقت الكلام الطويل", "Break monotony during long talk"))
            chips(p, listOf("0" to tx("مطفي", "Off"), "15" to tx("كل ١٥ ث", "Every 15 s"), "25" to tx("كل ٢٥ ث", "Every 25 s"), "40" to tx("كل ٤٠ ث", "Every 40 s")), t.breakEvery.toString()) { t.breakEvery = it.toInt() }
            if (t.breakEvery > 0) {
                chips(p, listOf("auto" to tx("بالتناوب", "Alternate"), "listener" to tx("على المستمع", "Listener"), "wide" to tx("الكاميرا العامة", "Wide camera"), "zoom" to tx("تقريب عليه", "Punch-in")), t.breakTo) { t.breakTo = it }
                chips(p, listOf("2.0" to tx("٢ ث", "2 s"), "2.5" to tx("٢٫٥ ث", "2.5 s"), "4.0" to tx("٤ ث", "4 s")), String.format(Locale.US, "%.1f", t.breakLen)) { t.breakLen = it.toFloat() }
                note(p, tx("إذا اخترت «الكاميرا العامة» وما في وحدة بالتصوير، بيصير تقريب بدالها.", "If you pick “Wide camera” and the shoot has none, a punch-in is used instead."))
            }
            label(p, tx("الكاميرا العامة (اللي بتجيب الكل)", "The wide camera (everyone)"))
            chips(p, listOf("0" to tx("حسب الأسلوب", "By style"), "2" to tx("بعد صمت ٢ ث", "After 2 s silence"), "3.5" to tx("بعد ٣٫٥ ث", "After 3.5 s"), "5" to tx("بعد ٥ ث", "After 5 s"), "-1" to tx("أبدًا", "Never")),
                when { t.wideAfter < 0f -> "-1"; t.wideAfter == 0f -> "0"; t.wideAfter < 2.5f -> "2"; t.wideAfter < 4.5f -> "3.5"; else -> "5" }) { t.wideAfter = it.toFloat() }
        }
        label(p, tx("شو بيصير تلقائيًا بهالقالب", "What happens automatically with this template"))
        for (l in PodTemplate.pacingInfo(t)) p.addView(UiKit.text(this, "• $l", 13.5f, UiKit.TEXT).apply { setPadding(0, dp(3), 0, dp(3)) })
        label(p, tx("الانتقال بين اللقطات", "Transition between shots"))
        chips(p, listOf("cut" to tx("قطع مباشر", "Direct cut"), "fade" to tx("تلاشي ناعم", "Soft fade")), if (t.fade) "fade" else "cut") { t.fade = it == "fade" }
        if (t.fade) chips(p, listOf("200" to "0.2 ث", "300" to "0.3 ث", "500" to "0.5 ث"), t.fadeMs.toString()) { t.fadeMs = it.toInt() }
        label(p, tx("اتجاه الفيديو النهائي", "Output orientation"))
        chips(p, listOf("auto" to tx("حسب الكاميرات", "By cameras"), "h" to "16:9", "v" to "9:16", "both" to tx("الاثنين", "Both")), t.orient) { t.orient = it }

        // ── المربع العائم
        if (t.pip) {
            val b = UiKit.section(this, opts, "tpl_pip", tx("المربع العائم", "Floating box"), TemplateActivity.summary(t).substringAfter(" · "), openByDefault = true)
            label(b, tx("المكان", "Position"))
            chips(b, listOf("tl" to tx("فوق يسار", "Top left"), "tr" to tx("فوق يمين", "Top right"), "custom" to tx("حر (اسحبه)", "Free (drag)"), "bl" to tx("تحت يسار", "Bottom left"), "br" to tx("تحت يمين", "Bottom right")), t.pipPos) { t.pipPos = it }
            note(b, tx("«حر»: اضغط «حرّك المربع» فوق واسحبه، وكبّره أو صغّره بإصبعين.", "“Free”: tap “Move the box” above and drag it; pinch to resize."))
            label(b, tx("مكانه بين اللقطات", "Placement between shots"))
            chips(b, listOf("fixed" to tx("نفس المكان", "Same place"), "person" to tx("حسب الشخص", "By person"), "alternate" to tx("يمين/يسار بالتناوب", "Alternate sides")), t.pipPlace) { t.pipPlace = it }
            note(b, when (t.pipPlace) { "person" -> tx("شخص ١ و٣ بمكانك المختار، وشخص ٢ و٤ بالجهة المقابلة.", "Persons 1 and 3 at your spot, 2 and 4 on the opposite side."); "alternate" -> tx("كل مربع جديد بيطلع بالجهة المقابلة للي قبله.", "Each new box appears on the side opposite the previous one."); else -> tx("دايمًا بنفس المكان.", "Always in the same place.") })
            slider(b, tx("الحجم", "Size"), 0.12f, 0.5f, t.pipSize, ::pct) { t.pipSize = it }
            label(b, tx("الشكل", "Shape"))
            chips(b, listOf("rect" to tx("مستطيل", "Rectangle"), "rounded" to tx("زوايا دائرية", "Rounded"), "circle" to tx("دائرة", "Circle"), "alternate" to tx("دائرة/مربع بالتناوب", "Circle/square alternating")), t.pipShape) { t.pipShape = it }
            if (t.pipShape == "rounded" || t.pipShape == "alternate") slider(b, tx("استدارة الزوايا", "Corner roundness"), 0f, 0.5f, t.pipRadius, ::pct) { t.pipRadius = it }
            label(b, tx("الإطار", "Border"))
            chips(b, listOf("0" to tx("بدون", "None"), "0.004" to tx("رفيع", "Thin"), "0.01" to tx("عريض", "Thick")), when { t.pipBorder <= 0f -> "0"; t.pipBorder < 0.007f -> "0.004"; else -> "0.01" }) { t.pipBorder = it.toFloat() }
            if (t.pipBorder > 0f) swatches(b, palette, t.pipBorderColor) { t.pipBorderColor = it }
            toggle(b, t.pipShadow, tx("ظل خفيف: نعم", "Soft shadow: yes"), tx("ظل خفيف: لا", "Soft shadow: no")) { t.pipShadow = it }
            label(b, tx("طريقة ظهوره", "How it appears"))
            chips(b, listOf("cut" to tx("مباشر", "Instant"), "fade" to tx("تلاشي", "Fade"), "slide" to tx("انزلاق من الجنب", "Slide in"), "zoom" to tx("تكبير", "Zoom in")), t.pipAnim) { t.pipAnim = it }
            if (t.pipAnim != "cut") chips(b, listOf("150" to tx("سريع", "Fast"), "250" to tx("عادي", "Normal"), "450" to tx("بطيء", "Slow")), t.pipAnimMs.toString()) { t.pipAnimMs = it.toInt() }
            if (t.pipPos != "custom") slider(b, tx("البعد عن الحواف", "Distance from edges"), 0f, 0.1f, t.pipMargin, ::pct) { t.pipMargin = it }
            label(b, tx("على الوجه", "On the face"))
            toggle(b, t.pipFace, tx("المربع مقرّب على وجه الشخص: نعم", "Box zoomed on the face: yes"), tx("المربع مقرّب على وجه الشخص: لا", "Box zoomed on the face: no")) { t.pipFace = it }
            if (t.pipFace) {
                chips(b, listOf("1.3" to tx("تقريب خفيف", "Light"), "1.6" to tx("متوسط", "Medium"), "2.2" to tx("قريب كثير", "Close")), String.format(Locale.US, "%.1f", t.faceZoom)) { t.faceZoom = it.toFloat() }
                if (t.pipShape != "circle") chips(b, listOf("square" to tx("مربع", "Square"), "portrait" to tx("طولي", "Portrait")), t.faceAspect) { t.faceAspect = it }
            }
            toggle(b, t.avoidFace, tx("ما يغطي وجه اللي بيحكي: نعم", "Never cover the speaker's face: yes"), tx("ما يغطي وجه اللي بيحكي: لا", "Never cover the speaker's face: no")) { t.avoidFace = it }
            if (t.pipFace || t.avoidFace) note(b, tx("بيحتاج تحليل الوجوه — بيصير تلقائيًا أول مرة بتعمل معاينة أو تصدير (بياخد شوي وقت). إذا كان مكان المربع فوق الوجه، بينتقل للجهة الثانية وبيبعد عن الحافة.", "Needs face analysis — done automatically on the first preview or export (takes a little time). If the box would sit on the face, it moves to the other side, away from the edge."))
        }

        // ── لما يحكوا مع بعض
        val m = UiKit.section(this, opts, "tpl_multi", tx("لما يحكوا مع بعض", "When several talk together"), if (t.multi == "boxes") tx("مربعات فوق خلفية", "Boxes over a background") else tx("شاشة مقسومة", "Split screen"))
        chips(m, listOf("split" to tx("شاشة مقسومة", "Split screen"), "boxes" to tx("مربعات فوق خلفية", "Boxes on a background")), t.multi) { t.multi = it }
        label(m, tx("الترتيب", "Arrangement"))
        chips(m, listOf("auto" to tx("تلقائي", "Auto"), "side" to tx("جنب بعض", "Side by side"), "stack" to tx("فوق بعض", "Stacked")), t.splitDir) { t.splitDir = it }
        if (t.multi == "split") {
            label(m, tx("الفاصل", "Divider"))
            chips(m, listOf("0" to tx("بدون", "None"), "0.004" to tx("رفيع", "Thin"), "0.012" to tx("عريض", "Wide")), when { t.gap <= 0f -> "0"; t.gap < 0.008f -> "0.004"; else -> "0.012" }) { t.gap = it.toFloat() }
            if (t.gap > 0f) swatches(m, palette, t.gapColor) { t.gapColor = it }
        } else {
            label(m, tx("لون الخلفية", "Background colour"))
            swatches(m, listOf(0xFF1B1D24.toInt(), 0xFF0B3D91.toInt(), 0xFF5B2C83.toInt(), 0xFF1E5631.toInt(), 0xFF7A1F1F.toInt(), 0xFFEDEDED.toInt()), t.bgColor) { t.bgColor = it }
            slider(m, tx("استدارة المربعات", "Box roundness"), 0f, 0.1f, t.boxRadius, ::pct) { t.boxRadius = it }
        }

        // ── اللي بيحكي
        val g = UiKit.section(this, opts, "tpl_glow", tx("إطار حول اللي بيحكي", "Frame around the speaker"), if (t.glow) tx("شغّال", "On") else tx("مطفي", "Off"))
        toggle(g, t.glow, tx("إطار مضيء: نعم", "Glow: yes"), tx("إطار مضيء: لا", "Glow: no")) { t.glow = it }
        if (t.glow) {
            swatches(g, palette, t.glowColor) { t.glowColor = it }
            chips(g, listOf("0.01" to tx("رفيع", "Thin"), "0.018" to tx("متوسط", "Medium"), "0.03" to tx("عريض", "Wide")), when { t.glowWidth < 0.014f -> "0.01"; t.glowWidth < 0.024f -> "0.018"; else -> "0.03" }) { t.glowWidth = it.toFloat() }
        }

        // ── الأسماء
        val n = UiKit.section(this, opts, "tpl_names", tx("أسماء الأشخاص على الفيديو", "Names on the video"), when (t.names) { "first" -> tx("أول مرة", "First time"); "switch" -> tx("كل ما يظهر", "Every time"); else -> tx("بدون", "None") })
        chips(n, listOf("never" to tx("بدون", "None"), "first" to tx("أول مرة بيظهر", "First appearance"), "switch" to tx("كل ما يظهر", "Every time")), t.names) { t.names = it }
        if (t.names != "never") {
            label(n, tx("المكان", "Position"))
            chips(n, listOf("tl" to tx("فوق يسار", "Top left"), "tr" to tx("فوق يمين", "Top right"), "bc" to tx("تحت بالنص", "Bottom centre"), "bl" to tx("تحت يسار", "Bottom left"), "br" to tx("تحت يمين", "Bottom right")), t.namePos) { t.namePos = it }
            swatches(n, palette, t.nameColor) { t.nameColor = it }
            note(n, tx("الاسم بيضل حوالي ٣ ثواني من بداية اللقطة. الأسماء من شاشة الجلسة (الأشخاص).", "The name stays about 3 seconds from the start of the shot. Names come from the session's People."))
        }

        // ── الثابتين
        val pn = UiKit.section(this, opts, "tpl_pin", tx("الأشخاص الثابتين", "Always-visible people"), tx("بتختارهم من المونتاج", "Chosen in the editor"))
        note(pn, tx("لما تثبّت شخص بالمونتاج، بيظهر بمربع صغير لما ما يكون باللقطة.", "When you pin a person in the editor, they show in a small box when they're not in the shot."))
        chips(pn, listOf("tl" to tx("فوق يسار", "Top left"), "tr" to tx("فوق يمين", "Top right"), "bl" to tx("تحت يسار", "Bottom left"), "br" to tx("تحت يمين", "Bottom right")), t.pinPos) { t.pinPos = it }
        slider(pn, tx("الحجم", "Size"), 0.12f, 0.35f, t.pinSize, ::pct) { t.pinSize = it }
        chips(pn, listOf("rect" to tx("مستطيل", "Rectangle"), "rounded" to tx("زوايا دائرية", "Rounded"), "circle" to tx("دائرة", "Circle")), t.pinShape) { t.pinShape = it }

        // ── باقي المونتاج
        val e = UiKit.section(this, opts, "tpl_edit", tx("باقي إعدادات المونتاج", "Other edit settings"), tx("الكادر، الزوم، الوجه", "Framing, zoom, face") + if (t.kind == "reel") tx("، الصمت", ", silence") else "")
        label(e, tx("طبيعة الحوار", "Conversation type"))
        chips(e, listOf("auto" to tx("تلقائي", "Auto"), "qa" to tx("سؤال وجواب", "Q&A"), "story" to tx("قصة", "Story"), "explain" to tx("شرح", "Explain"), "debate" to tx("نقاش سريع", "Debate"), "emotional" to tx("انفعالي", "Emotional")), t.style) { t.style = it }
        label(e, tx("الكاميرا داخل الإطار", "Camera inside the frame"))
        chips(e, listOf("smart" to tx("ذكي", "Smart"), "fit" to tx("الصورة كاملة", "Whole"), "fill" to tx("ملء مع قص", "Fill")), t.frame) { t.frame = it }
        label(e, tx("لما ما في فيديو لشخص", "When a person has no video"))
        chips(e, listOf("other" to tx("كاميرا ثانية", "Other camera"), "freeze" to tx("آخر صورة", "Last frame"), "card" to tx("بطاقة باسمه", "Name card")), t.fill) { t.fill = it }
        label(e, tx("لحظة قلب الكاميرا", "When a camera flips"))
        chips(e, listOf("freeze" to tx("آخر صورة", "Last frame"), "other" to tx("كاميرا ثانية", "Other camera"), "blur" to tx("تمويه", "Blur")), t.flipFill) { t.flipFill = it }
        label(e, tx("الزوم", "Zoom"))
        chips(e, listOf("off" to tx("مطفي", "Off"), "auto" to tx("تلقائي", "Auto")), if (t.zoomMode == "auto") "auto" else "off") { t.zoomMode = it }
        if (t.zoomMode == "auto") chips(e, listOf("1.08" to "1.08×", "1.12" to "1.12×", "1.15" to "1.15×", "1.2" to "1.20×"), String.format(Locale.US, "%.2f", t.zoomMax).trimEnd('0').trimEnd('.')) { t.zoomMax = it.toFloat() }
        toggle(e, t.faces, tx("الكادر بيلحق الوجه: نعم", "Frame follows the face: yes"), tx("الكادر بيلحق الوجه: لا", "Frame follows the face: no")) { t.faces = it }
        if (t.kind == "reel") {
            label(e, tx("قص الصمت", "Silence cuts"))
            chips(e, listOf("off" to tx("مطفي", "Off"), "light" to tx("خفيف", "Light"), "balanced" to tx("متوازن", "Balanced"), "intense" to tx("مكثّف", "Intense")), t.silence) { t.silence = it }
            toggle(e, t.titleOn, tx("عنوان بالبداية: نعم", "Opening title: yes"), tx("عنوان بالبداية: لا", "Opening title: no")) { t.titleOn = it }
        }

        // ── الكتابة
        val c = UiKit.section(this, opts, "tpl_caps", tx("الكتابة على الفيديو", "Captions"), tx("بتشتغل إذا في تفريغ للكلام", "Works when there's a transcript"))
        toggle(c, t.captions, tx("الكتابة: مفعّلة", "Captions: on"), tx("الكتابة: مطفية", "Captions: off")) { t.captions = it }
        if (t.captions) toggle(c, t.highlight, tx("تمييز الكلمات المهمة: نعم", "Highlight key words: yes"), tx("تمييز الكلمات المهمة: لا", "Highlight key words: no")) { t.highlight = it }
        chips(c, listOf("top" to tx("فوق", "Top"), "middle" to tx("بالنص", "Middle"), "bottom" to tx("تحت", "Bottom")), t.capPos) { t.capPos = it }
        chips(c, listOf("0.85" to tx("صغير", "Small"), "1.0" to tx("عادي", "Normal"), "1.2" to tx("كبير", "Large")), String.format(Locale.US, "%.2f", t.capSize).let { if (it == "1.00") "1.0" else it.trimEnd('0') }) { t.capSize = it.toFloat() }
        swatches(c, listOf(0xFFFFFFFF.toInt(), 0xFFFFD60A.toInt(), 0xFF3D8BFF.toInt(), 0xFF32D74B.toInt()), t.capColor) { t.capColor = it }
    }
}
