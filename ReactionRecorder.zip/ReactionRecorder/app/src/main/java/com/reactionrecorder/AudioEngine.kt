package com.reactionrecorder

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.math.max

/**
 * خط الصوت: ميكروفون + صوت التطبيقات الأخرى (AudioPlaybackCapture) → خلط → AAC.
 *
 *  mic thread ──► micQ ─┐
 *                        ├─► mixer thread ──► AudioEncoder ──► MuxerHolder
 *  src thread ──► srcQ ─┘
 *
 * ملاحظات مهمة:
 *  - AudioPlaybackCapture رسمي من Android 10. بعض التطبيقات تمنع التقاط صوتها (أو المحتوى المحمي بـ DRM)،
 *    وفي هذه الحالة يصل الصوت صامتًا — لا نحاول تجاوز ذلك. الحالة تظهر في [sourceStatus].
 *  - الميكروفون يلتقط صوت السماعة أيضًا (صدى). الحل الأفضل: سماعات رأس. خيار "Echo suppression"
 *    يستعمل مصدر VOICE_COMMUNICATION مع AEC/NS إذا وفّرها الجهاز.
 *  - كل الأوقات (PTS) مرتبطة بنفس ساعة النظام التي يستعملها الفيديو، مع استبعاد مدة الإيقاف المؤقت.
 */
class AudioEngine(
    private val micEnabled: Boolean,
    private val sourceEnabled: Boolean,
    private val projection: MediaProjection?,
    private val echoSuppress: Boolean,
    private val encoder: AudioEncoder,
    private val startNs: Long,
    private val pausedNanos: () -> Long,
    /** صوت المشغّل الداخلي (وضع Video file). إن وُجد لا نحتاج MediaProjection لصوت المصدر */
    private val feed: PlayerAudioFeed? = null,
    private val feedDelayMs: Int = 0,
) {
    private class Chunk(val data: ShortArray, val endNs: Long)

    @Volatile var micMuted = false
    @Volatile var micVol = 1f
    @Volatile var srcVol = 1f
    @Volatile var paused = false

    /** نص يُعرض للمستخدم عن حالة التقاط صوت المصدر */
    @Volatile var sourceStatus: String = ""
        private set
    @Volatile var micStatus: String = ""
        private set
    val hasMic get() = mic != null
    val hasSource get() = src != null
    val hasFeed get() = feed != null && sourceEnabled

    private var mic: AudioRecord? = null
    private var src: AudioRecord? = null
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null

    private val micQ = LinkedBlockingQueue<Chunk>(80)
    private val srcQ = LinkedBlockingQueue<Chunk>(80)
    private val tickQ = LinkedBlockingQueue<Chunk>(80)
    @Volatile private var running = false
    private val threads = ArrayList<Thread>()
    @Volatile private var lastPtsUs = 0L

    companion object {
        const val RATE = AudioEncoder.SAMPLE_RATE
        const val FRAMES = 1024 // كتلة واحدة = 1024 إطارًا ≈ 23ms
    }

    /** ينشئ كائنات AudioRecord فقط (بدون بدء الالتقاط). الجودة/التوفّر يظهران في micStatus/sourceStatus */
    @SuppressLint("MissingPermission")
    fun open() {
        if (micEnabled) {
            try {
                val srcType = if (echoSuppress) MediaRecorder.AudioSource.VOICE_COMMUNICATION else MediaRecorder.AudioSource.MIC
                val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val r = AudioRecord(srcType, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(min, FRAMES * 2) * 4)
                if (r.state == AudioRecord.STATE_INITIALIZED) {
                    mic = r
                    if (echoSuppress) {
                        if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(r.audioSessionId)?.also { it.enabled = true }
                        if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(r.audioSessionId)?.also { it.enabled = true }
                    }
                    micStatus = "Microphone: OK"
                } else {
                    r.release(); micStatus = "Microphone: unavailable"
                }
            } catch (t: Throwable) {
                micStatus = "Microphone: failed (${t.javaClass.simpleName})"
            }
        }
        if (sourceEnabled) {
            if (feed != null) {
                sourceStatus = "Video audio: OK"
            } else if (projection == null) {
                sourceStatus = "Source audio: needs screen capture"
            } else {
                try {
                    val cfg = AudioPlaybackCaptureConfiguration.Builder(projection)
                        .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                        .addMatchingUsage(AudioAttributes.USAGE_GAME)
                        .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                        .build()
                    val fmt = AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(RATE)
                        .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                        .build()
                    val r = AudioRecord.Builder()
                        .setAudioFormat(fmt)
                        .setBufferSizeInBytes(FRAMES * 4 * 8)
                        .setAudioPlaybackCaptureConfig(cfg)
                        .build()
                    if (r.state == AudioRecord.STATE_INITIALIZED) {
                        src = r
                        sourceStatus = "Source audio: capturing (apps that block capture stay silent)"
                    } else {
                        r.release(); sourceStatus = "Source audio: Android refused capture"
                    }
                } catch (t: Throwable) {
                    sourceStatus = "Source audio: not available (${t.javaClass.simpleName})"
                }
            }
        }
    }

    /** يبدأ الالتقاط والخلط. يُستدعى بعد تشغيل مُرمِّز AAC */
    fun go() {
        running = true
        if (feed != null) { feed.reset(feedDelayMs); feed.active = true }
        mic?.let { r -> r.startRecording(); threads.add(Thread({ readLoop(r, micQ, mono = true) }, "mic-read")) }
        src?.let { r -> r.startRecording(); threads.add(Thread({ readLoop(r, srcQ, mono = false) }, "src-read")) }
        if (mic == null && src == null) threads.add(Thread({ tickLoop() }, "audio-tick")) // ساعة بديلة عندما لا يوجد ميكروفون
        threads.add(Thread({ mixLoop() }, "audio-mix"))
        threads.forEach { it.start() }
    }

    private fun readLoop(r: AudioRecord, q: LinkedBlockingQueue<Chunk>, mono: Boolean) {
        val n = if (mono) FRAMES else FRAMES * 2
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO)
        while (running) {
            val buf = ShortArray(n)
            var got = 0
            while (got < n && running) {
                val rd = r.read(buf, got, n - got) // blocking
                if (rd < 0) return
                got += rd
            }
            if (got < n) return
            val data = if (mono) {
                val st = ShortArray(FRAMES * 2)
                for (i in 0 until FRAMES) { st[i * 2] = buf[i]; st[i * 2 + 1] = buf[i] }
                st
            } else buf
            if (!q.offer(Chunk(data, System.nanoTime()))) { q.poll(); q.offer(Chunk(data, System.nanoTime())) }
        }
    }

    /** مصدر توقيت بإيقاع الزمن الحقيقي (كتل صامتة) لحالة: لا ميكروفون ولا التقاط → فقط صوت المشغّل */
    private fun tickLoop() {
        val chunkNs = FRAMES * 1_000_000_000L / RATE
        var next = System.nanoTime() + chunkNs
        val silence = ShortArray(FRAMES * 2)
        while (running) {
            val now = System.nanoTime()
            if (next > now) {
                try { Thread.sleep((next - now) / 1_000_000L, ((next - now) % 1_000_000L).toInt()) } catch (_: InterruptedException) { return }
            }
            next += chunkNs
            if (!tickQ.offer(Chunk(silence, System.nanoTime()))) { tickQ.poll(); tickQ.offer(Chunk(silence, System.nanoTime())) }
        }
    }

    private fun mixLoop() {
        // المرجع الزمني: الميكروفون إن وُجد، وإلا التقاط الصوت، وإلا الساعة البديلة
        val kind = if (mic != null) 0 else if (src != null) 1 else 2
        val master = when (kind) { 0 -> micQ; 1 -> srcQ; else -> tickQ }
        val other = if (kind == 0) srcQ else null
        val chunkUs = FRAMES * 1_000_000L / RATE
        var framesOut = 0L
        var anchorUs = Long.MIN_VALUE
        val out = ShortArray(FRAMES * 2)
        val feedBuf = ShortArray(FRAMES * 2)
        val useFeed = feed != null && sourceEnabled
        while (running || master.isNotEmpty()) {
            val m = master.poll(100, TimeUnit.MILLISECONDS) ?: continue
            var o: Chunk? = null
            if (other != null) {
                while (other.size > 4) other.poll() // نحافظ على زمن تأخير صغير
                o = other.poll()
            }
            if (paused) continue
            if (useFeed) feed!!.read(feedBuf, FRAMES * 2)

            val gm = when (kind) { 0 -> if (micMuted) 0f else micVol; 1 -> srcVol; else -> 0f }
            val go = if (kind == 0) srcVol else 0f
            val gf = srcVol
            for (i in 0 until FRAMES * 2) {
                var v = m.data[i] * gm
                if (o != null) v += o.data[i] * go
                if (useFeed) v += feedBuf[i] * gf
                out[i] = if (v > 32767f) Short.MAX_VALUE else if (v < -32768f) Short.MIN_VALUE else v.toInt().toShort()
            }

            val wallUs = (m.endNs - startNs - pausedNanos()) / 1000L - chunkUs
            if (anchorUs == Long.MIN_VALUE) anchorUs = wallUs
            var pts = anchorUs + framesOut * 1_000_000L / RATE
            if (wallUs - pts > 40_000) { // تأخّر الالتقاط (فجوة) → نقفز للأمام ونُبقي التزامن
                anchorUs += wallUs - pts
                pts = wallUs
            }
            encoder.encode(out, max(pts, 0L))
            lastPtsUs = pts + chunkUs
            framesOut += FRAMES
        }
    }

    fun stop() {
        running = false
        feed?.active = false
        try { mic?.stop() } catch (_: Throwable) {}
        try { src?.stop() } catch (_: Throwable) {}
        threads.forEach { try { it.join(2000) } catch (_: Throwable) {} }
        try { aec?.release() } catch (_: Throwable) {}
        try { ns?.release() } catch (_: Throwable) {}
        try { mic?.release() } catch (_: Throwable) {}
        try { src?.release() } catch (_: Throwable) {}
        encoder.finish(lastPtsUs)
    }
}
