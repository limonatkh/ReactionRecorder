package com.reactionrecorder

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.Socket

/** قناة JSON سطر-بسطر فوق TCP. الإرسال من أي خيط آمن؛ القراءة من خيط واحد */
class SatSocket(val socket: Socket) {
    private val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
    private val out = socket.getOutputStream()

    init {
        try { socket.tcpNoDelay = true } catch (_: Throwable) {}
        try { socket.keepAlive = true } catch (_: Throwable) {}
    }

    @Synchronized
    fun send(o: JSONObject): Boolean = try {
        out.write((o.toString() + "\n").toByteArray(Charsets.UTF_8))
        out.flush()
        true
    } catch (_: Throwable) {
        false
    }

    /** يقرأ رسالة؛ null عند إغلاق الاتصال أو انتهاء المهلة أو رسالة غير صالحة */
    fun read(): JSONObject? = try {
        val line = reader.readLine()
        if (line == null) null else JSONObject(line)
    } catch (_: Throwable) {
        null
    }

    fun rawIn() = socket.getInputStream()
    fun rawOut() = socket.getOutputStream()

    fun close() { try { socket.close() } catch (_: Throwable) {} }
}

object SatNet {
    const val PORT = 47600
    const val VERSION = 1

    fun msg(type: String): JSONObject = JSONObject().put("t", type)

    /** نفس localIps بدون اسم الواجهة (لباركود الاقتران) */
    fun localIpsPlain(): List<String> = localIps().map { it.substringBefore(' ') }

    fun qrPayload(pin: String): String = "RRSAT1|" + localIpsPlain().joinToString(",") + "|" + PORT + "|" + pin

    /** عناوين IPv4 المحلية لهذا الجوال (واي فاي / هوتسبوت) */
    fun localIps(): List<String> {
        val res = ArrayList<String>()
        try {
            val en = NetworkInterface.getNetworkInterfaces()
            while (en != null && en.hasMoreElements()) {
                val ni = en.nextElement()
                if (!ni.isUp || ni.isLoopback) continue
                val addrs = ni.inetAddresses
                while (addrs.hasMoreElements()) {
                    val a = addrs.nextElement()
                    if (a is Inet4Address && a.isSiteLocalAddress) res.add(a.hostAddress + "  (" + ni.name + ")")
                }
            }
        } catch (_: Throwable) {
        }
        return res
    }
}
