package com.reactionrecorder

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.Socket

/** قناة JSON سطر-بسطر فوق TCP. الإرسال من أي خيط آمن؛ القراءة من خيط واحد */
class SatSocket(val socket: Socket) {
    private val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
    private val out = socket.getOutputStream()

    init {
        try { socket.tcpNoDelay = true } catch (_: Throwable) {}
        try { socket.keepAlive = true } catch (_: Throwable) {}
    }

    @Volatile private var closed = false
    private val lock = Any()
    /** كاتب خلفي للرسائل المرسلة من الخيط الرئيسي (أندرويد يمنع الشبكة على الخيط الرئيسي) */
    private val writer = java.util.concurrent.Executors.newSingleThreadExecutor()

    /**
     * يرسل رسالة. من خيط خلفي: كتابة مباشرة ويعيد النتيجة الفعلية.
     * من الخيط الرئيسي: تُرسل في الخلفية ويعيد true ما دام الاتصال مفتوحًا.
     */
    fun send(o: JSONObject): Boolean {
        if (closed) return false
        val bytes = (o.toString() + "\n").toByteArray(Charsets.UTF_8)
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            return try {
                writer.execute { write(bytes) }
                true
            } catch (_: Throwable) {
                false
            }
        }
        return write(bytes)
    }

    /** يرسل رسالة يُحسب وقتها لحظة الكتابة الفعلية (لقياس الساعة بدقة). من خيط خلفي فقط */
    fun sendStamped(build: (Long) -> JSONObject): Boolean {
        if (closed) return false
        return synchronized(lock) {
            try {
                val o = build(android.os.SystemClock.elapsedRealtimeNanos())
                out.write((o.toString() + "\n").toByteArray(Charsets.UTF_8))
                out.flush()
                true
            } catch (_: Throwable) {
                false
            }
        }
    }

    private fun write(bytes: ByteArray): Boolean = synchronized(lock) {
        try {
            out.write(bytes)
            out.flush()
            true
        } catch (_: Throwable) {
            false
        }
    }

    /** يقرأ رسالة؛ null عند إغلاق الاتصال أو انتهاء المهلة أو رسالة غير صالحة */
    fun read(): JSONObject? = try {
        val line = reader.readLine()
        if (line == null) null else JSONObject(line)
    } catch (_: Throwable) {
        null
    }

    fun rawIn() = socket.getInputStream()
    fun rawOut() = socket.getOutputStream()

    fun close() {
        closed = true
        try { socket.close() } catch (_: Throwable) {}
        try { writer.shutdown() } catch (_: Throwable) {}
    }
}

object SatNet {
    const val PORT = 47600
    const val VERSION = 1

    /** يحوّل الأرقام العربية/الفارسية إلى 0-9 (لوحات المفاتيح العربية) */
    fun normDigits(s: String): String = buildString {
        for (c in s) append(
            when (c) {
                in '\u0660'..'\u0669' -> '0' + (c - '\u0660')
                in '\u06F0'..'\u06F9' -> '0' + (c - '\u06F0')
                else -> c
            },
        )
    }

    fun msg(type: String): JSONObject = JSONObject().put("t", type)

    /** نفس localIps بدون اسم الواجهة (لباركود الاقتران) */
    fun localIpsPlain(): List<String> = localIps().map { it.substringBefore(' ') }

    fun qrPayload(pin: String, port: Int): String =
        "RRSAT1|" + localIpsPlain().joinToString(",") { "$it:$port" } + "|" + port + "|" + pin

    /** عناوين IPv4 المحلية لهذا الجوال (واي فاي / هوتسبوت) */
    fun localIps(): List<String> {
        val res = ArrayList<String>()
        try {
            val en = NetworkInterface.getNetworkInterfaces()
            while (en != null && en.hasMoreElements()) {
                val ni = en.nextElement()
                if (!ni.isUp || ni.isLoopback) continue
                val addrs = ni.inetAddresses
                while (addrs.hasMoreElements()) {
                    val a = addrs.nextElement()
                    if (a is Inet4Address && a.isSiteLocalAddress) res.add(a.hostAddress + "  (" + ni.name + ")")
                }
            }
        } catch (_: Throwable) {
        }
        return res
    }
}
