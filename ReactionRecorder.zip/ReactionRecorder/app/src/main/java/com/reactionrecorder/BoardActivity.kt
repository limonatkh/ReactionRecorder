package com.reactionrecorder

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import java.util.Locale
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * وضع الشرح: لوح رسم، قارئ PDF، وصفحة كتابة — داخل التطبيق نفسه.
 * التسجيل بيرسم "المسرح" مباشرة كمصدر فيديو (مش تصوير شاشة): ما بيطلع شريط الإشعارات ولا أي إشي من الجوال.
 * الصوت من المايك، وكاميرتك بمربع دائري (بتقدر تخفيها).
 */
class BoardActivity : BaseActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var stageBox: FrameLayout
    private lateinit var stage: FrameLayout
    private lateinit var board: BoardCanvas
    private lateinit var textEt: EditText
    private lateinit var panel: LinearLayout
    private lateinit var toolsBox: LinearLayout
    private lateinit var timeTv: TextView
    private lateinit var recBtn: Button
    private lateinit var holdStop: HoldButton
    private lateinit var liveRow: LinearLayout
    private lateinit var countTv: TextView
    private lateinit var monitor: SurfaceView
    private var portrait = false
    private var mode = "draw"
    private var pushThread: HandlerThread? = null
    private var pushH: Handler? = null
    private var lastPhase = RecorderState.Phase.IDLE

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r -> if (r.values.all { it } || hasCore()) startRec() }
    private val pickPdf = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) openPdf(u) }

    private fun dp(v: Int) = UiKit.dp(this, v)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun granted(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    private fun hasCore() = granted(Manifest.permission.RECORD_AUDIO) && granted(Manifest.permission.CAMERA)
    private val recording get() = RecorderState.isBusy && BoardBridge.surface != null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        portrait = getSharedPreferences("reaction_ui", MODE_PRIVATE).getBoolean("boardPortrait", false)
        requestedOrientation = if (portrait) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        board = BoardCanvas(this)
        textEt = EditText(this).apply {
            background = null; gravity = Gravity.TOP or Gravity.START; textSize = 30f; setTextColor(Color.parseColor("#1A1A1A"))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            isSingleLine = false; hint = tx("اكتب هون…", "Type here…"); setHintTextColor(Color.parseColor("#888888"))
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            setPadding(dp(18), dp(14), dp(18), dp(14)); visibility = View.GONE
        }
        buildLayout()
        RecorderState.addListener(stateL)
    }

    override fun onDestroy() {
        super.onDestroy()
        RecorderState.removeListener(stateL)
        stopPush()
        board.closePdf()
    }

    override fun onResume() { super.onResume(); ui.post(tick) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (RecorderState.isBusy) { toast(tx("أنهِ التسجيل أولًا (اضغط مطوّلًا على «إنهاء»)", "End the recording first (press and hold “End”)")); return }
        super.onBackPressed()
    }

    // ───────── الترتيب ─────────

    private fun buildLayout() {
        val root = LinearLayout(this).apply { orientation = if (portrait) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL; setBackgroundColor(Color.parseColor("#0D0E10")) }
        setContentView(root)
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars() or androidx.core.view.WindowInsetsCompat.Type.displayCutout() or androidx.core.view.WindowInsetsCompat.Type.ime())
            v.setPadding(b.left, b.top, b.right, b.bottom); insets
        }
        // المسرح (بنسبة الفيديو)
        stageBox = object : FrameLayout(this) {
            override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
                super.onLayout(changed, l, t, r, b)
                val W = r - l; val H = b - t
                val a = if (portrait) 9f / 16f else 16f / 9f
                var w = W; var h = (W / a).toInt()
                if (h > H) { h = H; w = (H * a).toInt() }
                val lp = stage.layoutParams as LayoutParams
                if (lp.width != w || lp.height != h) { lp.width = w; lp.height = h; lp.gravity = Gravity.CENTER; post { stage.layoutParams = lp } }
            }
        }
        stage = FrameLayout(this).apply { clipChildren = true }
        stage.addView(board, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        stage.addView(textEt, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        stageBox.addView(stage, FrameLayout.LayoutParams(dp(320), dp(180), Gravity.CENTER))
        countTv = UiKit.text(this, "", 90f, "#FFFFFF").apply { typeface = Fonts.bold; gravity = Gravity.CENTER; visibility = View.GONE; setShadowLayer(12f, 0f, 0f, Color.BLACK) }
        stageBox.addView(countTv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(stageBox, if (portrait) LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f) else LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))

        // اللوحة: التسجيل فوق، والأدوات تحت
        panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8)); setBackgroundColor(Color.parseColor("#17181C")) }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(UiKit.iconButton(this, if (L.ar) Ic.BACK else Ic.CHEV, tx("رجوع", "Back"), bgColor = null) { onBackPressedDispatcher.onBackPressed() })
        timeTv = UiKit.text(this, tx("شرح", "Lesson"), 18f, UiKit.TEXT).apply { typeface = Fonts.bold }
        head.addView(timeTv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        monitor = SurfaceView(this).apply { visibility = View.GONE; contentDescription = tx("معاينة الفيديو المسجّل", "Recorded video preview") }
        monitor.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(h: SurfaceHolder) { PreviewBridge.attach(h.surface) }
            override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) { PreviewBridge.attach(h.surface) }
            override fun surfaceDestroyed(h: SurfaceHolder) { PreviewBridge.detach() }
        })
        head.addView(monitor, LinearLayout.LayoutParams(if (portrait) dp(36) else dp(80), if (portrait) dp(64) else dp(45)))
        panel.addView(head)
        recBtn = UiKit.primary(this, "●  " + tx("سجّل", "Record"), UiKit.RED) { onRecord() }
        panel.addView(recBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)).apply { topMargin = dp(6) })
        liveRow = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val lr = LinearLayout(this)
        lr.addView(UiKit.chipIcon(this, Ic.PLAY, tx("إيقاف مؤقت", "Pause")) { togglePause() }.also { pauseBtn = it }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(6) })
        lr.addView(UiKit.chipIcon(this, Ic.CAM, tx("كاميرتي", "My camera")) { RecorderState.scene?.toggleCameraVisible(); toast(tx("انقلبت كاميرتك (ظاهرة/مخفية)", "Camera toggled (shown/hidden)")) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(6) })
        lr.addView(UiKit.chipIcon(this, Ic.MIC, tx("المايك", "Mic")) { val m = !RecorderState.micMuted; RecorderState.scene?.setMicMuted(m); toast(if (m) tx("المايك مكتوم", "Mic muted") else tx("المايك شغّال", "Mic on")) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        liveRow.addView(lr)
        holdStop = HoldButton(this, tx("إنهاء (اضغط مطوّلًا)", "End (press and hold)")) { stopRec() }
        holdStop.onShortTap = { toast(tx("اضغط مطوّلًا لحد ما يتعبّى الزر", "Press and hold until the button fills")) }
        liveRow.addView(holdStop, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)).apply { topMargin = dp(6) })
        panel.addView(liveRow)

        toolsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sv = ScrollView(this).apply { addView(toolsBox) }
        panel.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(6) })
        root.addView(panel, if (portrait) LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (resources.displayMetrics.heightPixels * 0.42f).toInt()) else LinearLayout.LayoutParams(min(dp(300), (resources.displayMetrics.widthPixels * 0.36f).toInt()), ViewGroup.LayoutParams.MATCH_PARENT))
        buildTools()
    }

    private var pauseBtn: Button? = null

    // ───────── الأدوات ─────────

    private fun row(): LinearLayout = LinearLayout(this).also { toolsBox.addView(it) }
    private fun cell(r: LinearLayout, v: View) = r.addView(v, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
    private fun small(label: String, sel: Boolean = false, run: () -> Unit) = UiKit.chip(this, label, sel) { run(); buildTools() }.apply { textSize = 13f; setPadding(dp(4), 0, dp(4), 0) }
    private fun title(s: String) = toolsBox.addView(UiKit.text(this, s, 13f, UiKit.SUB).apply { setPadding(dp(2), dp(10), 0, dp(2)) })

    private fun buildTools() {
        toolsBox.removeAllViews()
        // الوضع
        val m = row()
        for ((k, n) in listOf("draw" to tx("لوح", "Board"), "pdf" to "PDF", "text" to tx("كتابة", "Text"))) cell(m, small(n, mode == k) { setMode(k) })
        if (!RecorderState.isBusy) {
            val o = row()
            cell(o, small("16:9", !portrait) { setPortrait(false) })
            cell(o, small("9:16", portrait) { setPortrait(true) })
        }
        if (mode == "text") buildTextTools() else buildDrawTools()
    }

    private fun buildDrawTools() {
        if (mode == "pdf") {
            title(tx("الملف", "File"))
            val f = row()
            cell(f, small(tx("افتح PDF", "Open PDF")) { pickPdf.launch(arrayOf("application/pdf")) })
            if (board.pdfPages > 0) cell(f, small(tx("ملائمة", "Fit")) { board.resetView() })
            if (board.pdfPages == 0) toolsBox.addView(UiKit.text(this, tx("افتح ملف PDF وبعدين اكتب وعلّم عليه. إصبعين للتكبير والتحريك.", "Open a PDF, then write and mark on it. Two fingers to zoom and move."), 13f, UiKit.SUB))
        }
        title(tx("الأداة", "Tool"))
        val tools = listOf(BoardCanvas.PEN to tx("قلم", "Pen"), BoardCanvas.HL to tx("تمييز", "Highlight"), BoardCanvas.ERASE to tx("ممحاة", "Eraser"),
            BoardCanvas.LASER to tx("ليزر", "Laser"), BoardCanvas.LINE to tx("خط", "Line"), BoardCanvas.ARROW to tx("سهم", "Arrow"),
            BoardCanvas.RECT to tx("مربع", "Box"), BoardCanvas.OVAL to tx("دائرة", "Circle"))
        var r: LinearLayout? = null
        for ((i, t) in tools.withIndex()) { if (i % 3 == 0) r = row(); cell(r!!, small(t.second, board.tool == t.first) { board.tool = t.first }) }
        if (tools.size % 3 != 0) repeat(3 - tools.size % 3) { r!!.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) }
        title(tx("اللون", "Colour"))
        val cr = row()
        for (c in listOf(0xFF111111.toInt(), 0xFFFFFFFF.toInt(), 0xFFFF453A.toInt(), 0xFF3D8BFF.toInt(), 0xFF32D74B.toInt(), 0xFFFFD60A.toInt())) {
            cr.addView(View(this).apply {
                background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(c); setStroke(dp(if (board.color == c) 3 else 1), Color.parseColor(if (board.color == c) UiKit.BLUE else UiKit.LINE)) }
                contentDescription = tx("لون", "Colour"); setOnClickListener { board.color = c; buildTools() }
            }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
        }
        title(tx("السماكة", "Thickness"))
        val sr = row()
        for ((v, n) in listOf(0.003f to tx("رفيع", "Thin"), 0.006f to tx("وسط", "Medium"), 0.012f to tx("عريض", "Thick"))) cell(sr, small(n, abs(board.strokeW - v) < 0.0005f) { board.strokeW = v })
        val ur = row()
        cell(ur, UiKit.iconButton(this, Ic.UNDO, tx("تراجع", "Undo")) { board.undo() }.apply { layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f) })
        cell(ur, UiKit.iconButton(this, Ic.REDO, tx("إعادة", "Redo")) { board.redo() }.apply { layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f) })
        cell(ur, small(tx("امسح", "Clear")) { board.clearPage() })
        if (mode == "draw") {
            title(tx("الخلفية", "Background"))
            val br = row()
            for ((k, n) in listOf(BoardCanvas.BG_WHITE to tx("أبيض", "White"), BoardCanvas.BG_GRID to tx("مربعات", "Grid"), BoardCanvas.BG_BLACK to tx("أسود", "Black"))) cell(br, small(n, board.bg == k) { board.bg = k; board.invalidate() })
        }
        title(tx("الصفحة", "Page") + "  " + board.pageLabel())
        val pr = row()
        cell(pr, small(tx("السابقة", "Prev")) { board.prevPage() })
        cell(pr, small(tx("التالية", "Next")) { board.nextPage() })
        if (mode == "draw") cell(pr, small(tx("صفحة جديدة", "New page")) { board.addPage() })
    }

    // صفحات الكتابة
    private val textPages = arrayListOf("")
    private var textPage = 0
    private var textSize = 30f
    private var textColor = 0xFF1A1A1A.toInt()

    private fun buildTextTools() {
        title(tx("حجم الخط", "Text size"))
        val s = row()
        for ((v, n) in listOf(22f to tx("صغير", "Small"), 30f to tx("وسط", "Medium"), 44f to tx("كبير", "Large"), 60f to tx("ضخم", "Huge"))) cell(s, small(n, textSize == v) { textSize = v; textEt.textSize = v })
        title(tx("اللون", "Colour"))
        val cr = row()
        for (c in listOf(0xFF1A1A1A.toInt(), 0xFFFF453A.toInt(), 0xFF3D8BFF.toInt(), 0xFF1E8E3E.toInt())) {
            cr.addView(View(this).apply {
                background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(c); setStroke(dp(if (textColor == c) 3 else 1), Color.parseColor(if (textColor == c) UiKit.BLUE else UiKit.LINE)) }
                contentDescription = tx("لون", "Colour"); setOnClickListener { textColor = c; textEt.setTextColor(c); buildTools() }
            }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
        }
        title(tx("المحاذاة", "Alignment"))
        val a = row()
        cell(a, small(tx("بداية", "Start")) { textEt.gravity = Gravity.TOP or Gravity.START })
        cell(a, small(tx("بالنص", "Centre")) { textEt.gravity = Gravity.CENTER })
        title(tx("الصفحة", "Page") + "  ${textPage + 1}/${textPages.size}")
        val pr = row()
        cell(pr, small(tx("السابقة", "Prev")) { goText(textPage - 1) })
        cell(pr, small(tx("التالية", "Next")) { goText(textPage + 1) })
        cell(pr, small(tx("صفحة جديدة", "New page")) { textPages[textPage] = textEt.text.toString(); textPages.add(textPage + 1, ""); goText(textPage + 1) })
        toolsBox.addView(UiKit.text(this, tx("الكتابة على لوح أبيض، وبتنسجّل زي ما بتشوفها. تقدر ترجع للوح وترسم.", "You type on a white board and it's recorded as you see it. You can switch back to the board and draw."), 12.5f, UiKit.SUB).apply { setPadding(0, dp(8), 0, 0) })
    }

    private fun goText(i: Int) {
        if (i !in textPages.indices) return
        textPages[textPage] = textEt.text.toString()
        textPage = i
        textEt.setText(textPages[i])
    }

    private fun setMode(k: String) {
        if (mode == "text") textPages[textPage] = textEt.text.toString()
        mode = k
        board.setMode(k)
        textEt.visibility = if (k == "text") View.VISIBLE else View.GONE
        if (k == "text") { textEt.setText(textPages[textPage]); textEt.requestFocus() }
        else {
            textEt.clearFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).hideSoftInputFromWindow(textEt.windowToken, 0)
        }
        if (k == "pdf" && board.pdfPages == 0) pickPdf.launch(arrayOf("application/pdf"))
    }

    private fun setPortrait(p: Boolean) {
        if (portrait == p || RecorderState.isBusy) return
        portrait = p
        getSharedPreferences("reaction_ui", MODE_PRIVATE).edit().putBoolean("boardPortrait", p).apply()
        requestedOrientation = if (p) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        // نعيد بناء الترتيب مع نفس المحتوى
        (board.parent as? ViewGroup)?.removeView(board)
        (textEt.parent as? ViewGroup)?.removeView(textEt)
        buildLayout()
        setMode(mode)
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        stageBox.requestLayout()
    }

    private fun openPdf(u: Uri) {
        try {
            board.openPdf(contentResolver.openFileDescriptor(u, "r") ?: throw IllegalStateException("cannot open"))
            mode = "pdf"; board.setMode("pdf"); textEt.visibility = View.GONE
            buildTools()
        } catch (t: Throwable) { toast(tx("تعذر فتح الملف: ", "Could not open the file: ") + (t.message ?: "")) }
    }

    // ───────── التسجيل ─────────

    private fun onRecord() {
        if (RecorderState.isBusy) return
        if (PodRec.active != null) { toast(tx("في تسجيل بودكاست شغّال", "A podcast recording is running")); return }
        val need = ArrayList<String>()
        if (!granted(Manifest.permission.RECORD_AUDIO)) need += Manifest.permission.RECORD_AUDIO
        if (!granted(Manifest.permission.CAMERA)) need += Manifest.permission.CAMERA
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) perms.launch(need.toTypedArray()) else startRec()
    }

    private fun startRec() {
        if (!hasCore()) { toast(tx("بدها إذن المايك والكاميرا", "Needs mic and camera permission")); return }
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LOCKED
        ContextCompat.startForegroundService(this, Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_START)
            .putExtra(RecorderService.EXTRA_BOARD, true).putExtra(RecorderService.EXTRA_BOARD_PORTRAIT, portrait))
        startPush()
    }

    private fun stopRec() { startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP)) }

    private fun togglePause() {
        val paused = RecorderState.phase == RecorderState.Phase.PAUSED
        startService(Intent(this, RecorderService::class.java).setAction(if (paused) RecorderService.ACTION_RESUME else RecorderService.ACTION_PAUSE))
    }

    /** يرسم المسرح على سطح خدمة التسجيل ~25 مرة بالثانية (بخيط منفصل) */
    private fun startPush() {
        if (pushThread != null) return
        val th = HandlerThread("board-push").also { it.start() }
        pushThread = th
        pushH = Handler(th.looper)
        pushH?.post(push)
    }

    private fun stopPush() {
        pushH?.removeCallbacksAndMessages(null)
        pushThread?.quitSafely()
        pushThread = null; pushH = null
    }

    // مخزنين بالتناوب: الواجهة بترسم بواحد والخيط الثاني بيبعث الثاني
    private var bufs: Array<Bitmap>? = null
    @Volatile private var front = -1

    private val push = object : Runnable {
        override fun run() {
            val h = pushH ?: return
            val s = BoardBridge.surface
            val bs = bufs
            val f = front
            if (s != null && bs != null && f >= 0 && s.isValid) {
                val b = bs[f]
                try {
                    synchronized(b) {
                        val c = if (Build.VERSION.SDK_INT >= 23) s.lockHardwareCanvas() else s.lockCanvas(null)
                        c.drawColor(Color.BLACK)
                        c.drawBitmap(b, null, android.graphics.Rect(0, 0, BoardBridge.w, BoardBridge.h), null)
                        s.unlockCanvasAndPost(c)
                    }
                } catch (_: Throwable) {}
            }
            h.postDelayed(this, 40)
        }
    }

    /** لقطة من المسرح (على خيط الواجهة) — الخيط الثاني بيبعتها للتسجيل */
    private fun capture() {
        val w = BoardBridge.w; val h = BoardBridge.h
        if (stage.width <= 0 || stage.height <= 0) return
        var bs = bufs
        if (bs == null || bs[0].width != w || bs[0].height != h) { bs = arrayOf(Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888), Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)); bufs = bs; front = -1 }
        val back = if (front == 0) 1 else 0
        val b = bs[back]
        synchronized(b) {
            val c = Canvas(b)
            c.drawColor(Color.WHITE)
            c.scale(w.toFloat() / stage.width, h.toFloat() / stage.height)
            stage.draw(c)
        }
        front = back
    }

    private val stateL: () -> Unit = { ui.post { renderState() } }

    private fun renderState() {
        val ph = RecorderState.phase
        val busy = RecorderState.isBusy
        recBtn.visibility = if (busy) View.GONE else View.VISIBLE
        liveRow.visibility = if (busy && ph != RecorderState.Phase.STARTING) View.VISIBLE else View.GONE
        monitor.visibility = if (busy) View.VISIBLE else View.GONE
        countTv.visibility = if (ph == RecorderState.Phase.COUNTDOWN) View.VISIBLE else View.GONE
        countTv.text = RecorderState.countdownLeft.toString()
        pauseBtn?.text = if (ph == RecorderState.Phase.PAUSED) tx("كمّل", "Resume") else tx("إيقاف مؤقت", "Pause")
        if (lastPhase != ph) {
            if (ph == RecorderState.Phase.IDLE && lastPhase != RecorderState.Phase.IDLE) onFinished()
            lastPhase = ph
            buildTools()
        }
    }

    private fun onFinished() {
        stopPush()
        requestedOrientation = if (portrait) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        val uri = RecorderState.lastUri
        val err = RecorderState.lastError
        if (uri != null) {
            UiKit.sheet(this, tx("انحفظ الشرح", "Lesson saved")) { col, d ->
                col.addView(UiKit.text(this, tx("بالمعرض: Movies/ReactionRecorder", "In the Gallery: Movies/ReactionRecorder"), 14.5f, UiKit.SUB))
                val r = LinearLayout(this)
                r.addView(UiKit.chipIcon(this, Ic.PLAY, tx("شغّل", "Play")) {
                    try { startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) } catch (_: Throwable) {}
                }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(8) })
                r.addView(UiKit.chipIcon(this, Ic.SHARE, tx("شارك", "Share")) {
                    startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), tx("شارك", "Share")))
                }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                col.addView(r, UiKit.full(this, r, 12))
                val ok = UiKit.primary(this, tx("تمام", "Done")) { d.dismiss() }
                col.addView(ok, UiKit.full(this, ok, 12))
            }
        } else if (err != null) AlertDialog.Builder(this).setMessage(err).setPositiveButton(tx("تمام", "OK"), null).show()
    }

    private val tick = object : Runnable {
        override fun run() {
            if (RecorderState.isBusy) {
                capture()
                val ms = RecorderState.elapsedMs()
                val sec = ms / 1000
                timeTv.text = (if (RecorderState.phase == RecorderState.Phase.PAUSED) "❚❚ " else "● ") + String.format(Locale.US, "%d:%02d", sec / 60, sec % 60)
                timeTv.setTextColor(Color.parseColor(if (RecorderState.phase == RecorderState.Phase.PAUSED) UiKit.ORANGE else UiKit.RED))
            } else { timeTv.text = tx("شرح", "Lesson"); timeTv.setTextColor(Color.parseColor(UiKit.TEXT)) }
            renderState()
            ui.postDelayed(this, 40)
        }
    }
}

/**
 * لوح الرسم: صفحات، أدوات (قلم، تمييز، ممحاة، ليزر، أشكال)، وخلفيات؛ وفي وضع PDF بيرسم الصفحة
 * وتحتها التعليقات (بإحداثيات الصفحة، فبتضل مكانها مع التكبير والتحريك).
 */
class BoardCanvas(ctx: Context) : View(ctx) {
    companion object {
        const val PEN = 0; const val HL = 1; const val ERASE = 2; const val LASER = 3; const val LINE = 4; const val ARROW = 5; const val RECT = 6; const val OVAL = 7
        const val BG_WHITE = 0; const val BG_GRID = 1; const val BG_BLACK = 2
    }

    /** خط مرسوم بإحداثيات نسبية (x/عرض المرجع، y/عرض المرجع) */
    class Stroke(val tool: Int, val color: Int, val width: Float) { val pts = ArrayList<Float>() }
    private sealed class Act { class Add(val s: Stroke) : Act(); class Remove(val list: List<Stroke>) : Act(); class Clear(val list: List<Stroke>) : Act() }
    class Page { val strokes = ArrayList<Stroke>(); val undo = ArrayList<Any>(); val redo = ArrayList<Any>() }

    var tool = PEN
    var color = 0xFF111111.toInt()
    var strokeW = 0.006f
    var bg = BG_WHITE
    private var mode = "draw"
    private val pages = arrayListOf(Page())
    private var page = 0
    private val pdfAnn = HashMap<Int, Page>()
    private var pdfPage = 0
    var pdfPages = 0
        private set
    private var renderer: PdfRenderer? = null
    private var pfd: ParcelFileDescriptor? = null
    private var pdfBmp: Bitmap? = null
    private var pdfBmpPage = -1
    // عرض الـ PDF: تكبير وتحريك
    private var zoom = 1f
    private var panX = 0f
    private var panY = 0f
    private var cur: Stroke? = null
    private class LP(val x: Float, val y: Float, val t: Long)
    private val laser = ArrayList<LP>()

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmpP = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    private fun curPage(): Page = if (mode == "pdf") pdfAnn.getOrPut(pdfPage) { Page() } else pages[page]

    fun setMode(m: String) { mode = m; invalidate() }

    fun pageLabel(): String = if (mode == "pdf") (if (pdfPages > 0) "${pdfPage + 1}/$pdfPages" else "—") else "${page + 1}/${pages.size}"

    fun prevPage() { if (mode == "pdf") { if (pdfPage > 0) { pdfPage--; resetView() } } else if (page > 0) page--; invalidate() }
    fun nextPage() { if (mode == "pdf") { if (pdfPage < pdfPages - 1) { pdfPage++; resetView() } } else if (page < pages.size - 1) page++; invalidate() }
    fun addPage() { pages.add(page + 1, Page()); page++; invalidate() }

    fun resetView() { zoom = 1f; panX = 0f; panY = 0f; invalidate() }

    fun undo() { val p = curPage(); val a = p.undo.removeLastOrNull() as? Act ?: return; revert(p, a); p.redo.add(a); invalidate() }
    fun redo() { val p = curPage(); val a = p.redo.removeLastOrNull() as? Act ?: return; apply(p, a); p.undo.add(a); invalidate() }
    fun clearPage() { val p = curPage(); if (p.strokes.isEmpty()) return; val a = Act.Clear(p.strokes.toList()); apply(p, a); p.undo.add(a); p.redo.clear(); invalidate() }

    private fun apply(p: Page, a: Act) { when (a) { is Act.Add -> p.strokes.add(a.s); is Act.Remove -> p.strokes.removeAll(a.list.toSet()); is Act.Clear -> p.strokes.clear() } }
    private fun revert(p: Page, a: Act) { when (a) { is Act.Add -> p.strokes.remove(a.s); is Act.Remove -> p.strokes.addAll(a.list); is Act.Clear -> p.strokes.addAll(a.list) } }

    fun openPdf(f: ParcelFileDescriptor) {
        closePdf()
        pfd = f
        val r = PdfRenderer(f)
        renderer = r
        pdfPages = r.pageCount
        pdfPage = 0; pdfAnn.clear(); resetView()
    }

    fun closePdf() {
        try { renderer?.close() } catch (_: Throwable) {}
        try { pfd?.close() } catch (_: Throwable) {}
        renderer = null; pfd = null; pdfPages = 0; pdfBmp?.recycle(); pdfBmp = null; pdfBmpPage = -1
    }

    /** مستطيل الصفحة على الشاشة (ملاءمة + تكبير + تحريك) */
    private val pageRect = RectF()
    private fun layoutPdf() {
        val r = renderer ?: return
        if (pdfBmpPage != pdfPage) {
            try {
                val pg: PdfRenderer.Page = r.openPage(pdfPage)
                try {
                    val sc = (max(width, height) * 1.6f / max(pg.width, pg.height).toFloat()).coerceAtMost(4f)
                    val bw = (pg.width * sc).toInt().coerceIn(1, 2600); val bh = (pg.height * sc).toInt().coerceIn(1, 2600)
                    val b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
                    b.eraseColor(Color.WHITE)
                    pg.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    pdfBmp?.recycle(); pdfBmp = b; pdfBmpPage = pdfPage
                } finally { pg.close() }
            } catch (_: Throwable) {}
        }
        val b = pdfBmp ?: return
        val s = min(width / b.width.toFloat(), height / b.height.toFloat()) * zoom
        val w = b.width * s; val h = b.height * s
        val x = (width - w) / 2f + panX; val y = (height - h) / 2f + panY
        pageRect.set(x, y, x + w, y + h)
    }

    /** المرجع للإحداثيات النسبية: المسرح كله (لوح) أو الصفحة (PDF) */
    private fun ref(): RectF = if (mode == "pdf" && pdfPages > 0) pageRect else RectF(0f, 0f, width.toFloat(), height.toFloat())

    override fun onDraw(c: Canvas) {
        when {
            mode == "pdf" -> {
                c.drawColor(Color.parseColor("#3A3D45"))
                if (pdfPages > 0) { layoutPdf(); pdfBmp?.let { c.drawBitmap(it, null, pageRect, bmpP) } }
            }
            mode == "text" || bg == BG_WHITE -> c.drawColor(Color.WHITE)
            bg == BG_BLACK -> c.drawColor(Color.parseColor("#1E2421"))
            else -> {
                c.drawColor(Color.WHITE)
                fill.color = 0xFFE3E8EF.toInt(); fill.strokeWidth = 1.5f
                val step = width / 24f
                var x = step; while (x < width) { c.drawLine(x, 0f, x, height.toFloat(), fill); x += step }
                var y = step; while (y < height) { c.drawLine(0f, y, width.toFloat(), y, fill); y += step }
            }
        }
        if (mode == "text") return
        val R = ref()
        for (s in curPage().strokes) drawStroke(c, s, R)
        cur?.let { drawStroke(c, it, R) }
        // الليزر: أثر أحمر بيختفي خلال ثانية
        val now = SystemClock.uptimeMillis()
        laser.removeAll { now - it.t > 900 }
        if (laser.isNotEmpty()) {
            for (i in 1 until laser.size) {
                val a = 1f - (now - laser[i].t) / 900f
                paint.color = Color.argb((230 * a).toInt().coerceIn(0, 255), 255, 59, 48); paint.strokeWidth = R.width() * 0.008f; paint.pathEffect = null
                c.drawLine(R.left + laser[i - 1].x * R.width(), R.top + laser[i - 1].y * R.width(), R.left + laser[i].x * R.width(), R.top + laser[i].y * R.width(), paint)
            }
            val l = laser.last(); fill.color = 0xFFFF3B30.toInt()
            c.drawCircle(R.left + l.x * R.width(), R.top + l.y * R.width(), R.width() * 0.008f, fill)
            postInvalidateDelayed(30)
        }
    }

    private fun drawStroke(c: Canvas, s: Stroke, R: RectF) {
        if (s.pts.size < 2) return
        paint.color = s.color
        paint.strokeWidth = s.width * R.width() * (if (s.tool == HL) 3.2f else 1f)
        paint.alpha = if (s.tool == HL) 90 else 255
        paint.pathEffect = null
        fun X(i: Int) = R.left + s.pts[i] * R.width()
        fun Y(i: Int) = R.top + s.pts[i + 1] * R.width()
        val n = s.pts.size
        when (s.tool) {
            LINE, ARROW, RECT, OVAL -> {
                val x0 = X(0); val y0 = Y(0); val x1 = X(n - 2); val y1 = Y(n - 2)
                when (s.tool) {
                    LINE -> c.drawLine(x0, y0, x1, y1, paint)
                    ARROW -> {
                        c.drawLine(x0, y0, x1, y1, paint)
                        val ang = Math.atan2((y1 - y0).toDouble(), (x1 - x0).toDouble())
                        val len = paint.strokeWidth * 4f
                        for (d in listOf(2.6, -2.6)) c.drawLine(x1, y1, x1 + (len * Math.cos(ang + d)).toFloat(), y1 + (len * Math.sin(ang + d)).toFloat(), paint)
                    }
                    RECT -> c.drawRect(min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1), paint)
                    else -> c.drawOval(min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1), paint)
                }
            }
            else -> {
                val p = Path()
                p.moveTo(X(0), Y(0))
                var i = 2
                while (i < n) { val mx = (X(i - 2) + X(i)) / 2f; val my = (Y(i - 2) + Y(i)) / 2f; p.quadTo(X(i - 2), Y(i - 2), mx, my); i += 2 }
                p.lineTo(X(n - 2), Y(n - 2))
                c.drawPath(p, paint)
            }
        }
        paint.alpha = 255
    }

    // ───────── اللمس ─────────

    private var panning = false
    private var lastMx = 0f
    private var lastMy = 0f
    private val scaler = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            if (mode != "pdf" || pdfPages == 0) return false
            val nz = (zoom * d.scaleFactor).coerceIn(1f, 6f)
            val k = nz / zoom
            panX = (panX - (d.focusX - width / 2f)) * k + (d.focusX - width / 2f)
            panY = (panY - (d.focusY - height / 2f)) * k + (d.focusY - height / 2f)
            zoom = nz; invalidate(); return true
        }
    })

    @android.annotation.SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (mode == "text") return false
        scaler.onTouchEvent(e)
        if (e.pointerCount >= 2) {
            // إصبعين: تحريك/تكبير (PDF)، ونلغي الخط اللي بلش
            if (cur != null) { cur = null; invalidate() }
            val mx = (e.getX(0) + e.getX(1)) / 2f; val my = (e.getY(0) + e.getY(1)) / 2f
            if (!panning || e.actionMasked == MotionEvent.ACTION_POINTER_DOWN) { panning = true; lastMx = mx; lastMy = my }
            else if (mode == "pdf") { panX += mx - lastMx; panY += my - lastMy; lastMx = mx; lastMy = my; invalidate() }
            return true
        }
        if (panning) { if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) panning = false; return true }
        val R = ref()
        if (R.width() <= 0f) return true
        val nx = (e.x - R.left) / R.width(); val ny = (e.y - R.top) / R.width()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                when (tool) {
                    LASER -> { laser.add(LP(nx, ny, SystemClock.uptimeMillis())); invalidate() }
                    ERASE -> eraseAt(nx, ny)
                    else -> { cur = Stroke(tool, color, strokeW).also { it.pts.add(nx); it.pts.add(ny) }; invalidate() }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                when (tool) {
                    LASER -> { laser.add(LP(nx, ny, SystemClock.uptimeMillis())); invalidate() }
                    ERASE -> eraseAt(nx, ny)
                    else -> cur?.let { s ->
                        if (s.tool in listOf(LINE, ARROW, RECT, OVAL) && s.pts.size >= 4) { s.pts[s.pts.size - 2] = nx; s.pts[s.pts.size - 1] = ny }
                        else { val lx = s.pts[s.pts.size - 2]; val ly = s.pts[s.pts.size - 1]; if (hypot(nx - lx, ny - ly) > 0.0015f || s.pts.size < 4) { s.pts.add(nx); s.pts.add(ny) } }
                        invalidate()
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                cur?.let { s -> if (s.pts.size >= 4 || s.tool == PEN || s.tool == HL) { if (s.pts.size < 4) { s.pts.add(nx + 0.0005f); s.pts.add(ny) }; val p = curPage(); val a = Act.Add(s); apply(p, a); p.undo.add(a); p.redo.clear() } }
                cur = null; invalidate()
            }
        }
        return true
    }

    private fun eraseAt(nx: Float, ny: Float) {
        val p = curPage()
        val r = 0.02f
        val hit = p.strokes.filter { s -> var k = 0; var h = false; while (k < s.pts.size - 1) { if (abs(s.pts[k] - nx) < r && abs(s.pts[k + 1] - ny) < r) { h = true; break }; k += 2 }; h }
        if (hit.isEmpty()) return
        val a = Act.Remove(hit); apply(p, a); p.undo.add(a); p.redo.clear(); invalidate()
    }
}
