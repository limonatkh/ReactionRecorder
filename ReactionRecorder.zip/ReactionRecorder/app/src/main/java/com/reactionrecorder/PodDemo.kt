package com.reactionrecorder

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import kotlin.math.max
import kotlin.math.min

/**
 * نموذج مصغّر لشكل الفيديو بعد المونتاج — بنفس هندسة المونتاج الحقيقي (PodcastRenderer):
 *  • demo: مشهد متكرر ~6 ثواني (واحد بيحكي ← التاني بيرد ← مقاطعة ← نقاش مع بعض).
 *  • live: شو كان رح يطلع هلأ حسب مين بيحكي فعليًا (مستوى المايكات) وبصور الكاميرات الحية.
 */
class LayoutDemoView(ctx: Context) : View(ctx) {
    var landscape = true
    var names: List<String> = listOf("1", "2")
    var hasCam: List<Boolean> = listOf(true, true)
    var pip = true
    var boxes = false
    /** فلوق: switch / grid / mainboxes، أو null للحوار */
    var vlogLayout: String? = null
    var glow = true
    var live = false
    var frames: List<Bitmap?> = emptyList()
    var liveSpeakers: IntArray = IntArray(0)
    /** يُستدعى مع وصف المشهد الحالي (للنص تحت النموذج) */
    var onCaption: ((String) -> Unit)? = null

    private val t0 = SystemClock.uptimeMillis()
    private var lastCaption = ""
    private var liveMain = 0
    private var baseTs = 14f
    private val colors = intArrayOf(0xFF2F6FED.toInt(), 0xFFE0533D.toInt(), 0xFF2EA86B.toInt(), 0xFFB45CE0.toInt(), 0xFFE0A33D.toInt())
    private val pFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pBmp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val pTxt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true }
    private val pGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFFFFD60A.toInt() }
    private val pEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0x88FFFFFF.toInt(); strokeWidth = 2f }

    private class Scene(val type: Int, val main: Int, val others: IntArray, val speak: IntArray, val cap: String)

    private fun n() = names.size
    private fun lbl(i: Int) = tx("شخص ${i + 1}", "Person ${i + 1}")

    /** المشاهد حسب الإعداد — نفس قرارات المونتاج التلقائي */
    private fun script(): List<Scene> {
        val n = n()
        if (n <= 1) return listOf(Scene(PodShot.FULL, 0, IntArray(0), intArrayOf(0), tx("كاميرا وحدة — الفيديو كله منها", "One camera — the whole video uses it")))
        val all = (0 until n).toList().toIntArray()
        when (vlogLayout) {
            "grid" -> return listOf(
                Scene(PodShot.MULTI, 0, all, intArrayOf(0), tx("الكل ظاهر طول الوقت — ${lbl(0)} بيحكي", "Everyone shown — ${lbl(0)} speaks")),
                Scene(PodShot.MULTI, 0, all, intArrayOf(1), tx("الكل ظاهر — ${lbl(1)} بيحكي (الإطار المضيء بينتقل)", "Everyone shown — ${lbl(1)} speaks (the glow moves)")),
            )
            "mainboxes" -> return listOf(
                Scene(PodShot.FULL, 0, IntArray(0), intArrayOf(0), tx("${lbl(0)} بملء الشاشة، والباقي مربعات ثابتة", "${lbl(0)} full screen, the rest in fixed boxes")),
                Scene(PodShot.FULL, 0, IntArray(0), intArrayOf(1), tx("${lbl(1)} بيحكي — المربعات ما بتتحرك", "${lbl(1)} speaks — the boxes stay put")),
            )
        }
        val list = ArrayList<Scene>()
        list += Scene(PodShot.FULL, 0, IntArray(0), intArrayOf(0), tx("${lbl(0)} بيحكي ← بملء الشاشة", "${lbl(0)} speaks ← full screen"))
        list += Scene(PodShot.FULL, 1, IntArray(0), intArrayOf(1), tx("${lbl(1)} بيرد ← الكاميرا بتنتقل عليه", "${lbl(1)} replies ← the camera switches to them"))
        list += if (pip) Scene(PodShot.PIP, 1, intArrayOf(0), intArrayOf(0, 1), tx("${lbl(0)} قاطعه ← بيطلع بمربع عائم", "${lbl(0)} interrupts ← appears in a floating box"))
        else Scene(PodShot.MULTI, 0, intArrayOf(0, 1), intArrayOf(0, 1), tx("${lbl(0)} قاطعه ← الشاشة بتنقسم", "${lbl(0)} interrupts ← the screen splits"))
        list += Scene(PodShot.MULTI, 0, all, all, tx("نقاش سريع مع بعض ← الكل مع بعض", "Fast back-and-forth ← everyone together") + if (boxes) tx(" (مربعات فوق خلفية)", " (boxes over a background)") else "")
        return list
    }

    private fun liveScene(): Scene {
        val sp = liveSpeakers
        val n = n()
        if (n <= 1) return Scene(PodShot.FULL, 0, IntArray(0), sp, if (sp.isEmpty()) tx("ما حدا بيحكي", "Nobody is speaking") else tx("بيحكي", "Speaking"))
        val all = (0 until n).toList().toIntArray()
        when (vlogLayout) {
            "grid" -> return Scene(PodShot.MULTI, 0, all, sp, tx("الكل ظاهر", "Everyone shown"))
            "mainboxes" -> return Scene(PodShot.FULL, 0, IntArray(0), sp, tx("الرئيسي ثابت والباقي مربعات", "Main fixed, the rest in boxes"))
        }
        return when {
            sp.isEmpty() -> Scene(PodShot.FULL, liveMain, IntArray(0), sp, tx("ما حدا بيحكي ← بتضل آخر لقطة", "Nobody speaks ← the last shot stays"))
            sp.size == 1 -> { liveMain = sp[0]; Scene(PodShot.FULL, sp[0], IntArray(0), sp, "${names[sp[0]]} " + tx("بيحكي ← بملء الشاشة", "speaks ← full screen")) }
            pip -> {
                val m = if (liveMain in sp) liveMain else sp[0]
                liveMain = m
                Scene(PodShot.PIP, m, sp.filter { it != m }.toIntArray(), sp, tx("حدا قاطع ${names[m]} ← مربع عائم", "Someone interrupts ${names[m]} ← floating box"))
            }
            else -> Scene(PodShot.MULTI, sp[0], sp, sp, tx("بيحكوا مع بعض ← الشاشة مقسومة", "Talking together ← split screen"))
        }
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        val h = if (landscape) w * 9 / 16 else min(w * 16 / 9, (resources.displayMetrics.density * 380).toInt())
        setMeasuredDimension(w, h)
    }

    private fun shotFor(cam: Int): Int {
        // شخص بلا كاميرا: المونتاج بيعرض كاميرا ثانية مكانه
        if (hasCam.getOrNull(cam) == true) return cam
        return hasCam.indexOfFirst { it }.takeIf { it >= 0 } ?: cam
    }

    override fun onDraw(c: Canvas) {
        val sc: Scene = if (live) liveScene() else {
            val s = script()
            val i = (((SystemClock.uptimeMillis() - t0) / 1600L) % s.size).toInt()
            s[i]
        }
        if (sc.cap != lastCaption) { lastCaption = sc.cap; onCaption?.invoke(sc.cap) }
        // إطار الفيديو بنسبة الإخراج
        val a = if (landscape) 16f / 9f else 9f / 16f
        val s = min(width / a, height.toFloat())
        val W = s * a; val H = s
        val ox = (width - W) / 2f; val oy = (height - H) / 2f
        pFill.color = Color.BLACK
        c.drawRect(ox, oy, ox + W, oy + H, pFill)
        baseTs = max(11f, H / 14f)
        pGlow.strokeWidth = max(3f, H / 70f)
        val vertical = !landscape
        when (sc.type) {
            PodShot.FULL -> tile(c, shotFor(sc.main), sc.main, ox, oy, W, H, 0f, sc.speak, sc.main in sc.speak && glow && n() > 1)
            PodShot.PIP -> {
                tile(c, shotFor(sc.main), sc.main, ox, oy, W, H, 0f, sc.speak, false)
                val pw = if (vertical) W * 0.40f else W * 0.28f
                val ph = if (vertical) pw * 4f / 3f else pw * 9f / 16f
                val px = ox + W - pw - W * 0.04f
                val py = oy + if (vertical) H * 0.80f - ph else H - ph - H * 0.05f
                for ((i, o) in sc.others.withIndex()) {
                    val yy = py - i * (ph + H * 0.03f)
                    pFill.color = Color.WHITE
                    val b = max(2f, H / 120f)
                    c.drawRoundRect(RectF(px - b, yy - b, px + pw + b, yy + ph + b), ph * 0.1f + b, ph * 0.1f + b, pFill)
                    tile(c, shotFor(o), o, px, yy, pw, ph, ph * 0.1f, sc.speak, glow && o in sc.speak)
                }
            }
            else -> {
                val who = sc.others
                val pad = if (boxes) H * 0.08f else 0f
                if (boxes) { pFill.color = 0xFF1B1D24.toInt(); c.drawRect(ox, oy, ox + W, oy + H, pFill) }
                val cells = grid(who.size, vertical, ox + pad, oy + pad, W - 2 * pad, H - 2 * pad, if (boxes) H * 0.04f else max(2f, H / 180f))
                for ((i, r) in cells.withIndex()) tile(c, shotFor(who[i]), who[i], r[0], r[1], r[2], r[3], if (boxes) H * 0.035f else 0f, sc.speak, glow && who.size > 1 && who[i] in sc.speak)
            }
        }
        // فلوق "رئيسي + مربعات": الباقي ثابتين فوق
        if (vlogLayout == "mainboxes" && n() > 1) {
            val pw = if (vertical) W * 0.30f else W * 0.20f
            val ph = if (vertical) pw * 4f / 3f else pw * 9f / 16f
            for ((k, p) in (1 until n()).withIndex()) {
                val px = ox + W * 0.03f + k * (pw + W * 0.02f)
                val py = oy + if (vertical) H * 0.10f else H * 0.05f
                tile(c, shotFor(p), p, px, py, pw, ph, ph * 0.1f, sc.speak, glow && p in sc.speak)
            }
        }
        c.drawRect(ox, oy, ox + W, oy + H, pEdge)
        postInvalidateDelayed(80)
    }

    private fun grid(n: Int, vertical: Boolean, x: Float, y: Float, w: Float, h: Float, gap: Float): List<FloatArray> {
        val cols = if (vertical) (if (n >= 4) 2 else 1) else when (n) { 1 -> 1; 2 -> 2; 3 -> 3; else -> 2 }
        val rows = if (vertical) (if (n >= 4) 2 else n) else (if (n >= 4) 2 else 1)
        val cw = (w - gap * (cols - 1)) / cols
        val ch = (h - gap * (rows - 1)) / rows
        return (0 until n).map { i -> floatArrayOf(x + (i % cols) * (cw + gap), y + (i / cols) * (ch + gap), cw, ch) }
    }

    /** مربع شخص: صورة الكاميرا الحية (live) أو لون + اسم (demo) */
    private fun tile(c: Canvas, cam: Int, person: Int, x: Float, y: Float, w: Float, h: Float, r: Float, speak: IntArray, glowOn: Boolean) {
        val rect = RectF(x, y, x + w, y + h)
        val bmp = if (live) frames.getOrNull(cam) else null
        c.save()
        val path = android.graphics.Path().apply { addRoundRect(rect, r, r, android.graphics.Path.Direction.CW) }
        c.clipPath(path)
        if (bmp != null) {
            // الكاميرا بتعبّي المربع (نفس المونتاج) — قص من النص
            val sa = bmp.width.toFloat() / bmp.height; val da = w / h
            val src = if (sa > da) { val k = bmp.height * da; android.graphics.Rect(((bmp.width - k) / 2).toInt(), 0, ((bmp.width + k) / 2).toInt(), bmp.height) }
            else { val k = bmp.width / da; android.graphics.Rect(0, ((bmp.height - k) / 2).toInt(), bmp.width, ((bmp.height + k) / 2).toInt()) }
            c.drawBitmap(bmp, src, rect, pBmp)
        } else {
            pFill.color = colors[cam % colors.size]
            c.drawRect(rect, pFill)
        }
        c.restore()
        // الاسم
        val label = (if (person in speak) "🗣 " else "") + lbl(person) + (if (cam != person) " 🎤" else "")
        val ts = min(baseTs, h / 4.5f).coerceAtLeast(9f)
        pTxt.textSize = ts
        if (bmp != null) { pFill.color = 0x99000000.toInt(); c.drawRect(x, y + h - ts * 1.6f, x + w, y + h, pFill); c.drawText(label, x + w / 2, y + h - ts * 0.45f, pTxt) }
        else {
            c.drawText(label, x + w / 2, y + h / 2 - ts * 0.1f, pTxt)
            val nm = names.getOrNull(person) ?: ""
            if (nm.isNotBlank() && nm != lbl(person)) { val old = pTxt.textSize; pTxt.textSize = ts * 0.75f; c.drawText(nm, x + w / 2, y + h / 2 + ts * 1.0f, pTxt); pTxt.textSize = old }
        }
        if (glowOn) c.drawRoundRect(rect, r, r, pGlow)
    }
}

/** كشف مين بيحكي هلأ من مستوى المايكات (للنموذج الحي) — مع ذيل نص ثانية حتى ما يرجف */
class LiveSpeakers {
    private val until = HashMap<Int, Long>()

    fun update(levels: IntArray): IntArray {
        val now = SystemClock.elapsedRealtime()
        val top = levels.maxOrNull() ?: 0
        val thr = max(1800, (top * 0.45f).toInt())
        for ((i, l) in levels.withIndex()) if (l >= thr) until[i] = now + 500
        return levels.indices.filter { (until[it] ?: 0L) > now }.toIntArray()
    }
}
