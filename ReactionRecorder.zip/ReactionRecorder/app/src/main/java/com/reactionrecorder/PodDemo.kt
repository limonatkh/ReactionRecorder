package com.reactionrecorder

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.max
import kotlin.math.min

/**
 * نموذج مصغّر لشكل الفيديو بعد المونتاج — بنفس هندسة المونتاج الحقيقي (PodcastRenderer) وبالقالب المختار:
 *  • demo: مشاهد متكررة (واحد بيحكي ← التاني بيرد ← مقاطعة ← مقاطعة ثانية ← نقاش مع بعض).
 *  • live: شو كان رح يطلع هلأ حسب مين بيحكي فعليًا (مستوى المايكات) وبصور الكاميرات الحية.
 *  • editable: بمحرر القوالب، اسحب المربع العائم لمكانه وكبّره/صغّره بإصبعين.
 */
class LayoutDemoView(ctx: Context) : View(ctx) {
    var landscape = true
    var names: List<String> = listOf("1", "2")
    var hasCam: List<Boolean> = listOf(true, true)
    var pip = true
    var boxes = false
    /** فلوق: switch / grid / mainboxes، أو null للحوار */
    var vlogLayout: String? = null
    var glow = true
    var live = false
    var frames: List<Bitmap?> = emptyList()
    /** صور حقيقية من تصويرك (بدل المربعات الملونة) + مكان الوجه فيها [x,y,حجم] إن عُرف */
    var photos: List<Bitmap?> = emptyList()
    var photoFaces: List<FloatArray?> = emptyList()
    var liveSpeakers: IntArray = IntArray(0)
    /** القالب (إن وُجد بيتحكم بالشكل، وبيغطي pip/boxes/glow) */
    var tpl: PodTemplate? = null
    /** محرر القوالب: تثبيت مشهد معيّن (-1 = تشغيل) والسماح بسحب المربع */
    var hold = -1
    var editable = false
    var onTplChanged: (() -> Unit)? = null
    /** يُستدعى مع وصف المشهد الحالي (للنص تحت النموذج) */
    var onCaption: ((String) -> Unit)? = null

    private val t0 = SystemClock.uptimeMillis()
    private var lastCaption = ""
    private var liveMain = 0
    private var baseTs = 14f
    private val colors = intArrayOf(0xFF2F6FED.toInt(), 0xFFE0533D.toInt(), 0xFF2EA86B.toInt(), 0xFFB45CE0.toInt(), 0xFFE0A33D.toInt())
    private val pFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pBmp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val pTxt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true }
    private val pName = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; isFakeBoldText = true }
    private val pGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val pEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0x88FFFFFF.toInt(); strokeWidth = 2f }
    private val pHint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFF3D8BFF.toInt(); strokeWidth = 3f; pathEffect = android.graphics.DashPathEffect(floatArrayOf(10f, 8f), 0f) }

    private class Scene(val type: Int, val main: Int, val others: IntArray, val speak: IntArray, val cap: String, val ord: Int = 0)

    private fun n() = names.size
    private fun lbl(i: Int) = tx("شخص ${i + 1}", "Person ${i + 1}")
    private fun usePip() = tpl?.pip ?: pip
    private fun useBoxes() = tpl?.let { it.multi == "boxes" } ?: boxes
    private fun useGlow() = tpl?.glow ?: glow

    /** المشاهد حسب الإعداد — نفس قرارات المونتاج التلقائي */
    private fun script(): List<Scene> {
        val n = n()
        if (n <= 1) return listOf(Scene(PodShot.FULL, 0, IntArray(0), intArrayOf(0), tx("كاميرا وحدة — الفيديو كله منها", "One camera — the whole video uses it")))
        val all = (0 until n).toList().toIntArray()
        when (vlogLayout) {
            "grid" -> return listOf(
                Scene(PodShot.MULTI, 0, all, intArrayOf(0), tx("الكل ظاهر طول الوقت — ${lbl(0)} بيحكي", "Everyone shown — ${lbl(0)} speaks")),
                Scene(PodShot.MULTI, 0, all, intArrayOf(1), tx("الكل ظاهر — ${lbl(1)} بيحكي (الإطار المضيء بينتقل)", "Everyone shown — ${lbl(1)} speaks (the glow moves)")),
            )
            "mainboxes" -> return listOf(
                Scene(PodShot.FULL, 0, IntArray(0), intArrayOf(0), tx("${lbl(0)} بملء الشاشة، والباقي مربعات ثابتة", "${lbl(0)} full screen, the rest in fixed boxes")),
                Scene(PodShot.FULL, 0, IntArray(0), intArrayOf(1), tx("${lbl(1)} بيحكي — المربعات ما بتتحرك", "${lbl(1)} speaks — the boxes stay put")),
            )
        }
        val list = ArrayList<Scene>()
        list += Scene(PodShot.FULL, 0, IntArray(0), intArrayOf(0), tx("${lbl(0)} بيحكي ← بملء الشاشة", "${lbl(0)} speaks ← full screen"))
        list += Scene(PodShot.FULL, 1, IntArray(0), intArrayOf(1), tx("${lbl(1)} بيرد ← الكاميرا بتنتقل عليه", "${lbl(1)} replies ← the camera switches to them"))
        list += if (usePip()) Scene(PodShot.PIP, 1, intArrayOf(0), intArrayOf(0, 1), tx("${lbl(0)} قاطعه ← بيطلع بمربع عائم", "${lbl(0)} interrupts ← appears in a floating box"), 0)
        else Scene(PodShot.MULTI, 0, intArrayOf(0, 1), intArrayOf(0, 1), tx("${lbl(0)} قاطعه ← الشاشة بتنقسم", "${lbl(0)} interrupts ← the screen splits"))
        if (tpl != null) {
            list += Scene(PodShot.FULL, 0, IntArray(0), intArrayOf(0), tx("${lbl(0)} كمّل حكي ← صار بملء الشاشة", "${lbl(0)} keeps talking ← now full screen"))
            list += if (usePip()) Scene(PodShot.PIP, 0, intArrayOf(1), intArrayOf(0, 1), tx("${lbl(1)} قاطع ← مربع عائم (لاحظ التناوب إذا مفعّل)", "${lbl(1)} interrupts ← floating box (note alternation if on)"), 1)
            else Scene(PodShot.MULTI, 0, intArrayOf(0, 1), intArrayOf(0, 1), tx("${lbl(1)} قاطع ← الشاشة بتنقسم", "${lbl(1)} interrupts ← the screen splits"))
        }
        list += Scene(PodShot.MULTI, 0, all, all, tx("نقاش سريع مع بعض ← الكل مع بعض", "Fast back-and-forth ← everyone together") + if (useBoxes()) tx(" (مربعات فوق خلفية)", " (boxes over a background)") else "")
        return list
    }

    private fun liveScene(): Scene {
        val sp = liveSpeakers
        val n = n()
        if (n <= 1) return Scene(PodShot.FULL, 0, IntArray(0), sp, if (sp.isEmpty()) tx("ما حدا بيحكي", "Nobody is speaking") else tx("بيحكي", "Speaking"))
        val all = (0 until n).toList().toIntArray()
        when (vlogLayout) {
            "grid" -> return Scene(PodShot.MULTI, 0, all, sp, tx("الكل ظاهر", "Everyone shown"))
            "mainboxes" -> return Scene(PodShot.FULL, 0, IntArray(0), sp, tx("الرئيسي ثابت والباقي مربعات", "Main fixed, the rest in boxes"))
        }
        return when {
            sp.isEmpty() -> Scene(PodShot.FULL, liveMain, IntArray(0), sp, tx("ما حدا بيحكي ← بتضل آخر لقطة", "Nobody speaks ← the last shot stays"))
            sp.size == 1 -> { liveMain = sp[0]; Scene(PodShot.FULL, sp[0], IntArray(0), sp, "${names[sp[0]]} " + tx("بيحكي ← بملء الشاشة", "speaks ← full screen")) }
            usePip() -> {
                val m = if (liveMain in sp) liveMain else sp[0]
                liveMain = m
                Scene(PodShot.PIP, m, sp.filter { it != m }.toIntArray(), sp, tx("حدا قاطع ${names[m]} ← مربع عائم", "Someone interrupts ${names[m]} ← floating box"))
            }
            else -> Scene(PodShot.MULTI, sp[0], sp, sp, tx("بيحكوا مع بعض ← الشاشة مقسومة", "Talking together ← split screen"))
        }
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        val h = if (landscape) w * 9 / 16 else min(w * 16 / 9, (resources.displayMetrics.density * 380).toInt())
        setMeasuredDimension(w, h)
    }

    private fun shotFor(cam: Int): Int {
        if (hasCam.getOrNull(cam) == true) return cam
        return hasCam.indexOfFirst { it }.takeIf { it >= 0 } ?: cam
    }

    // آخر إطار مرسوم (للسحب)
    private val frameR = RectF()
    private val pipR = RectF()
    private var sceneStart = 0L
    private var sceneIdx = -1

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val sc: Scene = if (live) liveScene() else {
            val s = script()
            val i = if (hold in s.indices) hold else (((now - t0) / 1800L) % s.size).toInt()
            if (i != sceneIdx) { sceneIdx = i; sceneStart = now }
            s[i]
        }
        if (sc.cap != lastCaption) { lastCaption = sc.cap; onCaption?.invoke(sc.cap) }
        val a = if (landscape) 16f / 9f else 9f / 16f
        val s = min(width / a, height.toFloat())
        val W = s * a; val H = s
        val ox = (width - W) / 2f; val oy = (height - H) / 2f
        frameR.set(ox, oy, ox + W, oy + H)
        pFill.color = Color.BLACK
        c.drawRect(ox, oy, ox + W, oy + H, pFill)
        baseTs = max(11f, H / 14f)
        val t = tpl
        pGlow.color = t?.glowColor ?: 0xFFFFD60A.toInt()
        pGlow.strokeWidth = max(3f, H * (t?.glowWidth ?: 0.018f))
        val vertical = !landscape
        val glowOn = useGlow() && n() > 1
        pipR.setEmpty()
        when (sc.type) {
            PodShot.FULL -> tile(c, shotFor(sc.main), sc.main, ox, oy, W, H, 0f, sc.speak, sc.main in sc.speak && glowOn)
            PodShot.PIP -> {
                tile(c, shotFor(sc.main), sc.main, ox, oy, W, H, 0f, sc.speak, false)
                drawPip(c, sc, ox, oy, W, H, vertical, now)
            }
            else -> {
                val who = sc.others
                val bx = useBoxes()
                val pad = if (bx) H * 0.08f else 0f
                if (bx) { pFill.color = t?.bgColor ?: 0xFF1B1D24.toInt(); c.drawRect(ox, oy, ox + W, oy + H, pFill) }
                else if (t != null) { pFill.color = t.gapColor; c.drawRect(ox, oy, ox + W, oy + H, pFill) }
                val gap = if (bx) H * 0.04f else if (t != null) (if (t.gap <= 0f) 0f else max(1f, H * t.gap)) else max(2f, H / 180f)
                val stack = when (t?.splitDir) { "side" -> false; "stack" -> true; else -> vertical }
                val cells = grid(who.size, stack, ox + pad, oy + pad, W - 2 * pad, H - 2 * pad, gap)
                for ((i, r) in cells.withIndex()) tile(c, shotFor(who[i]), who[i], r[0], r[1], r[2], r[3], if (bx) H * (t?.boxRadius ?: 0.035f) else 0f, sc.speak, glowOn && who.size > 1 && who[i] in sc.speak)
            }
        }
        // فلوق "رئيسي + مربعات": الباقي ثابتين فوق
        if (vlogLayout == "mainboxes" && n() > 1) {
            val pw = if (vertical) W * 0.30f else W * 0.20f
            val ph = if (vertical) pw * 4f / 3f else pw * 9f / 16f
            for ((k, p) in (1 until n()).withIndex()) {
                val px = ox + W * 0.03f + k * (pw + W * 0.02f)
                val py = oy + if (vertical) H * 0.10f else H * 0.05f
                tile(c, shotFor(p), p, px, py, pw, ph, ph * 0.1f, sc.speak, glowOn && p in sc.speak)
            }
        }
        // اسم الشخص (حسب القالب)
        if (t != null && t.names != "never" && !live && (sc.type == PodShot.FULL || sc.type == PodShot.PIP)) {
            val since = now - sceneStart
            val first = script().indexOfFirst { (it.type == PodShot.FULL || it.type == PodShot.PIP) && it.main == sc.main } == sceneIdx
            if ((t.names == "switch" || first) && (since < 1500 || hold >= 0)) drawNameTag(c, names.getOrNull(sc.main) ?: lbl(sc.main), t, ox, oy, W, H, vertical)
        }
        drawOverlays(c, ox, oy, W, H, vertical, now)
        c.drawRect(ox, oy, ox + W, oy + H, pEdge)
        if (editable && !pipR.isEmpty) c.drawRect(pipR.left - 6, pipR.top - 6, pipR.right + 6, pipR.bottom + 6, pHint)
        postInvalidateDelayed(60)
    }

    private fun drawPip(c: Canvas, sc: Scene, ox: Float, oy: Float, W: Float, H: Float, vertical: Boolean, now: Long) {
        val t = tpl ?: PodTemplate()
        val circle = t.pipShape == "circle" || (t.pipShape == "alternate" && sc.ord % 2 == 0)
        val sz = PodLayout.pipSize(t, vertical, W, circle)
        val pw = sz[0]; val ph = sz[1]
        val r = when { circle -> pw / 2f; t.pipShape == "rect" -> 0f; else -> min(pw, ph) * t.pipRadius }
        val b = if (t.pipBorder > 0f) max(1.5f, H * t.pipBorder) else 0f
        val capsOn = t.captions && !live
        var mx = (t.pipPlace == "person" && (sc.others.firstOrNull() ?: 0) % 2 == 1) || (t.pipPlace == "alternate" && sc.ord % 2 == 1)
        var fy = false
        if (t.avoidFace && !live) {
            // نفس حساب التصدير: إذا المربع فوق وجه اللي بيحكي، بينتقل
            val f = demoFace(sc.main, 0f, 0f, W, H).let { PodLayout.Box(it.left, it.top, it.right, it.bottom) }
            val pad = PodLayout.margin(t, W, H) * 0.5f
            val best = listOf(0 to 0, 1 to 0, 0 to 1, 1 to 1).minByOrNull { (a, bb) ->
                PodLayout.pipRects(t, W, H, vertical, sc.others.size, pw, ph, mx xor (a == 1), bb == 1, capsOn)
                    .sumOf { rr -> PodLayout.overlap(rr.inset(pad), f).toDouble() } + (a + bb) * 0.001
            } ?: (0 to 0)
            if (best.first == 1) mx = !mx
            fy = best.second == 1
        }
        val rects = PodLayout.pipRects(t, W, H, vertical, sc.others.size, pw, ph, mx, fy, capsOn)
        val ap = if (t.pipAnim == "cut" || t.pipAnimMs <= 0 || hold >= 0) 1f else ((now - sceneStart) / t.pipAnimMs.toFloat()).coerceIn(0f, 1f)
        val e = 1f - (1f - ap) * (1f - ap)
        for ((i, o) in sc.others.withIndex()) {
            val rc = rects.getOrNull(i) ?: continue
            val px = rc.left; val py = rc.top
            var sw = pw; var sh = ph; var x = px; var y = py; var alpha = 1f
            when (t.pipAnim) {
                "fade" -> alpha = e
                "slide" -> x = if (px + pw / 2f < W / 2f) px - (1f - e) * (px + pw) else px + (1f - e) * (W - px)
                "zoom" -> { val k = 0.6f + 0.4f * e; sw = pw * k; sh = ph * k; x = px + (pw - sw) / 2f; y = py + (ph - sh) / 2f; alpha = e }
            }
            val rr = if (circle) sw / 2f else r * (sw / pw)
            val ax = ox + x; val ay = oy + y
            if (i == 0) pipR.set(ax, ay, ax + sw, ay + sh)
            if (t.pipShadow) { pFill.color = Color.argb((100 * alpha).toInt(), 0, 0, 0); c.drawRoundRect(RectF(ax + b + H * 0.006f, ay + b + H * 0.008f, ax + b + H * 0.006f + sw, ay + b + H * 0.008f + sh), rr + b, rr + b, pFill) }
            if (b > 0f) { pFill.color = t.pipBorderColor; pFill.alpha = (255 * alpha).toInt(); c.drawRoundRect(RectF(ax - b, ay - b, ax + sw + b, ay + sh + b), rr + b, rr + b, pFill); pFill.alpha = 255 }
            zoomFace = t.pipFace
            tile(c, shotFor(o), o, ax, ay, sw, sh, rr, sc.speak, useGlow() && o in sc.speak, alpha)
            zoomFace = false
        }
    }

    // ───────── طبقات القالب فوق الصورة (كتابة، عنوان، عناصر ثابتة، شريط، ومضة) ─────────

    /** نصوصك الثابتة (للعناصر) */
    var brand: Map<String, String> = emptyMap()
    private val sampleWords: List<String> by lazy { tx("هاي معاينة لشكل الكتابة على الفيديو بهالقالب وكيف بتتحرك الكلمات مع الكلام", "This is a preview of how captions look on the video with this template").split(' ') }
    private val pCap = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Fonts.bold }
    private val pCapS = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Fonts.bold; style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND; color = 0xE6000000.toInt() }

    /** يرسم كلمات بصف واحد بالنص (يمين لشمال بالعربي)، الكلمة hi ملوّنة؛ بيرجع العرض */
    private fun drawWords(c: Canvas, words: List<String>, hi: Set<Int>, cx: Float, cy: Float, size: Float, color: Int, hiColor: Int, box: Boolean, maxW: Float) {
        pCap.textSize = size; pCapS.textSize = size; pCapS.strokeWidth = size * 0.14f
        var sp = pCap.measureText(" ")
        var ws = words.map { pCap.measureText(it) }
        var total = ws.sum() + sp * (words.size - 1)
        if (total > maxW) { val k = maxW / total; pCap.textSize = size * k; pCapS.textSize = size * k; sp *= k; ws = ws.map { it * k }; total = maxW }
        val rtl = L.ar
        val base = cy + pCap.textSize * 0.35f
        if (box) { pFill.color = 0x99000000.toInt(); val pd = pCap.textSize * 0.35f; c.drawRoundRect(RectF(cx - total / 2 - pd, cy - pCap.textSize * 0.75f, cx + total / 2 + pd, cy + pCap.textSize * 0.75f), pd, pd, pFill) }
        var x = if (rtl) cx + total / 2 else cx - total / 2
        for ((i, w) in words.withIndex()) {
            val wx = if (rtl) x - ws[i] else x
            if (!box) c.drawText(w, wx, base, pCapS)
            pCap.color = if (i in hi) hiColor else color
            c.drawText(w, wx, base, pCap)
            x = if (rtl) wx - sp else wx + ws[i] + sp
        }
    }

    private fun drawOverlays(c: Canvas, ox: Float, oy: Float, W: Float, H: Float, vertical: Boolean, now: Long) {
        val t = tpl ?: return
        if (live) return
        val cycle = 1800L * max(1, script().size)
        val ph = ((now - t0) % cycle) / cycle.toFloat()
        c.save(); c.translate(ox, oy); c.clipRect(0f, 0f, W, H)
        // ومضة مع بداية كل مشهد
        if (t.trans == "flash" && now - sceneStart < 160 && hold < 0) { pFill.color = Color.argb((165 * (1f - (now - sceneStart) / 160f)).toInt().coerceIn(0, 255), 255, 255, 255); c.drawRect(0f, 0f, W, H, pFill) }
        val hookOn = t.titleOn && ph < 0.12f && hold < 0
        if (hookOn && t.hookStyle == "big") { pFill.color = 0x73000000; c.drawRect(0f, 0f, W, H, pFill) }
        // الكتابة
        if (t.captions && !(hookOn && t.hookStyle == "big")) {
            val per = 380L
            val idx = (((now - t0) / per) % sampleWords.size).toInt()
            val size = PodLayout.capTextSize(t, vertical, H, t.capSize)
            val cy = PodLayout.capCenterY(t, vertical, H)
            if (t.capStyle == "line") {
                val start = (idx / 6) * 6
                val ws = sampleWords.subList(start, min(sampleWords.size, start + 6))
                drawWords(c, ws, setOf(2), W / 2, cy, size, t.capColor, t.capHi, false, W * 0.86f)
            } else {
                val start = (idx / 3) * 3
                val ws = sampleWords.subList(start, min(sampleWords.size, start + 3))
                val pop = 0.86f + 0.14f * (((now - t0) % (per * 3)) / 120f).coerceIn(0f, 1f)
                drawWords(c, ws, setOf(idx - start), W / 2, cy, size * pop, t.capColor, t.capHi, t.capStyle == "boxed", W * 0.82f)
            }
        }
        // العنوان الافتتاحي
        if (hookOn) {
            val title = tx("عنوان الريل بيطلع هون", "The reel title shows here")
            if (t.hookStyle == "big") drawWords(c, title.split(' '), emptySet(), W / 2, H * 0.42f, if (vertical) H * 0.05f else H * 0.08f, Color.WHITE, t.capHi, false, W * 0.86f)
            else drawWords(c, title.split(' '), emptySet(), W / 2, (if (vertical) H * 0.13f else H * 0.10f), if (vertical) H * 0.032f else H * 0.055f, Color.WHITE, t.capHi, true, W * 0.80f)
        }
        // العناصر الثابتة
        if (t.items.isNotEmpty()) {
            val band = PodLayout.capBand(t, vertical, W, H, t.captions)
            val perPos = HashMap<String, Int>()
            for (it in t.items) {
                var txt = Brand.fill(it.text, brand)
                if (txt.isBlank()) txt = it.text.replace("{link}", tx("رابطك", "your link")).replace("{handle}", "@" + tx("حسابك", "you")).replace("{channel}", tx("اسم البودكاست", "Podcast name")).replace("{guest}", tx("اسم الضيف", "Guest"))
                val i = perPos.getOrDefault(it.pos, 0); perPos[it.pos] = i + 1
                val size = (if (vertical) H * 0.026f else H * 0.04f) * it.size
                pCap.textSize = size
                val w = pCap.measureText(txt) + size * 0.7f; val h = size * 1.7f
                val rr = PodLayout.itemRect(it.pos, min(w, W * 0.7f), h, W, H, vertical, i, band)
                if (it.bg) { pFill.color = 0x8C000000.toInt(); c.drawRoundRect(rr.toRectF(), h * 0.3f, h * 0.3f, pFill) }
                drawWords(c, listOf(txt), emptySet(), rr.centerX(), rr.centerY(), size, it.color, it.color, false, rr.width())
            }
        }
        // شريط التقدّم
        if (t.progress) {
            val bh = max(3f, H * 0.008f)
            pFill.color = 0x40FFFFFF; c.drawRect(0f, 0f, W, bh, pFill)
            pFill.color = t.capHi; c.drawRect(0f, 0f, W * ph, bh, pFill)
        }
        // المناطق اللي بتغطيها واجهة المنصة (بالريل)
        if (vertical && showGuides) {
            pFill.color = 0x30FF3B30
            for (z in PodLayout.blocked(true, W, H)) c.drawRect(z.toRectF(), pFill)
        }
        c.restore()
    }

    /** إظهار المناطق اللي بتغطيها أزرار المنصة (بمحرر القوالب) */
    var showGuides = false

    private var zoomFace = false
    private val pFace = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66FFFFFF }

    /** وجه تقريبي بالنموذج (الشخص الأول يمين شوي والثاني يسار شوي، متل جلسة حقيقية) */
    private fun demoFace(person: Int, x: Float, y: Float, w: Float, h: Float): RectF {
        val pb = photos.getOrNull(shotFor(person)); val f = photoFaces.getOrNull(shotFor(person))
        if (!zoomFace && pb != null && f != null) {
            // نفس قص الصورة بـ tile
            val sa = pb.width.toFloat() / pb.height; val da = w / h
            var kw = 1f; var kh = 1f
            if (sa > da) kw = da / sa else kh = sa / da
            var cx = 0.5f; var cy = 0.5f
            if (tpl?.faces == true || !landscape) { cx = f[0]; cy = f[1] + f[2] * 0.1f }
            cx = cx.coerceIn(kw / 2, 1 - kw / 2); cy = cy.coerceIn(kh / 2, 1 - kh / 2)
            val fx = x + (f[0] - (cx - kw / 2)) / kw * w; val fyy = y + (f[1] - (cy - kh / 2)) / kh * h
            val hw = f[2] / sa * 1.35f / kw * w / 2; val hh = f[2] * 1.5f / kh * h / 2
            return RectF(fx - hw, fyy - hh, fx + hw, fyy + hh)
        }
        if (zoomFace) { val r = min(w, h) * 0.30f; return RectF(x + w / 2 - r * 0.8f, y + h * 0.48f - r, x + w / 2 + r * 0.8f, y + h * 0.48f + r) }
        val r = min(w, h) * 0.17f
        val cx = x + w * (if (person % 2 == 0) 0.64f else 0.36f); val cy = y + h * 0.42f
        return RectF(cx - r * 0.8f, cy - r, cx + r * 0.8f, cy + r)
    }

    private fun drawNameTag(c: Canvas, name: String, t: PodTemplate, ox: Float, oy: Float, W: Float, H: Float, vertical: Boolean) {
        pName.textSize = max(10f, if (vertical) H * 0.030f else H * 0.050f)
        val pad = pName.textSize * 0.55f
        val w = pName.measureText(name) + pad * 2
        val h = pName.textSize * 1.7f
        val m = min(W, H) * 0.045f
        val x = ox + when (t.namePos) { "bc" -> (W - w) / 2f; "br", "tr" -> W - w - m; else -> m }
        val y = oy + if (t.namePos.startsWith("t")) m + (if (vertical) H * 0.06f else 0f) else (if (vertical) H * 0.62f else H - h - m * 2.2f)
        pFill.color = t.nameColor
        c.drawRoundRect(RectF(x, y, x + w, y + h), h / 2f, h / 2f, pFill)
        c.drawText(name, x + pad, y + pName.textSize * 1.2f, pName)
    }

    private fun grid(n: Int, stack: Boolean, x: Float, y: Float, w: Float, h: Float, gap: Float): List<FloatArray> {
        val cols = if (stack) (if (n >= 4) 2 else 1) else when (n) { 1 -> 1; 2 -> 2; 3 -> 3; else -> 2 }
        val rows = if (stack) (if (n >= 4) 2 else n) else (if (n >= 4) 2 else 1)
        val cw = (w - gap * (cols - 1)) / cols
        val ch = (h - gap * (rows - 1)) / rows
        return (0 until n).map { i -> floatArrayOf(x + (i % cols) * (cw + gap), y + (i / cols) * (ch + gap), cw, ch) }
    }

    /** مربع شخص: صورة الكاميرا الحية (live) أو لون + اسم (demo) */
    private fun tile(c: Canvas, cam: Int, person: Int, x: Float, y: Float, w: Float, h: Float, r: Float, speak: IntArray, glowOn: Boolean, alpha: Float = 1f) {
        val rect = RectF(x, y, x + w, y + h)
        val bmp = if (live) frames.getOrNull(cam) else null
        c.save()
        c.clipPath(Path().apply { addRoundRect(rect, r, r, Path.Direction.CW) })
        if (bmp != null) {
            val sa = bmp.width.toFloat() / bmp.height; val da = w / h
            val src = if (sa > da) { val k = bmp.height * da; android.graphics.Rect(((bmp.width - k) / 2).toInt(), 0, ((bmp.width + k) / 2).toInt(), bmp.height) }
            else { val k = bmp.width / da; android.graphics.Rect(0, ((bmp.height - k) / 2).toInt(), bmp.width, ((bmp.height + k) / 2).toInt()) }
            pBmp.alpha = (255 * alpha).toInt()
            c.drawBitmap(bmp, src, rect, pBmp)
        } else if (photos.getOrNull(cam) != null) {
            // صورة حقيقية: قص ملء، ومركزه الوجه (إذا القالب بيلحق الوجه أو المربع على الوجه)
            val pb = photos[cam]!!
            val f = photoFaces.getOrNull(cam)
            val sa = pb.width.toFloat() / pb.height; val da = w / h
            var kw = 1f; var kh = 1f
            if (sa > da) kw = da / sa else kh = sa / da
            val z = if (zoomFace && f != null) (tpl?.faceZoom ?: 1.6f) else 1f
            kw /= z; kh /= z
            var cx = 0.5f; var cy = 0.5f
            if (f != null && (zoomFace || tpl?.faces == true || !landscape)) { cx = f[0]; cy = f[1] + f[2] * 0.1f }
            cx = cx.coerceIn(kw / 2, 1 - kw / 2); cy = cy.coerceIn(kh / 2, 1 - kh / 2)
            val src = android.graphics.Rect(((cx - kw / 2) * pb.width).toInt(), ((cy - kh / 2) * pb.height).toInt(), ((cx + kw / 2) * pb.width).toInt(), ((cy + kh / 2) * pb.height).toInt())
            pBmp.alpha = (255 * alpha).toInt()
            c.drawBitmap(pb, src, rect, pBmp)
        } else {
            pFill.color = colors[cam % colors.size]; pFill.alpha = (255 * alpha).toInt()
            c.drawRect(rect, pFill); pFill.alpha = 255
            if (tpl?.pipFace == true || tpl?.avoidFace == true) { pFace.alpha = (0x66 * alpha).toInt(); c.drawOval(demoFace(person, x, y, w, h), pFace) }
        }
        c.restore()
        if (bmp == null && photos.getOrNull(cam) != null) { if (glowOn) { pGlow.alpha = (255 * alpha).toInt(); c.drawRoundRect(rect, r, r, pGlow); pGlow.alpha = 255 }; return }
        val label = (if (person in speak) "🗣 " else "") + lbl(person) + (if (cam != person) " 🎤" else "")
        val ts = min(baseTs, h / 4.5f).coerceAtLeast(9f)
        pTxt.textSize = ts; pTxt.alpha = (255 * alpha).toInt()
        if (bmp != null) { pFill.color = 0x99000000.toInt(); c.drawRect(x, y + h - ts * 1.6f, x + w, y + h, pFill); c.drawText(label, x + w / 2, y + h - ts * 0.45f, pTxt) }
        else {
            c.drawText(label, x + w / 2, y + h / 2 - ts * 0.1f, pTxt)
            val nm = names.getOrNull(person) ?: ""
            if (nm.isNotBlank() && nm != lbl(person)) { pTxt.textSize = ts * 0.75f; c.drawText(nm, x + w / 2, y + h / 2 + ts * 1.0f, pTxt) }
        }
        pTxt.alpha = 255
        if (glowOn) { pGlow.alpha = (255 * alpha).toInt(); c.drawRoundRect(rect, r, r, pGlow); pGlow.alpha = 255 }
    }

    // ───────── محرر القوالب: سحب المربع وتكبيره ─────────

    private var dragging = false
    private val scaler = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            val t = tpl ?: return false
            t.pipSize = (t.pipSize * d.scaleFactor).coerceIn(0.12f, 0.5f)
            onTplChanged?.invoke(); return true
        }
    })

    @android.annotation.SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!editable || tpl == null) return super.onTouchEvent(e)
        scaler.onTouchEvent(e)
        if (e.pointerCount > 1) { dragging = false; parent?.requestDisallowInterceptTouchEvent(true); return true }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = !pipR.isEmpty && RectF(pipR).apply { inset(-30f, -30f) }.contains(e.x, e.y)
                if (dragging) parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> if (dragging) {
                val t = tpl!!
                val s = script().getOrNull(sceneIdx)
                var fx = ((e.x - frameR.left) / frameR.width()).coerceIn(0.05f, 0.95f)
                val fy = ((e.y - frameR.top) / frameR.height()).coerceIn(0.05f, 0.95f)
                // إذا المشهد معكوس (حسب الشخص/بالتناوب) نخزن المكان الأصلي
                val mirrored = s != null && ((t.pipPlace == "person" && (s.others.firstOrNull() ?: 0) % 2 == 1) || (t.pipPlace == "alternate" && s.ord % 2 == 1))
                if (mirrored) fx = 1f - fx
                t.pipPos = "custom"; t.pipX = fx; t.pipY = fy
                onTplChanged?.invoke()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { dragging = false; parent?.requestDisallowInterceptTouchEvent(false) }
        }
        return true
    }
}

/** كشف مين بيحكي هلأ من مستوى المايكات (للنموذج الحي) — مع ذيل نص ثانية حتى ما يرجف */
class LiveSpeakers {
    private val until = HashMap<Int, Long>()

    fun update(levels: IntArray): IntArray {
        val now = SystemClock.elapsedRealtime()
        val top = levels.maxOrNull() ?: 0
        val thr = max(1800, (top * 0.45f).toInt())
        for ((i, l) in levels.withIndex()) if (l >= thr) until[i] = now + 500
        return levels.indices.filter { (until[it] ?: 0L) > now }.toIntArray()
    }
}

/** صور حقيقية من آخر تصوير (لنموذج القالب) — مع مكان الوجه */
object DemoPhotos {
    class Pack(val sid: String, val photos: List<Bitmap?>, val faces: List<FloatArray?>, val names: List<String>)
    @Volatile private var cache: Pack? = null

    /** بيشتغل بخيط خلفي. sid = جلسة معيّنة، وإلا آخر جلسة فيها فيديو كاميرات */
    fun load(ctx: Context, sid: String? = null): Pack? {
        cache?.let { if (sid == null || it.sid == sid) return it }
        val sessions = if (sid != null) listOfNotNull(SessionStore.load(ctx, sid)) else try { SessionStore.list(ctx).sortedByDescending { it.wallMs }.take(20) } catch (_: Throwable) { emptyList() }
        for (s in sessions) {
            val setup = PodcastAnalyzer.setupOf(s)
            val files = setup.people.map { p -> if (p.camDev.isEmpty()) null else java.io.File(SessionStore.devDir(ctx, s.id, p.camDev), "video.mp4").takeIf { it.exists() && it.length() > 100_000 } }
            if (files.count { it != null } == 0) continue
            val photos = ArrayList<Bitmap?>(); val faces = ArrayList<FloatArray?>()
            for ((i, f) in files.withIndex()) {
                if (f == null) { photos.add(null); faces.add(null); continue }
                var bmp: Bitmap? = null; var ms = 0.0
                val r = android.media.MediaMetadataRetriever()
                try {
                    r.setDataSource(f.absolutePath)
                    val dur = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    ms = dur * 0.35
                    bmp = r.getScaledFrameAtTime((ms * 1000).toLong(), android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 640, 640)
                } catch (_: Throwable) {} finally { try { r.release() } catch (_: Throwable) {} }
                photos.add(bmp)
                var face: FloatArray? = try { PodFaces.load(ctx, s.id, setup.people[i].camDev)?.at(ms)?.takeIf { !it[0].isNaN() } } catch (_: Throwable) { null }
                if (face == null && bmp != null) face = detect(bmp)
                faces.add(face)
            }
            val set = Pack(s.id, photos, faces, setup.people.map { it.name })
            cache = set
            return set
        }
        return null
    }

    private fun detect(b: Bitmap): FloatArray? = try {
        val det = com.google.mlkit.vision.face.FaceDetection.getClient(com.google.mlkit.vision.face.FaceDetectorOptions.Builder().setPerformanceMode(com.google.mlkit.vision.face.FaceDetectorOptions.PERFORMANCE_MODE_FAST).build())
        try {
            val fs = com.google.android.gms.tasks.Tasks.await(det.process(com.google.mlkit.vision.common.InputImage.fromBitmap(b, 0)))
            fs.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() }?.let { f -> floatArrayOf(f.boundingBox.exactCenterX() / b.width, f.boundingBox.exactCenterY() / b.height, f.boundingBox.height().toFloat() / b.height) }
        } finally { det.close() }
    } catch (_: Throwable) { null }

    /** يحط الصور بنموذج */
    fun apply(v: LayoutDemoView, s: Pack?) {
        if (s == null) return
        v.photos = s.photos; v.photoFaces = s.faces
        if (s.names.size >= 2) v.names = s.names
        v.hasCam = s.photos.map { it != null }
        v.invalidate()
    }
}
