package com.reactionrecorder

import android.content.Context
import android.media.MediaMetadataRetriever
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs

/**
 * مسار الوجه في فيديو كاميرا: مركز الوجه (0..1 من أعلى اليسار) وحجمه، بزمن الملف (ms).
 * يُنعَّم ويُثبَّت (منطقة ميتة) حتى لا يهتز الكادر.
 */
class FaceTrack(val t: DoubleArray, val x: FloatArray, val y: FloatArray, val s: FloatArray) {
    fun at(ms: Double): FloatArray? {
        if (t.isEmpty()) return null
        if (ms <= t[0]) return floatArrayOf(x[0], y[0], s[0])
        if (ms >= t[t.size - 1]) return floatArrayOf(x[t.size - 1], y[t.size - 1], s[t.size - 1])
        var lo = 0
        var hi = t.size - 1
        while (hi - lo > 1) { val m = (lo + hi) / 2; if (t[m] <= ms) lo = m else hi = m }
        val k = ((ms - t[lo]) / (t[hi] - t[lo])).toFloat().coerceIn(0f, 1f)
        return floatArrayOf(x[lo] + (x[hi] - x[lo]) * k, y[lo] + (y[hi] - y[lo]) * k, s[lo] + (s[hi] - s[lo]) * k)
    }

    fun toJson(): JSONObject = JSONObject().put("t", JSONArray(t.toList())).put("x", JSONArray(x.map { it.toDouble() }))
        .put("y", JSONArray(y.map { it.toDouble() })).put("s", JSONArray(s.map { it.toDouble() }))

    companion object {
        fun fromJson(o: JSONObject): FaceTrack {
            val t = o.getJSONArray("t"); val x = o.getJSONArray("x"); val y = o.getJSONArray("y"); val s = o.getJSONArray("s")
            return FaceTrack(DoubleArray(t.length()) { t.getDouble(it) }, FloatArray(x.length()) { x.getDouble(it).toFloat() },
                FloatArray(y.length()) { y.getDouble(it).toFloat() }, FloatArray(s.length()) { s.getDouble(it).toFloat() })
        }

        /** من عيّنات خام (قد تحوي NaN حيث لم يُكتشف وجه) إلى مسار ناعم ثابت */
        fun build(raw: List<FloatArray>, times: List<Double>): FaceTrack? {
            val idx = raw.indices.filter { !raw[it][0].isNaN() }
            if (idx.isEmpty()) return null
            val n = raw.size
            val x = FloatArray(n); val y = FloatArray(n); val s = FloatArray(n)
            // ملء الفراغات بأقرب قيمة معروفة
            var last = idx.first()
            for (i in 0 until n) {
                if (!raw[i][0].isNaN()) last = i
                val src = if (raw[i][0].isNaN()) (idx.minByOrNull { abs(it - i) } ?: last) else i
                x[i] = raw[src][0]; y[i] = raw[src][1]; s[i] = raw[src][2]
            }
            // تنعيم أمامي وخلفي (بلا تأخير)
            fun smooth(a: FloatArray) {
                val k = 0.35f
                for (i in 1 until n) a[i] = a[i - 1] + (a[i] - a[i - 1]) * k
                for (i in n - 2 downTo 0) a[i] = a[i + 1] + (a[i] - a[i + 1]) * k
            }
            smooth(x); smooth(y); smooth(s)
            // منطقة ميتة: لا نتحرك إلا لتغيّر واضح (> 4%)
            fun dead(a: FloatArray) {
                var held = a[0]
                for (i in a.indices) { if (abs(a[i] - held) > 0.04f) held += (a[i] - held) * 0.5f; a[i] = held }
            }
            dead(x); dead(y)
            return FaceTrack(times.toDoubleArray(), x, y, s)
        }
    }
}

/** اكتشاف الوجه بـ ML Kit (على الجهاز، بدون إنترنت) — اختياري ويُحفظ لإعادة الاستعمال */
object PodFaces {
    private fun file(ctx: Context, sid: String, dev: String) = File(SessionStore.devDir(ctx, sid, dev), "faces.json")

    fun load(ctx: Context, sid: String, dev: String): FaceTrack? = try {
        val f = file(ctx, sid, dev)
        if (f.exists()) FaceTrack.fromJson(JSONObject(f.readText())) else null
    } catch (_: Throwable) { null }

    /**
     * يحلل فيديو جهاز بين fromMs و toMs (زمن الملف) بعيّنة كل stepMs، ويدمج مع ما حُلل سابقًا.
     * يعيد عدد العينات التي وُجد فيها وجه.
     */
    fun analyze(ctx: Context, sid: String, dev: String, fromMs: Double, toMs: Double, stepMs: Double, progress: (Float) -> Unit, cancelled: () -> Boolean): Int {
        val vf = File(SessionStore.devDir(ctx, sid, dev), "video.mp4")
        if (!vf.exists()) return 0
        val old = load(ctx, sid, dev)
        val times = ArrayList<Double>()
        val raw = ArrayList<FloatArray>()
        if (old != null) for (i in old.t.indices) if (old.t[i] < fromMs || old.t[i] > toMs) { times.add(old.t[i]); raw.add(floatArrayOf(old.x[i], old.y[i], old.s[i])) }
        val opts = FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setMinFaceSize(0.12f)
            .build()
        val det = FaceDetection.getClient(opts)
        val r = MediaMetadataRetriever()
        var found = 0
        try {
            r.setDataSource(vf.absolutePath)
            val durMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toDoubleOrNull() ?: toMs
            var t = maxOf(0.0, fromMs)
            val end = minOf(toMs, durMs)
            val total = maxOf(1.0, end - t)
            val start = t
            while (t <= end) {
                if (cancelled()) break
                val bmp = r.getScaledFrameAtTime((t * 1000).toLong(), MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 360, 360)
                var v = floatArrayOf(Float.NaN, Float.NaN, Float.NaN)
                if (bmp != null) {
                    try {
                        val faces = Tasks.await(det.process(InputImage.fromBitmap(bmp, 0)))
                        val f = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() }
                        if (f != null) {
                            val b = f.boundingBox
                            v = floatArrayOf(b.exactCenterX() / bmp.width, b.exactCenterY() / bmp.height, b.height().toFloat() / bmp.height)
                            found++
                        }
                    } catch (_: Throwable) {
                    } finally {
                        bmp.recycle()
                    }
                }
                times.add(t); raw.add(v)
                t += stepMs
                progress(((t - start) / total).toFloat().coerceIn(0f, 1f))
            }
        } finally {
            try { r.release() } catch (_: Throwable) {}
            try { det.close() } catch (_: Throwable) {}
        }
        val order = times.indices.sortedBy { times[it] }
        val tr = FaceTrack.build(order.map { raw[it] }, order.map { times[it] })
        if (tr != null) try { file(ctx, sid, dev).writeText(tr.toJson().toString()) } catch (_: Throwable) {}
        return found
    }
}
