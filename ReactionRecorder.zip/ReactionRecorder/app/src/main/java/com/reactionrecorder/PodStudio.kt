package com.reactionrecorder

import android.content.Context
import java.io.File
import kotlin.math.max
import kotlin.math.min

/**
 * ربط منطق المونتاج (PodEngine) بملفات الجلسة: تحميل التحليل والنص، توليد/إعادة توليد مشروع مع حماية المثبّت،
 * وبناء مهمة التصدير أو المعاينة بنفس القرارات.
 */
object PodStudio {
    class Data(val s: SessionInfo, val setup: PodSetup, val an: PodAnalysis, val tr: Transcript?, val sem: Semantic?, val markers: List<PMarker>) {
        var camsPortrait = false
        /** فلوق: اختيارات الكاميرا وقت التصوير */
        var live: List<Pair<Double, Int>> = emptyList()
        /** وصلت ملفات جديدة منذ آخر فتح → أُعيد التحليل والمونتاج (غير المثبّت) */
        var inputsChanged = false
        /** ملفات لم تصل بعد (للعرض) */
        var missing: List<String> = emptyList()
        fun hasCam(i: Int) = setup.people.getOrNull(i)?.camDev?.isNotEmpty() == true
        val duration get() = an.duration
        val names get() = setup.people.map { it.name }
        val turns: List<PodEngine.Turn> by lazy { PodEngine.markBackchannels(PodEngine.turns(an, setup.people.size)) }
        /** طبيعة الحوار: من التحليل الدلالي إن وُجد (أدق)، وإلا من التوقيت محليًا */
        val regions: List<PodEngine.Region> by lazy {
            val ai = sem?.regions
            if (!ai.isNullOrEmpty()) ai else PodEngine.regions(turns, an.duration)
        }
    }

    /** نتيجة آخر مزامنة بالصوت (للعرض في الواجهة) */
    @Volatile var lastSync: List<PodSync.SyncResult> = emptyList()

    /** يحمّل كل ما يلزم؛ يحلل الصوت إن لم يكن محللًا (ويحفظ النتيجة فقط إذا اكتمل) */
    fun load(ctx: Context, sid: String, progress: (Float) -> Unit, cancelled: () -> Boolean): Data? {
        val s = SessionStore.load(ctx, sid) ?: return null
        val setup = PodcastAnalyzer.setupOf(s)
        var ss = s
        defaultFlipFill = ctx.getSharedPreferences("reaction_ui", Context.MODE_PRIVATE).getString("flipFill", "freeze") ?: "freeze"
        // أجهزة بلا قياس ساعة (انضمت متأخرة / استيراد يدوي): نضبطها بالصوت قبل التحليل
        val unsynced = s.devices.values.any { it.started && it.samples.isEmpty() && File(SessionStore.devDir(ctx, sid, it.id), "audio.wav").exists() }
        if (unsynced) {
            val r = PodSync.syncBySound(ctx, sid, emptySet(), { f -> progress(f * 0.2f) }, cancelled)
            if (cancelled()) return null
            if (r.any { it.ok }) {
                try { File(SessionStore.dir(ctx, sid), "pod_analysis.json").delete() } catch (_: Throwable) {}
                ss = SessionStore.load(ctx, sid) ?: s
            }
            lastSync = r
        }
        // بصمة الملفات الواصلة: إذا وصل ملف جديد (صاحبك رفع بعد ما فتحت المونتاج) نعيد التحليل والمونتاج
        val fpFile = File(SessionStore.dir(ctx, sid), "pod_inputs.txt")
        val fp = inputsOf(ctx, ss)
        val oldFp = try { if (fpFile.exists()) fpFile.readText() else null } catch (_: Throwable) { null }
        val anFile = File(SessionStore.dir(ctx, sid), "pod_analysis.json")
        var changed = false
        if (oldFp != fp && anFile.exists()) { try { anFile.delete() } catch (_: Throwable) {}; changed = true }
        val an = PodcastAnalyzer.loadAnalysis(ctx, sid) ?: run {
            val a = PodcastAnalyzer.analyze(ctx, ss, setup, progress, cancelled)
            if (cancelled()) return null
            PodcastAnalyzer.saveAnalysis(ctx, sid, a)
            a
        }
        try { fpFile.writeText(fp) } catch (_: Throwable) {}
        val d = Data(ss, setup, an, PodAI.loadTranscript(ctx, sid), PodAI.loadSemantic(ctx, sid), ProjectStore.markers(ctx, ss)).also {
            it.camsPortrait = portraitCams(ctx, ss); it.live = PodRec.liveList(ctx, ss); it.missing = missingOf(ctx, ss, setup)
        }
        if (changed) {
            d.inputsChanged = true
            val dir = ProjectStore.dir(ctx, sid)
            for (f in dir.listFiles()?.filter { it.isFile && it.name.endsWith(".json") } ?: emptyList()) {
                val p = ProjectStore.load(ctx, sid, f.name.removeSuffix(".json")) ?: continue
                if (setup.vlog) p.st.liveSwitch = p.st.liveSwitch && d.live.isNotEmpty()
                try { regenerate(d, p); ProjectStore.save(ctx, sid, p) } catch (_: Throwable) {}
            }
        }
        return d
    }

    private fun devFiles(ctx: Context, s: SessionInfo, dev: String): Pair<Boolean, Boolean> {
        if (dev.isEmpty()) return false to false
        val dd = SessionStore.devDir(ctx, s.id, dev)
        val meta = File(dd, "meta.json").exists()
        return (meta && File(dd, "audio.wav").exists()) to (meta && File(dd, "video.mp4").exists())
    }

    private fun inputsOf(ctx: Context, s: SessionInfo): String =
        s.devices.keys.sorted().joinToString("|") { id -> val (a, v) = devFiles(ctx, s, id); "$id:$a:$v" }

    private fun missingOf(ctx: Context, s: SessionInfo, setup: PodSetup): List<String> {
        val out = ArrayList<String>()
        for (p in setup.people) {
            if (p.camDev.isNotEmpty() && !devFiles(ctx, s, p.camDev).second) out += tx("فيديو ${p.name} لسا ما وصل", "${p.name}'s video hasn't arrived yet")
            val mic = PodcastAnalyzer.micOf(ctx, s, p)
            if (mic.isNotEmpty() && !devFiles(ctx, s, mic).first) out += tx("صوت ${p.name} لسا ما وصل", "${p.name}'s audio hasn't arrived yet")
        }
        return out
    }

    /**
     * إعادة توليد العناصر غير المثبّتة (كل المشروع أو المدى [ra,rb] فقط):
     * اللقطات، قص الصمت التلقائي (للريلز)، وحركات الزوم التلقائية.
     */
    fun regenerate(d: Data, p: PodProject, ra: Double? = null, rb: Double? = null) {
        val a = p.a
        val b = p.end(d.duration)
        val r0 = ra ?: a
        val r1 = rb ?: b
        val fresh = vlogShots(d, p, a, b) ?: PodEngine.autoShots(d.an, d.setup.people.size, d.setup.wides.isNotEmpty(), p.st.pip, p.st, a, b, d.regions)
        p.shots = if (p.shots.isEmpty()) fresh else PodEngine.regenerate(p.shots, fresh, a, b, ra, rb)
        if (p.kind == PodProject.REEL) {
            p.cuts.removeAll { it.kind == PCut.SILENCE && !it.locked && it.b > r0 && it.a < r1 }
            p.cuts.addAll(PodEngine.silenceCuts(d.an, d.turns, p.st.silence, r0, r1))
            p.cuts.sortBy { it.a }
        }
        val keepZ = p.zooms.filter { it.locked || !it.auto || it.b <= r0 || it.a >= r1 }
        val fz = PodEngine.autoZooms(p.shots, d.turns, d.regions, p.st, d.sem?.keys, r0, r1)
            .filter { z -> z.a < r1 && z.b > r0 && keepZ.none { k -> z.a < k.b && z.b > k.a } }
        val merged = (keepZ.map { it.copy() } + fz).sortedBy { it.a }
        p.zooms.clear()
        p.zooms.addAll(merged)
    }

    /** فلوق: لقطات حسب شكل الفيديو المختار (أو null = المونتاج التلقائي على المتكلم) */
    fun vlogShots(d: Data, p: PodProject, a: Double, b: Double): MutableList<PodShot>? {
        if (!d.setup.vlog) return null
        val cams = d.setup.people.indices.filter { d.hasCam(it) }
        if (cams.isEmpty()) return null
        return when (d.setup.vlogLayout) {
            "grid" -> mutableListOf(PodShot(a, b, PodShot.MULTI, cams[0], cams.toIntArray()))
            "mainboxes" -> mutableListOf(PodShot(a, b, PodShot.FULL, cams[0], IntArray(0)))
            else -> if (p.st.liveSwitch && d.live.isNotEmpty()) PodEngine.shotsFromLive(d.live, a, b, { d.hasCam(it) }, cams[0]) else null
        }
    }

    /** إعدادات الفلوق الافتراضية لمشروع جديد */
    private fun vlogDefaults(d: Data, p: PodProject) {
        if (!d.setup.vlog) return
        p.st.glow = d.setup.glow
        // المونتاج الطبيعي: تلقائي على اللي بيحكي؛ إلا إذا اخترت كاميرات بإيدك وقت التصوير
        p.st.liveSwitch = d.live.isNotEmpty()
        if (d.setup.vlogLayout == "mainboxes") p.st.pinned = d.setup.people.indices.filter { d.hasCam(it) }.drop(1)
        if (p.kind == PodProject.EPISODE) p.st.orient = "v"
    }

    fun newEpisode(d: Data): PodProject {
        val p = PodProject("episode", PodProject.EPISODE)
        p.title = tx("الحلقة الكاملة", "Full episode")
        p.st.height = d.setup.height
        p.st.fade = d.setup.fade
        // اتجاه الإخراج الافتراضي = اتجاه أغلب الكاميرات (لا نقص صورًا عمودية داخل إطار أفقي)
        if (camerasMostlyPortrait(d)) p.st.orient = "v"
        p.st.flipFill = defaultFlipFill
        vlogDefaults(d, p)
        regenerate(d, p)
        return p
    }

    /** هل أغلب فيديوهات الكاميرات عمودية؟ (يُحسب عند التحميل) */
    fun camerasMostlyPortrait(d: Data): Boolean = d.camsPortrait

    private fun portraitCams(ctx: Context, s: SessionInfo): Boolean {
        var por = 0; var land = 0
        for (dv in s.devices.values) {
            val v = try { org.json.JSONObject(File(SessionStore.devDir(ctx, s.id, dv.id), "meta.json").readText()).optJSONObject("video") } catch (_: Throwable) { null } ?: continue
            if (v.optInt("h") > v.optInt("w")) por++ else land++
        }
        return por > land
    }

    fun newReel(d: Data, a: Double, b: Double, title: String, reason: String, target: Float): PodProject {
        val p = PodProject(ProjectStore.newReelId(), PodProject.REEL)
        p.a = a.coerceIn(0.0, max(0.0, d.duration - 1.0))
        p.b = b.coerceIn(min(p.a + 1.0, d.duration), d.duration)
        p.title = title
        p.reason = reason
        p.st.targetLen = target
        p.st.captions = d.tr != null
        p.st.height = d.setup.height
        p.st.flipFill = defaultFlipFill
        vlogDefaults(d, p)
        regenerate(d, p)
        return p
    }

    /** خيار الإعدادات: كيف تُملأ لحظة قلب الكاميرا في المشاريع الجديدة */
    @Volatile var defaultFlipFill = "freeze"

    /** الأجزاء الباقية من المشروع بعد كل الحذف (الصمت، الفراغات، الجمل المحذوفة) */
    fun keepSegs(d: Data, p: PodProject): List<DoubleArray> {
        val cuts = if (p.kind == PodProject.REEL && p.st.silence == "off") p.cuts.filter { it.kind != PCut.SILENCE } else p.cuts
        return PodEngine.keepSegments(p.a, p.end(d.duration), cuts)
    }

    /** نفس قرارات التصدير؛ المعاينة: 20 ثانية من زمن الجلسة from (بعد القص) وبدقة خفيفة */
    fun buildJob(ctx: Context, d: Data, p: PodProject, vertical: Boolean, preview: Boolean, from: Double = 0.0, previewLen: Double = 20.0): RenderJob {
        var segs = keepSegs(d, p)
        var previewOffset = 0.0
        if (preview) {
            val map = PodEngine.TimeMap(segs)
            val o0 = max(0.0, min(map.toOutNearest(from), map.outDur - previewLen))
            val o1 = min(map.outDur, o0 + previewLen)
            previewOffset = o0
            val win = ArrayList<DoubleArray>()
            for ((i, sg) in segs.withIndex()) {
                val sa = map.outStart[i]
                val sb = sa + (sg[1] - sg[0])
                val x0 = max(sa, o0); val x1 = min(sb, o1)
                if (x1 - x0 > 0.04) win.add(doubleArrayOf(sg[0] + (x0 - sa), sg[0] + (x1 - sa)))
            }
            segs = win
        }
        val shots = if (p.shots.isNotEmpty()) p.shots else PodEngine.autoShots(d.an, d.setup.people.size, d.setup.wides.isNotEmpty(), p.st.pip, p.st, p.a, p.end(d.duration), d.regions)
        val zooms = if (p.st.zoomMode == "off") emptyList() else p.zooms.toList()
        val caps = if (p.st.captions && d.tr != null) {
            val a = p.a; val b = p.end(d.duration)
            val emph = HashSet(p.emph)
            if (p.st.highlight) d.sem?.emphWords?.let { emph.addAll(it) }
            PodEngine.captionChunks(d.tr.segs.filter { it.b > a && it.a < b }, if (p.st.highlight) emph else emptySet())
        } else emptyList()
        val faces = HashMap<String, FaceTrack>()
        if (p.st.faces) {
            val devs = (d.setup.people.map { it.camDev } + d.setup.wides).filter { it.isNotEmpty() }.distinct()
            for (dev in devs) PodFaces.load(ctx, d.s.id, dev)?.let { faces[dev] = it }
        }
        val label = when {
            preview -> "_preview"
            p.kind == PodProject.REEL -> "_reel_" + p.a.toInt()
            else -> ""
        }
        return RenderJob(
            shots = shots, segs = segs, vertical = vertical, label = label, zooms = zooms, captions = caps,
            title = if (p.st.titleOn) p.title else "", titleSecs = p.st.titleSecs.toDouble(), fade = p.st.fade,
            height = p.st.height, capSize = p.st.capSize, faces = faces, preview = preview,
            outFile = if (preview) File(ctx.cacheDir, "pod_preview.mp4") else null,
            outOffset = previewOffset,
            frame = p.st.frame, fill = p.st.fill, pinned = p.st.pinned, glow = p.st.glow, flipFill = p.st.flipFill,
        )
    }

    /** ملف SRT لمشروع (بأزمنة النسخة المعدّلة)، مع ترجمة اختيارية للنصوص */
    fun srtFor(d: Data, p: PodProject, texts: List<String>? = null): String {
        val tr = d.tr ?: return ""
        val a = p.a; val b = p.end(d.duration)
        val segs = tr.segs.filter { it.b > a && it.a < b }
        val map = PodEngine.TimeMap(keepSegs(d, p))
        val entries = segs.mapIndexed { i, g -> Triple(max(a, g.a), min(b, g.b), texts?.getOrNull(i) ?: g.text) }
            .filter { e -> map.toOut((e.first + e.second) / 2) != null }
        return PodEngine.srt(entries, map)
    }
}
