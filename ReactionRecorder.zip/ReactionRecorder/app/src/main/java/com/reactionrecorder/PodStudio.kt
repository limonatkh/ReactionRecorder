package com.reactionrecorder

import android.content.Context
import java.io.File
import kotlin.math.max
import kotlin.math.min

/**
 * ربط منطق المونتاج (PodEngine) بملفات الجلسة: تحميل التحليل والنص، توليد/إعادة توليد مشروع مع حماية المثبّت،
 * وبناء مهمة التصدير أو المعاينة بنفس القرارات.
 */
object PodStudio {
    class Data(val s: SessionInfo, val setup: PodSetup, val an: PodAnalysis, val tr: Transcript?, val sem: Semantic?, val markers: List<PMarker>) {
        var camsPortrait = false
        val duration get() = an.duration
        val names get() = setup.people.map { it.name }
        val turns: List<PodEngine.Turn> by lazy { PodEngine.markBackchannels(PodEngine.turns(an, setup.people.size)) }
        /** طبيعة الحوار: من التحليل الدلالي إن وُجد (أدق)، وإلا من التوقيت محليًا */
        val regions: List<PodEngine.Region> by lazy {
            val ai = sem?.regions
            if (!ai.isNullOrEmpty()) ai else PodEngine.regions(turns, an.duration)
        }
    }

    /** نتيجة آخر مزامنة بالصوت (للعرض في الواجهة) */
    @Volatile var lastSync: List<PodSync.SyncResult> = emptyList()

    /** يحمّل كل ما يلزم؛ يحلل الصوت إن لم يكن محللًا (ويحفظ النتيجة فقط إذا اكتمل) */
    fun load(ctx: Context, sid: String, progress: (Float) -> Unit, cancelled: () -> Boolean): Data? {
        val s = SessionStore.load(ctx, sid) ?: return null
        val setup = PodcastAnalyzer.setupOf(s)
        var ss = s
        // أجهزة بلا قياس ساعة (انضمت متأخرة / استيراد يدوي): نضبطها بالصوت قبل التحليل
        val unsynced = s.devices.values.any { it.started && it.samples.isEmpty() && File(SessionStore.devDir(ctx, sid, it.id), "audio.wav").exists() }
        if (unsynced) {
            val r = PodSync.syncBySound(ctx, sid, emptySet(), { f -> progress(f * 0.2f) }, cancelled)
            if (cancelled()) return null
            if (r.any { it.ok }) {
                try { File(SessionStore.dir(ctx, sid), "pod_analysis.json").delete() } catch (_: Throwable) {}
                ss = SessionStore.load(ctx, sid) ?: s
            }
            lastSync = r
        }
        val an = PodcastAnalyzer.loadAnalysis(ctx, sid) ?: run {
            val a = PodcastAnalyzer.analyze(ctx, ss, setup, progress, cancelled)
            if (cancelled()) return null
            PodcastAnalyzer.saveAnalysis(ctx, sid, a)
            a
        }
        return Data(ss, setup, an, PodAI.loadTranscript(ctx, sid), PodAI.loadSemantic(ctx, sid), ProjectStore.markers(ctx, ss)).also { it.camsPortrait = portraitCams(ctx, ss) }
    }

    /**
     * إعادة توليد العناصر غير المثبّتة (كل المشروع أو المدى [ra,rb] فقط):
     * اللقطات، قص الصمت التلقائي (للريلز)، وحركات الزوم التلقائية.
     */
    fun regenerate(d: Data, p: PodProject, ra: Double? = null, rb: Double? = null) {
        val a = p.a
        val b = p.end(d.duration)
        val r0 = ra ?: a
        val r1 = rb ?: b
        val fresh = PodEngine.autoShots(d.an, d.setup.people.size, d.setup.wides.isNotEmpty(), p.st.pip, p.st, a, b, d.regions)
        p.shots = if (p.shots.isEmpty()) fresh else PodEngine.regenerate(p.shots, fresh, a, b, ra, rb)
        if (p.kind == PodProject.REEL) {
            p.cuts.removeAll { it.kind == PCut.SILENCE && !it.locked && it.b > r0 && it.a < r1 }
            p.cuts.addAll(PodEngine.silenceCuts(d.an, d.turns, p.st.silence, r0, r1))
            p.cuts.sortBy { it.a }
        }
        val keepZ = p.zooms.filter { it.locked || !it.auto || it.b <= r0 || it.a >= r1 }
        val fz = PodEngine.autoZooms(p.shots, d.turns, d.regions, p.st, d.sem?.keys, r0, r1)
            .filter { z -> z.a < r1 && z.b > r0 && keepZ.none { k -> z.a < k.b && z.b > k.a } }
        val merged = (keepZ.map { it.copy() } + fz).sortedBy { it.a }
        p.zooms.clear()
        p.zooms.addAll(merged)
    }

    fun newEpisode(d: Data): PodProject {
        val p = PodProject("episode", PodProject.EPISODE)
        p.title = tx("الحلقة الكاملة", "Full episode")
        p.st.height = d.setup.height
        p.st.fade = d.setup.fade
        // اتجاه الإخراج الافتراضي = اتجاه أغلب الكاميرات (لا نقص صورًا عمودية داخل إطار أفقي)
        if (camerasMostlyPortrait(d)) p.st.orient = "v"
        regenerate(d, p)
        return p
    }

    /** هل أغلب فيديوهات الكاميرات عمودية؟ (يُحسب عند التحميل) */
    fun camerasMostlyPortrait(d: Data): Boolean = d.camsPortrait

    private fun portraitCams(ctx: Context, s: SessionInfo): Boolean {
        var por = 0; var land = 0
        for (dv in s.devices.values) {
            val v = try { org.json.JSONObject(File(SessionStore.devDir(ctx, s.id, dv.id), "meta.json").readText()).optJSONObject("video") } catch (_: Throwable) { null } ?: continue
            if (v.optInt("h") > v.optInt("w")) por++ else land++
        }
        return por > land
    }

    fun newReel(d: Data, a: Double, b: Double, title: String, reason: String, target: Float): PodProject {
        val p = PodProject(ProjectStore.newReelId(), PodProject.REEL)
        p.a = a.coerceIn(0.0, max(0.0, d.duration - 1.0))
        p.b = b.coerceIn(min(p.a + 1.0, d.duration), d.duration)
        p.title = title
        p.reason = reason
        p.st.targetLen = target
        p.st.captions = d.tr != null
        p.st.height = d.setup.height
        regenerate(d, p)
        return p
    }

    /** الأجزاء الباقية من المشروع بعد كل الحذف (الصمت، الفراغات، الجمل المحذوفة) */
    fun keepSegs(d: Data, p: PodProject): List<DoubleArray> {
        val cuts = if (p.kind == PodProject.REEL && p.st.silence == "off") p.cuts.filter { it.kind != PCut.SILENCE } else p.cuts
        return PodEngine.keepSegments(p.a, p.end(d.duration), cuts)
    }

    /** نفس قرارات التصدير؛ المعاينة: 20 ثانية من زمن الجلسة from (بعد القص) وبدقة خفيفة */
    fun buildJob(ctx: Context, d: Data, p: PodProject, vertical: Boolean, preview: Boolean, from: Double = 0.0, previewLen: Double = 20.0): RenderJob {
        var segs = keepSegs(d, p)
        var previewOffset = 0.0
        if (preview) {
            val map = PodEngine.TimeMap(segs)
            val o0 = max(0.0, min(map.toOutNearest(from), map.outDur - previewLen))
            val o1 = min(map.outDur, o0 + previewLen)
            previewOffset = o0
            val win = ArrayList<DoubleArray>()
            for ((i, sg) in segs.withIndex()) {
                val sa = map.outStart[i]
                val sb = sa + (sg[1] - sg[0])
                val x0 = max(sa, o0); val x1 = min(sb, o1)
                if (x1 - x0 > 0.04) win.add(doubleArrayOf(sg[0] + (x0 - sa), sg[0] + (x1 - sa)))
            }
            segs = win
        }
        val shots = if (p.shots.isNotEmpty()) p.shots else PodEngine.autoShots(d.an, d.setup.people.size, d.setup.wides.isNotEmpty(), p.st.pip, p.st, p.a, p.end(d.duration), d.regions)
        val zooms = if (p.st.zoomMode == "off") emptyList() else p.zooms.toList()
        val caps = if (p.st.captions && d.tr != null) {
            val a = p.a; val b = p.end(d.duration)
            val emph = HashSet(p.emph)
            if (p.st.highlight) d.sem?.emphWords?.let { emph.addAll(it) }
            PodEngine.captionChunks(d.tr.segs.filter { it.b > a && it.a < b }, if (p.st.highlight) emph else emptySet())
        } else emptyList()
        val faces = HashMap<String, FaceTrack>()
        if (p.st.faces) {
            val devs = (d.setup.people.map { it.camDev } + d.setup.wides).filter { it.isNotEmpty() }.distinct()
            for (dev in devs) PodFaces.load(ctx, d.s.id, dev)?.let { faces[dev] = it }
        }
        val label = when {
            preview -> "_preview"
            p.kind == PodProject.REEL -> "_reel_" + p.a.toInt()
            else -> ""
        }
        return RenderJob(
            shots = shots, segs = segs, vertical = vertical, label = label, zooms = zooms, captions = caps,
            title = if (p.st.titleOn) p.title else "", titleSecs = p.st.titleSecs.toDouble(), fade = p.st.fade,
            height = p.st.height, capSize = p.st.capSize, faces = faces, preview = preview,
            outFile = if (preview) File(ctx.cacheDir, "pod_preview.mp4") else null,
            outOffset = previewOffset,
            frame = p.st.frame, fill = p.st.fill, pinned = p.st.pinned,
        )
    }

    /** ملف SRT لمشروع (بأزمنة النسخة المعدّلة)، مع ترجمة اختيارية للنصوص */
    fun srtFor(d: Data, p: PodProject, texts: List<String>? = null): String {
        val tr = d.tr ?: return ""
        val a = p.a; val b = p.end(d.duration)
        val segs = tr.segs.filter { it.b > a && it.a < b }
        val map = PodEngine.TimeMap(keepSegs(d, p))
        val entries = segs.mapIndexed { i, g -> Triple(max(a, g.a), min(b, g.b), texts?.getOrNull(i) ?: g.text) }
            .filter { e -> map.toOut((e.first + e.second) / 2) != null }
        return PodEngine.srt(entries, map)
    }
}
