package com.reactionrecorder

import android.content.Intent
import android.graphics.Color
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.VideoView
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * اختيار مقطع من الحلقة (للإنترو): بتختار الكاميرا، بتشغّل الفيديو بصوته، بتقدّم وبترجّع،
 * وبتحدد «بداية هون» و«نهاية هون». بيرجع ia/ib (ثواني على خط الجلسة) وicam.
 */
class IntroPickActivity : BaseActivity() {
    private lateinit var sid: String
    private lateinit var s: SessionInfo
    private lateinit var setup: PodSetup
    private val cams = ArrayList<Int>()
    private var cam = 0
    private var a = 0.0
    private var b = 10.0
    private var dur = 60.0
    /** فرق الوقت بين خط الجلسة وملف الفيديو/الصوت (ms) */
    private var vOff = 0.0
    private var aOff = 0.0
    private lateinit var video: VideoView
    private var audio: MediaPlayer? = null
    private lateinit var seek: SeekBar
    private lateinit var timeTv: TextView
    private lateinit var rangeTv: TextView
    private lateinit var camRow: LinearLayout
    private lateinit var playBtn: android.widget.Button
    private val ui = Handler(Looper.getMainLooper())
    private var playing = false
    /** لما بنشغّل المقطع: بنوقف عند النهاية */
    private var stopAt = -1.0
    private var t = 0.0

    private fun dp(v: Int) = UiKit.dp(this, v)
    private fun fmt(x: Double): String { val q = max(0.0, x); return "${q.toInt() / 60}:${String.format(Locale.US, "%04.1f", q % 60)}" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sid = intent.getStringExtra("session") ?: run { finish(); return }
        s = SessionStore.load(this, sid) ?: run { finish(); return }
        setup = PodcastAnalyzer.setupOf(s)
        for ((i, p) in setup.people.withIndex()) if (p.camDev.isNotEmpty() && File(SessionStore.devDir(this, sid, p.camDev), "video.mp4").exists()) cams.add(i)
        dur = PodcastAnalyzer.duration(s)
        a = intent.getDoubleExtra("a", 0.0).coerceIn(0.0, dur); b = intent.getDoubleExtra("b", a + 10.0).coerceIn(a, dur)
        if (b - a < 1.0) b = min(dur, a + 10.0)
        cam = intent.getIntExtra("cam", -1).takeIf { it in cams } ?: cams.firstOrNull() ?: 0
        t = a

        val col = UiKit.page(this, tx("اختار مقطع الإنترو", "Pick the intro clip"))
        camRow = LinearLayout(this)
        col.addView(android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(camRow) })
        val box = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        video = VideoView(this)
        box.addView(video, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        col.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220)).apply { topMargin = dp(8) })
        timeTv = UiKit.text(this, "", 16f, UiKit.TEXT, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0) }
        col.addView(timeTv)
        seek = SeekBar(this).apply {
            max = (dur * 10).toInt(); minimumHeight = dp(44)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) { if (u) { t = p / 10.0; showTime(); if (!playing) seekAll(t) } }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) { seekAll(t) }
            })
        }
        col.addView(seek)
        // التحكم: رجوع/تقديم + تشغيل
        val ctl = LinearLayout(this).apply { gravity = Gravity.CENTER }
        fun c(label: String, run: () -> Unit) = ctl.addView(UiKit.chip(this, label) { run() }.apply { textSize = 15f }, LinearLayout.LayoutParams(0, dp(52), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        c("−5") { jump(-5.0) }; c("−1") { jump(-1.0) }
        playBtn = UiKit.primary(this, "▶") { toggle() }
        ctl.addView(playBtn, LinearLayout.LayoutParams(0, dp(52), 1.3f).apply { setMargins(dp(3), 0, dp(3), 0) })
        c("+1") { jump(1.0) }; c("+5") { jump(5.0) }
        col.addView(ctl, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
        // البداية والنهاية
        rangeTv = UiKit.text(this, "", 15f, "#FFD60A", true).apply { gravity = Gravity.CENTER; setPadding(0, dp(14), 0, dp(4)) }
        col.addView(rangeTv)
        val se = LinearLayout(this)
        se.addView(UiKit.chip(this, "⟵ " + tx("البداية هون", "Start here")) { a = t; if (b <= a + 0.5) b = min(dur, a + 10.0); showRange() }, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginEnd = dp(6) })
        se.addView(UiKit.chip(this, tx("النهاية هون", "End here") + " ⟶") { b = t; if (a >= b - 0.5) a = max(0.0, b - 10.0); showRange() }, LinearLayout.LayoutParams(0, dp(54), 1f))
        col.addView(se)
        val pr = UiKit.chip(this, "▶ " + tx("شغّل المقطع من أوله", "Play the clip from its start")) { t = a; seekAll(a); stopAt = b; if (!playing) toggle() }
        col.addView(pr, UiKit.full(this, pr, 8, 52))
        val ok = UiKit.primary(this, "✓ " + tx("خلّي هاد الإنترو", "Use this as the intro")) {
            setResult(RESULT_OK, Intent().putExtra("a", a).putExtra("b", b).putExtra("cam", cam)); finish()
        }
        col.addView(ok, UiKit.full(this, ok, 16, 56))
        renderCams(); showRange(); load()
    }

    private fun renderCams() {
        camRow.removeAllViews()
        for (i in cams) camRow.addView(UiKit.chip(this, "🎥 " + setup.people[i].name, i == cam) { if (cam != i) { cam = i; renderCams(); load() } },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(6) })
    }

    private fun showTime() { timeTv.text = fmt(t) + "  /  " + fmt(dur); seek.progress = (t * 10).toInt() }
    private fun showRange() { rangeTv.text = tx("الإنترو: ${fmt(a)} → ${fmt(b)}  (${(b - a).toInt()} ث)", "Intro: ${fmt(a)} → ${fmt(b)}  (${(b - a).toInt()} s)") }

    /** فيديو الكاميرا + صوت مايك صاحبها، والاثنين على نفس الوقت */
    private fun load() {
        pause()
        val p = setup.people.getOrNull(cam) ?: return
        val dv = s.devices[p.camDev] ?: return
        val dir = SessionStore.devDir(this, sid, p.camDev)
        try {
            val vm = JSONObject(File(dir, "meta.json").readText()).optJSONObject("video")
            if (vm != null) {
                val tm = Finalizer.SatVideoTime(s, dv, vm.optLong("startBoot"))
                vOff = tm.fileMs(0L)
            }
        } catch (_: Throwable) { vOff = 0.0 }
        video.setVideoURI(Uri.fromFile(File(dir, "video.mp4")))
        video.setOnPreparedListener { mp -> mp.setVolume(0f, 0f); seekAll(t) }
        audio?.release(); audio = null
        try {
            val mic = PodcastAnalyzer.micOf(this, s, p)
            val src = PodAudioSrc.open(this, s, mic)
            if (src != null) {
                aOff = src.nAt(0.0) / src.rd.rate * 1000.0
                src.close()
                audio = MediaPlayer().apply { setDataSource(File(SessionStore.devDir(this@IntroPickActivity, sid, mic), "audio.wav").absolutePath); prepare() }
            }
        } catch (_: Throwable) { audio = null }
        showTime()
    }

    private fun seekAll(x: Double) {
        try { video.seekTo((x * 1000 + vOff).toInt().coerceAtLeast(0)) } catch (_: Throwable) {}
        try { audio?.seekTo((x * 1000 + aOff).toInt().coerceAtLeast(0)) } catch (_: Throwable) {}
    }

    private fun jump(d: Double) { t = (t + d).coerceIn(0.0, dur); showTime(); seekAll(t) }

    private fun toggle() { if (playing) pause() else play() }

    private fun play() {
        seekAll(t)
        video.start(); audio?.start(); playing = true; playBtn.text = "⏸"
        ui.post(tick)
    }

    private fun pause() {
        playing = false; stopAt = -1.0
        if (::playBtn.isInitialized) playBtn.text = "▶"
        try { video.pause() } catch (_: Throwable) {}
        try { audio?.pause() } catch (_: Throwable) {}
        ui.removeCallbacks(tick)
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!playing) return
            val vt = (video.currentPosition - vOff) / 1000.0
            if (vt > 0) t = vt
            // الصوت بيمشي مع الصورة: إذا بعدوا أكثر من ربع ثانية بنرجّعه
            audio?.let { m -> val at = (m.currentPosition - aOff) / 1000.0; if (abs(at - t) > 0.25) m.seekTo((t * 1000 + aOff).toInt().coerceAtLeast(0)) }
            showTime()
            if (stopAt > 0 && t >= stopAt) { pause(); return }
            ui.postDelayed(this, 200)
        }
    }

    override fun onPause() { super.onPause(); pause() }
    override fun onDestroy() { super.onDestroy(); audio?.release(); audio = null }
}
