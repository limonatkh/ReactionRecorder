package com.reactionrecorder

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.Locale

/**
 * حوار / بودكاست: الأجهزة ← الأشخاص ← تسجيل. كل قسم يطوى، والمراقبة الخفيفة ظاهرة دائمًا.
 * التسجيلات ومونتاجها في "تسجيلاتي".
 */
class PodcastActivity : BaseActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var setup: PodSetup
    private lateinit var devBody: LinearLayout
    private lateinit var hubTv: TextView
    private lateinit var thisPhoneRow: LinearLayout
    private lateinit var qrView: ImageView
    private lateinit var devList: LinearLayout
    private lateinit var peopleBody: LinearLayout
    private lateinit var countRow: LinearLayout
    private lateinit var peopleBox: LinearLayout
    private lateinit var widesBox: LinearLayout
    private lateinit var styleBody: LinearLayout
    private lateinit var monitorRow: LinearLayout
    private lateinit var recBtn: Button
    private lateinit var recTv: TextView
    private lateinit var markerRow: LinearLayout
    private lateinit var lastTv: TextView
    private var lastSid: String? = null
    private var qrFor = ""
    private var devSig = ""
    private val monViews = HashMap<String, ImageView>()
    private val monSeen = HashMap<String, Long>()
    private val levelBars = HashMap<Int, ProgressBar>()
    private val devLines = HashMap<String, TextView>()

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { pendingAfterPerm?.invoke(); pendingAfterPerm = null }
    private var pendingAfterPerm: (() -> Unit)? = null

    private val pickBg = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Throwable) {}
            setup.bgImage = u.toString()
            save(); buildStyle()
        }
    }

    private fun dp(v: Int) = UiKit.dp(this, v)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun granted(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setup = PodSetup.loadDefault(this)
        lastSid = getSharedPreferences("reaction_podcast", MODE_PRIVATE).getString("lastSid", null)
        build()
        if (!SatHub.running) {
            val c = applicationContext
            Thread { try { SatHub.start(c); SatHub.setHubWanted(c, SatHub.running) } catch (_: Throwable) {} }.start()
        }
    }

    override fun onResume() {
        super.onResume()
        devSig = ""
        ui.post(tick)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(tick)
        for (l in SatHub.links.values) SatHub.setPreview(l.id, l.stripOn, false, l.stripOn)
    }

    private fun save() = PodSetup.saveDefault(this, setup)

    private fun build() {
        val col = UiKit.page(this, "🎙 " + tx("حوار / بودكاست", "Conversation / podcast"),
            tx("وصّل الجوالات، أعطِ كل شخص كاميرا ومايك، ثم سجّل. المونتاج بعدين من تسجيلاتي.", "Connect the phones, give each person a camera and a mic, then record. Edit later from My recordings."))

        // ── الأجهزة
        devBody = UiKit.section(this, col, "pod_dev", "📡 " + tx("الأجهزة", "Devices"), "", openByDefault = true)
        hubTv = UiKit.text(this, "", 12.5f, UiKit.SUB)
        devBody.addView(hubTv)
        devBody.addView(UiKit.text(this, tx("هذا الجوال", "This phone"), 13f, UiKit.TEXT, true).apply { setPadding(0, dp(10), 0, dp(2)) })
        thisPhoneRow = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        devBody.addView(thisPhoneRow)
        buildThisPhone()
        devBody.addView(UiKit.text(this, tx("الأجهزة المتصلة", "Connected devices"), 13f, UiKit.TEXT, true).apply { setPadding(0, dp(12), 0, dp(2)) })
        devList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        devBody.addView(devList)
        val qrBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; visibility = View.GONE }
        qrView = ImageView(this).apply { setBackgroundColor(Color.WHITE); setPadding(dp(8), dp(8), dp(8), dp(8)) }
        qrBox.addView(UiKit.text(this, tx("على الجوال الآخر: انضمام لتسجيل ← اختر الدور ← امسح هذا الباركود. يتصل تلقائيًا، ويرجع لحاله إذا انقطع.", "On the other phone: Join a recording ← pick a role ← scan this code. It connects by itself and reconnects if dropped."), 12f, UiKit.SUB))
        qrBox.addView(qrView, LinearLayout.LayoutParams(dp(230), dp(230)).apply { topMargin = dp(8) })
        val qrBtn = UiKit.chip(this, "➕ " + tx("أضف جهازًا (باركود)", "Add a device (QR)")) {}
        qrBtn.setOnClickListener { qrBox.visibility = if (qrBox.visibility == View.VISIBLE) View.GONE else View.VISIBLE; qrFor = "" }
        devBody.addView(qrBtn, UiKit.full(this, qrBtn, 8))
        devBody.addView(qrBox)

        // ── الأشخاص
        peopleBody = UiKit.section(this, col, "pod_people", "👥 " + tx("الأشخاص", "People"), "", openByDefault = true)
        countRow = LinearLayout(this)
        peopleBody.addView(UiKit.text(this, tx("كم شخص؟", "How many people?"), 12.5f, UiKit.SUB))
        peopleBody.addView(countRow)
        peopleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        peopleBody.addView(peopleBox)
        peopleBody.addView(UiKit.text(this, tx("كاميرا عامة (تُظهر الجميع) — اختياري", "Wide camera (shows everyone) — optional"), 13f, UiKit.TEXT, true).apply { setPadding(0, dp(12), 0, 0) })
        widesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        peopleBody.addView(widesBox)

        // ── شكل اللقطات المشتركة
        styleBody = UiKit.section(this, col, "pod_style", "🖼 " + tx("شكل المشهد عند تكلّم أكثر من شخص", "Look when several people speak"), tx("تقسيم الشاشة أو مربعات", "Split screen or boxes"))
        buildStyle()

        // ── المراقبة
        val mon = UiKit.card(this, tx("مراقبة خفيفة", "Light monitor"), col)
        mon.addView(UiKit.text(this, tx("صور صغيرة للاطمئنان فقط — التسجيل الحقيقي بجودة كاملة على كل جوال.", "Small pictures for peace of mind — each phone records in full quality."), 11.5f, UiKit.SUB))
        monitorRow = LinearLayout(this)
        mon.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(monitorRow) }, UiKit.full(this, monitorRow, 6))
        val studioBtn = UiKit.chip(this, "🎛 " + tx("شاشة الستوديو (كل الكاميرات)", "Studio screen (all cameras)")) { startActivity(Intent(this, MonitorActivity::class.java)) }
        mon.addView(studioBtn, UiKit.full(this, studioBtn, 8))

        // ── التسجيل
        recTv = UiKit.text(this, "", 15f, UiKit.TEXT, true).apply { gravity = Gravity.CENTER }
        col.addView(recTv, UiKit.full(this, recTv, 14))
        recBtn = UiKit.primary(this, "") { onRecord() }
        col.addView(recBtn, UiKit.full(this, recBtn, 6, 58))
        markerRow = UiKit.row(this,
            UiKit.chip(this, "⭐ " + tx("لحظة مهمة", "Key moment"), true) { mark("star") },
            UiKit.chip(this, "✖ " + tx("غلطة / إعادة", "Mistake / retake")) { mark("oops") },
        )
        col.addView(markerRow, UiKit.full(this, markerRow, 6))
        lastTv = UiKit.text(this, "", 13f, UiKit.SUB).apply {
            background = UiKit.bg(UiKit.CARD, 14, this@PodcastActivity)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setOnClickListener { lastSid?.let { startActivity(Intent(this@PodcastActivity, SessionActivity::class.java).putExtra("session", it)) } }
        }
        col.addView(lastTv, UiKit.full(this, lastTv, 12))
        val all = UiKit.chip(this, "📁 " + tx("كل التسجيلات", "All recordings")) { startActivity(Intent(this, RecordingsActivity::class.java)) }
        col.addView(all, UiKit.full(this, all, 8))
        setPeople(setup.people.size.coerceIn(1, 4))
    }

    // ───────── هذا الجوال ─────────

    private fun buildThisPhone() {
        thisPhoneRow.removeAllViews()
        val mode = if (!SatState.serviceOn) "off" else SatCfg.load(this).role
        val sc = SatCfg.load(this)
        thisPhoneRow.addView(UiKit.row(this,
            UiKit.chip(this, tx("لا يسجّل", "Not recording"), mode == "off") { stopThisPhone() },
            UiKit.chip(this, "🎥 " + tx("كاميرا + مايك", "Camera + mic"), mode == "both") { startThisPhone("both", sc.front) },
            UiKit.chip(this, "🎤 " + tx("مايك", "Mic"), mode == "mic") { startThisPhone("mic", sc.front) },
        ))
        if (mode == "both") {
            thisPhoneRow.addView(UiKit.row(this,
                UiKit.chip(this, if (sc.front) tx("الكاميرا الأمامية", "Front camera") else tx("الكاميرا الخلفية", "Back camera")) { startThisPhone("both", !sc.front) },
                UiKit.chip(this, when (sc.orient) { "portrait" -> tx("عمودي", "Portrait"); "landscape" -> tx("أفقي", "Landscape"); else -> tx("اتجاه تلقائي", "Auto orientation") }) {
                    val c = SatCfg.load(this)
                    c.orient = when (c.orient) { "auto" -> "portrait"; "portrait" -> "landscape"; else -> "auto" }
                    SatCfg.save(this, c); buildThisPhone()
                },
            ))
        }
    }

    /** هذا الجوال يسجّل ككاميرا/مايك عبر نفس نظام الأجهزة المساعدة (اتصال داخلي) */
    private fun startThisPhone(role: String, front: Boolean, asked: Boolean = false) {
        if (asked) {
            if (!granted(Manifest.permission.RECORD_AUDIO)) { toast(tx("يلزم إذن المايك", "Microphone permission is required")); return }
            if (role == "both" && !granted(Manifest.permission.CAMERA)) { toast(tx("يلزم إذن الكاميرا", "Camera permission is required")); return }
        } else {
            val need = ArrayList<String>()
            if (!granted(Manifest.permission.RECORD_AUDIO)) need += Manifest.permission.RECORD_AUDIO
            if (role == "both" && !granted(Manifest.permission.CAMERA)) need += Manifest.permission.CAMERA
            if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) need += Manifest.permission.POST_NOTIFICATIONS
            if (need.isNotEmpty()) { pendingAfterPerm = { startThisPhone(role, front, true) }; perms.launch(need.toTypedArray()); return }
        }
        if (!SatHub.running) { toast(tx("جارٍ تشغيل الاستقبال… حاول بعد ثانية", "Starting… try again in a second")); return }
        if (RecorderState.isBusy) { toast(tx("أوقف تسجيل الرياكشن أولًا", "Stop the reaction recording first")); return }
        if (PodRec.active != null) { toast(tx("لا يمكن التغيير أثناء التسجيل", "Can't change while recording")); return }
        val c = SatCfg.load(this)
        val restart = SatState.serviceOn && (c.role != role || c.front != front)
        c.host = "127.0.0.1:${SatHub.port}"
        c.pin = SatHub.pin
        c.hubId = SatHub.hubId
        c.name = tx("هذا الجوال", "This phone")
        c.role = role
        c.front = front
        SatCfg.save(this, c)
        if (restart) {
            startService(Intent(this, SatelliteService::class.java).setAction(SatelliteService.ACTION_DISCONNECT))
            ui.postDelayed({
                if (!isFinishing && !isDestroyed) {
                    try { ContextCompat.startForegroundService(this, Intent(this, SatelliteService::class.java).setAction(SatelliteService.ACTION_CONNECT)) } catch (_: Throwable) { toast(tx("تعذرت إعادة التشغيل — اضغط مرة ثانية", "Could not restart — tap again")) }
                    buildThisPhone()
                }
            }, 2000)
        } else if (!SatState.serviceOn) {
            ContextCompat.startForegroundService(this, Intent(this, SatelliteService::class.java).setAction(SatelliteService.ACTION_CONNECT))
        }
        ui.postDelayed({ buildThisPhone() }, 400)
    }

    private fun stopThisPhone() {
        if (PodRec.active != null) { toast(tx("لا يمكن التغيير أثناء التسجيل", "Can't change while recording")); return }
        if (SatState.serviceOn) startService(Intent(this, SatelliteService::class.java).setAction(SatelliteService.ACTION_DISCONNECT))
        ui.postDelayed({ buildThisPhone() }, 400)
    }

    // ───────── الأشخاص ─────────

    private fun setPeople(n: Int) {
        while (setup.people.size < n) setup.people.add(PodPerson(tx("شخص", "Person") + " ${setup.people.size + 1}", "", ""))
        while (setup.people.size > n) setup.people.removeAt(setup.people.size - 1)
        save()
        countRow.removeAllViews()
        for (k in 1..4) countRow.addView(UiKit.chip(this, "$k", k == n) { if (PodRec.active == null) setPeople(k) },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(6) })
        devSig = ""
    }

    private class Dev(val id: String, val name: String)

    private fun devices(): List<Dev> = SatHub.links.values.sortedBy { it.name }.map {
        Dev(it.id, (if (it.connected) "🟢 " else "⚪ ") + it.name + if (it.role == "both") " (" + tx("كاميرا+مايك", "cam+mic") + ")" else " (" + tx("مايك", "mic") + ")")
    }

    private fun spinner(items: List<Dev>, selId: String, none: String, onSel: (String) -> Unit): Spinner {
        val labels = ArrayList(listOf(none) + items.map { it.name })
        val ids = ArrayList(listOf("") + items.map { it.id })
        if (selId.isNotEmpty() && selId !in ids) { ids.add(selId); labels.add("⚪ " + tx("جهاز محفوظ (غير متصل)", "Saved device (offline)")) }
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        sp.setSelection(ids.indexOf(selId).coerceAtLeast(0))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { onSel(ids[pos]) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        sp.isEnabled = PodRec.active == null
        return sp
    }

    private fun buildPeople() {
        peopleBox.removeAllViews()
        levelBars.clear()
        val devs = devices()
        val cams = devs.filter { d -> SatHub.links[d.id]?.role == "both" }
        if (devs.isEmpty()) peopleBox.addView(UiKit.text(this, tx("لا أجهزة بعد — وصّل الجوالات أولًا، أو اجعل هذا الجوال يسجّل.", "No devices yet — connect phones first, or let this phone record."), 12.5f, UiKit.ORANGE).apply { setPadding(0, dp(8), 0, 0) })
        for ((i, p) in setup.people.withIndex()) {
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(10)); background = UiKit.bg(UiKit.CARD2, 14, this@PodcastActivity) }
            val name = EditText(this).apply {
                setText(p.name); setTextColor(Color.WHITE); textSize = 15f; setSingleLine()
                addTextChangedListener(object : android.text.TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun afterTextChanged(e: android.text.Editable?) { p.name = e?.toString()?.ifBlank { tx("شخص", "Person") + " ${i + 1}" } ?: p.name; save() }
                })
            }
            box.addView(name)
            val r = LinearLayout(this)
            val c1 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            c1.addView(UiKit.text(this, "🎥 " + tx("كاميرته", "Camera"), 12f, UiKit.SUB))
            c1.addView(spinner(cams, p.camDev, tx("— بدون —", "— none —")) { id -> if (p.camDev != id) { p.camDev = id; save() } })
            val c2 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            c2.addView(UiKit.text(this, "🎤 " + tx("مايكه", "Mic"), 12f, UiKit.SUB))
            c2.addView(spinner(devs, p.micDev, tx("— بدون —", "— none —")) { id -> if (p.micDev != id) { p.micDev = id; save() } })
            r.addView(c1, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(8) })
            r.addView(c2, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            box.addView(r)
            val pb = UiKit.level(this)
            levelBars[i] = pb
            box.addView(pb, UiKit.full(this, pb, 6, 6))
            peopleBox.addView(box, UiKit.full(this, box, 8))
        }
        widesBox.removeAllViews()
        if (cams.isEmpty()) widesBox.addView(UiKit.text(this, tx("لا توجد كاميرات متصلة", "No cameras connected"), 12f, UiKit.SUB))
        for (d in cams) {
            widesBox.addView(CheckBox(this).apply {
                text = d.name; setTextColor(Color.WHITE)
                isChecked = d.id in setup.wides
                isEnabled = PodRec.active == null
                setOnCheckedChangeListener { _, on -> if (on) { if (d.id !in setup.wides) setup.wides.add(d.id) } else setup.wides.remove(d.id); save() }
            })
        }
        val nc = setup.people.count { it.camDev.isNotEmpty() }; val nm = setup.people.count { it.micDev.isNotEmpty() }
        UiKit.setSummary(peopleBody, tx("${setup.people.size} أشخاص • $nc كاميرا • $nm مايك", "${setup.people.size} people • $nc cameras • $nm mics"))
    }

    private fun buildStyle() {
        styleBody.removeAllViews()
        styleBody.addView(UiKit.row(this,
            UiKit.chip(this, "▥ " + tx("تقسيم الشاشة", "Split screen"), setup.multiStyle == "split") { setup.multiStyle = "split"; save(); buildStyle() },
            UiKit.chip(this, "▣ " + tx("مربعات على خلفية", "Boxes on a background"), setup.multiStyle == "boxes") { setup.multiStyle = "boxes"; save(); buildStyle() },
        ))
        if (setup.multiStyle == "boxes") {
            val colors = listOf(0xFF1B1D24.toInt(), 0xFF0B3D91.toInt(), 0xFF5B2C83.toInt(), 0xFF1E5631.toInt(), 0xFF7A1F1F.toInt(), 0xFFEDEDED.toInt())
            val r = LinearLayout(this)
            for (c in colors) {
                r.addView(View(this).apply {
                    background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(c); if (setup.bgColor == c && setup.bgImage.isEmpty()) setStroke(dp(3), Color.parseColor(UiKit.RED)) }
                    setOnClickListener { setup.bgColor = c; setup.bgImage = ""; save(); buildStyle() }
                }, LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(0, dp(6), dp(8), 0) })
            }
            styleBody.addView(r)
            styleBody.addView(UiKit.chip(this, if (setup.bgImage.isEmpty()) "🖼 " + tx("صورة كخلفية", "Image as background") else "🖼 " + tx("صورة مختارة ✓", "Image chosen ✓"), setup.bgImage.isNotEmpty()) { pickBg.launch(arrayOf("image/*")) })
        }
        styleBody.addView(UiKit.text(this, tx("التبديل بين المتكلمين والزوم والكتابة تُضبط لكل حلقة/ريل في المونتاج.", "Speaker switching, zoom and captions are set per episode/reel in the editor."), 11.5f, UiKit.SUB).apply { setPadding(0, dp(8), 0, 0) })
        UiKit.setSummary(styleBody, if (setup.multiStyle == "split") tx("تقسيم الشاشة", "Split screen") else tx("مربعات على خلفية", "Boxes on a background"))
    }

    // ───────── التسجيل ─────────

    private fun onRecord() {
        if (PodRec.active != null) {
            AlertDialog.Builder(this).setTitle(tx("إيقاف التسجيل؟", "Stop recording?"))
                .setMessage(tx("يتوقف على كل الجوالات ويُحفظ، ثم تُجمع الملفات تلقائيًا.", "It stops on every phone and is saved; the files are then collected automatically."))
                .setPositiveButton(tx("أوقف", "Stop")) { _, _ -> stopRec() }.setNegativeButton(tx("استمر", "Keep recording"), null).show()
            return
        }
        if (RecorderState.isBusy) { toast(tx("أوقف تسجيل الرياكشن أولًا", "Stop the reaction recording first")); return }
        if (!SatHub.running) { toast(tx("الاستقبال لا يعمل", "Receiving is off")); return }
        val missing = PodRec.check(setup)
        if (missing.isNotEmpty()) {
            AlertDialog.Builder(this).setTitle(tx("تحقّق قبل التسجيل", "Check before recording")).setMessage(missing.joinToString("\n"))
                .setPositiveButton(tx("سجّل على أي حال", "Record anyway")) { _, _ -> startRec() }.setNegativeButton(tx("إلغاء", "Cancel"), null).show()
        } else startRec()
    }

    private fun startRec() {
        val sid = PodRec.start(this, setup)
        lastSid = sid
        getSharedPreferences("reaction_podcast", MODE_PRIVATE).edit().putString("lastSid", sid).apply()
        devSig = ""
        render()
    }

    private fun stopRec() {
        PodRec.stop(this)
        toast(tx("حُفظ على كل جوال — جارٍ جمع الملفات", "Saved on every phone — collecting the files"))
        devSig = ""
        render()
    }

    private fun mark(kind: String) {
        PodRec.mark(this, kind)
        toast(if (kind == "star") "⭐ " + tx("سُجّلت لحظة مهمة", "Key moment marked") else "✖ " + tx("سُجّلت علامة غلطة (لن يُحذف شيء تلقائيًا)", "Mistake marked (nothing is deleted automatically)"))
    }

    private fun render() {
        val r = PodRec.active != null
        markerRow.visibility = if (r) View.VISIBLE else View.GONE
        recBtn.text = if (r) "■  " + tx("إيقاف", "Stop") else "●  " + tx("ابدأ التسجيل", "Start recording")
        recBtn.background = UiKit.bg(if (r) "#7A1F1A" else UiKit.RED, 24, this)
        if (r) {
            val sec = PodRec.elapsedSec(this)
            recTv.text = "🔴 " + String.format(Locale.US, "%d:%02d", sec / 60, sec % 60)
            recTv.visibility = View.VISIBLE
        } else recTv.visibility = View.GONE
    }

    // ───────── تحديث دوري ─────────

    private val tick = object : Runnable {
        override fun run() {
            if (!isFinishing && !isDestroyed) refresh()
            ui.postDelayed(this, 300)
        }
    }

    private fun refresh() {
        val conn = SatHub.links.values.count { it.connected }
        hubTv.text = if (SatHub.running) tx("الاستقبال يعمل • متصل: $conn", "Receiving • connected: $conn") else tx("تشغيل الاستقبال…", "Starting…")
        UiKit.setSummary(devBody, if (SatHub.running) tx("متصل: $conn جهاز", "Connected: $conn") else "")
        // الباركود
        if (SatHub.running) {
            val payload = AppShare.pairQr()
            if (payload != qrFor && (qrView.parent as View).visibility == View.VISIBLE) {
                qrFor = payload
                qrView.setImageBitmap(qrBitmap(payload))
            }
        }
        val rec = PodRec.active != null
        val sig = SatHub.links.values.joinToString("|") { "${it.id}${it.connected}${it.role}${it.name}" } + setup.people.size + rec
        if (sig != devSig) {
            devSig = sig
            buildPeople()
            buildThisPhone()
            buildDevList()
            val camIds = (setup.people.map { it.camDev } + setup.wides).filter { it.isNotEmpty() }.toSet()
            val micIds = setup.people.map { it.micDev }.filter { it.isNotEmpty() }.toSet()
            for (l in SatHub.links.values) {
                if (l.id in camIds) SatHub.setLightPreview(l.id, true, if (rec) 1000 else 400, 240)
                else SatHub.setPreview(l.id, l.stripOn, false, l.id in micIds || l.stripOn)
            }
            monitorRow.removeAllViews(); monViews.clear(); monSeen.clear()
            if (camIds.isEmpty()) monitorRow.addView(UiKit.text(this, tx("اختر كاميرات للأشخاص لتظهر هنا", "Pick cameras for people to see them here"), 12f, UiKit.SUB))
            for (id in camIds) {
                val iv = ImageView(this).apply { setBackgroundColor(Color.BLACK); scaleType = ImageView.ScaleType.FIT_CENTER }
                monViews[id] = iv
                val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setOnClickListener { startActivity(Intent(this@PodcastActivity, StudioActivity::class.java).putExtra("dev", id)) } }
                cell.addView(iv, LinearLayout.LayoutParams(dp(136), dp(100)))
                cell.addView(TextView(this).apply { text = SatHub.links[id]?.name ?: "?"; textSize = 11f; setTextColor(Color.parseColor(UiKit.SUB)); gravity = Gravity.CENTER })
                monitorRow.addView(cell, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(8) })
            }
        }
        for ((id, iv) in monViews) {
            val l = SatHub.links[id] ?: continue
            val f = l.frame
            if (f != null && monSeen[id] != l.frameAt) { iv.setImageBitmap(f); monSeen[id] = l.frameAt }
        }
        for ((i, pb) in levelBars) {
            val l = SatHub.links[setup.people.getOrNull(i)?.micDev ?: ""]
            pb.progress = if (l != null && l.connected) (l.level * 100 / 32767).coerceIn(0, 100) else 0
        }
        for (l in SatHub.links.values) devLines[l.id]?.text = devStatus(l)
        render()
        renderLast()
    }

    private fun devStatus(l: SatHub.Link): String = if (!l.connected) "⚪ " + tx("غير متصل", "Offline") else
        (if (l.recording) "🔴 " + tx("يسجّل", "Recording") else "🟢 " + tx("جاهز", "Ready")) +
            (if (l.battery >= 0) "  •  🔋${l.battery}%" else "") + (if (l.freeMb >= 0) "  •  💾" + String.format(Locale.US, "%.1fGB", l.freeMb / 1024f) else "") +
            (if (l.transfer.isNotEmpty()) "  •  ⬆ ${l.transfer}" else "")

    private fun buildDevList() {
        devList.removeAllViews(); devLines.clear()
        val links = SatHub.links.values.sortedBy { it.name }
        if (links.isEmpty()) devList.addView(UiKit.text(this, tx("لا أجهزة بعد", "No devices yet"), 12f, UiKit.SUB))
        for (l in links) {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
            val tcol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            tcol.addView(UiKit.text(this, (if (l.role == "both") "🎥 " else "🎤 ") + l.name, 14f))
            val st = UiKit.text(this, devStatus(l), 11.5f, UiKit.SUB)
            devLines[l.id] = st
            tcol.addView(st)
            row.addView(tcol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            PodUi.licenseButton(this, l) { ui.postDelayed({ buildDevList() }, 700) }?.let { row.addView(it) }
            row.addView(UiKit.chip(this, "🎛") { startActivity(Intent(this, StudioActivity::class.java).putExtra("dev", l.id)) })
            devList.addView(row)
        }
    }

    private fun renderLast() {
        val sid = lastSid
        if (sid == null || PodRec.active == sid) { lastTv.visibility = View.GONE; return }
        val s = SessionStore.load(this, sid)
        if (s == null) { lastTv.visibility = View.GONE; return }
        lastTv.visibility = View.VISIBLE
        val waiting = s.devices.values.filter { it.started && !it.uploaded }
        lastTv.text = tx("آخر تسجيل: ", "Last recording: ") + if (waiting.isEmpty()) "✓ " + tx("وصلت كل الملفات — اضغط للمونتاج", "all files received — tap to edit")
        else "⏳ " + tx("بانتظار: ", "waiting for: ") + waiting.joinToString(", ") { it.name } + tx(" (يصل تلقائيًا عند الاتصال) — اضغط للتفاصيل", " (arrives automatically when connected) — tap for details")
        lastTv.setTextColor(Color.parseColor(if (waiting.isEmpty()) UiKit.GREEN else UiKit.ORANGE))
    }

    companion object {
        fun qrBitmap(payload: String): android.graphics.Bitmap? = try {
            val bm = com.google.zxing.qrcode.QRCodeWriter().encode(payload, com.google.zxing.BarcodeFormat.QR_CODE, 512, 512)
            val px = IntArray(512 * 512)
            for (y in 0 until 512) for (x in 0 until 512) px[y * 512 + x] = if (bm.get(x, y)) Color.BLACK else Color.WHITE
            android.graphics.Bitmap.createBitmap(px, 512, 512, android.graphics.Bitmap.Config.ARGB_8888)
        } catch (_: Throwable) { null }
    }
}

/** أدوات واجهة مشتركة للبودكاست */
object PodUi {
    /** لصاحب التطبيق فقط: زر 🔓 يفعّل نسخة الجهاز المتصل يومًا، أو 🔒 يقفلها */
    fun licenseButton(a: AppCompatActivity, l: SatHub.Link, after: () -> Unit): View? {
        if (!License.isOwner(a) || !l.connected || l.licOwner || l.id == SatCfg.load(a).devId) return null
        val on = l.licLeft > 0
        return UiKit.chip(a, if (on) "🔒" else "🔓") {
            val ok = if (on) SatHub.revokeLicense(l.id) else SatHub.sendLicense(l.id, License.DAY)
            Toast.makeText(a, if (!ok) tx("تعذر الإرسال", "Could not send") else if (on) tx("أُقفلت نسخته", "Their copy is locked") else tx("فُعّلت نسخته ليوم", "Activated for 1 day"), Toast.LENGTH_SHORT).show()
            after()
        }
    }

    /** إعداد الخدمة الخارجية الاختيارية (تفريغ الكلام وفهم الحوار والترجمة) */
    fun aiDialog(a: AppCompatActivity) {
        val c = PodAI.cfg(a)
        val d = a.resources.displayMetrics.density
        val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding((18 * d).toInt(), (8 * d).toInt(), (18 * d).toInt(), (8 * d).toInt()) }
        col.addView(TextView(a).apply {
            textSize = 12f
            text = tx("اختياري. التفريغ النصي وفهم المعنى يحتاجان خدمة خارجية متوافقة مع OpenAI (مثل OpenAI أو Groq) بمفتاحك الخاص.\n" +
                "• لا يُرفع أي صوت إلا عندما تضغط \"تفريغ\" وتوافق.\n• المفتاح يُحفظ على هذا الجوال فقط، وليس داخل التطبيق.\n" +
                "• التفريغ يرفع صوت الحلقة، وفهم الحوار يرسل النص فقط.\n• المونتاج الأساسي يعمل بدون أي خدمة.",
                "Optional. Transcription and meaning need an external OpenAI-compatible service (e.g. OpenAI or Groq) with your own key.\n" +
                    "• No audio is uploaded unless you tap \"Transcribe\" and agree.\n• The key is stored on this phone only, never inside the app.\n" +
                    "• Transcription uploads the episode audio; understanding sends text only.\n• Basic editing works without any service.")
        })
        fun field(label: String, value: String, secret: Boolean = false): EditText {
            col.addView(TextView(a).apply { text = label; textSize = 12f; setPadding(0, (10 * d).toInt(), 0, 0) })
            val e = EditText(a).apply {
                setText(value); setSingleLine(); textDirection = View.TEXT_DIRECTION_LTR
                if (secret) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            col.addView(e)
            return e
        }
        val base = field(tx("عنوان الخدمة (Base URL)", "Service address (Base URL)"), c.base)
        val key = field(tx("المفتاح (API key)", "API key"), c.key, true)
        val stt = field(tx("نموذج التفريغ (OpenAI: whisper-1 — Groq: whisper-large-v3)", "Transcription model (OpenAI: whisper-1 — Groq: whisper-large-v3)"), c.stt)
        val chat = field(tx("نموذج فهم الحوار والترجمة (مثل gpt-4o-mini أو llama-3.3-70b-versatile)", "Understanding/translation model (e.g. gpt-4o-mini or llama-3.3-70b-versatile)"), c.chat)
        val lang = field(tx("لغة الكلام (ar)", "Spoken language (ar)"), c.lang)
        val presets = LinearLayout(a)
        presets.addView(Button(a).apply { text = "OpenAI"; isAllCaps = false; setOnClickListener { base.setText("https://api.openai.com/v1"); stt.setText("whisper-1"); chat.setText("gpt-4o-mini") } })
        presets.addView(Button(a).apply { text = "Groq"; isAllCaps = false; setOnClickListener { base.setText("https://api.groq.com/openai/v1"); stt.setText("whisper-large-v3"); chat.setText("llama-3.3-70b-versatile") } })
        col.addView(presets)
        AlertDialog.Builder(a).setTitle("🤖 " + tx("خدمة التفريغ وفهم الحوار", "Transcription & understanding service")).setView(ScrollView(a).apply { addView(col) })
            .setPositiveButton(tx("حفظ", "Save")) { _, _ -> PodAI.save(a, AiCfg(base.text.toString(), key.text.toString(), stt.text.toString(), chat.text.toString(), lang.text.toString())) }
            .setNeutralButton(tx("حذف المفتاح", "Remove key")) { _, _ -> PodAI.save(a, AiCfg(c.base, "", c.stt, c.chat, c.lang)) }
            .setNegativeButton(tx("إلغاء", "Cancel"), null).show()
    }

    /** يعرض نتيجة آخر تصدير: تشغيل/مشاركة لكل ملف + الخطأ والتنبيهات */
    fun results(a: AppCompatActivity, box: LinearLayout) {
        box.removeAllViews()
        fun tv(s: String, c: String, size: Float = 13f) = TextView(a).apply { text = s; textSize = size; setTextColor(Color.parseColor(c)); setPadding(0, 8, 0, 4) }
        PodState.error?.let { box.addView(tv("⚠ $it", "#FF6B6B")) }
        for ((i, u) in PodState.results.withIndex()) {
            box.addView(tv("✓ " + tx("حُفظ في Movies/ReactionRecorder", "Saved to Movies/ReactionRecorder") + if (PodState.results.size > 1) (if (i == 0) " (16:9)" else " (9:16)") else "", "#7CFC9A"))
            val row = LinearLayout(a)
            row.addView(Button(a).apply {
                text = "▶ " + tx("تشغيل", "Play"); isAllCaps = false
                setOnClickListener { try { a.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(u), "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) } catch (_: Throwable) {} }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Button(a).apply {
                text = "↗ " + tx("مشاركة", "Share"); isAllCaps = false
                setOnClickListener {
                    val sh = Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, Uri.parse(u)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    a.startActivity(Intent.createChooser(sh, tx("مشاركة", "Share")))
                }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            box.addView(row)
        }
        for (w in PodState.warnings) box.addView(tv("• $w", "#FFB86B", 11f))
    }

    fun pacingDialog(a: AppCompatActivity, init: PodPacing, onSave: (PodPacing) -> Unit) {
        val p = init.copy()
        val d = a.resources.displayMetrics.density
        val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding((18 * d).toInt(), (8 * d).toInt(), (18 * d).toInt(), (8 * d).toInt()) }
        fun slider(title: String, min: Float, max: Float, get: () -> Float, set: (Float) -> Unit) {
            val tv = TextView(a).apply { textSize = 13f; setPadding(0, (10 * d).toInt(), 0, 0) }
            fun upd() { tv.text = "$title: ${String.format(Locale.US, "%.1f", get())} s" }
            upd()
            col.addView(tv)
            col.addView(SeekBar(a).apply {
                this.max = 100
                progress = (((get() - min) / (max - min)) * 100).toInt().coerceIn(0, 100)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { set(min + (max - min) * v / 100f); upd() }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            })
        }
        slider(tx("كلام لازم قبل التبديل", "Speech needed before switching"), 0.2f, 3f, { p.switchDelay }, { p.switchDelay = it })
        slider(tx("أقصر لقطة", "Shortest shot"), 0.5f, 6f, { p.minShot }, { p.minShot = it })
        slider(tx("من المربع العائم إلى ملء الشاشة بعد", "From floating box to full screen after"), 0.5f, 6f, { p.pipToFull }, { p.pipToFull = it })
        slider(tx("تجاهل الأصوات الأقصر من (آه، امم)", "Ignore sounds shorter than (uh, hmm)"), 0.1f, 1.5f, { p.minSpeech }, { p.minSpeech = it })
        slider(tx("أطول لقطة قبل لقطة عامة (0 = أبدًا)", "Longest shot before a wide shot (0 = never)"), 0f, 60f, { p.maxShot }, { p.maxShot = it })
        slider(tx("صمت قبل إظهار الكاميرا العامة", "Silence before showing the wide camera"), 1f, 10f, { p.silenceToWide }, { p.silenceToWide = it })
        AlertDialog.Builder(a).setTitle(tx("إيقاع المونتاج", "Editing pace")).setView(ScrollView(a).apply { addView(col) })
            .setPositiveButton(tx("حفظ", "Save")) { _, _ -> onSave(p) }.setNegativeButton(tx("إلغاء", "Cancel"), null).show()
    }
}
