package com.reactionrecorder

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * واجهة البودكاست: توزيع الكاميرات والمايكات على الأشخاص (حتى 4) + كاميرات عامة،
 * مراقبة خفيفة، تسجيل على كل الأجهزة، ثم المونتاج التلقائي والتصدير.
 */
class PodcastActivity : AppCompatActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var setup: PodSetup
    private lateinit var col: LinearLayout
    private lateinit var hubTv: TextView
    private lateinit var peopleBox: LinearLayout
    private lateinit var widesBox: LinearLayout
    private lateinit var monitorRow: LinearLayout
    private lateinit var recBtn: Button
    private lateinit var recTv: TextView
    private lateinit var sessionsBox: LinearLayout
    private lateinit var jobTv: TextView
    private lateinit var jobBar: ProgressBar
    private lateinit var paceRow: LinearLayout
    private lateinit var styleRow: LinearLayout
    private lateinit var thisPhoneRow: LinearLayout
    private var devSig = ""
    private var sesSig = ""
    private val monViews = HashMap<String, ImageView>()
    private val monSeen = HashMap<String, Long>()
    private val levelBars = HashMap<Int, ProgressBar>()
    @Volatile private var recSid: String? = null
    private var recStartMs = 0L
    private var sessionsCache: List<SessionInfo> = emptyList()
    private var lastLoad = 0L
    @Volatile private var loading = false
    private val bg = java.util.concurrent.Executors.newSingleThreadExecutor()

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { pendingAfterPerm?.invoke(); pendingAfterPerm = null }
    private var pendingAfterPerm: (() -> Unit)? = null

    private val pickBg = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Throwable) {}
            setup.bgImage = u.toString()
            save(); buildStyleRow()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun granted(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setup = PodSetup.loadDefault(this)
        build()
        // رجوع للشاشة أثناء تسجيل جارٍ: نستعيد زر الإيقاف
        SatHub.activeSession?.let { a ->
            if (a.startsWith("p")) {
                recSid = a
                recStartMs = getSharedPreferences("reaction_podcast", MODE_PRIVATE).getLong("recStart", SystemClock.elapsedRealtime())
            }
        }
        if (!SatHub.running) {
            val c = applicationContext
            Thread { try { SatHub.start(c); SatHub.setHubWanted(c, SatHub.running) } catch (_: Throwable) {} }.start()
        }
    }

    override fun onResume() {
        super.onResume()
        devSig = ""
        ui.post(tick)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(tick)
        // نطفئ المعاينة الخفيفة (إلا ما فعّله المستخدم للشاشة الرئيسية)
        for (l in SatHub.links.values) SatHub.setPreview(l.id, l.stripOn, false, l.stripOn)
    }

    override fun onDestroy() {
        super.onDestroy()
        bg.shutdown()
    }

    private fun save() = PodSetup.saveDefault(this, setup)

    // ───────── واجهة ─────────

    private fun txt(t: String, size: Float = 13f, color: String = "#E6E8EE") = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.parseColor(color)); setPadding(0, dp(6), 0, dp(2))
    }

    private fun pill(b: Button, sel: Boolean) {
        b.isAllCaps = false; b.setTextColor(Color.WHITE); b.textSize = 12f
        b.minWidth = 0; b.minimumWidth = 0
        b.background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(Color.parseColor(if (sel) "#FF3B30" else "#2A2D36")) }
    }

    private fun btn(label: String, sel: Boolean = false, run: () -> Unit) = Button(this).apply { text = label; pill(this, sel); setOnClickListener { run() } }

    private fun rowOf(vararg v: View) = LinearLayout(this).apply {
        for (x in v) addView(x, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, 0, dp(6), 0) })
    }

    private fun build() {
        col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(24)) }
        val sv = ScrollView(this).apply { setBackgroundColor(Color.parseColor("#101114")); addView(col) }
        setContentView(sv)
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(sv) { v, insets ->
            val b = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, b.top, 0, b.bottom); insets
        }
        col.addView(txt("🎙 Podcast", 20f))
        col.addView(txt("Connect the other phones (📲 Satellite on each, scan the QR in 📡 Devices). Give every person a camera and a microphone, add a wide camera if you have one, then record. The edit is made automatically afterwards from who is talking.", 12f, "#AAB0BD"))
        hubTv = txt("", 12f, "#AAB0BD")
        col.addView(hubTv)
        col.addView(btn("📡 Devices & QR code") { startActivity(Intent(this, DevicesActivity::class.java)) })

        col.addView(txt("This phone", 15f))
        thisPhoneRow = LinearLayout(this)
        col.addView(thisPhoneRow)
        buildThisPhone()

        col.addView(txt("People", 15f))
        val countRow = LinearLayout(this)
        for (n in 1..4) countRow.addView(btn("$n") { setPeople(n) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, 0, dp(6), 0) })
        countRow.tag = "count"
        col.addView(countRow)
        peopleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(peopleBox)
        col.addView(txt("Wide camera(s) — show everyone together", 15f))
        widesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(widesBox)

        col.addView(txt("Editing pace", 15f))
        paceRow = LinearLayout(this)
        col.addView(paceRow)
        buildPaceRow()
        col.addView(txt("When several people talk", 15f))
        styleRow = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(styleRow)
        buildStyleRow()

        col.addView(txt("Monitor (light preview — the real recording is full quality on each phone)", 13f))
        monitorRow = LinearLayout(this)
        col.addView(HorizontalScrollView(this).apply { addView(monitorRow) })

        recBtn = Button(this).apply { textSize = 17f; setOnClickListener { onRecord() } }
        col.addView(recBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)).apply { topMargin = dp(12) })
        recTv = txt("", 14f)
        col.addView(recTv)

        jobTv = txt("", 13f, "#FFD60A")
        jobBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        col.addView(jobTv)
        col.addView(jobBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8)))

        col.addView(txt("Podcast recordings", 15f))
        sessionsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(sessionsBox)
        setPeople(setup.people.size.coerceIn(1, 4))
    }

    private fun buildThisPhone() {
        thisPhoneRow.removeAllViews()
        val mode = if (!SatState.serviceOn) "off" else SatCfg.load(this).role
        val sc = SatCfg.load(this)
        thisPhoneRow.addView(rowOf(
            btn("Off", mode == "off") { stopThisPhone() },
            btn("🎥 Camera + mic", mode == "both") { startThisPhone("both", sc.front) },
            btn("🎤 Mic only", mode == "mic") { startThisPhone("mic", sc.front) },
        ))
        if (mode == "both") {
            val sw = btn(if (sc.front) "Using FRONT camera — tap for back" else "Using BACK camera — tap for front") {
                startThisPhone("both", !sc.front)
            }
            thisPhoneRow.orientation = LinearLayout.VERTICAL
            thisPhoneRow.addView(sw)
        } else thisPhoneRow.orientation = LinearLayout.VERTICAL
    }

    /** هذا الجوال يسجّل ككاميرا/مايك عبر نفس نظام الأجهزة المساعدة (اتصال داخلي) */
    private fun startThisPhone(role: String, front: Boolean, asked: Boolean = false) {
        if (asked) {
            if (!granted(Manifest.permission.RECORD_AUDIO)) { toast("Microphone permission is needed"); return }
            if (role == "both" && !granted(Manifest.permission.CAMERA)) { toast("Camera permission is needed"); return }
        } else {
            val need = ArrayList<String>()
            if (!granted(Manifest.permission.RECORD_AUDIO)) need += Manifest.permission.RECORD_AUDIO
            if (role == "both" && !granted(Manifest.permission.CAMERA)) need += Manifest.permission.CAMERA
            if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) need += Manifest.permission.POST_NOTIFICATIONS
            if (need.isNotEmpty()) { pendingAfterPerm = { startThisPhone(role, front, true) }; perms.launch(need.toTypedArray()); return }
        }
        if (!SatHub.running) { toast("Starting the receiver… try again in a second"); return }
        if (RecorderState.isBusy) { toast("Stop the normal recording first"); return }
        val c = SatCfg.load(this)
        val restart = SatState.serviceOn && (c.role != role || c.front != front)
        c.host = "127.0.0.1:${SatHub.port}"
        c.pin = SatHub.pin
        c.name = "This phone"
        c.role = role
        c.front = front
        SatCfg.save(this, c)
        if (restart) {
            startService(Intent(this, SatelliteService::class.java).setAction(SatelliteService.ACTION_DISCONNECT))
            ui.postDelayed({
                if (!isFinishing && !isDestroyed) {
                    try { ContextCompat.startForegroundService(this, Intent(this, SatelliteService::class.java).setAction(SatelliteService.ACTION_CONNECT)) } catch (_: Throwable) { toast("Could not restart — tap the mode again") }
                    buildThisPhone()
                }
            }, 2000)
        } else if (!SatState.serviceOn) {
            ContextCompat.startForegroundService(this, Intent(this, SatelliteService::class.java).setAction(SatelliteService.ACTION_CONNECT))
        }
        ui.postDelayed({ buildThisPhone() }, 400)
    }

    private fun stopThisPhone() {
        if (SatState.serviceOn) startService(Intent(this, SatelliteService::class.java).setAction(SatelliteService.ACTION_DISCONNECT))
        ui.postDelayed({ buildThisPhone() }, 400)
    }

    private fun setPeople(n: Int) {
        while (setup.people.size < n) setup.people.add(PodPerson("Person ${setup.people.size + 1}", "", ""))
        while (setup.people.size > n) setup.people.removeAt(setup.people.size - 1)
        save()
        val cr = col.findViewWithTag<LinearLayout>("count")
        if (cr != null) for (i in 0 until cr.childCount) pill(cr.getChildAt(i) as Button, i + 1 == n)
        devSig = ""
    }

    private class Dev(val id: String, val name: String)

    private fun devices(): List<Dev> = SatHub.links.values.sortedBy { it.name }.map {
        Dev(it.id, (if (it.connected) "🟢 " else "⚪ ") + it.name + if (it.role == "both") " (cam+mic)" else " (mic)")
    }

    private fun spinner(items: List<Dev>, selId: String, allowNone: String, onSel: (String) -> Unit): Spinner {
        val labels = ArrayList(listOf(allowNone) + items.map { it.name })
        val ids = ArrayList(listOf("") + items.map { it.id })
        // جهاز محفوظ لكنه غير معروف الآن (لم يتصل بعد): نبقيه مختارًا ولا نمسحه
        if (selId.isNotEmpty() && selId !in ids) { ids.add(selId); labels.add("⚪ saved device (not connected)") }
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        sp.setSelection(ids.indexOf(selId).coerceAtLeast(0))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { onSel(ids[pos]) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        return sp
    }

    private fun buildPeople() {
        peopleBox.removeAllViews()
        levelBars.clear()
        val devs = devices()
        val cams = devs.filter { d -> SatHub.links[d.id]?.role == "both" }
        if (devs.isEmpty()) peopleBox.addView(txt("No devices yet — connect phones first (or turn on \"This phone\").", 12f, "#FFB86B"))
        for ((i, p) in setup.people.withIndex()) {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(6), dp(10), dp(8))
                background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(Color.parseColor("#1B1D24")) }
            }
            val name = EditText(this).apply {
                setText(p.name); setTextColor(Color.WHITE); textSize = 15f; setSingleLine()
                addTextChangedListener(object : android.text.TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun afterTextChanged(e: android.text.Editable?) { p.name = e?.toString()?.ifBlank { "Person ${i + 1}" } ?: p.name; save() }
                })
            }
            box.addView(name)
            box.addView(txt("Camera", 12f, "#AAB0BD"))
            box.addView(spinner(cams, p.camDev, "— no camera —") { id -> if (p.camDev != id) { p.camDev = id; save() } })
            box.addView(txt("Microphone", 12f, "#AAB0BD"))
            box.addView(spinner(devs, p.micDev, "— no microphone —") { id -> if (p.micDev != id) { p.micDev = id; save() } })
            val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
            levelBars[i] = pb
            box.addView(pb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(6)).apply { topMargin = dp(4) })
            peopleBox.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        }
        widesBox.removeAllViews()
        if (cams.isEmpty()) widesBox.addView(txt("No camera devices connected", 12f, "#AAB0BD"))
        for (d in cams) {
            widesBox.addView(CheckBox(this).apply {
                text = d.name; setTextColor(Color.WHITE)
                isChecked = d.id in setup.wides
                setOnCheckedChangeListener { _, on -> if (on) { if (d.id !in setup.wides) setup.wides.add(d.id) } else setup.wides.remove(d.id); save() }
            })
        }
    }

    private fun buildPaceRow() {
        paceRow.removeAllViews()
        for ((k, label) in listOf("fast" to "⚡ Fast", "medium" to "Medium", "calm" to "🌙 Calm", "custom" to "⚙ Custom")) {
            paceRow.addView(btn(label, setup.presetName == k) {
                if (k == "custom") showPacing(setup.pacing) { p -> setup.pacing = p; setup.presetName = "custom"; save(); buildPaceRow() }
                else { setup.presetName = k; setup.pacing = PodPacing.preset(k); save(); buildPaceRow() }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, 0, dp(4), 0) })
        }
    }

    private fun buildStyleRow() {
        styleRow.removeAllViews()
        styleRow.addView(rowOf(
            btn("▥ Split screen", setup.multiStyle == "split") { setup.multiStyle = "split"; save(); buildStyleRow() },
            btn("▣ Boxes on background", setup.multiStyle == "boxes") { setup.multiStyle = "boxes"; save(); buildStyleRow() },
        ))
        if (setup.multiStyle == "boxes") {
            val colors = listOf(0xFF1B1D24.toInt(), 0xFF0B3D91.toInt(), 0xFF5B2C83.toInt(), 0xFF1E5631.toInt(), 0xFF7A1F1F.toInt(), 0xFFEDEDED.toInt())
            val r = LinearLayout(this)
            for (c in colors) {
                r.addView(View(this).apply {
                    background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(c); if (setup.bgColor == c && setup.bgImage.isEmpty()) setStroke(dp(3), Color.parseColor("#FF3B30")) }
                    setOnClickListener { setup.bgColor = c; setup.bgImage = ""; save(); buildStyleRow() }
                }, LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(0, dp(6), dp(8), 0) })
            }
            styleRow.addView(r)
            styleRow.addView(btn(if (setup.bgImage.isEmpty()) "🖼 Use an image as background" else "🖼 Image chosen ✓ (tap to change)", setup.bgImage.isNotEmpty()) {
                pickBg.launch(arrayOf("image/*"))
            })
        }
        styleRow.addView(rowOf(
            btn(if (setup.usePip) "Floating box first: ON" else "Floating box first: OFF", setup.usePip) { setup.usePip = !setup.usePip; save(); buildStyleRow() },
            btn(if (setup.fade) "Soft transitions: ON" else "Soft transitions: OFF", setup.fade) { setup.fade = !setup.fade; save(); buildStyleRow() },
        ))
        styleRow.addView(rowOf(
            btn("720p", setup.height < 1080) { setup.height = 720; save(); buildStyleRow() },
            btn("1080p", setup.height >= 1080) { setup.height = 1080; save(); buildStyleRow() },
        ))
    }

    /** نافذة ضبط الإيقاع (تُستعمل هنا وفي شاشة المونتاج) */
    private fun showPacing(init: PodPacing, onSave: (PodPacing) -> Unit) = PodUi.pacingDialog(this, init, onSave)

    // ───────── التسجيل ─────────

    private fun onRecord() {
        val sid = recSid
        if (sid != null) { stopRec(sid); return }
        if (RecorderState.isBusy) { toast("Stop the normal recording first"); return }
        if (!SatHub.running) { toast("The receiver is not running"); return }
        val missing = ArrayList<String>()
        for (p in setup.people) {
            if (p.camDev.isEmpty() && p.micDev.isEmpty()) missing += "${p.name}: no camera and no microphone"
            for (d in listOf(p.camDev, p.micDev)) if (d.isNotEmpty() && SatHub.links[d]?.connected != true) missing += "${p.name}: ${SatHub.links[d]?.name ?: "device"} is not connected"
        }
        for (w in setup.wides) if (SatHub.links[w]?.connected != true) missing += "Wide camera ${SatHub.links[w]?.name ?: ""} is not connected"
        if (missing.isNotEmpty()) {
            AlertDialog.Builder(this).setTitle("Check before recording").setMessage(missing.distinct().joinToString("\n"))
                .setPositiveButton("Record anyway") { _, _ -> startRec() }.setNegativeButton("Cancel", null).show()
        } else startRec()
    }

    private fun startRec() {
        val sid = "p" + System.currentTimeMillis()
        recSid = sid
        recStartMs = SystemClock.elapsedRealtime()
        getSharedPreferences("reaction_podcast", MODE_PRIVATE).edit().putLong("recStart", recStartMs).apply()
        val ctx = applicationContext
        val extra = setup.toJson().toString()
        bg.execute {
            SessionStore.create(ctx, sid)
            SessionStore.update(ctx, sid) { x -> x.kind = "podcast"; x.extra = extra }
            SatHub.startSession(ctx, sid)
            // الأجهزة تحتاج لحظة لتبدأ فعلًا: نبدأ خط الزمن بعد ثانية ونصف
            val start = SystemClock.elapsedRealtimeNanos() + 1_500_000_000L
            SessionStore.update(ctx, sid) { x -> x.startElapsedNs = start }
        }
        render()
    }

    private fun stopRec(sid: String) {
        recSid = null
        val ctx = applicationContext
        bg.execute {
            val end = SystemClock.elapsedRealtimeNanos()
            SessionStore.update(ctx, sid) { x -> x.endElapsedNs = end; x.ended = true; x.mainUri = "" }
            SatHub.stopSession(ctx, sid)
        }
        lastLoad = 0L
        toast("Saved on each phone — the files are being collected")
        render()
    }

    private fun render() {
        val r = recSid != null
        recBtn.text = if (r) "■ Stop" else "● Record podcast"
        pill(recBtn, !r)
        if (r) {
            val sec = (SystemClock.elapsedRealtime() - recStartMs) / 1000
            recTv.text = "🔴 Recording ${sec / 60}:${String.format(Locale.US, "%02d", sec % 60)}"
        } else recTv.text = ""
    }

    // ───────── تحديث دوري ─────────

    private val tick = object : Runnable {
        override fun run() {
            if (!isFinishing && !isDestroyed) refresh()
            ui.postDelayed(this, 300)
        }
    }

    private fun refresh() {
        hubTv.text = if (SatHub.running) "Receiver ON • PIN ${SatHub.pin} • ${SatHub.links.values.count { it.connected }} device(s) connected" else "Receiver starting…"
        val sig = SatHub.links.values.joinToString("|") { "${it.id}${it.connected}${it.role}${it.name}" } + setup.people.size
        if (sig != devSig) {
            devSig = sig
            buildPeople()
            buildThisPhone()
            // نطلب معاينة خفيفة من الأجهزة المستعملة
            val camIds = (setup.people.map { it.camDev } + setup.wides).filter { it.isNotEmpty() }.toSet()
            val micIds = setup.people.map { it.micDev }.filter { it.isNotEmpty() }.toSet()
            for (l in SatHub.links.values) {
                val v = l.id in camIds || l.stripOn
                val lv = l.id in micIds || l.stripOn
                SatHub.setPreview(l.id, v, false, lv)
            }
            monitorRow.removeAllViews(); monViews.clear(); monSeen.clear()
            for (id in camIds) {
                val iv = ImageView(this).apply { setBackgroundColor(Color.BLACK); scaleType = ImageView.ScaleType.FIT_CENTER }
                monViews[id] = iv
                val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                cell.addView(iv, LinearLayout.LayoutParams(dp(128), dp(96)))
                cell.addView(TextView(this).apply { text = SatHub.links[id]?.name ?: "?"; textSize = 10f; setTextColor(Color.parseColor("#AAB0BD")); gravity = Gravity.CENTER })
                monitorRow.addView(cell, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, 0, dp(6), 0) })
            }
        }
        for ((id, iv) in monViews) {
            val l = SatHub.links[id] ?: continue
            val f = l.frame
            if (f != null && monSeen[id] != l.frameAt) { iv.setImageBitmap(f); monSeen[id] = l.frameAt }
        }
        for ((i, pb) in levelBars) {
            val l = SatHub.links[setup.people.getOrNull(i)?.micDev ?: ""]
            pb.progress = if (l != null && l.connected) (l.level * 100 / 32767).coerceIn(0, 100) else 0
        }
        render()

        if (PodState.running) {
            jobTv.text = "${PodState.stage} ${(PodState.progress * 100).toInt()}%"
            jobBar.visibility = View.VISIBLE
            jobBar.progress = (PodState.progress * 100).toInt()
        } else {
            jobBar.visibility = View.GONE
            jobTv.text = PodState.error?.let { "⚠ $it" } ?: ""
        }

        val now = SystemClock.elapsedRealtime()
        if (!loading && now - lastLoad > 2000) {
            loading = true; lastLoad = now
            val c = applicationContext
            bg.execute {
                val list = try { SessionStore.list(c).filter { it.kind == "podcast" } } catch (_: Throwable) { emptyList() }
                ui.post { sessionsCache = list; loading = false }
            }
        }
        val ssig = sessionsCache.joinToString("|") { s -> s.id + s.ended + s.mergedUri + s.devices.values.joinToString(",") { "${it.uploaded}" } } + PodState.running + recSid
        if (ssig != sesSig) {
            sesSig = ssig
            sessionsBox.removeAllViews()
            if (sessionsCache.isEmpty()) sessionsBox.addView(txt("None yet", 12f, "#AAB0BD"))
            for (s in sessionsCache) sessionsBox.addView(sessionView(s))
        }
    }

    private fun sessionView(s: SessionInfo): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(Color.parseColor("#1B1D24")) }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) }
        }
        val d = PodcastAnalyzer.duration(s).toLong()
        val st = PodcastAnalyzer.setupOf(s)
        box.addView(txt(SimpleDateFormat("MM-dd HH:mm", Locale.US).format(Date(s.wallMs)) +
            (if (s.ended) "  •  ${d / 60}:${String.format(Locale.US, "%02d", d % 60)}" else "  •  recording / not finished") +
            "  •  " + st.people.joinToString(", ") { it.name }, 14f))
        val waiting = s.devices.values.filter { it.started && !it.uploaded }
        box.addView(txt(if (waiting.isEmpty()) "All files received ✓" else "Waiting for files from: " + waiting.joinToString(", ") { it.name }, 12f, if (waiting.isEmpty()) "#7CFC9A" else "#FFB86B"))
        val r = LinearLayout(this)
        if (waiting.isNotEmpty() && s.ended) r.addView(btn("⬇ Fetch files") { SatHub.requestFiles(s.id); toast("Requested from connected devices") }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, 0, dp(6), 0) })
        if (s.ended) r.addView(btn("✂ Edit & export", true) {
            if (waiting.isNotEmpty()) {
                AlertDialog.Builder(this).setMessage("Some files have not arrived yet. Their camera/mic will be missing from the edit. Continue?")
                    .setPositiveButton("Continue") { _, _ -> openEditor(s.id) }.setNegativeButton("Wait", null).show()
            } else openEditor(s.id)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, 0, dp(6), 0) })
        if (s.mergedUri.isNotEmpty()) r.addView(btn("▶ Play") { play(s.mergedUri) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, 0, dp(6), 0) })
        r.addView(btn("🗑") {
            AlertDialog.Builder(this).setTitle("Delete this podcast's working files?")
                .setMessage("Exported videos in your Gallery are kept.")
                .setPositiveButton("Delete") { _, _ -> SessionStore.delete(this, s.id); lastLoad = 0L }
                .setNegativeButton("Keep", null).show()
        })
        box.addView(r)
        return box
    }

    private fun openEditor(sid: String) = startActivity(Intent(this, PodcastEditActivity::class.java).putExtra("session", sid))

    private fun play(uri: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(uri), "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) } catch (_: Throwable) { toast("No player found") }
    }
}

/** أدوات واجهة مشتركة للبودكاست */
object PodUi {
    /** يعرض نتيجة آخر تصدير: تشغيل/مشاركة لكل ملف + الخطأ والتنبيهات */
    fun results(a: AppCompatActivity, box: LinearLayout) {
        box.removeAllViews()
        fun t(s: String, c: String, size: Float = 13f) = TextView(a).apply { text = s; textSize = size; setTextColor(Color.parseColor(c)); setPadding(0, 8, 0, 4) }
        PodState.error?.let { box.addView(t("⚠ $it", "#FF6B6B")) }
        for ((i, u) in PodState.results.withIndex()) {
            box.addView(t("✓ Saved in Movies/ReactionRecorder" + if (PodState.results.size > 1) (if (i == 0) " (16:9)" else " (9:16)") else "", "#7CFC9A"))
            val row = LinearLayout(a)
            row.addView(Button(a).apply {
                text = "▶ Play"; isAllCaps = false
                setOnClickListener { try { a.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(u), "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) } catch (_: Throwable) {} }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Button(a).apply {
                text = "↗ Share"; isAllCaps = false
                setOnClickListener {
                    val sh = Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, Uri.parse(u)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    a.startActivity(Intent.createChooser(sh, "Share"))
                }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            box.addView(row)
        }
        for (w in PodState.warnings) box.addView(t("• $w", "#FFB86B", 11f))
    }

    fun pacingDialog(a: AppCompatActivity, init: PodPacing, onSave: (PodPacing) -> Unit) {
        val p = init.copy()
        val d = a.resources.displayMetrics.density
        val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding((18 * d).toInt(), (8 * d).toInt(), (18 * d).toInt(), (8 * d).toInt()) }
        fun slider(title: String, min: Float, max: Float, get: () -> Float, set: (Float) -> Unit) {
            val tv = TextView(a).apply { textSize = 13f; setPadding(0, (10 * d).toInt(), 0, 0) }
            fun upd() { tv.text = "$title: ${String.format(Locale.US, "%.1f", get())} s" }
            upd()
            col.addView(tv)
            col.addView(SeekBar(a).apply {
                this.max = 100
                progress = (((get() - min) / (max - min)) * 100).toInt().coerceIn(0, 100)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { set(min + (max - min) * v / 100f); upd() }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            })
        }
        slider("Speech needed before switching", 0.2f, 3f, { p.switchDelay }, { p.switchDelay = it })
        slider("Shortest shot", 0.5f, 6f, { p.minShot }, { p.minShot = it })
        slider("Floating box → full screen after", 0.5f, 6f, { p.pipToFull }, { p.pipToFull = it })
        slider("Ignore sounds shorter than (\"uh\", \"hmm\")", 0.1f, 1.5f, { p.minSpeech }, { p.minSpeech = it })
        slider("Longest shot before a wide cut-away (0 = never)", 0f, 60f, { p.maxShot }, { p.maxShot = it })
        slider("Silence before showing the wide camera", 1f, 10f, { p.silenceToWide }, { p.silenceToWide = it })
        AlertDialog.Builder(a).setTitle("Editing pace").setView(ScrollView(a).apply { addView(col) })
            .setPositiveButton("Save") { _, _ -> onSave(p) }.setNegativeButton("Cancel", null).show()
    }
}
