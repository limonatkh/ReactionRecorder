package com.reactionrecorder

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager

/**
 * الشاشة الرئيسية: أربع بطاقات فقط — تسجيل جديد، انضمام لتسجيل، تسجيلاتي، الإعدادات.
 * وشريط علوي يظهر عند وجود تسجيل جارٍ للرجوع إليه مباشرة.
 */
class HomeActivity : BaseActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var liveBar: TextView

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = UiKit.page(this)
        col.addView(UiKit.text(this, "Reaction Recorder", 24f, UiKit.TEXT, true).apply { setPadding(0, UiKit.dp(this@HomeActivity, 18), 0, 0) })
        col.addView(UiKit.text(this, tx("سجّل، صوّر من أكثر من جوال، ومنتج تلقائيًا", "Record, film with several phones, and edit automatically"), 13f, UiKit.SUB).apply { setPadding(0, UiKit.dp(this@HomeActivity, 4), 0, UiKit.dp(this@HomeActivity, 8)) })

        liveBar = UiKit.text(this, "", 14f, "#FFFFFF", true).apply {
            background = UiKit.bg(UiKit.RED, 14, this@HomeActivity)
            setPadding(UiKit.dp(this@HomeActivity, 14), UiKit.dp(this@HomeActivity, 12), UiKit.dp(this@HomeActivity, 14), UiKit.dp(this@HomeActivity, 12))
            visibility = View.GONE
            setOnClickListener { openLive() }
        }
        col.addView(liveBar, UiKit.full(this, liveBar, 8))

        fun add(v: View) = col.addView(v, UiKit.full(this, v, 12))
        add(UiKit.bigCard(this, "🎬", tx("تسجيل جديد", "New recording"), tx("رياكشن على فيديو، أو حوار وبودكاست بأكثر من جوال", "React to a video, or a podcast with several phones"), "#3A1D1D") { newRecording() })
        add(UiKit.bigCard(this, "📡", tx("انضمام لتسجيل", "Join a recording"), tx("اجعل هذا الجوال كاميرا أو مايك لاسلكي لجوال آخر", "Use this phone as a camera or a wireless mic for another phone"), "#1D2A3A") { startActivity(Intent(this, JoinActivity::class.java)) })
        add(UiKit.bigCard(this, "📁", tx("تسجيلاتي", "My recordings"), tx("الملفات، المونتاج، الريلز والتصدير", "Files, editing, reels and export"), "#1D3A26") { startActivity(Intent(this, RecordingsActivity::class.java)) })
        add(UiKit.bigCard(this, "⚙️", tx("الإعدادات", "Settings"), tx("اللغة، التصوير، الأجهزة، التخزين", "Language, recording, devices, storage"), "#2A2D36") { startActivity(Intent(this, SettingsActivity::class.java)) })

        col.addView(UiKit.text(this, "v" + (try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Throwable) { "" }), 11f, UiKit.SUB).apply {
            setPadding(0, UiKit.dp(this@HomeActivity, 20), 0, 0); textAlignment = View.TEXT_ALIGNMENT_CENTER
        })

        if (SatHub.hubWanted(this) && !SatHub.running) Thread { try { SatHub.start(applicationContext) } catch (_: Throwable) {} }.start()
        askPerms()
    }

    private fun askPerms() {
        val need = ArrayList<String>()
        for (p in listOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)) if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) need += p
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) perms.launch(need.toTypedArray())
    }

    private fun newRecording() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(UiKit.dp(this@HomeActivity, 12), UiKit.dp(this@HomeActivity, 8), UiKit.dp(this@HomeActivity, 12), UiKit.dp(this@HomeActivity, 8)) }
        val dlg = AlertDialog.Builder(this).setTitle(tx("نوع التسجيل", "Recording type")).setView(col).setNegativeButton(tx("إلغاء", "Cancel"), null).create()
        fun add(v: View) = col.addView(v, UiKit.full(this, v, 8))
        add(UiKit.bigCard(this, "🎞", tx("رياكشن", "Reaction"), tx("فيديو أو شاشة + كاميرتك، في فيديو واحد", "A video or the screen + your camera, in one video"), "#3A1D1D") {
            dlg.dismiss(); startActivity(Intent(this, MainActivity::class.java))
        })
        add(UiKit.bigCard(this, "🎙", tx("حوار / بودكاست", "Conversation / podcast"), tx("كل شخص بكاميرته ومايكه، ومونتاج تلقائي على من يتكلم", "Each person with a camera and mic, auto-edited on whoever speaks"), "#1D2A3A") {
            dlg.dismiss(); startActivity(Intent(this, PodcastActivity::class.java))
        })
        dlg.show()
    }

    private fun openLive() {
        when {
            RecorderState.isBusy -> startActivity(Intent(this, MainActivity::class.java))
            PodRec.active != null -> startActivity(Intent(this, PodcastActivity::class.java))
            SatState.serviceOn -> startActivity(Intent(this, SatelliteActivity::class.java))
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            val txt = when {
                RecorderState.isBusy -> tx("● تسجيل رياكشن جارٍ — اضغط للرجوع", "● Reaction recording in progress — tap to return")
                PodRec.active != null -> tx("● تسجيل حوار جارٍ — اضغط للرجوع", "● Podcast recording in progress — tap to return")
                SatState.recording -> tx("● هذا الجوال يسجّل كجهاز مساعد — اضغط للرجوع", "● This phone is recording as a remote device — tap to return")
                SatState.serviceOn -> tx("📡 هذا الجوال متصل كجهاز مساعد — اضغط للرجوع", "📡 This phone is connected as a remote device — tap to return")
                else -> ""
            }
            liveBar.text = txt
            liveBar.visibility = if (txt.isEmpty()) View.GONE else View.VISIBLE
            liveBar.background = UiKit.bg(if (SatState.serviceOn && !SatState.recording && txt.isNotEmpty() && !RecorderState.isBusy && PodRec.active == null) UiKit.BLUE else UiKit.RED, 14, this@HomeActivity)
            ui.postDelayed(this, 700)
        }
    }

    override fun onResume() { super.onResume(); ui.post(tick) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }
}
