package com.reactionrecorder

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager

/**
 * الشاشة الرئيسية: أربع بطاقات فقط — تسجيل جديد، انضمام لتسجيل، تسجيلاتي، الإعدادات.
 * وشريط علوي يظهر عند وجود تسجيل جارٍ للرجوع إليه مباشرة.
 */
class HomeActivity : BaseActivity() {
    override val allowedWithoutLicense = true
    private lateinit var cards: LinearLayout
    private var builtFull: Boolean? = null
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var liveBar: TextView

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = UiKit.page(this)
        col.addView(UiKit.text(this, "Reaction Recorder", 24f, UiKit.TEXT, true).apply { setPadding(0, UiKit.dp(this@HomeActivity, 18), 0, 0) })
        col.addView(UiKit.text(this, tx("سجّل، صوّر من أكثر من جوال، ومنتج تلقائيًا", "Record, film with several phones, and edit automatically"), 13f, UiKit.SUB).apply { setPadding(0, UiKit.dp(this@HomeActivity, 4), 0, UiKit.dp(this@HomeActivity, 8)) })

        liveBar = UiKit.text(this, "", 14f, "#FFFFFF", true).apply {
            background = UiKit.bg(UiKit.RED, 14, this@HomeActivity)
            setPadding(UiKit.dp(this@HomeActivity, 14), UiKit.dp(this@HomeActivity, 12), UiKit.dp(this@HomeActivity, 14), UiKit.dp(this@HomeActivity, 12))
            visibility = View.GONE
            setOnClickListener { openLive() }
        }
        col.addView(liveBar, UiKit.full(this, liveBar, 8))

        cards = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(cards)

        col.addView(UiKit.text(this, "v" + (try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Throwable) { "" }), 11f, UiKit.SUB).apply {
            setPadding(0, UiKit.dp(this@HomeActivity, 20), 0, 0); textAlignment = View.TEXT_ALIGNMENT_CENTER
        })

        if (SatHub.hubWanted(this) && !SatHub.running) Thread { try { SatHub.start(applicationContext) } catch (_: Throwable) {} }.start()
        askPerms()
    }

    /** البطاقات حسب التفعيل: نسخة غير مفعّلة ترى الانضمام والتفعيل فقط */
    private fun buildCards() {
        val full = License.active(this)
        if (builtFull == full) return
        builtFull = full
        cards.removeAllViews()
        fun add(v: View) = cards.addView(v, UiKit.full(this, v, 12))
        if (full) {
            add(UiKit.bigCard(this, "🎬", tx("تسجيل جديد", "New recording"), tx("رياكشن، حوار/بودكاست، أو فلوق مع صحابك", "Reaction, podcast, or a vlog with friends"), "#3A1D1D") { newRecording() })
        }
        add(UiKit.bigCard(this, "📡", tx("انضمام لتسجيل", "Join a recording"), tx("اجعل هذا الجوال كاميرا أو مايك لاسلكي لجوال آخر", "Use this phone as a camera or a wireless mic for another phone"), "#1D2A3A") { startActivity(Intent(this, JoinActivity::class.java)) })
        if (full) {
            add(UiKit.bigCard(this, "📁", tx("تسجيلاتي", "My recordings"), tx("الملفات، المونتاج، الريلز والتصدير", "Files, editing, reels and export"), "#1D3A26") { startActivity(Intent(this, RecordingsActivity::class.java)) })
            add(UiKit.bigCard(this, "⚙️", tx("الإعدادات", "Settings"), tx("اللغة، التصوير، الأجهزة، التخزين", "Language, recording, devices, storage"), "#2A2D36") { startActivity(Intent(this, SettingsActivity::class.java)) })
            val r = UiKit.row(this,
                UiKit.chip(this, "📤 " + tx("شارك التطبيق", "Share the app")) { shareDialog() },
                UiKit.chip(this, "🔐 " + tx("التفعيل", "Activation")) { startActivity(Intent(this, LicenseActivity::class.java)) },
            )
            cards.addView(r, UiKit.full(this, r, 12))
        } else {
            add(UiKit.bigCard(this, "🔐", tx("التفعيل", "Activation"), tx("هذه النسخة غير مفعّلة — اطلب التفعيل من صاحب التطبيق", "This copy is not activated — ask the app owner"), "#3A2D1D") { startActivity(Intent(this, LicenseActivity::class.java)) })
        }
    }

    /** مشاركة التطبيق: باركود واحد ينزّل التطبيق من هذا الجوال (بدون إنترنت) ويقترن به */
    private fun shareDialog() {
        val c = applicationContext
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = android.view.Gravity.CENTER_HORIZONTAL; setPadding(UiKit.dp(this@HomeActivity, 16), UiKit.dp(this@HomeActivity, 8), UiKit.dp(this@HomeActivity, 16), UiKit.dp(this@HomeActivity, 8)) }
        val img = android.widget.ImageView(this).apply { setBackgroundColor(android.graphics.Color.WHITE); setPadding(16, 16, 16, 16) }
        val note = UiKit.text(this, tx("جارٍ التشغيل…", "Starting…"), 13f, "#333333")
        box.addView(img, LinearLayout.LayoutParams(UiKit.dp(this, 260), UiKit.dp(this, 260)))
        box.addView(note)
        AlertDialog.Builder(this).setTitle("📤 " + tx("شارك التطبيق", "Share the app")).setView(box).setPositiveButton(tx("تم", "Done"), null).show()
        Thread {
            try { if (!SatHub.running) { SatHub.start(c); SatHub.setHubWanted(c, SatHub.running) } } catch (_: Throwable) {}
            try { AppShare.start(c) } catch (_: Throwable) {}
            val url = AppShare.pairQr()
            ui.post {
                if (!AppShare.running || AppShare.ip() == null) {
                    note.text = tx("شغّل الهوتسبوت أو الواي فاي أولًا ثم افتح هذه النافذة من جديد.", "Turn on the hotspot or Wi-Fi first, then open this again.")
                } else {
                    img.setImageBitmap(PodcastActivity.qrBitmap(url))
                    note.text = tx("خلي صاحبك يتصل بشبكة جوالك (الهوتسبوت) ويمسح الباركود بكاميرا جواله: ينزل التطبيق من جوالك بدون إنترنت. ومن عنده التطبيق، نفس الباركود يربطه بجوالك. النسخ الجديدة تحتاج تفعيلك.",
                        "Your friend joins your phone's hotspot and scans this with their camera: the app downloads from your phone, no internet. If they already have the app, the same code pairs them with you. New copies need your activation.")
                }
            }
        }.start()
    }

    private fun askPerms() {
        val need = ArrayList<String>()
        for (p in listOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)) if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) need += p
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) perms.launch(need.toTypedArray())
    }

    private fun newRecording() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(UiKit.dp(this@HomeActivity, 12), UiKit.dp(this@HomeActivity, 8), UiKit.dp(this@HomeActivity, 12), UiKit.dp(this@HomeActivity, 8)) }
        val dlg = AlertDialog.Builder(this).setTitle(tx("نوع التسجيل", "Recording type")).setView(col).setNegativeButton(tx("إلغاء", "Cancel"), null).create()
        fun add(v: View) = col.addView(v, UiKit.full(this, v, 8))
        add(UiKit.bigCard(this, "🎞", tx("رياكشن", "Reaction"), tx("فيديو أو شاشة + كاميرتك، في فيديو واحد", "A video or the screen + your camera, in one video"), "#3A1D1D") {
            dlg.dismiss(); startActivity(Intent(this, MainActivity::class.java))
        })
        add(UiKit.bigCard(this, "🎙", tx("حوار / بودكاست", "Conversation / podcast"), tx("كل شخص بكاميرته ومايكه، ومونتاج تلقائي على من يتكلم", "Each person with a camera and mic, auto-edited on whoever speaks"), "#1D2A3A") {
            dlg.dismiss(); startActivity(Intent(this, PodcastActivity::class.java))
        })
        add(UiKit.bigCard(this, "🎥", tx("فلوق", "Vlog"), tx("جوالك كاميرا، وصحابك مايكات أو كاميرات بإيدهم، وأنتو ماشيين", "Your phone films; friends are mics or cameras in hand, on the move"), "#1D3A33") {
            dlg.dismiss(); startActivity(Intent(this, VlogActivity::class.java))
        })
        dlg.show()
    }

    private fun openLive() {
        when {
            RecorderState.isBusy -> startActivity(Intent(this, MainActivity::class.java))
            PodRec.active != null -> startActivity(Intent(this, if (PodRec.isVlog(this)) VlogActivity::class.java else PodcastActivity::class.java))
            SatState.serviceOn -> startActivity(Intent(this, SatelliteActivity::class.java))
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            val txt = when {
                RecorderState.isBusy -> tx("● تسجيل رياكشن جارٍ — اضغط للرجوع", "● Reaction recording in progress — tap to return")
                PodRec.active != null -> tx("● تسجيل حوار جارٍ — اضغط للرجوع", "● Podcast recording in progress — tap to return")
                SatState.recording -> tx("● هذا الجوال يسجّل كجهاز مساعد — اضغط للرجوع", "● This phone is recording as a remote device — tap to return")
                SatState.serviceOn -> tx("📡 هذا الجوال متصل كجهاز مساعد — اضغط للرجوع", "📡 This phone is connected as a remote device — tap to return")
                else -> ""
            }
            liveBar.text = txt
            liveBar.visibility = if (txt.isEmpty()) View.GONE else View.VISIBLE
            liveBar.background = UiKit.bg(if (SatState.serviceOn && !SatState.recording && txt.isNotEmpty() && !RecorderState.isBusy && PodRec.active == null) UiKit.BLUE else UiKit.RED, 14, this@HomeActivity)
            ui.postDelayed(this, 700)
        }
    }

    override fun onResume() { super.onResume(); buildCards(); ui.post(tick) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }
}
