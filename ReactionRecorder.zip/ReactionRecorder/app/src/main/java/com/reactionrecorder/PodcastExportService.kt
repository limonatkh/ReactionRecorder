package com.reactionrecorder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import java.io.File

/** حالة أعمال البودكاست الطويلة للواجهة */
object PodState {
    @Volatile var running = false
    @Volatile var sid = ""
    @Volatile var job = ""
    @Volatile var project = ""
    @Volatile var stage = ""
    @Volatile var progress = 0f
    @Volatile var error: String? = null
    @Volatile var resultUri: String? = null
    /** كل الملفات الناتجة من آخر تصدير (قد يكون عرضي + طولي) */
    @Volatile var results: List<String> = emptyList()
    @Volatile var previewFile: String? = null
    @Volatile var info: String? = null
    @Volatile var warnings: List<String> = emptyList()
    @Volatile var cancel = false
    /** يزيد عند انتهاء كل عمل (لتعرف الواجهة أن هناك نتيجة جديدة) */
    @Volatile var doneSeq = 0
}

/**
 * خدمة في الخلفية للأعمال الطويلة: التصدير، المعاينة، التفريغ، فهم الحوار، تتبع الوجه، وملفات SRT.
 * لا تحذف أي مشروع أو أصل عند الفشل.
 */
class PodcastExportService : Service() {
    companion object {
        const val ACTION_EXPORT = "pod.EXPORT"
        const val ACTION_PREVIEW = "pod.PREVIEW"
        const val ACTION_TRANSCRIBE = "pod.TRANSCRIBE"
        const val ACTION_SEMANTIC = "pod.SEMANTIC"
        const val ACTION_FACES = "pod.FACES"
        const val ACTION_SRT = "pod.SRT"
        const val ACTION_CANCEL = "pod.CANCEL"
        private const val CHANNEL = "podcast"
        private const val NOTIF_ID = 1004
    }

    private var wake: PowerManager.WakeLock? = null
    private var lastPct = -1

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val act = intent?.action
        if (act == ACTION_CANCEL) {
            PodState.cancel = true
            if (!PodState.running) stopSelf()
            return START_NOT_STICKY
        }
        val sid = intent?.getStringExtra("session")
        if (act == null || sid == null || PodState.running) {
            if (!PodState.running) stopSelf()
            return START_NOT_STICKY
        }
        begin(act, sid, intent)
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun begin(act: String, sid: String, intent: Intent) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Podcast", NotificationManager.IMPORTANCE_LOW))
        }
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, notif("…"), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            else startForeground(NOTIF_ID, notif("…"))
        } catch (t: Throwable) {
            PodState.error = "Cannot start: ${t.message}"
            stopSelf(); return
        }
        val projId = intent.getStringExtra("project") ?: "episode"
        PodState.running = true
        PodState.sid = sid
        PodState.job = act
        PodState.project = projId
        PodState.error = null
        PodState.info = null
        PodState.cancel = false
        PodState.progress = 0f
        PodState.warnings = emptyList()
        PodState.stage = "تحضير…"
        if (act == ACTION_EXPORT) { PodState.resultUri = null; PodState.results = emptyList() }
        if (act == ACTION_PREVIEW) PodState.previewFile = null
        lastPct = -1
        try {
            wake = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "rr:podcast").also { it.acquire(4 * 60 * 60 * 1000L) }
        } catch (_: Throwable) {}

        Thread({
            var err: String? = null
            try {
                val d = PodStudio.load(this, sid, { p -> report("تحليل الأصوات", p) }, { PodState.cancel })
                    ?: throw IllegalStateException(if (PodState.cancel) "أُلغي" else "الجلسة غير موجودة")
                when (act) {
                    ACTION_EXPORT, ACTION_PREVIEW -> {
                        val p = (if (projId == "episode") ProjectStore.episode(this, sid) else ProjectStore.load(this, sid, projId))
                            ?: (if (projId == "episode") PodStudio.newEpisode(d).also { ProjectStore.save(this, sid, it) } else throw IllegalStateException("المشروع غير موجود"))
                        val orient = intent.getStringExtra("orient") ?: p.st.orient
                        if (act == ACTION_PREVIEW) {
                            val from = intent.getDoubleExtra("from", p.a)
                            val job = PodStudio.buildJob(this, d, p, orient == "v", true, from)
                            val r = PodcastRenderer(this, d.s, d.setup, d.an, job, { st, pr -> report(st, pr) }, { PodState.cancel })
                            err = r.run()
                            PodState.warnings = r.warnings.toList()
                            if (err == null) PodState.previewFile = job.outFile?.absolutePath
                        } else {
                            val outs = when (orient) { "v" -> listOf(true); "both" -> listOf(false, true); else -> listOf(false) }
                            val done = ArrayList<String>()
                            val warns = ArrayList<String>()
                            for ((idx, vert) in outs.withIndex()) {
                                val tag = if (outs.size > 1) " (${idx + 1}/${outs.size} ${if (vert) "9:16" else "16:9"})" else ""
                                val job = PodStudio.buildJob(this, d, p, vert, false)
                                val r = PodcastRenderer(this, d.s, d.setup, d.an, job, { st, pr -> report(st + tag, pr) }, { PodState.cancel })
                                val e = r.run()
                                warns.addAll(r.warnings)
                                if (e != null) { err = e; break }
                                r.resultUri?.toString()?.let { done.add(it) }
                            }
                            PodState.warnings = warns.distinct()
                            PodState.results = done.toList()
                            PodState.resultUri = done.lastOrNull()
                            val u = done.lastOrNull()
                            if (err == null && u != null && projId == "episode") SessionStore.update(this, sid) { x -> x.mergedUri = u; x.merged = true }
                        }
                    }
                    ACTION_TRANSCRIBE -> {
                        val tr = PodAI.transcribe(this, d.s, d.setup, d.an, { st, pr -> report(st, pr) }, { PodState.cancel })
                        PodState.info = "تم تفريغ ${tr.segs.size} جملة"
                    }
                    ACTION_SEMANTIC -> {
                        val tr = d.tr ?: throw IllegalStateException("لا يوجد نص — افرغ الكلام أولًا")
                        val sem = PodAI.semantic(this, sid, tr, d.names, d.duration, intent.getDoubleExtra("target", 45.0), { st, pr -> report(st, pr) }, { PodState.cancel })
                        PodState.info = "تم: ${sem.regions.size} منطقة، ${sem.keys.size} جملة محورية، ${sem.ideas.size} فكرة ريل"
                    }
                    ACTION_FACES -> {
                        val p = if (projId == "episode") ProjectStore.episode(this, sid) else ProjectStore.load(this, sid, projId)
                        val a = p?.a ?: 0.0
                        val b = p?.end(d.duration) ?: d.duration
                        val devs = (d.setup.people.map { it.camDev } + d.setup.wides).filter { it.isNotEmpty() }.distinct()
                        var found = 0
                        for ((k, dev) in devs.withIndex()) {
                            val dv = d.s.devices[dev] ?: continue
                            val mf = File(SessionStore.devDir(this, sid, dev), "meta.json")
                            val vm = try { JSONObject(mf.readText()).optJSONObject("video") } catch (_: Throwable) { null } ?: continue
                            val tm = Finalizer.SatVideoTime(d.s, dv, vm.optLong("startBoot"))
                            val f0 = tm.fileMs((a * 1e9).toLong())
                            val f1 = tm.fileMs((b * 1e9).toLong())
                            val step = if (b - a > 600) 2000.0 else 1000.0
                            found += PodFaces.analyze(this, sid, dev, f0, f1, step, { pr -> report("تتبع الوجه ${k + 1}/${devs.size}", (k + pr) / devs.size) }, { PodState.cancel })
                            if (PodState.cancel) break
                        }
                        PodState.info = if (found == 0) "لم يُكتشف وجه — سيُستعمل الضبط اليدوي/المنتصف" else "تم تتبع الوجه ($found عينة)"
                    }
                    ACTION_SRT -> {
                        val p = (if (projId == "episode") ProjectStore.episode(this, sid) else ProjectStore.load(this, sid, projId)) ?: throw IllegalStateException("المشروع غير موجود")
                        val tr = d.tr ?: throw IllegalStateException("لا يوجد نص — افرغ الكلام أولًا")
                        val lang = intent.getStringExtra("lang") ?: ""
                        val a = p.a; val b = p.end(d.duration)
                        val segs = tr.segs.filter { it.b > a && it.a < b }
                        val texts = if (lang.isBlank()) null else PodAI.translate(this, segs.map { it.text }, lang, { pr -> report("الترجمة", pr) }, { PodState.cancel })
                        val srt = PodStudio.srtFor(d, p, texts)
                        val name = "Podcast_" + d.s.id + (if (p.kind == PodProject.REEL) "_reel" else "") + (if (lang.isBlank()) "" else "_$lang") + ".srt"
                        val path = PodAI.saveToDownloads(this, name, srt) ?: throw IllegalStateException("تعذر حفظ الملف")
                        PodState.info = "تم حفظ $path"
                    }
                }
            } catch (t: Throwable) {
                err = if (t is InterruptedException) "أُلغي" else (t.message ?: t.javaClass.simpleName)
            }
            PodState.error = err
            PodState.stage = if (err == null) "تم ✓" else "فشل"
            PodState.running = false
            PodState.doneSeq++
            try { if (wake?.isHeld == true) wake?.release() } catch (_: Throwable) {}
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }, "pod-work").start()
    }

    private fun report(stage: String, p: Float) {
        PodState.stage = stage
        PodState.progress = p
        val pct = (p * 100).toInt()
        if (pct != lastPct) {
            lastPct = pct
            try { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, notif("$stage $pct%")) } catch (_: Throwable) {}
        }
    }

    private fun notif(text: String): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, PodcastActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("Podcast")
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { if (wake?.isHeld == true) wake?.release() } catch (_: Throwable) {}
    }
}
