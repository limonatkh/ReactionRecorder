package com.reactionrecorder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat

/** حالة تصدير البودكاست للواجهة */
object PodState {
    @Volatile var running = false
    @Volatile var sid = ""
    @Volatile var stage = ""
    @Volatile var progress = 0f
    @Volatile var error: String? = null
    @Volatile var resultUri: String? = null
    @Volatile var warnings: List<String> = emptyList()
    @Volatile var cancel = false
}

/** خدمة في الخلفية لتصدير حلقة البودكاست (قد تأخذ دقائق) */
class PodcastExportService : Service() {
    companion object {
        const val ACTION_EXPORT = "pod.EXPORT"
        const val ACTION_CANCEL = "pod.CANCEL"
        private const val CHANNEL = "podcast"
        private const val NOTIF_ID = 1004
    }

    private var wake: PowerManager.WakeLock? = null
    private var lastPct = -1

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> { PodState.cancel = true; if (!PodState.running) stopSelf() }
            ACTION_EXPORT -> {
                val sid = intent.getStringExtra("session")
                if (sid == null || PodState.running) {
                    if (!PodState.running) stopSelf()
                    return START_NOT_STICKY
                }
                begin(sid)
            }
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun begin(sid: String) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Podcast export", NotificationManager.IMPORTANCE_LOW))
        }
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, notif("Preparing…"), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            else startForeground(NOTIF_ID, notif("Preparing…"))
        } catch (t: Throwable) {
            PodState.error = "Cannot start: ${t.message}"
            stopSelf(); return
        }
        PodState.running = true
        PodState.sid = sid
        PodState.error = null
        PodState.resultUri = null
        PodState.cancel = false
        PodState.progress = 0f
        PodState.warnings = emptyList()
        PodState.stage = "Preparing…"
        try {
            wake = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "rr:podcast").also { it.acquire(4 * 60 * 60 * 1000L) }
        } catch (_: Throwable) {}

        Thread({
            var err: String? = null
            var uri: String? = null
            try {
                val s = SessionStore.load(this, sid) ?: throw IllegalStateException("Session not found")
                val setup = PodcastAnalyzer.setupOf(s)
                val an: PodAnalysis = PodcastAnalyzer.loadAnalysis(this, sid)
                    ?: PodcastAnalyzer.analyze(this, s, setup, { p -> report("Analyzing voices", p) }, { PodState.cancel })
                        .also { if (!PodState.cancel) PodcastAnalyzer.saveAnalysis(this, sid, it) }
                val shots = PodcastAnalyzer.loadShots(this, sid) ?: PodcastAnalyzer.autoShots(an, setup)
                val r = PodcastRenderer(this, s, setup, shots, an, { st, p -> report(st, p) }, { PodState.cancel })
                err = r.run()
                PodState.warnings = r.warnings.toList()
                val u = r.resultUri?.toString()
                uri = u
                if (err == null && u != null) SessionStore.update(this, sid) { x -> x.mergedUri = u; x.merged = true }
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
            }
            PodState.error = err
            PodState.resultUri = uri
            PodState.stage = if (err == null) "Done ✓" else "Failed"
            PodState.running = false
            try { if (wake?.isHeld == true) wake?.release() } catch (_: Throwable) {}
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }, "pod-export").start()
    }

    private fun report(stage: String, p: Float) {
        PodState.stage = stage
        PodState.progress = p
        val pct = (p * 100).toInt()
        if (pct != lastPct) {
            lastPct = pct
            try { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, notif("$stage $pct%")) } catch (_: Throwable) {}
        }
    }

    private fun notif(text: String): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, PodcastActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("Podcast export")
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { if (wake?.isHeld == true) wake?.release() } catch (_: Throwable) {}
    }
}
