package com.reactionrecorder

import android.Manifest
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import java.util.Locale

/**
 * فلوق: جوالك كاميرا (المعاينة بملء الشاشة)، وصحابك مايكات أو كاميرات بإيدهم ويقلبون كاميراتهم بأنفسهم.
 * أثناء التسجيل: اضغط صورة صاحبك لتصير كاميرته هي الظاهرة، واضغط معاينتك لترجع لكاميرتك —
 * هذه "قرارات مونتاج" تُحفظ ويمكن تعديلها لاحقًا، وكل الكاميرات تسجّل طول الوقت.
 */
class VlogActivity : BaseActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var setup: PodSetup
    private lateinit var finder: FrameLayout
    private lateinit var finderImg: ImageView
    private lateinit var finderSurface: SurfaceView
    private lateinit var finderHint: TextView
    private lateinit var liveBadge: TextView
    private lateinit var thumbs: LinearLayout
    private lateinit var timeTv: TextView
    private lateinit var recBtn: Button
    private lateinit var micBox: LinearLayout
    private lateinit var devList: LinearLayout
    private lateinit var layoutBody: LinearLayout
    private lateinit var qrView: ImageView
    private var qrFor = ""
    private var sig = ""
    private var seenLocal = 0L
    private val thumbViews = HashMap<String, ImageView>()
    private val thumbSeen = HashMap<String, Long>()
    private val levelBars = HashMap<String, ProgressBar>()
    private val devLines = HashMap<String, TextView>()
    /** الشخص الظاهر الآن (رقم في setup.people)، وربط الجهاز ← الشخص للتسجيل الجاري */
    private var liveIdx = 0
    private val personOf = HashMap<String, Int>()

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { ensureThisPhone() }

    private fun dp(v: Int) = UiKit.dp(this, v)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun granted(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    private val myId: String get() = SatCfg.load(this).devId

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setup = PodSetup.loadDefault(this, "vlog").also { it.vlog = true }
        build()
        val c = applicationContext
        Thread {
            try { if (!SatHub.running) { SatHub.start(c); SatHub.setHubWanted(c, SatHub.running) } } catch (_: Throwable) {}
            ui.post { askThenStart() }
        }.start()
    }

    override fun onResume() { super.onResume(); sig = ""; ui.post(tick) }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(tick)
        for (l in SatHub.links.values) SatHub.setPreview(l.id, l.stripOn, false, l.stripOn)
    }

    override fun onDestroy() {
        super.onDestroy()
        PreviewBridge.detach()
    }

    private fun save() = PodSetup.saveDefault(this, setup, "vlog")

    // ───────── هذا الجوال = الكاميرا الرئيسية ─────────

    private fun askThenStart() {
        val need = ArrayList<String>()
        if (!granted(Manifest.permission.RECORD_AUDIO)) need += Manifest.permission.RECORD_AUDIO
        if (!granted(Manifest.permission.CAMERA)) need += Manifest.permission.CAMERA
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) perms.launch(need.toTypedArray()) else ensureThisPhone()
    }

    private fun ensureThisPhone() {
        if (!SatHub.running) { ui.postDelayed({ ensureThisPhone() }, 800); return }
        if (RecorderState.isBusy) { toast(tx("أوقف تسجيل الرياكشن أولًا", "Stop the reaction recording first")); return }
        val c = SatCfg.load(this)
        val ok = SatState.serviceOn && c.role == "both" && c.host.startsWith("127.0.0.1")
        if (ok) return
        if (PodRec.active != null) return
        val restart = SatState.serviceOn
        c.host = "127.0.0.1:${SatHub.port}"; c.pin = SatHub.pin; c.hubId = SatHub.hubId
        c.name = tx("أنا", "Me"); c.role = "both"
        SatCfg.save(this, c)
        if (restart) {
            startService(Intent(this, SatelliteService::class.java).setAction(SatelliteService.ACTION_DISCONNECT))
            ui.postDelayed({ if (!isFinishing) ContextCompat.startForegroundService(this, Intent(this, SatelliteService::class.java).setAction(SatelliteService.ACTION_CONNECT)) }, 2000)
        } else ContextCompat.startForegroundService(this, Intent(this, SatelliteService::class.java).setAction(SatelliteService.ACTION_CONNECT))
    }

    // ───────── الواجهة ─────────

    private fun build() {
        val col = UiKit.page(this, "🎥 " + tx("فلوق", "Vlog"))

        // المعاينة بملء العرض + صور صحابك فوقها
        finder = FrameLayout(this).apply { background = UiKit.bg("#000000", 18, this@VlogActivity); clipToOutline = true }
        finderImg = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; setBackgroundColor(Color.BLACK) }
        finder.addView(finderImg, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        finderSurface = SurfaceView(this).apply { visibility = View.GONE }
        finderSurface.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(h: SurfaceHolder) { PreviewBridge.attach(h.surface) }
            override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) { PreviewBridge.attach(h.surface) }
            override fun surfaceDestroyed(h: SurfaceHolder) { PreviewBridge.detach() }
        })
        finder.addView(finderSurface, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        finderHint = UiKit.text(this, tx("تجهيز الكاميرا…", "Preparing the camera…"), 13f, "#FFFFFF").apply { gravity = Gravity.CENTER }
        finder.addView(finderHint, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        liveBadge = UiKit.text(this, "", 12f, "#FFFFFF", true).apply { setPadding(dp(10), dp(4), dp(10), dp(4)); background = UiKit.bg(UiKit.RED, 10, this@VlogActivity); visibility = View.GONE }
        finder.addView(liveBadge, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START).apply { setMargins(dp(10), dp(10), dp(10), dp(10)) })
        thumbs = LinearLayout(this)
        finder.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(thumbs) },
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply { setMargins(dp(8), dp(8), dp(8), dp(8)) })
        finder.setOnClickListener { goLive(0) }
        col.addView(finder, UiKit.full(this, finder, 4, 440))

        timeTv = UiKit.text(this, "", 17f, UiKit.TEXT, true).apply { gravity = Gravity.CENTER }
        col.addView(timeTv, UiKit.full(this, timeTv, 8))
        val ctl = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val flip = UiKit.chip(this, "🔄 " + tx("اقلب", "Flip")) { startService(Intent(this, SatelliteService::class.java).setAction(SatelliteService.ACTION_FLIP)) }
        recBtn = UiKit.primary(this, "") { onRecord() }
        val star = UiKit.chip(this, "⭐") { if (PodRec.active != null) { PodRec.mark(this, "star"); toast("⭐") } }
        ctl.addView(flip, LinearLayout.LayoutParams(0, dp(52), 1f))
        ctl.addView(recBtn, LinearLayout.LayoutParams(0, dp(60), 1.6f).apply { setMargins(dp(8), 0, dp(8), 0) })
        ctl.addView(star, LinearLayout.LayoutParams(0, dp(52), 1f))
        col.addView(ctl, UiKit.full(this, ctl, 4))
        col.addView(UiKit.text(this, tx("أثناء التسجيل: اضغط صورة صاحبك لتظهر كاميرته، واضغط معاينتك لترجع لكاميرتك. صحابك يقلبون كاميراتهم بأنفسهم.", "While recording: tap a friend's picture to show their camera, tap your preview to come back. Friends flip their own cameras."), 11.5f, UiKit.SUB).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0) })

        val mic = UiKit.card(this, "🎤 " + tx("الأصوات", "Sound"), col)
        micBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mic.addView(micBox)

        val dev = UiKit.section(this, col, "vlog_dev", "📡 " + tx("صحابك (أجهزة)", "Friends (devices)"), "", openByDefault = true)
        devList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        dev.addView(devList)
        val qrBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; visibility = View.GONE }
        qrView = ImageView(this).apply { setBackgroundColor(Color.WHITE); setPadding(dp(8), dp(8), dp(8), dp(8)) }
        qrBox.addView(UiKit.text(this, tx("صاحبك يتصل بشبكة جوالك (الهوتسبوت) ويمسح الباركود: إذا ما عنده التطبيق بينزله من جوالك، وإذا عنده بيتصل. ثم يختار: كاميرا ومايك، أو مايك.", "Your friend joins your hotspot and scans: without the app it downloads from your phone; with it, it connects. Then they pick: camera and mic, or mic."), 12f, UiKit.SUB))
        qrBox.addView(qrView, LinearLayout.LayoutParams(dp(230), dp(230)).apply { topMargin = dp(8) })
        val qrBtn = UiKit.chip(this, "➕ " + tx("أضف صاحب (باركود)", "Add a friend (QR)")) {}
        qrBtn.setOnClickListener { qrBox.visibility = if (qrBox.visibility == View.VISIBLE) View.GONE else View.VISIBLE; qrFor = "" }
        dev.addView(qrBtn, UiKit.full(this, qrBtn, 8))
        dev.addView(qrBox)

        layoutBody = UiKit.section(this, col, "vlog_layout", "🎞 " + tx("شكل الفيديو", "Video layout"), "")
        buildLayout()

        val rec = UiKit.chip(this, "📁 " + tx("تسجيلاتي", "My recordings")) { startActivity(Intent(this, RecordingsActivity::class.java)) }
        col.addView(rec, UiKit.full(this, rec, 12))
    }

    private fun buildLayout() {
        layoutBody.removeAllViews()
        layoutBody.addView(UiKit.text(this, tx("يُطبَّق في المونتاج ويمكن تغييره بعدين.", "Applied in the edit; you can change it later."), 12f, UiKit.SUB))
        val opts = listOf(
            "switch" to tx("تبديل بين الكاميرات", "Switch between cameras"),
            "mainboxes" to tx("أنا بملء الشاشة + صحابي مربعات", "Me full screen + friends in boxes"),
            "grid" to tx("الكل ثابت (مقسوم)", "Everyone fixed (split)"),
        )
        for ((k, n) in opts) {
            val b = UiKit.chip(this, n, setup.vlogLayout == k) { if (PodRec.active == null) { setup.vlogLayout = k; save(); buildLayout() } }
            layoutBody.addView(b, UiKit.full(this, b, 6))
        }
        if (setup.vlogLayout == "switch") layoutBody.addView(UiKit.row(this,
            UiKit.chip(this, tx("حسب اختياري وقت التصوير", "My picks while filming"), setup.vlogManual) { setup.vlogManual = true; save(); buildLayout() },
            UiKit.chip(this, tx("تلقائي على من يتكلم", "Auto on the speaker"), !setup.vlogManual) { setup.vlogManual = false; save(); buildLayout() },
        ))
        val g = UiKit.chip(this, if (setup.glow) "✨ " + tx("إطار مضيء حول من يتكلم: نعم", "Glow around the speaker: yes") else "✨ " + tx("إطار مضيء حول من يتكلم: لا", "Glow around the speaker: no"), setup.glow) { setup.glow = !setup.glow; save(); buildLayout() }
        layoutBody.addView(g, UiKit.full(this, g, 6))
        UiKit.setSummary(layoutBody, opts.first { it.first == setup.vlogLayout }.second)
    }

    // ───────── التسجيل ─────────

    /** الناس = أنا أولًا، ثم كل جهاز متصل (كاميرا+مايك أو مايك) */
    private fun buildPeople() {
        val me = myId
        setup.people.clear(); setup.wides.clear(); personOf.clear()
        setup.people.add(PodPerson(tx("أنا", "Me"), me, me)); personOf[me] = 0
        for (l in SatHub.links.values.filter { it.connected && it.use && it.id != me }.sortedBy { it.name }) {
            personOf[l.id] = setup.people.size
            setup.people.add(PodPerson(l.name, if (l.role == "both") l.id else "", l.id))
        }
        setup.vlog = true
        save()
    }

    private fun onRecord() {
        if (PodRec.active != null) {
            AlertDialog.Builder(this).setTitle(tx("إيقاف التسجيل؟", "Stop recording?"))
                .setPositiveButton(tx("أوقف", "Stop")) { _, _ -> PodRec.stop(this); toast(tx("حُفظ على كل جوال — جارٍ جمع الملفات", "Saved on every phone — collecting files")) }
                .setNegativeButton(tx("استمر", "Keep recording"), null).show()
            return
        }
        if (RecorderState.isBusy) { toast(tx("أوقف تسجيل الرياكشن أولًا", "Stop the reaction recording first")); return }
        if (SatHub.links[myId]?.connected != true) { toast(tx("كاميرا هذا الجوال لم تجهز بعد", "This phone's camera isn't ready yet")); ensureThisPhone(); return }
        buildPeople()
        val friends = setup.people.size - 1
        val go = {
            liveIdx = 0
            val sid = PodRec.start(this, setup)
            getSharedPreferences("reaction_podcast", MODE_PRIVATE).edit().putString("lastSid", sid).apply()
            sig = ""
        }
        if (friends == 0) AlertDialog.Builder(this).setMessage(tx("لا يوجد صاحب متصل — سيُسجَّل من جوالك فقط. متابعة؟", "No friend connected — only your phone will record. Continue?"))
            .setPositiveButton(tx("سجّل", "Record")) { _, _ -> go() }.setNegativeButton(tx("إلغاء", "Cancel"), null).show()
        else go()
    }

    private fun goLive(idx: Int) {
        if (PodRec.active == null || idx == liveIdx) return
        if (setup.people.getOrNull(idx)?.camDev.isNullOrEmpty()) { toast(tx("هذا الجهاز مايك فقط", "This device is mic only")); return }
        liveIdx = idx
        PodRec.live(this, idx)
        sig = ""
    }

    // ───────── تحديث دوري ─────────

    private val tick = object : Runnable {
        override fun run() {
            if (!isFinishing && !isDestroyed) refresh()
            ui.postDelayed(this, 250)
        }
    }

    private fun refresh() {
        val rec = PodRec.active != null
        val want = if (rec) ActivityInfo.SCREEN_ORIENTATION_LOCKED else ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        if (requestedOrientation != want) requestedOrientation = want
        val me = myId
        val links = SatHub.links.values.filter { it.id != me }.sortedBy { it.name }
        val s = links.joinToString("|") { "${it.id}${it.connected}${it.role}${it.licLeft > 0}${it.licOwner}" } + rec + liveIdx
        if (s != sig) {
            sig = s
            // معاينتي: صورة متوسطة قبل التسجيل؛ أثناءه الصورة المسجّلة نفسها
            SatHub.setPreview(me, !rec, false, true, 125, 360)
            for (l in links) if (l.role == "both") SatHub.setLightPreview(l.id, true, if (rec) 800 else 500, 240) else SatHub.setPreview(l.id, false, false, true)
            buildThumbs(links, rec)
            buildDevList(links)
            buildMics(links)
        }
        // المعاينة
        finderSurface.visibility = if (rec) View.VISIBLE else View.GONE
        val local = SatHub.links[me]
        val f = local?.frame
        if (!rec && f != null && local.frameAt != seenLocal) { finderImg.setImageBitmap(f); seenLocal = local.frameAt }
        finderHint.visibility = if (!rec && f == null) View.VISIBLE else View.GONE
        if (rec) fitSurface()
        liveBadge.visibility = if (rec) View.VISIBLE else View.GONE
        liveBadge.text = "● " + tx("الظاهر: ", "Live: ") + (setup.people.getOrNull(liveIdx)?.name ?: tx("أنا", "Me"))
        for ((id, iv) in thumbViews) {
            val l = SatHub.links[id] ?: continue
            val fr = l.frame
            if (fr != null && thumbSeen[id] != l.frameAt) { iv.setImageBitmap(fr); thumbSeen[id] = l.frameAt }
        }
        for ((id, pb) in levelBars) { val l = SatHub.links[id]; pb.progress = if (l != null && l.connected) (l.level * 100 / 32767).coerceIn(0, 100) else 0 }
        for ((id, tv) in devLines) SatHub.links[id]?.let { tv.text = status(it) }
        recBtn.text = if (rec) "■  " + tx("إيقاف", "Stop") else "●  " + tx("سجّل", "Record")
        recBtn.background = UiKit.bg(if (rec) "#7A1F1A" else UiKit.RED, 30, this)
        if (rec) { val sec = PodRec.elapsedSec(this); timeTv.text = "🔴 " + String.format(Locale.US, "%d:%02d", sec / 60, sec % 60); timeTv.visibility = View.VISIBLE }
        else timeTv.visibility = View.GONE
        if (SatHub.running && qrView.parent is View && (qrView.parent as View).visibility == View.VISIBLE) {
            val p = AppShare.pairQr()
            if (p != qrFor) { qrFor = p; qrView.setImageBitmap(PodcastActivity.qrBitmap(p)) }
        }
    }

    private fun fitSurface() {
        val bw = finder.width; val bh = finder.height
        if (bw <= 0 || bh <= 0) return
        val a = if (SatState.lockedOrient == 2) 16f / 9f else 9f / 16f
        var w = bw; var h = (bw / a).toInt()
        if (h > bh) { h = bh; w = (bh * a).toInt() }
        val lp = finderSurface.layoutParams as FrameLayout.LayoutParams
        if (lp.width != w || lp.height != h) { lp.width = w; lp.height = h; lp.gravity = Gravity.CENTER; finderSurface.layoutParams = lp }
    }

    private fun buildThumbs(links: List<SatHub.Link>, rec: Boolean) {
        thumbs.removeAllViews(); thumbViews.clear(); thumbSeen.clear()
        for (l in links.filter { it.role == "both" && it.connected }) {
            val idx = personOf[l.id] ?: -1
            val cell = FrameLayout(this).apply {
                background = UiKit.bg(if (rec && idx == liveIdx) UiKit.RED else "#55000000", 10, this@VlogActivity)
                setPadding(dp(3), dp(3), dp(3), dp(3))
                setOnClickListener { if (rec) goLive(idx) else startActivity(Intent(this@VlogActivity, StudioActivity::class.java).putExtra("dev", l.id)) }
            }
            val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(Color.BLACK) }
            cell.addView(iv, FrameLayout.LayoutParams(dp(84), dp(112)))
            cell.addView(UiKit.text(this, l.name, 10f, "#FFFFFF").apply { setBackgroundColor(0x88000000.toInt()); setPadding(dp(4), dp(1), dp(4), dp(1)) },
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
            thumbViews[l.id] = iv
            thumbs.addView(cell, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(6) })
        }
    }

    private fun buildMics(links: List<SatHub.Link>) {
        micBox.removeAllViews(); levelBars.clear()
        val all = listOfNotNull(SatHub.links[myId]) + links
        if (all.isEmpty()) micBox.addView(UiKit.text(this, tx("لا مايكات بعد", "No mics yet"), 12f, UiKit.SUB))
        for (l in all) {
            val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(3), 0, dp(3)) }
            r.addView(UiKit.text(this, (if (l.id == myId) tx("أنا", "Me") else l.name) + if (!l.connected) " ⚪" else "", 12.5f), LinearLayout.LayoutParams(dp(110), ViewGroup.LayoutParams.WRAP_CONTENT))
            val pb = UiKit.level(this)
            levelBars[l.id] = pb
            r.addView(pb, LinearLayout.LayoutParams(0, dp(8), 1f))
            micBox.addView(r)
        }
    }

    private fun status(l: SatHub.Link): String = if (!l.connected) "⚪ " + tx("برّا التغطية — يكمل تسجيل عنده إن كان بدأ", "Out of range — keeps recording if it started") else
        (if (l.recording) "🔴 " + tx("يسجّل", "Recording") else "🟢 " + tx("جاهز", "Ready")) + (if (l.battery >= 0) "  🔋${l.battery}%" else "") +
            (if (l.battery in 0..15) " ⚠" else "") + (if (l.transfer.isNotEmpty()) "  ⬆ ${l.transfer}" else "")

    private fun buildDevList(links: List<SatHub.Link>) {
        devList.removeAllViews(); devLines.clear()
        if (links.isEmpty()) devList.addView(UiKit.text(this, tx("لا أحد بعد — اضغط \"أضف صاحب\"", "Nobody yet — tap \"Add a friend\""), 12.5f, UiKit.SUB))
        for (l in links) {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
            val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            t.addView(UiKit.text(this, (if (l.role == "both") "🎥 " else "🎤 ") + l.name, 14f))
            val st = UiKit.text(this, status(l), 11.5f, UiKit.SUB)
            devLines[l.id] = st
            t.addView(st)
            row.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            PodUi.licenseButton(this, l) { sig = "" }?.let { row.addView(it) }
            devList.addView(row)
        }
    }
}
