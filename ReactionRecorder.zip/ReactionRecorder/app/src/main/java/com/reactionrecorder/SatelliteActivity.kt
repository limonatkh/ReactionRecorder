package com.reactionrecorder

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.util.Locale

/**
 * شاشة "الجهاز المساعد": هذا الجوال يعمل ميكروفونًا (وكاميرا اختياريًا) لجوال التسجيل الرئيسي.
 * التسجيل محلي على هذا الجوال، فلا يتأثر بانقطاع الشبكة؛ والملفات تُرفع عند عودة الاتصال.
 */
class SatelliteActivity : AppCompatActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var cfg: SatCfg
    private lateinit var hostEt: EditText
    private lateinit var pinEt: EditText
    private lateinit var nameEt: EditText
    private lateinit var statusTv: TextView
    private lateinit var transferTv: TextView
    private lateinit var level: ProgressBar
    private lateinit var connectBtn: Button
    private lateinit var camBox: LinearLayout
    private lateinit var previewView: PreviewView
    private lateinit var sessionsBox: LinearLayout
    private val roleBtns = ArrayList<Button>()
    private var previewBound = false
    private var lastSessionsSig = ""

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == false && !granted(Manifest.permission.RECORD_AUDIO)) {
            SatState.status = "Microphone permission is required"
        } else {
            doConnect()
        }
    }

    private val scanLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        if (r.resultCode == RESULT_OK && d != null) {
            hostEt.setText(d.getStringExtra("host") ?: "")
            pinEt.setText(d.getStringExtra("pin") ?: "")
            SatState.status = "Scanned ✓ — press Connect"
        }
    }

    private val camPermForScan = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) openScanner() else SatState.status = "Camera permission is needed to scan the code"
    }

    private fun openScanner() {
        try { ProcessCameraProvider.getInstance(this).get().unbindAll() } catch (_: Throwable) {}
        previewBound = false
        scanLauncher.launch(Intent(this, ScanActivity::class.java))
    }

    private fun granted(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        cfg = SatCfg.load(this)
        build()
        ui.post(tick)
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacks(tick)
        if (!SatState.recording) try { ProcessCameraProvider.getInstance(this).get().unbindAll() } catch (_: Throwable) {}
    }

    private fun txt(t: String, size: Float = 13f, color: String = "#E6E8EE") = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.parseColor(color)); setPadding(0, dp(8), 0, dp(2))
    }

    private fun field(hint: String, value: String, number: Boolean = false) = EditText(this).apply {
        setText(value); this.hint = hint
        setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); textSize = 15f
        inputType = if (number) InputType.TYPE_CLASS_NUMBER else InputType.TYPE_CLASS_TEXT
        setSingleLine()
    }

    private fun pill(b: Button, sel: Boolean) {
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            setColor(Color.parseColor(if (sel) "#FF3B30" else "#2A2D36"))
        }
    }

    private fun row(vararg v: android.view.View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        for (x in v) addView(x, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, 0, dp(6), 0) })
    }

    private fun build() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(16)) }
        val sv = ScrollView(this).apply { setBackgroundColor(Color.parseColor("#101114")); addView(col) }
        setContentView(sv)
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(sv) { v, insets ->
            val b = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, b.top, 0, b.bottom); insets
        }

        col.addView(txt("📲 Satellite mode", 20f))
        col.addView(txt("This phone records locally (mic, and camera if you choose). Keep it on the same Wi-Fi/hotspot as the main phone when you press record; after that it keeps recording even if the connection drops, and sends the files when you reconnect.", 12f, "#AAB0BD"))

        col.addView(Button(this).apply {
            text = "📷 Scan the QR code from the main phone"; pill(this, true)
            setOnClickListener {
                if (SatState.serviceOn) { SatState.status = "Disconnect first, then scan"; return@setOnClickListener }
                if (granted(Manifest.permission.CAMERA)) openScanner() else camPermForScan.launch(Manifest.permission.CAMERA)
            }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply { topMargin = dp(8) })
        col.addView(txt("…or type the main phone's address (📡 Devices)"))
        hostEt = field("e.g. 192.168.43.1", cfg.host)
        col.addView(hostEt)
        col.addView(txt("PIN"))
        pinEt = field("4 digits", cfg.pin, true)
        col.addView(pinEt)
        col.addView(txt("This device's name"))
        nameEt = field("name", cfg.name)
        col.addView(nameEt)

        col.addView(txt("What does this phone send?"))
        val bMic = Button(this).apply { text = "🎤 Audio only"; setOnClickListener { cfg.role = "mic"; refreshRole() } }
        val bBoth = Button(this).apply { text = "🎥 Audio + video"; setOnClickListener { cfg.role = "both"; refreshRole() } }
        roleBtns += bMic; roleBtns += bBoth
        col.addView(row(bMic, bBoth))

        camBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bFront = Button(this); val bBack = Button(this)
        fun camSel() { pill(bFront, cfg.front); pill(bBack, !cfg.front) }
        bFront.text = "Front camera"; bBack.text = "Back camera"
        bFront.setOnClickListener { cfg.front = true; camSel(); rebindPreview() }
        bBack.setOnClickListener { cfg.front = false; camSel(); rebindPreview() }
        camSel()
        camBox.addView(row(bFront, bBack))
        val b480 = Button(this); val b720 = Button(this); val b1080 = Button(this)
        fun qSel() { pill(b480, cfg.shortSide == 480); pill(b720, cfg.shortSide == 720); pill(b1080, cfg.shortSide == 1080) }
        b480.text = "480p"; b720.text = "720p"; b1080.text = "1080p"
        b480.setOnClickListener { cfg.shortSide = 480; cfg.camLong = 854; qSel() }
        b720.setOnClickListener { cfg.shortSide = 720; cfg.camLong = 1280; qSel() }
        b1080.setOnClickListener { cfg.shortSide = 1080; cfg.camLong = 1920; qSel() }
        qSel()
        camBox.addView(txt("Video quality (lower = more reliable on weak phones)"))
        camBox.addView(row(b480, b720, b1080))
        val bPort = Button(this); val bLand = Button(this)
        fun oSel() { pill(bPort, cfg.portrait); pill(bLand, !cfg.portrait) }
        bPort.text = "Portrait"; bLand.text = "Landscape"
        bPort.setOnClickListener { cfg.portrait = true; oSel() }
        bLand.setOnClickListener { cfg.portrait = false; oSel() }
        oSel()
        camBox.addView(txt("Video orientation"))
        camBox.addView(row(bPort, bLand))
        previewView = PreviewView(this).apply { implementationMode = PreviewView.ImplementationMode.COMPATIBLE }
        camBox.addView(txt("Preview (while not recording)"))
        camBox.addView(FrameLayout(this).apply { addView(previewView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220))) })
        col.addView(camBox)

        col.addView(txt("Microphone"))
        val bNorm = Button(this); val bRaw = Button(this)
        fun aSel() { pill(bNorm, cfg.aSrc == 0); pill(bRaw, cfg.aSrc == 1) }
        bNorm.text = "Normal"; bRaw.text = "Raw (no processing)"
        bNorm.setOnClickListener { cfg.aSrc = 0; aSel() }
        bRaw.setOnClickListener { cfg.aSrc = 1; aSel() }
        aSel()
        col.addView(row(bNorm, bRaw))
        val gainTv = txt("Mic gain: ${String.format(Locale.US, "%.1f", cfg.gain)}x")
        col.addView(gainTv)
        col.addView(SeekBar(this).apply {
            max = 300; progress = (cfg.gain * 100).toInt().coerceIn(0, 300)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    cfg.gain = (p / 100f).coerceAtLeast(0.1f)
                    gainTv.text = "Mic gain: ${String.format(Locale.US, "%.1f", cfg.gain)}x"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        connectBtn = Button(this).apply {
            isAllCaps = false; textSize = 16f
            setOnClickListener { onConnectClicked() }
        }
        col.addView(connectBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(16) })
        statusTv = txt("", 14f)
        col.addView(statusTv)
        level = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        col.addView(level, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(10)))
        transferTv = txt("", 12f, "#AAB0BD")
        col.addView(transferTv)

        col.addView(txt("Recordings stored on this phone", 15f))
        sessionsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(sessionsBox)

        refreshRole()
    }

    private fun refreshRole() {
        pill(roleBtns[0], cfg.role == "mic")
        pill(roleBtns[1], cfg.role == "both")
        camBox.visibility = if (cfg.role == "both") android.view.View.VISIBLE else android.view.View.GONE
        if (cfg.role == "both") rebindPreview() else {
            if (previewBound) try { ProcessCameraProvider.getInstance(this).get().unbindAll() } catch (_: Throwable) {}
            previewBound = false
        }
    }

    private fun readFields() {
        cfg.host = hostEt.text.toString().trim()
        cfg.pin = pinEt.text.toString().trim()
        cfg.name = nameEt.text.toString().trim().ifEmpty { Build.MODEL ?: "Phone" }
        SatCfg.save(this, cfg)
    }

    private fun onConnectClicked() {
        if (SatState.serviceOn) {
            startService(Intent(this, SatelliteService::class.java).setAction(SatelliteService.ACTION_DISCONNECT))
            return
        }
        readFields()
        if (cfg.host.isEmpty() || cfg.pin.length != 4) {
            AlertDialog.Builder(this).setMessage("Enter the main phone's address and its 4-digit PIN (shown in 📡 Devices on the main phone).")
                .setPositiveButton("OK", null).show()
            return
        }
        val need = ArrayList<String>()
        if (!granted(Manifest.permission.RECORD_AUDIO)) need += Manifest.permission.RECORD_AUDIO
        if (cfg.role == "both" && !granted(Manifest.permission.CAMERA)) need += Manifest.permission.CAMERA
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) permLauncher.launch(need.toTypedArray()) else doConnect()
    }

    private fun doConnect() {
        readFields()
        // الكاميرا تُحرَّر من المعاينة قبل أن تأخذها الخدمة
        try { ProcessCameraProvider.getInstance(this).get().unbindAll() } catch (_: Throwable) {}
        previewBound = false
        SatState.status = "Connecting…"
        ContextCompat.startForegroundService(this, Intent(this, SatelliteService::class.java).setAction(SatelliteService.ACTION_CONNECT))
    }

    private fun rebindPreview() {
        if (cfg.role != "both" || SatState.recording || !granted(Manifest.permission.CAMERA)) return
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            try {
                if (SatState.recording) return@addListener
                val p = f.get()
                p.unbindAll()
                val pv = Preview.Builder().build()
                pv.setSurfaceProvider(previewView.surfaceProvider)
                p.bindToLifecycle(this, if (cfg.front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA, pv)
                previewBound = true
            } catch (_: Throwable) {
                previewBound = false
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 400)
        }
    }

    private fun refresh() {
        val on = SatState.serviceOn
        connectBtn.text = if (on) "Disconnect" else "Connect"
        pill(connectBtn, !on)
        statusTv.text = (if (SatState.recording) "🔴 " else if (SatState.connected) "🟢 " else "⚪ ") + SatState.status
        level.progress = (SatState.level * 100 / 32767).coerceIn(0, 100)
        transferTv.text = SatState.transfer
        if (SatState.recording) previewBound = false
        else if (cfg.role == "both" && !previewBound && !on) rebindPreview()
        else if (cfg.role == "both" && !previewBound && on && SatState.connected) rebindPreview()
        // الحقول لا تُعدَّل أثناء الاتصال
        for (e in listOf(hostEt, pinEt, nameEt)) e.isEnabled = !on
        for (b in roleBtns) b.isEnabled = !on

        val list = SatState.localSessions(this)
        val sig = list.joinToString("|") { "${it.id}:${it.uploaded}:${it.sizeBytes / 100000}" } + SatState.connected
        if (sig != lastSessionsSig) {
            lastSessionsSig = sig
            sessionsBox.removeAllViews()
            if (list.isEmpty()) sessionsBox.addView(txt("None", 12f, "#AAB0BD"))
            for (s in list) {
                val line = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
                val label = TextView(this).apply {
                    text = s.id + "\n" + StorageUtil.formatBytes(s.sizeBytes) + (if (s.hasVideo) " • video" else " • audio") + if (s.uploaded) " • sent ✓" else " • not sent yet"
                    setTextColor(Color.parseColor("#E6E8EE")); textSize = 12f
                }
                line.addView(label, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                val send = Button(this).apply {
                    text = "Send"; isAllCaps = false
                    isEnabled = SatState.connected && !SatState.recording
                    setOnClickListener {
                        startService(Intent(this@SatelliteActivity, SatelliteService::class.java).setAction(SatelliteService.ACTION_UPLOAD).putExtra("session", s.id))
                    }
                }
                val del = Button(this).apply {
                    text = "Delete"; isAllCaps = false
                    setOnClickListener {
                        AlertDialog.Builder(this@SatelliteActivity).setTitle("Delete this recording from this phone?")
                            .setMessage(if (s.uploaded) "It was already sent to the main phone." else "It was NOT sent yet — it will be lost.")
                            .setPositiveButton("Delete") { _, _ -> SatState.deleteLocal(this@SatelliteActivity, s.id); lastSessionsSig = "" }
                            .setNegativeButton("Keep", null).show()
                    }
                }
                line.addView(send)
                line.addView(del)
                sessionsBox.addView(line)
            }
        }
    }
}
