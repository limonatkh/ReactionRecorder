package com.reactionrecorder

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** شخص في البودكاست: كاميرته ومايكه (معرّفات الأجهزة)، واسمه */
class PodPerson(var name: String, var camDev: String, var micDev: String)

/** إيقاع المونتاج (بالثواني) */
class PodPacing(
    /** يجب أن يستمر الكلام هذه المدة قبل أن تتغيّر اللقطة */
    var switchDelay: Float,
    /** أقل مدة للقطة */
    var minShot: Float,
    /** مدة المربع العائم قبل أن يصير المتكلم الجديد بملء الشاشة */
    var pipToFull: Float,
    /** أقصر كلام يُحسب (أقصر منه = "آه"، "اممم"…) */
    var minSpeech: Float,
    /** أطول لقطة لنفس الشخص قبل لقطة عامة للتنويع (0 = بدون) */
    var maxShot: Float,
    /** سكوت بهذه المدة → الكاميرا العامة */
    var silenceToWide: Float,
) {
    fun copy() = PodPacing(switchDelay, minShot, pipToFull, minSpeech, maxShot, silenceToWide)

    fun toJson(): JSONObject = JSONObject().put("sd", switchDelay.toDouble()).put("ms", minShot.toDouble()).put("pf", pipToFull.toDouble())
        .put("msp", minSpeech.toDouble()).put("mx", maxShot.toDouble()).put("sw", silenceToWide.toDouble())

    companion object {
        val FAST = PodPacing(0.4f, 1.2f, 1.2f, 0.25f, 8f, 2.5f)
        val MEDIUM = PodPacing(0.8f, 2.0f, 2.0f, 0.4f, 15f, 3.5f)
        val CALM = PodPacing(1.5f, 3.5f, 3.5f, 0.6f, 25f, 5f)

        fun preset(name: String): PodPacing = when (name) { "fast" -> FAST.copy(); "calm" -> CALM.copy(); else -> MEDIUM.copy() }

        fun fromJson(o: JSONObject?, def: PodPacing): PodPacing {
            if (o == null) return def.copy()
            return PodPacing(
                o.optDouble("sd", def.switchDelay.toDouble()).toFloat(), o.optDouble("ms", def.minShot.toDouble()).toFloat(),
                o.optDouble("pf", def.pipToFull.toDouble()).toFloat(), o.optDouble("msp", def.minSpeech.toDouble()).toFloat(),
                o.optDouble("mx", def.maxShot.toDouble()).toFloat(), o.optDouble("sw", def.silenceToWide.toDouble()).toFloat(),
            )
        }
    }
}

/** إعداد جلسة البودكاست */
class PodSetup {
    val people = ArrayList<PodPerson>()
    val wides = ArrayList<String>()
    var presetName = "medium"
    var pacing: PodPacing = PodPacing.MEDIUM.copy()
    /** شكل المشهد لأكثر من شخص: split = تقسيم الشاشة، boxes = مربعات فوق خلفية */
    var multiStyle = "split"
    var usePip = true
    var fade = true
    /** لون خلفية المربعات (ARGB) وصورة اختيارية */
    var bgColor = 0xFF1B1D24.toInt()
    var bgImage = ""
    /** horizontal / vertical / both (الطولي في الدفعة القادمة) */
    var output = "horizontal"
    var height = 720
    /** حساسية الكلام (dB فوق ضوضاء الخلفية) والفرق المطلوب عن بقية المايكات */
    var thrDb = 12f
    var domDb = 6f
    /** تخفيض المايكات الساكتة (0..1) وتوحيد مستوى الأصوات */
    var duck = 0.35f
    var level = true
    /** موضع القص الأفقي/العمودي لكل كاميرا (-1..1) عند ملء إطار بنسبة مختلفة — المفتاح p0..p3 أو w0.. */
    val panX = HashMap<String, Float>()
    val panY = HashMap<String, Float>()
    /** قص السكتات في الحلقة الكاملة، وأقل سكتة تُقص (ثوانٍ) */
    var cutSilence = false
    var silenceGap = 0.35f

    fun toJson(): JSONObject {
        val o = JSONObject()
        val p = JSONArray()
        for (x in people) p.put(JSONObject().put("n", x.name).put("c", x.camDev).put("m", x.micDev))
        o.put("people", p)
        o.put("wides", JSONArray(wides))
        o.put("preset", presetName).put("pacing", pacing.toJson()).put("multi", multiStyle).put("pip", usePip).put("fade", fade)
            .put("bg", bgColor).put("bgImg", bgImage).put("out", output).put("h", height)
            .put("thr", thrDb.toDouble()).put("dom", domDb.toDouble()).put("duck", duck.toDouble()).put("lvl", level)
            .put("cutSil", cutSilence).put("gap", silenceGap.toDouble())
        val px = JSONObject()
        for ((k, v) in panX) px.put(k, v.toDouble())
        val py = JSONObject()
        for ((k, v) in panY) py.put(k, v.toDouble())
        o.put("panX", px).put("panY", py)
        return o
    }

    companion object {
        fun fromJson(o: JSONObject?): PodSetup {
            val s = PodSetup()
            if (o == null) return s
            val p = o.optJSONArray("people")
            if (p != null) for (i in 0 until p.length()) {
                val j = p.getJSONObject(i)
                s.people.add(PodPerson(j.optString("n", "Person ${i + 1}"), j.optString("c"), j.optString("m")))
            }
            val w = o.optJSONArray("wides")
            if (w != null) for (i in 0 until w.length()) s.wides.add(w.getString(i))
            s.presetName = o.optString("preset", "medium")
            s.pacing = PodPacing.fromJson(o.optJSONObject("pacing"), PodPacing.preset(s.presetName))
            s.multiStyle = o.optString("multi", "split")
            s.usePip = o.optBoolean("pip", true)
            s.fade = o.optBoolean("fade", true)
            s.bgColor = o.optInt("bg", 0xFF1B1D24.toInt())
            s.bgImage = o.optString("bgImg")
            s.output = o.optString("out", "horizontal")
            s.height = o.optInt("h", 720)
            s.thrDb = o.optDouble("thr", 12.0).toFloat()
            s.domDb = o.optDouble("dom", 6.0).toFloat()
            s.duck = o.optDouble("duck", 0.35).toFloat()
            s.level = o.optBoolean("lvl", true)
            s.cutSilence = o.optBoolean("cutSil", false)
            s.silenceGap = o.optDouble("gap", 0.35).toFloat()
            o.optJSONObject("panX")?.let { j -> for (k in j.keys()) s.panX[k] = j.optDouble(k, 0.0).toFloat() }
            o.optJSONObject("panY")?.let { j -> for (k in j.keys()) s.panY[k] = j.optDouble(k, 0.0).toFloat() }
            return s
        }

        private const val P = "reaction_podcast"

        fun loadDefault(ctx: Context): PodSetup {
            val t = ctx.getSharedPreferences(P, Context.MODE_PRIVATE).getString("setup", null)
            val s = try { fromJson(if (t != null) JSONObject(t) else null) } catch (_: Throwable) { PodSetup() }
            if (s.people.isEmpty()) {
                s.people.add(PodPerson("Person 1", "", ""))
                s.people.add(PodPerson("Person 2", "", ""))
            }
            return s
        }

        fun saveDefault(ctx: Context, s: PodSetup) {
            ctx.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putString("setup", s.toJson().toString()).apply()
        }
    }
}

/** لقطة في المونتاج: من/إلى (ثوانٍ على خط الجلسة)، النوع، ومن يظهر */
class PodShot(var start: Double, var end: Double, var type: Int, var main: Int, var others: IntArray) {
    val dur: Double get() = end - start
    /** مثبّتة: لا تستبدلها إعادة المونتاج التلقائي */
    var locked = false
    /** "" تلقائية، "manual" يدوية، "reaction" لقطة رد فعل */
    var tag = ""

    fun copy() = PodShot(start, end, type, main, others.copyOf()).also { it.locked = locked; it.tag = tag }

    fun toJson(): JSONObject = JSONObject().put("s", start).put("e", end).put("t", type).put("m", main).put("o", JSONArray(others.toList()))
        .put("l", locked).put("g", tag)

    fun label(setup: PodSetup): String {
        fun nm(i: Int) = setup.people.getOrNull(i)?.name ?: "?"
        return when (type) {
            FULL -> nm(main)
            PIP -> nm(main) + " + " + others.joinToString(",") { nm(it) }
            MULTI -> others.joinToString(" | ") { nm(it) }
            else -> "عامة"
        }
    }

    fun same(o: PodShot): Boolean = type == o.type && main == o.main && others.contentEquals(o.others)

    companion object {
        const val FULL = 0
        const val PIP = 1
        const val MULTI = 2
        const val WIDE = 3

        fun fromJson(o: JSONObject): PodShot {
            val a = o.optJSONArray("o")
            val others = IntArray(a?.length() ?: 0) { a!!.getInt(it) }
            return PodShot(o.optDouble("s"), o.optDouble("e"), o.optInt("t"), o.optInt("m"), others).also {
                it.locked = o.optBoolean("l", false)
                it.tag = o.optString("g", "")
            }
        }
    }
}

/** ناتج تحليل الصوت: نشاط كل مايك كل 50ms، ومستوى كلامه، ومدة الجلسة */
class PodAnalysis(val frameSec: Double, val active: Array<BooleanArray>, val speechDb: FloatArray, val duration: Double) {
    val frames: Int get() = active.firstOrNull()?.size ?: 0

    fun toJson(): JSONObject {
        val a = JSONArray()
        for (row in active) {
            val sb = StringBuilder(row.size)
            for (b in row) sb.append(if (b) '1' else '0')
            a.put(sb.toString())
        }
        return JSONObject().put("fs", frameSec).put("act", a).put("db", JSONArray(speechDb.map { it.toDouble() })).put("dur", duration)
    }

    companion object {
        fun fromJson(o: JSONObject): PodAnalysis {
            val a = o.getJSONArray("act")
            val act = Array(a.length()) { i -> val s = a.getString(i); BooleanArray(s.length) { s[it] == '1' } }
            val d = o.getJSONArray("db")
            return PodAnalysis(o.optDouble("fs", 0.05), act, FloatArray(d.length()) { d.getDouble(it).toFloat() }, o.optDouble("dur"))
        }
    }
}
