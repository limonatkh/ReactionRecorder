package com.reactionrecorder

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File
import java.util.Locale

/** ألوان الأشخاص في الخط الزمني */
object PodColors {
    val people = intArrayOf(0xFFFF6B6B.toInt(), 0xFF4DABF7.toInt(), 0xFFFFD43B.toInt(), 0xFF69DB7C.toInt())
    const val WIDE = 0xFF9775FA.toInt()
    const val MULTI = 0xFFADB5BD.toInt()
}

/** الخط الزمني: مسار كلام لكل شخص + صف اللقطات + مؤشر الوقت المختار */
class PodTimelineView(ctx: Context) : View(ctx) {
    var setup = PodSetup()
    var an: PodAnalysis? = null
    var shots: List<PodShot> = emptyList()
    var duration = 1.0
    var pxPerSec = 12f
        set(v) { field = v.coerceIn(2f, 120f); requestLayout(); invalidate() }
    var selected = -1.0
    var onTap: ((Double) -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val lane = 14 * d
    private val shotH = 40 * d
    private val ruler = 18 * d
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 11 * d }
    private val clip = Rect()

    override fun onMeasure(w: Int, h: Int) {
        val n = setup.people.size
        setMeasuredDimension((duration * pxPerSec).toInt() + (20 * d).toInt(), (ruler + n * (lane + 3 * d) + shotH + 10 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        c.getClipBounds(clip)
        val t0 = (clip.left / pxPerSec).toDouble()
        val t1 = (clip.right / pxPerSec).toDouble()
        c.drawColor(Color.parseColor("#14161B"))
        // المسطرة
        p.color = Color.parseColor("#55FFFFFF")
        val step = when { pxPerSec >= 40 -> 1; pxPerSec >= 12 -> 5; pxPerSec >= 5 -> 10; else -> 30 }
        var s = (t0 / step).toInt() * step
        while (s <= t1) {
            val x = s * pxPerSec
            c.drawLine(x, 0f, x, ruler * 0.6f, p)
            if (s % (step * 2) == 0) c.drawText("${s / 60}:${String.format(Locale.US, "%02d", s % 60)}", x + 2 * d, ruler - 3 * d, tp)
            s += step
        }
        // مسارات الكلام
        val a = an
        var y = ruler
        for (i in setup.people.indices) {
            p.color = Color.parseColor("#22FFFFFF")
            c.drawRect(clip.left.toFloat(), y, clip.right.toFloat(), y + lane, p)
            if (a != null && i < a.active.size) {
                p.color = PodColors.people[i % 4]
                val row = a.active[i]
                val f0 = (t0 / a.frameSec).toInt().coerceAtLeast(0)
                val f1 = (t1 / a.frameSec).toInt().coerceAtMost(row.size - 1)
                var f = f0
                while (f <= f1) {
                    if (row[f]) {
                        var g = f
                        while (g <= f1 && row[g]) g++
                        c.drawRect((f * a.frameSec * pxPerSec).toFloat(), y, (g * a.frameSec * pxPerSec).toFloat(), y + lane, p)
                        f = g
                    } else f++
                }
            }
            y += lane + 3 * d
        }
        // اللقطات
        val r = RectF()
        for (sh in shots) {
            if (sh.end < t0 || sh.start > t1) continue
            r.set((sh.start * pxPerSec).toFloat() + 1, y + 2 * d, (sh.end * pxPerSec).toFloat() - 1, y + shotH)
            p.color = when (sh.type) {
                PodShot.WIDE -> PodColors.WIDE
                PodShot.MULTI -> PodColors.MULTI
                else -> PodColors.people[sh.main % 4]
            }
            c.drawRoundRect(r, 6 * d, 6 * d, p)
            if (sh.type == PodShot.PIP && sh.others.isNotEmpty()) {
                p.color = PodColors.people[sh.others[0] % 4]
                c.drawRect(r.right - minOf(r.width() * 0.3f, 18 * d), r.top + 4 * d, r.right - 3 * d, r.top + 14 * d, p)
            }
            val label = sh.label(setup)
            if (r.width() > tp.measureText(label) + 8 * d) {
                tp.color = Color.BLACK
                c.drawText(label, r.left + 4 * d, r.centerY() + 4 * d, tp)
                tp.color = Color.WHITE
            }
        }
        if (selected >= 0) {
            p.color = Color.WHITE
            val x = (selected * pxPerSec).toFloat()
            c.drawRect(x - d, 0f, x + d, height.toFloat(), p)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            val t = (e.x / pxPerSec).toDouble().coerceIn(0.0, duration)
            selected = t
            invalidate()
            onTap?.invoke(t)
            performClick()
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }
}

/**
 * شاشة المونتاج: يحلل الأصوات، يبني اللقطات تلقائيًا، يعرضها على خط زمني قابل للتعديل، ثم يصدّر.
 */
class PodcastEditActivity : AppCompatActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var sid: String
    private var session: SessionInfo? = null
    private var setup = PodSetup()
    private var an: PodAnalysis? = null
    private var shots: MutableList<PodShot> = ArrayList()
    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private lateinit var tl: PodTimelineView
    private lateinit var preview: ImageView
    private lateinit var shotInfo: TextView
    private lateinit var shotBox: LinearLayout
    private lateinit var exportBtn: Button
    private lateinit var resultBox: LinearLayout
    @Volatile private var busy = false
    private var lastResult: String? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sid = intent.getStringExtra("session") ?: run { finish(); return }
        build()
        loadAll()
        ui.post(tick)
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacks(tick)
    }

    private fun txt(t: String, size: Float = 13f, color: String = "#E6E8EE") = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.parseColor(color)); setPadding(0, dp(6), 0, dp(2))
    }

    private fun btn(label: String, sel: Boolean = false, run: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; setTextColor(Color.WHITE); textSize = 12f; minWidth = 0; minimumWidth = 0
        background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(Color.parseColor(if (sel) "#FF3B30" else "#2A2D36")) }
        setOnClickListener { run() }
    }

    private fun rowOf(vararg v: View) = LinearLayout(this).apply {
        for (x in v) addView(x, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, 0, dp(6), 0) })
    }

    private fun build() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(24)) }
        val sv = ScrollView(this).apply { setBackgroundColor(Color.parseColor("#101114")); addView(col) }
        setContentView(sv)
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(sv) { v, insets ->
            val b = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, b.top, 0, b.bottom); insets
        }
        col.addView(txt("✂ Podcast edit", 20f))
        status = txt("Loading…", 13f, "#FFD60A")
        col.addView(status)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        col.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8)))

        preview = ImageView(this).apply { setBackgroundColor(Color.BLACK); scaleType = ImageView.ScaleType.FIT_CENTER }
        col.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(200)).apply { topMargin = dp(8) })
        shotInfo = txt("Tap the timeline to pick a moment", 13f)
        col.addView(shotInfo)

        tl = PodTimelineView(this)
        tl.onTap = { t -> onPick(t) }
        col.addView(HorizontalScrollView(this).apply { addView(tl) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
        col.addView(rowOf(btn("－ Zoom out") { tl.pxPerSec = tl.pxPerSec / 1.6f }, btn("＋ Zoom in") { tl.pxPerSec = tl.pxPerSec * 1.6f }))

        shotBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(shotBox)

        col.addView(txt("Automatic edit", 15f))
        col.addView(rowOf(
            btn("⚡ Fast") { rerun(PodPacing.preset("fast"), "fast") },
            btn("Medium") { rerun(PodPacing.preset("medium"), "medium") },
            btn("🌙 Calm") { rerun(PodPacing.preset("calm"), "calm") },
            btn("⚙ Custom") { PodUi.pacingDialog(this, setup.pacing) { p -> rerun(p, "custom") } },
        ))
        col.addView(rowOf(
            btn("🎚 Voice sensitivity") { sensitivityDialog() },
            btn("🔊 Audio") { audioDialog() },
        ))
        col.addView(txt("Rebuilding replaces your manual changes.", 11f, "#AAB0BD"))

        exportBtn = btn("⬆ Export 16:9 video", true) { export() }
        col.addView(exportBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(14) })
        resultBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(resultBox)
    }

    private fun loadAll() {
        busy = true
        Thread {
            val s = SessionStore.load(this, sid)
            if (s == null) { ui.post { status.text = "Session not found"; busy = false }; return@Thread }
            session = s
            setup = PodcastAnalyzer.setupOf(s)
            val a: PodAnalysis = PodcastAnalyzer.loadAnalysis(this, sid)
                ?: PodcastAnalyzer.analyze(this, s, setup, { p -> ui.post { status.text = "Listening to who is talking… ${(p * 100).toInt()}%"; bar.progress = (p * 100).toInt() } }, { isFinishing })
                    .also { if (!isFinishing) PodcastAnalyzer.saveAnalysis(this, sid, it) }
            if (isFinishing) return@Thread
            an = a
            val sh = PodcastAnalyzer.loadShots(this, sid) ?: PodcastAnalyzer.autoShots(a, setup).also { PodcastAnalyzer.saveShots(this, sid, it) }
            ui.post {
                shots = sh
                tl.setup = setup
                tl.an = a
                tl.duration = a.duration
                tl.shots = shots
                tl.requestLayout(); tl.invalidate()
                busy = false
                status.text = summary()
                bar.progress = 100
            }
        }.start()
    }

    private fun summary(): String {
        val a = an ?: return ""
        val parts = setup.people.indices.map { i ->
            val talk = a.active.getOrNull(i)?.count { it } ?: 0
            "${setup.people[i].name}: ${(talk * a.frameSec / 60).toInt()} min"
        }
        return "${shots.size} shots • " + parts.joinToString(" • ")
    }

    private fun saveShots() {
        val t = PodcastAnalyzer.tidy(shots, 0.0)
        shots = t
        tl.shots = t
        tl.invalidate()
        PodcastAnalyzer.saveShots(this, sid, t)
        status.text = summary()
    }

    private fun rerun(p: PodPacing, name: String) {
        val a = an ?: return
        AlertDialog.Builder(this).setMessage("Rebuild the edit with this pace? Manual changes will be lost.")
            .setPositiveButton("Rebuild") { _, _ ->
                setup.pacing = p; setup.presetName = name
                saveSetup()
                shots = PodcastAnalyzer.autoShots(a, setup)
                saveShots()
                toast("Edit rebuilt")
            }.setNegativeButton("Cancel", null).show()
    }

    private fun saveSetup() {
        val ex = setup.toJson().toString()
        SessionStore.update(this, sid) { x -> x.extra = ex }
    }

    private fun sensitivityDialog() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), dp(8)) }
        var thr = setup.thrDb
        var dom = setup.domDb
        fun sl(title: String, min: Float, max: Float, init: Float, set: (Float) -> Unit) {
            val tv = TextView(this).apply { textSize = 13f; setPadding(0, dp(10), 0, 0) }
            fun u(v: Float) { tv.text = "$title: ${String.format(Locale.US, "%.0f", v)} dB" }
            u(init)
            col.addView(tv)
            col.addView(SeekBar(this).apply {
                this.max = 100; progress = (((init - min) / (max - min)) * 100).toInt()
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, v: Int, b: Boolean) { val x = min + (max - min) * v / 100f; set(x); u(x) }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            })
        }
        sl("Voice must be above background noise by", 4f, 30f, thr) { thr = it }
        sl("…and close to the loudest mic (lower = stricter)", 2f, 15f, dom) { dom = it }
        col.addView(TextView(this).apply { textSize = 11f; text = "If someone's voice is shown when they are not talking (their mic hears the other person), raise the first value or lower the second." })
        AlertDialog.Builder(this).setTitle("Voice detection").setView(col)
            .setPositiveButton("Re-analyze") { _, _ ->
                setup.thrDb = thr; setup.domDb = dom; saveSetup()
                File(SessionStore.dir(this, sid), "pod_analysis.json").delete()
                File(SessionStore.dir(this, sid), "pod_edit.json").delete()
                loadAll()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun audioDialog() {
        val items = arrayOf(
            (if (setup.level) "✓ " else "") + "Even out voice levels",
            "Lower silent mics: " + when { setup.duck >= 0.99f -> "off"; setup.duck >= 0.5f -> "a little"; setup.duck >= 0.3f -> "medium"; else -> "strong" },
        )
        AlertDialog.Builder(this).setTitle("Audio").setItems(items) { _, i ->
            if (i == 0) setup.level = !setup.level
            else setup.duck = when { setup.duck >= 0.99f -> 0.6f; setup.duck >= 0.5f -> 0.35f; setup.duck >= 0.3f -> 0.15f; else -> 1f }
            saveSetup()
            audioDialog()
        }.setNegativeButton("Done", null).show()
    }

    // ───────── اختيار لحظة وتعديل لقطتها ─────────

    private fun shotIndexAt(t: Double): Int {
        for ((i, s) in shots.withIndex()) if (t >= s.start && t < s.end) return i
        return shots.size - 1
    }

    private fun onPick(t: Double) {
        if (busy || shots.isEmpty()) return
        val i = shotIndexAt(t)
        val sh = shots[i]
        shotInfo.text = "At ${fmt(t)}  —  shot ${i + 1}/${shots.size}: ${typeName(sh)} (${fmt(sh.start)}–${fmt(sh.end)})"
        loadPreview(sh, t)
        shotBox.removeAllViews()
        val n = setup.people.size
        val fulls = (0 until n).map { p -> btn("👤 ${setup.people[p].name}", sh.type == PodShot.FULL && sh.main == p) { change(i) { it.type = PodShot.FULL; it.main = p; it.others = IntArray(0) } } }
        shotBox.addView(txt("Show in this shot:", 12f, "#AAB0BD"))
        shotBox.addView(rowOf(*fulls.toTypedArray()))
        val extra = ArrayList<View>()
        if (n >= 2) extra += btn("👥 Everyone (split)", sh.type == PodShot.MULTI) { change(i) { it.type = PodShot.MULTI; it.main = 0; it.others = IntArray(n) { k -> k } } }
        if (setup.wides.isNotEmpty()) extra += btn("🎥 Wide", sh.type == PodShot.WIDE) { change(i) { it.type = PodShot.WIDE; it.main = 0; it.others = IntArray(0) } }
        if (n >= 2) extra += btn("🔲 Floating box…", sh.type == PodShot.PIP) { pickPip(i) }
        if (extra.isNotEmpty()) shotBox.addView(rowOf(*extra.toTypedArray()))
        shotBox.addView(rowOf(
            btn("✂ Split here") { splitAt(i, t) },
            btn("⇤ Merge with previous") { if (i > 0) { shots[i - 1].end = shots[i].end; shots.removeAt(i); saveShots(); onPick(t) } },
        ))
    }

    private fun pickPip(i: Int) {
        val n = setup.people.size
        val names = setup.people.map { it.name }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Full screen").setItems(names) { _, main ->
            val rest = (0 until n).filter { it != main }
            AlertDialog.Builder(this).setTitle("In the floating box").setItems(rest.map { names[it] }.toTypedArray()) { _, k ->
                change(i) { it.type = PodShot.PIP; it.main = main; it.others = intArrayOf(rest[k]) }
            }.show()
        }.show()
    }

    private fun change(i: Int, f: (PodShot) -> Unit) {
        f(shots[i])
        val t = tl.selected
        saveShots()
        if (t >= 0) onPick(t)
    }

    private fun splitAt(i: Int, t: Double) {
        val sh = shots[i]
        if (t - sh.start < 0.3 || sh.end - t < 0.3) { toast("Too close to the edge of the shot"); return }
        val b = sh.copy()
        sh.end = t
        b.start = t
        shots.add(i + 1, b)
        PodcastAnalyzer.saveShots(this, sid, shots)
        tl.shots = shots
        tl.invalidate()
        toast("Split — now change one of the two parts")
        onPick(t + 0.01)
    }

    private fun typeName(s: PodShot) = when (s.type) {
        PodShot.FULL -> "${setup.people.getOrNull(s.main)?.name} full screen"
        PodShot.PIP -> "${setup.people.getOrNull(s.main)?.name} + floating ${s.others.joinToString { setup.people.getOrNull(it)?.name ?: "?" }}"
        PodShot.MULTI -> "split: " + s.others.joinToString { setup.people.getOrNull(it)?.name ?: "?" }
        else -> "wide camera"
    }

    private fun fmt(t: Double): String { val s = t.toLong(); return "${s / 60}:${String.format(Locale.US, "%02d", s % 60)}" }

    /** صورة من فيديو المصدر الرئيسي للقطة في تلك اللحظة */
    private fun loadPreview(sh: PodShot, t: Double) {
        val s = session ?: return
        val dev = if (sh.type == PodShot.WIDE) setup.wides.getOrNull(sh.main) else setup.people.getOrNull(if (sh.type == PodShot.MULTI && sh.others.isNotEmpty()) sh.others[0] else sh.main)?.camDev
        if (dev.isNullOrEmpty()) { preview.setImageDrawable(null); return }
        Thread {
            val bmp = try {
                val dd = SessionStore.devDir(this, sid, dev)
                val vm = JSONObject(File(dd, "meta.json").readText()).optJSONObject("video")
                val dv = s.devices[dev]
                if (vm == null || dv == null) null else {
                    val ms = Finalizer.SatVideoTime(s, dv, vm.optLong("startBoot")).fileMs((t * 1e9).toLong())
                    val r = MediaMetadataRetriever()
                    try {
                        r.setDataSource(File(dd, "video.mp4").absolutePath)
                        r.getFrameAtTime((ms * 1000).toLong().coerceAtLeast(0L), MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    } finally { r.release() }
                }
            } catch (_: Throwable) { null }
            ui.post { preview.setImageBitmap(bmp) }
        }.start()
    }

    // ───────── التصدير ─────────

    private fun export() {
        if (busy) return
        if (PodState.running) { toast("An export is already running"); return }
        PodcastAnalyzer.saveShots(this, sid, shots)
        lastResult = null
        ContextCompat.startForegroundService(this, Intent(this, PodcastExportService::class.java).setAction(PodcastExportService.ACTION_EXPORT).putExtra("session", sid))
        toast("Export started — you can leave this screen")
    }

    private val tick = object : Runnable {
        override fun run() {
            if (PodState.running && PodState.sid == sid) {
                status.text = "${PodState.stage} ${(PodState.progress * 100).toInt()}%"
                bar.progress = (PodState.progress * 100).toInt()
                exportBtn.text = "■ Cancel export"
                exportBtn.setOnClickListener { startService(Intent(this@PodcastEditActivity, PodcastExportService::class.java).setAction(PodcastExportService.ACTION_CANCEL)) }
            } else if (PodState.sid == sid && !PodState.running && (PodState.resultUri != null || PodState.error != null)) {
                exportBtn.text = "⬆ Export 16:9 video"
                exportBtn.setOnClickListener { export() }
                val key = (PodState.resultUri ?: "") + (PodState.error ?: "")
                if (key != lastResult) {
                    lastResult = key
                    resultBox.removeAllViews()
                    val e = PodState.error
                    if (e != null) resultBox.addView(txt("⚠ $e", 13f, "#FF6B6B"))
                    val u = PodState.resultUri
                    if (u != null) {
                        resultBox.addView(txt("✓ Saved in Movies/ReactionRecorder", 13f, "#7CFC9A"))
                        resultBox.addView(rowOf(
                            btn("▶ Play") { try { startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(u), "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) } catch (_: Throwable) {} },
                            btn("↗ Share") {
                                val sh = Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, Uri.parse(u)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                startActivity(Intent.createChooser(sh, "Share"))
                            },
                        ))
                    }
                    for (w in PodState.warnings) resultBox.addView(txt("• $w", 11f, "#FFB86B"))
                    status.text = summary()
                }
            }
            ui.postDelayed(this, 400)
        }
    }
}
