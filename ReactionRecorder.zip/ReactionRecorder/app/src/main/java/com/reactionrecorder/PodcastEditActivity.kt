package com.reactionrecorder

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** ألوان الأشخاص في الخط الزمني */
object PodColors {
    val people = intArrayOf(0xFFFF6B6B.toInt(), 0xFF4DABF7.toInt(), 0xFFFFD43B.toInt(), 0xFF69DB7C.toInt())
    const val WIDE = 0xFF9775FA.toInt()
    const val MULTI = 0xFFADB5BD.toInt()
    fun region(type: String): Int = when (type) {
        "monologue", "story", "explain" -> 0xFF2F9E44.toInt()
        "qa" -> 0xFF1971C2.toInt()
        "fast", "debate" -> 0xFFE8590C.toInt()
        "overlap", "emotional" -> 0xFFC2255C.toInt()
        "silence" -> 0xFF343A40.toInt()
        else -> 0xFF495057.toInt()
    }
}

/**
 * الخط الزمني لمشروع: طبيعة الحوار، مسار كلام لكل شخص، اللقطات (🔒 = مثبّتة)، المقاطع المحذوفة، حركات الزوم، والعلامات.
 * يعرض حدود المشروع فقط [a,b].
 */
class PodTimelineView(ctx: Context) : View(ctx) {
    var setup = PodSetup()
    var an: PodAnalysis? = null
    var regions: List<PodEngine.Region> = emptyList()
    var project: PodProject? = null
    var markers: List<PMarker> = emptyList()
    var a = 0.0
    var b = 1.0
    var pxPerSec = 12f
        set(v) { field = v.coerceIn(2f, 120f); requestLayout(); invalidate() }
    var selected = -1.0
    var onTap: ((Double) -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val lane = 12 * d
    private val shotH = 36 * d
    private val ruler = 16 * d
    private val regH = 10 * d
    private val zoomH = 8 * d
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 11 * d }
    private val clip = Rect()

    private fun x(t: Double) = ((t - a) * pxPerSec).toFloat()

    override fun onMeasure(w: Int, h: Int) {
        val n = setup.people.size
        setMeasuredDimension(((b - a) * pxPerSec).toInt() + (20 * d).toInt(), (ruler + regH + 4 * d + n * (lane + 3 * d) + shotH + zoomH + 14 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        c.getClipBounds(clip)
        val t0 = a + clip.left / pxPerSec
        val t1 = a + clip.right / pxPerSec
        c.drawColor(Color.parseColor("#14161B"))
        p.color = Color.parseColor("#55FFFFFF")
        val step = when { pxPerSec >= 40 -> 1; pxPerSec >= 12 -> 5; pxPerSec >= 5 -> 10; else -> 30 }
        var s = (t0 / step).toInt() * step
        while (s <= t1) {
            if (s >= a) {
                val xx = x(s.toDouble())
                c.drawLine(xx, 0f, xx, ruler * 0.6f, p)
                if (s % (step * 2) == 0) c.drawText("${s / 60}:${String.format(Locale.US, "%02d", s % 60)}", xx + 2 * d, ruler - 3 * d, tp)
            }
            s += step
        }
        var y = ruler
        // طبيعة الحوار
        for (r in regions) {
            if (r.b < t0 || r.a > t1) continue
            p.color = PodColors.region(r.type)
            p.alpha = (110 + 145 * r.conf).toInt().coerceIn(60, 255)
            c.drawRect(x(r.a), y, x(r.b), y + regH, p)
        }
        p.alpha = 255
        y += regH + 4 * d
        val an0 = an
        for (i in setup.people.indices) {
            p.color = Color.parseColor("#22FFFFFF")
            c.drawRect(clip.left.toFloat(), y, clip.right.toFloat(), y + lane, p)
            if (an0 != null && i < an0.active.size) {
                p.color = PodColors.people[i % 4]
                val row = an0.active[i]
                val f0 = (t0 / an0.frameSec).toInt().coerceAtLeast(0)
                val f1 = (t1 / an0.frameSec).toInt().coerceAtMost(row.size - 1)
                var f = f0
                while (f <= f1) {
                    if (row[f]) {
                        var g = f
                        while (g <= f1 && row[g]) g++
                        c.drawRect(x(f * an0.frameSec), y, x(g * an0.frameSec), y + lane, p)
                        f = g
                    } else f++
                }
            }
            y += lane + 3 * d
        }
        val pr = project
        val r = RectF()
        if (pr != null) {
            for (sh in pr.shots) {
                if (sh.end < t0 || sh.start > t1) continue
                r.set(x(sh.start) + 1, y + 2 * d, x(sh.end) - 1, y + shotH)
                p.color = when (sh.type) { PodShot.WIDE -> PodColors.WIDE; PodShot.MULTI -> PodColors.MULTI; else -> PodColors.people[sh.main % 4] }
                c.drawRoundRect(r, 6 * d, 6 * d, p)
                if (sh.type == PodShot.PIP && sh.others.isNotEmpty()) {
                    p.color = PodColors.people[sh.others[0] % 4]
                    c.drawRect(r.right - min(r.width() * 0.3f, 18 * d), r.top + 4 * d, r.right - 3 * d, r.top + 14 * d, p)
                }
                if (sh.locked) {
                    p.color = Color.WHITE; p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f * d
                    c.drawRoundRect(r, 6 * d, 6 * d, p); p.style = Paint.Style.FILL
                }
                val label = (if (sh.locked) "🔒" else "") + (if (sh.tag == "reaction") "↩" else "") + sh.label(setup)
                if (r.width() > tp.measureText(label) + 8 * d) {
                    tp.color = Color.BLACK
                    c.drawText(label, r.left + 4 * d, r.centerY() + 4 * d, tp)
                    tp.color = Color.WHITE
                }
            }
            // المقاطع المحذوفة (من النسخة المعدّلة فقط)
            p.color = 0xAA000000.toInt()
            for (cu in pr.cuts) {
                if (cu.b < t0 || cu.a > t1) continue
                if (cu.kind == PCut.SILENCE && pr.st.silence == "off") continue
                c.drawRect(x(cu.a), ruler, x(cu.b), y + shotH, p)
            }
            p.color = 0xFFFF3B30.toInt()
            for (cu in pr.cuts) {
                if (cu.b < t0 || cu.a > t1 || cu.kind == PCut.SILENCE) continue
                c.drawRect(x(cu.a), y + shotH - 3 * d, x(cu.b), y + shotH, p)
            }
            y += shotH + 2 * d
            // الزوم
            for (z in pr.zooms) {
                if (z.b < t0 || z.a > t1) continue
                p.color = if (z.scale <= 1.001f) 0xFF868E96.toInt() else if (z.auto) 0xFFBE4BDB.toInt() else 0xFFF06595.toInt()
                c.drawRect(x(z.a), y + 2 * d, x(z.b), y + zoomH, p)
                if (z.locked) { p.color = Color.WHITE; c.drawRect(x(z.a), y + 2 * d, x(z.a) + 3 * d, y + zoomH, p) }
            }
        }
        // العلامات
        for (m in markers) {
            if (m.t < t0 || m.t > t1) continue
            p.color = if (m.kind == "star") 0xFFFFD43B.toInt() else 0xFFFF6B6B.toInt()
            c.drawRect(x(m.t) - 1.5f * d, 0f, x(m.t) + 1.5f * d, height.toFloat(), p)
        }
        if (selected >= 0) {
            p.color = Color.WHITE
            val xx = x(selected)
            c.drawRect(xx - d, 0f, xx + d, height.toFloat(), p)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            val t = (a + e.x / pxPerSec).coerceIn(a, b)
            selected = t
            invalidate()
            onTap?.invoke(t)
            performClick()
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }
}

/**
 * محرّر مشروع (حلقة كاملة أو ريل): كل التعديلات غير إتلافية، مع تراجع/إعادة وحفظ تلقائي ونسخ سابقة،
 * وتثبيت اللقطات والزوم، وإعادة توليد غير المثبّت فقط، ومعاينة 20 ثانية بنفس قرارات التصدير.
 */
class PodcastEditActivity : AppCompatActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var sid: String
    private lateinit var projId: String
    private var d: PodStudio.Data? = null
    private var p: PodProject? = null
    private val undo = UndoStack()
    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private lateinit var tl: PodTimelineView
    private lateinit var preview: ImageView
    private lateinit var info: TextView
    private lateinit var body: LinearLayout
    private lateinit var shotBox: LinearLayout
    private lateinit var resultBox: LinearLayout
    private lateinit var undoBtn: Button
    private lateinit var redoBtn: Button
    private var lastDone = PodState.doneSeq
    @Volatile private var busy = true

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private val isReel get() = p?.kind == PodProject.REEL

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        sid = intent.getStringExtra("session") ?: run { finish(); return }
        projId = intent.getStringExtra("project") ?: "episode"
        build()
        loadAll()
        ui.post(tick)
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacks(tick)
    }

    // ───────── أدوات الواجهة ─────────

    private fun txt(t: String, size: Float = 13f, color: String = "#E6E8EE") = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.parseColor(color)); setPadding(0, dp(6), 0, dp(2))
    }

    private fun btn(label: String, sel: Boolean = false, run: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; setTextColor(Color.WHITE); textSize = 12f; minWidth = 0; minimumWidth = 0
        background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(Color.parseColor(if (sel) "#FF3B30" else "#2A2D36")) }
        setOnClickListener { run() }
    }

    private fun rowOf(vararg v: View) = LinearLayout(this).apply {
        for (x in v) addView(x, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
    }

    private fun card(title: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(6), dp(10), dp(8))
            background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(Color.parseColor("#1B1D24")) }
        }
        c.addView(txt(title, 15f))
        body.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        return c
    }

    private fun fmt(t: Double): String { val s = max(0.0, t).toLong(); return "${s / 60}:${String.format(Locale.US, "%02d", s % 60)}" }

    // ───────── البناء ─────────

    private fun build() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(24)) }
        val sv = ScrollView(this).apply { setBackgroundColor(Color.parseColor("#101114")); addView(col) }
        setContentView(sv)
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(sv) { v, insets ->
            val b = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, b.top, 0, b.bottom); insets
        }
        status = txt("جارٍ التحميل…", 13f, "#FFD60A")
        col.addView(status)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        col.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(6)))
        undoBtn = btn("↶ تراجع") { doUndo() }
        redoBtn = btn("↷ إعادة") { doRedo() }
        col.addView(rowOf(undoBtn, redoBtn, btn("📜 النسخ") { versionsDialog() }))
        preview = ImageView(this).apply { setBackgroundColor(Color.BLACK); scaleType = ImageView.ScaleType.FIT_CENTER }
        col.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(190)).apply { topMargin = dp(6) })
        info = txt("اضغط على الخط الزمني لاختيار لحظة", 12f)
        col.addView(info)
        col.addView(rowOf(btn("▶ معاينة 20 ثانية من هنا", true) { previewHere() }))
        tl = PodTimelineView(this)
        tl.onTap = { t -> onPick(t) }
        col.addView(HorizontalScrollView(this).apply { layoutDirection = View.LAYOUT_DIRECTION_LTR; addView(tl) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        col.addView(rowOf(btn("－ تصغير") { tl.pxPerSec = tl.pxPerSec / 1.6f }, btn("＋ تكبير") { tl.pxPerSec = tl.pxPerSec * 1.6f }))
        col.addView(txt("الشريط العلوي = طبيعة الحوار • الألوان = من يتكلم • 🔒 مثبّتة • المظلّل = محذوف • البنفسجي = زوم • ⭐/✖ علامات التسجيل", 10f, "#AAB0BD"))
        shotBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(shotBox)
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(body)
        resultBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(resultBox)
    }

    private fun loadAll() {
        busy = true
        Thread {
            val dd = PodStudio.load(this, sid, { pr -> ui.post { status.text = "تحليل من يتكلم… ${(pr * 100).toInt()}%"; bar.progress = (pr * 100).toInt() } }, { isFinishing })
            if (dd == null) { ui.post { status.text = if (isFinishing) "" else "تعذر فتح الجلسة" }; return@Thread }
            var pp = if (projId == "episode") ProjectStore.episode(this, sid) else ProjectStore.load(this, sid, projId)
            if (pp == null && projId == "episode") pp = PodStudio.newEpisode(dd).also { ProjectStore.save(this, sid, it) }
            if (pp != null && pp.shots.isEmpty()) { PodStudio.regenerate(dd, pp); ProjectStore.save(this, sid, pp) }
            ui.post {
                if (pp == null) { status.text = "المشروع غير موجود"; return@post }
                d = dd; p = pp
                busy = false
                bar.progress = 100
                refreshAll()
            }
        }.start()
    }

    // ───────── تعديل مع تراجع وحفظ تلقائي ─────────

    private fun edit(f: (PodProject) -> Unit) {
        if (busy) { toast("انتظر… جارٍ الحساب"); return }
        val pp = p ?: return
        undo.push(pp.toJson().toString())
        f(pp)
        ProjectStore.save(this, sid, pp)
        refreshAll()
    }

    private var busy = false

    /** تعديل ثقيل (إعادة توليد، قص صمت، زوم تلقائي): يُحسب على نسخة في الخلفية ثم يُعتمد */
    private fun editHeavy(f: (PodProject) -> Unit) {
        val pp = p ?: return
        if (busy) { toast("انتظر… جارٍ الحساب"); return }
        busy = true
        val before = pp.toJson().toString()
        val cp = pp.copy()
        status.text = "جارٍ الحساب…"
        Thread {
            val err = try { f(cp); null } catch (t: Throwable) { t.message ?: t.javaClass.simpleName }
            ui.post {
                busy = false
                if (isFinishing || isDestroyed) return@post
                if (err != null) { status.text = "⚠ $err"; return@post }
                undo.push(before)
                p = cp
                ProjectStore.save(this, sid, cp)
                refreshAll()
            }
        }.start()
    }

    private fun doUndo() {
        if (busy) return
        val pp = p ?: return
        val s = undo.undo(pp.toJson().toString()) ?: return
        p = PodProject.fromJson(JSONObject(s)); ProjectStore.save(this, sid, p!!); refreshAll()
    }

    private fun doRedo() {
        if (busy) return
        val pp = p ?: return
        val s = undo.redo(pp.toJson().toString()) ?: return
        p = PodProject.fromJson(JSONObject(s)); ProjectStore.save(this, sid, p!!); refreshAll()
    }

    private fun refreshAll() {
        val dd = d ?: return
        val pp = p ?: return
        tl.setup = dd.setup; tl.an = dd.an; tl.regions = dd.regions; tl.project = pp; tl.markers = dd.markers
        tl.a = pp.a; tl.b = pp.end(dd.duration)
        tl.requestLayout(); tl.invalidate()
        undoBtn.isEnabled = undo.canUndo(); redoBtn.isEnabled = undo.canRedo()
        undoBtn.alpha = if (undo.canUndo()) 1f else 0.4f; redoBtn.alpha = if (undo.canRedo()) 1f else 0.4f
        status.text = summary()
        buildBody()
        if (tl.selected >= 0) onPick(tl.selected) else shotBox.removeAllViews()
    }

    private fun summary(): String {
        val dd = d ?: return ""
        val pp = p ?: return ""
        val keep = PodStudio.keepSegs(dd, pp)
        val outDur = keep.sumOf { it[1] - it[0] }
        val orig = pp.end(dd.duration) - pp.a
        val head = if (isReel) "📱 ريل: ${pp.title}" else "🎬 الحلقة الكاملة"
        return "$head • ${pp.shots.size} لقطة • المدة ${fmt(outDur)}" + (if (orig - outDur > 0.5) " (حُذف ${fmt(orig - outDur)})" else "") +
            (if (pp.zooms.isNotEmpty() && pp.st.zoomMode != "off") " • ${pp.zooms.size} زوم" else "")
    }

    // ───────── اختيار لحظة ─────────

    private fun shotIndexAt(t: Double): Int {
        val pp = p ?: return -1
        for ((i, s) in pp.shots.withIndex()) if (t >= s.start && t < s.end) return i
        return pp.shots.size - 1
    }

    private fun onPick(t: Double) {
        val pp = p ?: return
        val dd = d ?: return
        if (pp.shots.isEmpty()) return
        tl.selected = t; tl.invalidate()
        val i = shotIndexAt(t)
        val sh = pp.shots[i]
        val reg = PodEngine.regionAt(dd.regions, t)
        val cut = pp.cuts.firstOrNull { t >= it.a && t < it.b && !(it.kind == PCut.SILENCE && pp.st.silence == "off") }
        val text = dd.tr?.segs?.firstOrNull { t >= it.a - 0.2 && t < it.b + 0.2 }?.text
        info.text = "عند ${fmt(t)} — لقطة ${i + 1}/${pp.shots.size}: ${typeName(sh)}" + (if (sh.locked) " 🔒" else "") +
            (reg?.let { "\nطبيعة الجزء: ${it.label()} (ثقة ${(it.conf * 100).toInt()}% • ${if (it.source == "ai") "من فهم النص" else "تقدير من التوقيت"})" } ?: "") +
            (if (cut != null) "\n✂ هذه اللحظة محذوفة من النسخة المعدّلة (${cutName(cut.kind)})" else "") +
            (text?.let { "\n«$it»" } ?: "")
        loadPreview(sh, t)
        shotBox.removeAllViews()
        val n = dd.setup.people.size
        shotBox.addView(txt("في هذه اللقطة اعرض:", 12f, "#AAB0BD"))
        shotBox.addView(rowOf(*(0 until n).map { k ->
            btn("👤 ${dd.setup.people[k].name}", sh.type == PodShot.FULL && sh.main == k) { change(i) { it.type = PodShot.FULL; it.main = k; it.others = IntArray(0) } }
        }.toTypedArray()))
        val extra = ArrayList<View>()
        if (n >= 2) extra += btn("👥 مشتركة", sh.type == PodShot.MULTI) { change(i) { it.type = PodShot.MULTI; it.main = 0; it.others = IntArray(n) { k -> k } } }
        if (dd.setup.wides.isNotEmpty()) extra += btn("🎥 عامة", sh.type == PodShot.WIDE) { change(i) { it.type = PodShot.WIDE; it.main = 0; it.others = IntArray(0) } }
        if (n >= 2) extra += btn("🔲 مربع عائم…", sh.type == PodShot.PIP) { pickPip(i) }
        if (extra.isNotEmpty()) shotBox.addView(rowOf(*extra.toTypedArray()))
        shotBox.addView(rowOf(
            btn(if (sh.locked) "🔓 إلغاء التثبيت" else "🔒 تثبيت", sh.locked) { edit { it.shots[i].locked = !it.shots[i].locked } },
            btn("↩ لقطة رد فعل هنا") { reactionHere(t) },
        ))
        shotBox.addView(rowOf(
            btn("✂ قسّم هنا") { splitAt(i, t) },
            btn("⇤ ادمج مع السابقة") { if (i > 0) edit { it.shots[i - 1].end = it.shots[i].end; it.shots.removeAt(i) } },
            btn("♻ أعد توليد هذا الجزء") { regenPart(t) },
        ))
    }

    private fun cutName(k: String) = when (k) { PCut.SILENCE -> "قص صمت"; PCut.GAP -> "فراغ طويل"; PCut.TEXT -> "جملة محذوفة"; else -> "حذف يدوي" }

    private fun typeName(s: PodShot): String {
        val st = d?.setup ?: return ""
        fun nm(i: Int) = st.people.getOrNull(i)?.name ?: "؟"
        return when (s.type) {
            PodShot.FULL -> "${nm(s.main)} بملء الشاشة" + if (s.tag == "reaction") " (رد فعل)" else ""
            PodShot.PIP -> "${nm(s.main)} + مربع عائم ${s.others.joinToString { nm(it) }}"
            PodShot.MULTI -> "مشتركة: " + s.others.joinToString { nm(it) }
            else -> "الكاميرا العامة"
        }
    }

    /** أي تعديل يدوي على لقطة يثبّتها تلقائيًا حتى لا تستبدلها إعادة التوليد */
    private fun change(i: Int, f: (PodShot) -> Unit) = edit { pp ->
        val sh = pp.shots[i]
        f(sh)
        sh.locked = true
        sh.tag = if (sh.tag == "reaction") "reaction" else "manual"
        pp.shots = PodEngine.tidy(pp.shots)
    }

    private fun pickPip(i: Int) {
        val st = d?.setup ?: return
        val n = st.people.size
        val names = st.people.map { it.name }.toTypedArray()
        AlertDialog.Builder(this).setTitle("بملء الشاشة").setItems(names) { _, main ->
            val rest = (0 until n).filter { it != main }
            AlertDialog.Builder(this).setTitle("في المربع العائم").setItems(rest.map { names[it] }.toTypedArray()) { _, k ->
                change(i) { it.type = PodShot.PIP; it.main = main; it.others = intArrayOf(rest[k]) }
            }.show()
        }.show()
    }

    private fun splitAt(i: Int, t: Double) {
        val pp = p ?: return
        val sh = pp.shots[i]
        if (t - sh.start < 0.3 || sh.end - t < 0.3) { toast("قريب جدًا من حد اللقطة"); return }
        edit { q ->
            val s0 = q.shots[i]
            val b2 = s0.copy()
            s0.end = t
            b2.start = t
            q.shots.add(i + 1, b2)
        }
        toast("قُسمت — غيّر أحد الجزأين الآن")
    }

    /** إدراج لقطة رد فعل يدوية (1.5 ثانية) لشخص تختاره */
    private fun reactionHere(t: Double) {
        val st = d?.setup ?: return
        val names = st.people.map { it.name }.toTypedArray()
        AlertDialog.Builder(this).setTitle("رد فعل من؟").setItems(names) { _, k ->
            edit { pp ->
                val r = PodShot(t, min(pp.end(d!!.duration), t + 1.5), PodShot.FULL, k, IntArray(0)).also { it.locked = true; it.tag = "reaction" }
                pp.shots = PodEngine.tidy(PodEngine.overlay(pp.shots, listOf(r)))
            }
        }.show()
    }

    private fun regenPart(t: Double) {
        val dd = d ?: return
        val pp = p ?: return
        val i = shotIndexAt(t)
        val r0 = max(pp.a, pp.shots[max(0, i - 1)].start)
        val r1 = min(pp.end(dd.duration), pp.shots[min(pp.shots.size - 1, i + 1)].end)
        ProjectStore.snapshot(this, sid, pp, "قبل إعادة توليد جزء")
        editHeavy { PodStudio.regenerate(dd, it, r0, r1) }
        toast("أُعيد توليد ${fmt(r0)}–${fmt(r1)} (المثبّت بقي كما هو)")
    }

    private var frameReq = 0

    private fun loadPreview(sh: PodShot, t: Double) {
        val dd = d ?: return
        val req = ++frameReq
        val dev = if (sh.type == PodShot.WIDE) dd.setup.wides.getOrNull(sh.main) else dd.setup.people.getOrNull(if (sh.type == PodShot.MULTI && sh.others.isNotEmpty()) sh.others[0] else sh.main)?.camDev
        if (dev.isNullOrEmpty()) { preview.setImageDrawable(null); return }
        Thread {
            val bmp = try {
                val dir = SessionStore.devDir(this, sid, dev)
                val vm = JSONObject(File(dir, "meta.json").readText()).optJSONObject("video")
                val dv = dd.s.devices[dev]
                if (vm == null || dv == null) null else {
                    val ms = Finalizer.SatVideoTime(dd.s, dv, vm.optLong("startBoot")).fileMs((t * 1e9).toLong())
                    val r = MediaMetadataRetriever()
                    try {
                        r.setDataSource(File(dir, "video.mp4").absolutePath)
                        r.getScaledFrameAtTime((ms * 1000).toLong().coerceAtLeast(0L), MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 640, 640)
                    } finally { r.release() }
                }
            } catch (_: Throwable) { null }
            ui.post { if (req == frameReq) preview.setImageBitmap(bmp) }
        }.start()
    }

    // ───────── الأقسام ─────────

    private fun buildBody() {
        val dd = d ?: return
        val pp = p ?: return
        body.removeAllViews()

        if (isReel) {
            val c = card("حدود الريل: ${fmt(pp.a)} → ${fmt(pp.end(dd.duration))}")
            if (pp.reason.isNotBlank()) c.addView(txt("سبب الاختيار: ${pp.reason}", 11f, "#AAB0BD"))
            c.addView(rowOf(btn("البداية −2ث") { moveEdge(true, -2.0) }, btn("البداية +2ث") { moveEdge(true, 2.0) }))
            c.addView(rowOf(btn("النهاية −2ث") { moveEdge(false, -2.0) }, btn("النهاية +2ث") { moveEdge(false, 2.0) }))
            c.addView(rowOf(btn("✎ العنوان") { editTitle() }))
        }

        // استراتيجية المونتاج
        run {
            val c = card("استراتيجية المونتاج")
            val styles = listOf("auto" to "تلقائي حسب الحوار", "qa" to "سؤال وجواب", "story" to "قصة / سرد", "explain" to "شرح", "debate" to "نقاش سريع", "emotional" to "لحظة انفعالية")
            c.addView(rowOf(*styles.take(3).map { (k, n) -> btn(n, pp.st.style == k) { edit { it.st.style = k } } }.toTypedArray()))
            c.addView(rowOf(*styles.drop(3).map { (k, n) -> btn(n, pp.st.style == k) { edit { it.st.style = k } } }.toTypedArray()))
            c.addView(txt("الشدة", 12f, "#AAB0BD"))
            c.addView(rowOf(*listOf("calm" to "🌙 هادئ", "balanced" to "متوازن", "lively" to "⚡ حيوي").map { (k, n) -> btn(n, pp.st.intensity == k) { edit { it.st.intensity = k } } }.toTypedArray()))
            c.addView(rowOf(btn(if (pp.st.fade) "انتقالات ناعمة: مفعّلة" else "قطع مباشر (افتراضي)", pp.st.fade) { edit { it.st.fade = !it.st.fade } }))
            val src = if (!dd.sem?.regions.isNullOrEmpty()) "طبيعة الحوار من فهم النص" else "طبيعة الحوار مقدّرة من توقيت الكلام فقط (بدون فهم المعنى)"
            c.addView(txt("$src. التعقيبات القصيرة (آه، صح) لا تبدّل الكاميرا، ولا تبديل بمؤقت ثابت.", 11f, "#AAB0BD"))
            c.addView(rowOf(btn("♻ أعد توليد غير المثبّت", true) {
                AlertDialog.Builder(this).setMessage("ستُستبدل اللقطات والزوم والقص التلقائي غير المثبّت. تُحفظ نسخة من الحالية أولًا.")
                    .setPositiveButton("أعد التوليد") { _, _ ->
                        ProjectStore.snapshot(this, sid, pp, "قبل إعادة التوليد")
                        editHeavy { PodStudio.regenerate(dd, it) }
                    }.setNegativeButton("إلغاء", null).show()
            }))
        }

        // الصمت
        run {
            val c = card("قص الصمت")
            if (isReel) {
                c.addView(rowOf(*listOf("off" to "إيقاف", "light" to "خفيف", "balanced" to "متوازن", "intense" to "مكثّف").map { (k, n) ->
                    btn(n, pp.st.silence == k) {
                        editHeavy { q ->
                            q.st.silence = k
                            q.cuts.removeAll { it.kind == PCut.SILENCE && !it.locked }
                            q.cuts.addAll(PodEngine.silenceCuts(dd.an, dd.turns, k, q.a, q.end(dd.duration)))
                        }
                    }
                }.toTypedArray()))
                c.addView(txt("القص عند فواصل الكلام فقط مع هامش قبل الكلام وبعده؛ الضحك وأي صوت مسموع لا يُقص، والوقفة التعبيرية تُقصَّر ولا تُحذف (إلا في المكثّف). لا يُسرَّع الصوت.", 11f, "#AAB0BD"))
            } else {
                val gaps = pp.cuts.filter { it.kind == PCut.GAP }
                c.addView(txt(if (gaps.isEmpty()) "معطّل (الافتراضي للحلقة الكاملة)" else "محذوف: ${gaps.size} فراغ طويل (${fmt(gaps.sumOf { it.b - it.a })})", 12f))
                c.addView(rowOf(
                    btn("🔍 راجع الفراغات الطويلة") { gapsDialog() },
                    btn("↺ أعدها كلها") { edit { it.cuts.removeAll { x -> x.kind == PCut.GAP } } },
                ))
            }
        }

        // الزوم
        run {
            val c = card("الزوم")
            c.addView(rowOf(*listOf("off" to "معطّل", "auto" to "تلقائي", "manual" to "يدوي").map { (k, n) ->
                btn(n, pp.st.zoomMode == k) {
                    editHeavy { q ->
                        q.st.zoomMode = k
                        if (k == "auto") q.zooms.let { z -> val keep = z.filter { it.locked || !it.auto }; z.clear(); z.addAll(PodEngine.mergeZooms(keep, PodEngine.autoZooms(q.shots, dd.turns, dd.regions, q.st, dd.sem?.keys, q.a, q.end(dd.duration)))) }
                    }
                }
            }.toTypedArray()))
            if (pp.st.zoomMode != "off") {
                c.addView(txt("أقصى تقريب: ${String.format(Locale.US, "%.2f", pp.st.zoomMax)}×", 12f, "#AAB0BD"))
                c.addView(rowOf(*listOf(1.05f, 1.10f, 1.15f, 1.20f).map { v -> btn(String.format(Locale.US, "%.2f×", v), abs(pp.st.zoomMax - v) < 0.001f) { edit { it.st.zoomMax = v; for (z in it.zooms) if (z.auto && z.scale > v) z.scale = v } } }.toTypedArray()))
                c.addView(rowOf(
                    btn(if (pp.st.zoomSmooth) "حركة تدريجية" else "انتقال مباشر", true) { edit { it.st.zoomSmooth = !it.st.zoomSmooth; for (z in it.zooms) if (z.auto) z.smooth = it.st.zoomSmooth } },
                    btn("💡 اقترح الزوم") { editHeavy { q -> val keep = q.zooms.filter { it.locked || !it.auto }; q.zooms.clear(); q.zooms.addAll(PodEngine.mergeZooms(keep, PodEngine.autoZooms(q.shots, dd.turns, dd.regions, q.st.copy().also { s -> s.zoomMode = "auto" }, dd.sem?.keys, q.a, q.end(dd.duration)))) } },
                ))
                c.addView(rowOf(
                    btn("🔍 زوم هنا") { zoomHere() },
                    btn("📌 ثبّت الكادر هنا") { holdFrameHere() },
                    btn("📋 الحركات") { zoomsDialog() },
                ))
                val keysTxt = if (dd.sem?.keys.isNullOrEmpty()) "بدون نص: التقريب التلقائي يعتمد على طول السرد فقط (وبعد الوقفات في الحيوي)." else "الجمل المحورية من فهم النص تُستعمل للتقريب."
                c.addView(txt("$keysTxt الزوم محدود بدقة الكاميرا وبالقص العمودي حتى لا تتدهور الصورة.", 11f, "#AAB0BD"))
            }
            c.addView(rowOf(
                btn(if (pp.st.faces) "تتبع الوجه: مفعّل" else "تتبع الوجه: معطّل", pp.st.faces) { edit { it.st.faces = !it.st.faces } },
                btn("🙂 حلّل الوجوه") { startJob(PodcastExportService.ACTION_FACES) },
                btn("🎯 الكادر") { framingDialog() },
            ))
        }

        // النص والكتابة
        run {
            val c = card("النص والكتابة على الفيديو")
            val tr = dd.tr
            if (tr == null) {
                c.addView(txt("لا يوجد تفريغ بعد. التفريغ يحتاج خدمة خارجية اختيارية بمفتاحك (🤖)، ويرفع صوت الحلقة عند طلبك فقط.", 12f, "#AAB0BD"))
                c.addView(rowOf(btn("🤖 الخدمة") { PodUi.aiDialog(this) }, btn("📝 فرّغ الكلام", true) { confirmTranscribe() }))
            } else {
                c.addView(txt("${tr.segs.size} جملة مفرّغة (${tr.source})", 12f, "#AAB0BD"))
                c.addView(rowOf(
                    btn("📝 النص") { transcriptDialog() },
                    btn("🧠 افهم الحوار") { confirmSemantic() },
                ))
                c.addView(rowOf(
                    btn(if (pp.st.captions) "الكتابة: مفعّلة" else "الكتابة: معطّلة", pp.st.captions) { edit { it.st.captions = !it.st.captions } },
                    btn(if (pp.st.highlight) "تمييز كلمة: نعم" else "تمييز كلمة: لا", pp.st.highlight) { edit { it.st.highlight = !it.st.highlight } },
                ))
                if (pp.st.captions) c.addView(rowOf(*listOf(0.85f to "صغير", 1f to "عادي", 1.2f to "كبير").map { (v, n) -> btn(n, abs(pp.st.capSize - v) < 0.01f) { edit { it.st.capSize = v } } }.toTypedArray()))
            }
            c.addView(rowOf(
                btn(if (pp.st.titleOn) "عنوان افتتاحي: مفعّل" else "عنوان افتتاحي: معطّل", pp.st.titleOn) { edit { it.st.titleOn = !it.st.titleOn } },
                btn("✎ نص العنوان") { editTitle() },
            ))
            c.addView(txt("الكتابة سطر أو سطران بخط عربي واتجاه صحيح، في منطقة آمنة بعيدًا عن أزرار المنصات (تظهر الأدلة في المعاينة).", 11f, "#AAB0BD"))
        }

        // التصدير
        run {
            val c = card("التصدير")
            val opts = if (isReel) listOf("v" to "9:16", "h" to "16:9") else listOf("h" to "16:9", "v" to "9:16", "both" to "الاثنين")
            c.addView(rowOf(*opts.map { (k, n) -> btn(n, pp.st.orient == k) { edit { it.st.orient = k } } }.toTypedArray()))
            c.addView(rowOf(btn("720p", pp.st.height < 1080) { edit { it.st.height = 720 } }, btn("1080p", pp.st.height >= 1080) { edit { it.st.height = 1080 } }))
            c.addView(rowOf(btn("⬆ صدّر الفيديو", true) { startJob(PodcastExportService.ACTION_EXPORT) }))
            if (dd.tr != null) c.addView(rowOf(btn("📄 ملف SRT") { startJob(PodcastExportService.ACTION_SRT) }, btn("🌐 SRT مترجم…") { translateSrt() }))
            c.addView(txt("التصدير ينتج ملفًا جديدًا؛ التسجيل الأصلي والمشروع لا يتغيران، ولا يُحذف شيء عند الفشل.", 11f, "#AAB0BD"))
        }
    }

    private fun moveEdge(start: Boolean, delta: Double) {
        val dd = d ?: return
        editHeavy { q ->
            val e = q.end(dd.duration)
            if (start) q.a = (q.a + delta).coerceIn(0.0, max(0.0, e - 3.0))
            else q.b = (e + delta).coerceIn(min(q.a + 3.0, dd.duration), dd.duration)
            // نقرب الحد من أقرب وقفة حتى لا يبدأ أو ينتهي في منتصف كلمة
            val real = dd.turns.filter { !it.backchannel }
            if (start) real.filter { abs(it.a - q.a) < 1.0 }.minByOrNull { abs(it.a - q.a) }?.let { q.a = max(0.0, it.a - 0.15) }
            else real.filter { abs(it.b - q.b) < 1.0 }.minByOrNull { abs(it.b - q.b) }?.let { q.b = min(dd.duration, it.b + 0.3) }
            PodStudio.regenerate(dd, q)
        }
    }

    private fun editTitle() {
        val pp = p ?: return
        val et = EditText(this).apply { setText(pp.title); setSingleLine() }
        AlertDialog.Builder(this).setTitle("العنوان").setView(et)
            .setPositiveButton("حفظ") { _, _ -> edit { it.title = et.text.toString().trim() } }
            .setNegativeButton("إلغاء", null).show()
    }

    // ───────── الفراغات الطويلة (الحلقة) ─────────

    private fun gapsDialog() {
        val dd = d ?: return
        val pp = p ?: return
        val found = PodEngine.longGaps(dd.an, pp.st.gapMin.toDouble(), pp.a, pp.end(dd.duration))
        if (found.isEmpty()) { toast("لا توجد فراغات أطول من ${pp.st.gapMin} ثانية"); return }
        val labels = found.map { "${fmt(it.a)} — حذف ${String.format(Locale.US, "%.1f", it.b - it.a)} ث (يبقى 0.6 ث)" }.toTypedArray()
        val checked = BooleanArray(found.size) { k -> pp.cuts.any { it.kind == PCut.GAP && abs(it.a - found[k].a) < 0.05 } || pp.cuts.none { it.kind == PCut.GAP } }
        AlertDialog.Builder(this).setTitle("الفراغات الطويلة — اختر ما يُحذف")
            .setMultiChoiceItems(labels, checked) { _, k, on -> checked[k] = on }
            .setPositiveButton("اعتمد") { _, _ ->
                edit { q ->
                    q.cuts.removeAll { it.kind == PCut.GAP }
                    for ((k, g) in found.withIndex()) if (checked[k]) q.cuts.add(g.copy().also { it.locked = true })
                    q.cuts.sortBy { it.a }
                }
            }
            .setNeutralButton("أقل فراغ…") { _, _ ->
                val opts = arrayOf("1.0 ث", "1.5 ث", "2.0 ث", "3.0 ث")
                AlertDialog.Builder(this).setItems(opts) { _, k -> edit { it.st.gapMin = listOf(1f, 1.5f, 2f, 3f)[k] }; gapsDialog() }.show()
            }
            .setNegativeButton("إلغاء", null).show()
    }

    // ───────── الزوم اليدوي ─────────

    private fun zoomHere() {
        val pp = p ?: return
        val t = tl.selected
        if (t < 0) { toast("اختر لحظة على الخط الزمني أولًا"); return }
        val sh = pp.shots.getOrNull(shotIndexAt(t)) ?: return
        if (sh.type == PodShot.MULTI || sh.type == PodShot.WIDE) { toast("الزوم يعمل على لقطة شخص واحد"); return }
        edit { q ->
            if (q.st.zoomMode == "off") q.st.zoomMode = "manual"
            val z = PZoom(t, min(sh.end, t + 3.0), q.st.zoomMax, q.st.zoomSmooth, locked = true, auto = false, reason = "يدوي")
            q.zooms.removeAll { it.a < z.b && it.b > z.a }
            q.zooms.add(z); q.zooms.sortBy { it.a }
        }
    }

    private fun holdFrameHere() {
        val pp = p ?: return
        val t = tl.selected
        if (t < 0) { toast("اختر لحظة على الخط الزمني أولًا"); return }
        val sh = pp.shots.getOrNull(shotIndexAt(t)) ?: return
        edit { q ->
            val z = PZoom(sh.start, sh.end, 1f, false, locked = true, auto = false, reason = "تثبيت الكادر")
            q.zooms.removeAll { it.a < z.b && it.b > z.a }
            q.zooms.add(z); q.zooms.sortBy { it.a }
        }
        toast("الكادر مثبّت في هذه اللقطة (لا زوم)")
    }

    private fun zoomsDialog() {
        val pp = p ?: return
        if (pp.zooms.isEmpty()) { toast("لا توجد حركات زوم"); return }
        val items = pp.zooms.map { z ->
            (if (z.locked) "🔒 " else "") + "${fmt(z.a)}–${fmt(z.b)} • " + (if (z.scale <= 1.001f) "تثبيت" else String.format(Locale.US, "%.2f×", z.scale)) +
                " • ${if (z.smooth) "تدريجي" else "مباشر"} • ${z.reason}"
        }.toTypedArray()
        AlertDialog.Builder(this).setTitle("حركات الزوم").setItems(items) { _, k ->
            val z = pp.zooms[k]
            AlertDialog.Builder(this).setTitle(items[k])
                .setItems(arrayOf(if (z.locked) "إلغاء التثبيت" else "تثبيت", "تقريب أقوى", "تقريب أخف", if (z.smooth) "اجعله مباشرًا" else "اجعله تدريجيًا", "اذهب إليها", "حذف")) { _, a ->
                    when (a) {
                        0 -> edit { it.zooms[k].locked = !z.locked }
                        1 -> edit { it.zooms[k].scale = min(it.st.zoomMax + 0.1f, z.scale + 0.03f); it.zooms[k].locked = true; it.zooms[k].auto = false }
                        2 -> edit { it.zooms[k].scale = max(1f, z.scale - 0.03f); it.zooms[k].locked = true; it.zooms[k].auto = false }
                        3 -> edit { it.zooms[k].smooth = !z.smooth; it.zooms[k].locked = true }
                        4 -> onPick(z.a + 0.01)
                        5 -> edit { it.zooms.removeAt(k) }
                    }
                }.show()
        }.show()
    }

    // ───────── النص ─────────

    private fun transcriptDialog() {
        val dd = d ?: return
        val pp = p ?: return
        val tr = dd.tr ?: return
        val a = pp.a; val b = pp.end(dd.duration)
        val segs = tr.segs.filter { it.b > a && it.a < b }
        var dlg: AlertDialog? = null
        val lv = ListView(this)
        val adapter = object : BaseAdapter() {
            override fun getCount() = segs.size
            override fun getItem(i: Int) = segs[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, cv: View?, parent: ViewGroup?): View {
                val g = segs[i]
                val q = p ?: pp
                val deleted = q.cuts.any { it.kind == PCut.TEXT && it.ref == g.i }
                val tv = (cv as? TextView) ?: TextView(this@PodcastEditActivity).apply { setPadding(dp(10), dp(8), dp(10), dp(8)); textSize = 15f; textDirection = View.TEXT_DIRECTION_RTL }
                val who = dd.setup.people.getOrNull(g.speaker)?.name ?: "؟"
                tv.text = "${fmt(g.a)} • $who\n${g.text}"
                tv.setTextColor(if (deleted) Color.GRAY else Color.WHITE)
                tv.paintFlags = if (deleted) tv.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG else tv.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
                tv.setBackgroundColor(if (g.speaker >= 0) (PodColors.people[g.speaker % 4] and 0x00FFFFFF) or 0x22000000 else 0)
                return tv
            }
        }
        lv.adapter = adapter
        lv.setOnItemClickListener { _, _, i, _ -> dlg?.dismiss(); onPick(segs[i].a + 0.01) }
        lv.setOnItemLongClickListener { _, _, i, _ ->
            val g = segs[i]
            val q = p ?: pp
            val deleted = q.cuts.any { it.kind == PCut.TEXT && it.ref == g.i }
            AlertDialog.Builder(this).setTitle(g.text.take(60))
                .setItems(arrayOf("✎ تصحيح النص", if (deleted) "↺ أرجع الجملة" else "✂ احذفها من النسخة المعدّلة", "★ ميّز كلمة")) { _, k ->
                    when (k) {
                        0 -> {
                            val et = EditText(this).apply { setText(g.text); textDirection = View.TEXT_DIRECTION_RTL }
                            AlertDialog.Builder(this).setView(et).setPositiveButton("حفظ") { _, _ ->
                                val nt = et.text.toString().trim()
                                if (nt != g.text) {
                                    g.text = nt
                                    // توقيت الكلمات القديم لا يطابق النص المصحَّح: الكتابة تتوزع نسبيًا على مدة الجملة
                                    g.words = emptyList()
                                    PodAI.saveTranscript(this, sid, tr)
                                }
                                adapter.notifyDataSetChanged()
                            }.setNegativeButton("إلغاء", null).show()
                        }
                        1 -> {
                            edit { pr ->
                                if (deleted) pr.cuts.removeAll { it.kind == PCut.TEXT && it.ref == g.i }
                                else { pr.cuts.add(PCut(max(pr.a, g.a - 0.05), min(pr.end(dd.duration), g.b + 0.05), PCut.TEXT, true, g.i)); pr.cuts.sortBy { it.a } }
                            }
                            adapter.notifyDataSetChanged()
                        }
                        2 -> {
                            val words = g.text.split(Regex("\\s+")).filter { it.isNotEmpty() }.toTypedArray()
                            AlertDialog.Builder(this).setItems(words) { _, w ->
                                edit { pr -> val key = "${g.i}:$w"; if (!pr.emph.remove(key)) pr.emph.add(key) }
                            }.show()
                        }
                    }
                }.show()
            true
        }
        dlg = AlertDialog.Builder(this).setTitle("النص — اضغط للانتقال، ضغطة مطوّلة للتعديل أو الحذف").setView(lv)
            .setPositiveButton("إغلاق", null).show()
    }

    private fun confirmTranscribe() {
        if (!PodAI.cfg(this).ok) { PodUi.aiDialog(this); return }
        val c = PodAI.cfg(this)
        AlertDialog.Builder(this).setTitle("رفع الصوت للتفريغ؟")
            .setMessage("سيُرفع صوت الحلقة (مخلوط، 16kHz) إلى:\n${c.base}\nبنموذج ${c.stt}.\nلن يُرفع الفيديو. قد تُحتسب تكلفة على حسابك لدى الخدمة.")
            .setPositiveButton("ارفع وفرّغ") { _, _ -> startJob(PodcastExportService.ACTION_TRANSCRIBE) }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun confirmSemantic() {
        if (!PodAI.cfg(this).ok) { PodUi.aiDialog(this); return }
        AlertDialog.Builder(this).setTitle("فهم الحوار؟")
            .setMessage("سيُرسل النص المفرّغ فقط (بدون صوت) إلى الخدمة لتصنيف أجزاء الحوار وتحديد الجمل المحورية واقتراح أفكار ريلز.")
            .setPositiveButton("أرسل") { _, _ -> startJob(PodcastExportService.ACTION_SEMANTIC) }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun translateSrt() {
        if (!PodAI.cfg(this).ok) { PodUi.aiDialog(this); return }
        val langs = arrayOf("English", "Français", "Deutsch", "Español", "Türkçe")
        AlertDialog.Builder(this).setTitle("ترجمة إلى").setItems(langs) { _, k -> startJob(PodcastExportService.ACTION_SRT, langs[k]) }.show()
    }

    // ───────── الأعمال الطويلة ─────────

    private fun startJob(action: String, lang: String = "") {
        val pp = p ?: return
        if (PodState.running) { toast("هناك عمل آخر قيد التنفيذ"); return }
        ProjectStore.save(this, sid, pp)
        val it = Intent(this, PodcastExportService::class.java).setAction(action).putExtra("session", sid).putExtra("project", pp.id)
            .putExtra("orient", pp.st.orient).putExtra("target", pp.st.targetLen.toDouble())
        if (lang.isNotBlank()) it.putExtra("lang", lang)
        ContextCompat.startForegroundService(this, it)
    }

    private fun previewHere() {
        val pp = p ?: return
        if (PodState.running) { toast("هناك عمل آخر قيد التنفيذ"); return }
        val t = if (tl.selected >= 0) tl.selected else pp.a
        ProjectStore.save(this, sid, pp)
        ContextCompat.startForegroundService(this, Intent(this, PodcastExportService::class.java).setAction(PodcastExportService.ACTION_PREVIEW)
            .putExtra("session", sid).putExtra("project", pp.id).putExtra("from", t).putExtra("orient", if (pp.st.orient == "v") "v" else "h"))
    }

    // ───────── النسخ ─────────

    private fun versionsDialog() {
        val pp = p ?: return
        val dd = d ?: return
        val vs = ProjectStore.versions(this, sid, pp.id)
        val df = SimpleDateFormat("MM-dd HH:mm:ss", Locale.US)
        val items = (listOf("💾 احفظ نسخة من الحالية") + vs.map { "${df.format(Date(it.time))} — ${it.label}" }).toTypedArray()
        AlertDialog.Builder(this).setTitle("النسخ السابقة").setItems(items) { _, k ->
            if (k == 0) { ProjectStore.snapshot(this, sid, pp, "حفظ يدوي"); toast("حُفظت نسخة"); return@setItems }
            val v = vs[k - 1]
            val old = ProjectStore.loadVersion(v) ?: return@setItems
            AlertDialog.Builder(this).setTitle("مقارنة مع الحالية").setMessage(compare(dd, old, pp))
                .setPositiveButton("استرجع هذه") { _, _ ->
                    ProjectStore.snapshot(this, sid, pp, "قبل الاسترجاع")
                    edit { cur -> val o = old.copy(); cur.shots = o.shots; cur.cuts.clear(); cur.cuts.addAll(o.cuts); cur.zooms.clear(); cur.zooms.addAll(o.zooms); cur.st = o.st; cur.a = o.a; cur.b = o.b; cur.title = o.title; cur.emph.clear(); cur.emph.addAll(o.emph) }
                }
                .setNegativeButton("أبقِ الحالية", null).show()
        }.show()
    }

    private fun compare(dd: PodStudio.Data, x: PodProject, y: PodProject): String {
        fun dur(q: PodProject) = PodStudio.keepSegs(dd, q).sumOf { it[1] - it[0] }
        val a = min(x.a, y.a); val b = max(x.end(dd.duration), y.end(dd.duration))
        var diff = 0.0
        var t = a
        while (t < b) {
            val sx = x.shots.firstOrNull { t >= it.start && t < it.end }
            val sy = y.shots.firstOrNull { t >= it.start && t < it.end }
            if (sx == null || sy == null || !sx.same(sy)) diff += 0.5
            t += 0.5
        }
        return "النسخة السابقة: ${x.shots.size} لقطة، مدة ${fmt(dur(x))}، ${x.zooms.size} زوم، ${x.cuts.size} حذف، ${x.shots.count { it.locked }} مثبّتة\n" +
            "الحالية: ${y.shots.size} لقطة، مدة ${fmt(dur(y))}، ${y.zooms.size} زوم، ${y.cuts.size} حذف، ${y.shots.count { it.locked }} مثبّتة\n" +
            "اللقطات مختلفة في ${((diff / max(1.0, b - a)) * 100).toInt()}% من الوقت."
    }

    // ───────── الكادر لكل كاميرا ─────────

    private fun framingDialog() {
        val dd = d ?: return
        val keys = ArrayList<Pair<String, String>>()
        for ((i, pr) in dd.setup.people.withIndex()) if (pr.camDev.isNotEmpty()) keys.add("p$i" to pr.camDev)
        for ((i, w) in dd.setup.wides.withIndex()) keys.add("w$i" to w)
        if (keys.isEmpty()) { toast("لا كاميرات في هذا البودكاست"); return }
        val names = keys.map { (k, _) -> if (k.startsWith("p")) dd.setup.people[k.substring(1).toInt()].name else "العامة ${k.substring(1).toInt() + 1}" }
        AlertDialog.Builder(this).setTitle("أي كاميرا؟").setItems(names.toTypedArray()) { _, which ->
            val (key, dev) = keys[which]
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(8), dp(14), dp(8)) }
            val iv = ImageView(this).apply { setBackgroundColor(Color.BLACK); scaleType = ImageView.ScaleType.FIT_CENTER }
            col.addView(iv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220)))
            var px = dd.setup.panX[key] ?: 0f
            var src: android.graphics.Bitmap? = null
            fun redraw() {
                val bm = src ?: return
                val out = bm.copy(android.graphics.Bitmap.Config.ARGB_8888, true)
                val c = Canvas(out)
                val k = (9f / 16f) / (bm.width.toFloat() / bm.height)
                if (k < 1f) {
                    val w = bm.width * k
                    val cx = (0.5f + px * 0.5f).coerceIn(k / 2f, 1f - k / 2f) * bm.width
                    val x0 = cx - w / 2f
                    val shade = Paint().apply { color = 0xAA000000.toInt() }
                    c.drawRect(0f, 0f, x0, bm.height.toFloat(), shade)
                    c.drawRect(x0 + w, 0f, bm.width.toFloat(), bm.height.toFloat(), shade)
                    c.drawRect(x0, 0f, x0 + w, bm.height.toFloat(), Paint().apply { style = Paint.Style.STROKE; strokeWidth = bm.width / 120f; color = Color.WHITE })
                }
                iv.setImageBitmap(out)
            }
            col.addView(TextView(this).apply { text = "حرّك إطار 9:16 يمينًا/يسارًا (الضبط اليدوي له أولوية على تتبع الوجه؛ المنتصف = تلقائي)"; textSize = 12f; setPadding(0, dp(8), 0, 0) })
            col.addView(SeekBar(this).apply {
                max = 200; progress = ((px + 1f) * 100).toInt()
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, v: Int, u: Boolean) { px = v / 100f - 1f; redraw() }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            })
            Thread {
                val bmp = try {
                    val r = MediaMetadataRetriever()
                    try {
                        r.setDataSource(File(SessionStore.devDir(this, sid, dev), "video.mp4").absolutePath)
                        val durMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                        r.getFrameAtTime(durMs * 500L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    } finally { r.release() }
                } catch (_: Throwable) { null }
                ui.post { src = bmp; if (bmp == null) toast("لا يوجد فيديو من هذه الكاميرا") else redraw() }
            }.start()
            AlertDialog.Builder(this).setTitle(names[which]).setView(ScrollView(this).apply { addView(col) })
                .setPositiveButton("حفظ") { _, _ ->
                    dd.setup.panX[key] = px
                    val ex = dd.setup.toJson().toString()
                    SessionStore.update(this, sid) { x -> x.extra = ex }
                }
                .setNegativeButton("إلغاء", null).show()
        }.show()
    }

    // ───────── متابعة الأعمال ─────────

    private val tick = object : Runnable {
        override fun run() {
            val mine = PodState.sid == sid
            if (PodState.running && mine) {
                status.text = "${PodState.stage} ${(PodState.progress * 100).toInt()}%  (اضغط للإلغاء)"
                status.setOnClickListener { startService(Intent(this@PodcastEditActivity, PodcastExportService::class.java).setAction(PodcastExportService.ACTION_CANCEL)) }
                bar.progress = (PodState.progress * 100).toInt()
            } else if (mine && PodState.doneSeq != lastDone && !PodState.running) {
                lastDone = PodState.doneSeq
                status.setOnClickListener(null)
                onJobDone()
            }
            ui.postDelayed(this, 400)
        }
    }

    private fun onJobDone() {
        resultBox.removeAllViews()
        val e = PodState.error
        when (PodState.job) {
            PodcastExportService.ACTION_PREVIEW -> {
                if (e == null && PodState.previewFile != null) startActivity(Intent(this, PodPreviewActivity::class.java).putExtra("file", PodState.previewFile))
                else if (e != null) resultBox.addView(txt("⚠ $e", 13f, "#FF6B6B"))
            }
            PodcastExportService.ACTION_EXPORT -> PodUi.results(this, resultBox)
            else -> {
                if (e != null) resultBox.addView(txt("⚠ $e", 13f, "#FF6B6B"))
                PodState.info?.let { resultBox.addView(txt("✓ $it", 13f, "#7CFC9A")) }
                if (PodState.job == PodcastExportService.ACTION_TRANSCRIBE || PodState.job == PodcastExportService.ACTION_SEMANTIC || PodState.job == PodcastExportService.ACTION_FACES) reloadData()
            }
        }
        for (w in PodState.warnings) if (PodState.job != PodcastExportService.ACTION_EXPORT) resultBox.addView(txt("• $w", 11f, "#FFB86B"))
        status.text = summary()
    }

    /** بعد التفريغ/الفهم: نعيد تحميل البيانات (المشروع كما هو) */
    private fun reloadData() {
        Thread {
            val dd = PodStudio.load(this, sid, {}, { false }) ?: return@Thread
            ui.post { d = dd; refreshAll() }
        }.start()
    }
}
