package com.reactionrecorder

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import java.util.Locale

/**
 * شاشة الستوديو: كل الأجهزة في شبكة واحدة — صورة خفيفة جدًا من كل كاميرا (صورة كل ثانية تقريبًا)،
 * مستوى كل مايك، البطارية والمساحة وحالة التسجيل. عند بدء التسجيل تصل صورة تأكيد من كل كاميرا.
 * ليست معاينة كاملة — للاطمئنان فقط؛ التسجيل الحقيقي بجودة كاملة على كل جوال.
 */
class MonitorActivity : BaseActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var grid: LinearLayout
    private lateinit var timeTv: TextView
    private lateinit var recBtn: Button
    private lateinit var markRow: LinearLayout
    private var sig = ""

    private class Tile(val img: ImageView, val name: TextView, val st: TextView, val lvl: ProgressBar, val badge: TextView) { var seen = 0L }
    private val tiles = HashMap<String, Tile>()

    private fun dp(v: Int) = UiKit.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val col = UiKit.page(this, "🎛 " + tx("الستوديو", "Studio"), tx("صورة خفيفة من كل جهاز للاطمئنان — اضغط على أي جهاز للتحكم به.", "A light picture from each device — tap any device to control it."))
        timeTv = UiKit.text(this, "", 18f, UiKit.TEXT, true).apply { gravity = Gravity.CENTER }
        col.addView(timeTv, UiKit.full(this, timeTv, 4))
        grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(grid, UiKit.full(this, grid, 6))
        recBtn = UiKit.primary(this, "") { onRec() }
        col.addView(recBtn, UiKit.full(this, recBtn, 14, 56))
        markRow = UiKit.row(this,
            UiKit.chip(this, "⭐ " + tx("لحظة مهمة", "Key moment"), true) { PodRec.mark(this, "star"); toast("⭐") },
            UiKit.chip(this, "✖ " + tx("غلطة / إعادة", "Mistake / retake")) { PodRec.mark(this, "oops"); toast("✖") },
        )
        col.addView(markRow, UiKit.full(this, markRow, 6))
    }

    private fun toast(s: String) = android.widget.Toast.makeText(this, s, android.widget.Toast.LENGTH_SHORT).show()

    override fun onResume() { super.onResume(); sig = ""; ui.post(tick) }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(tick)
        for (l in SatHub.links.values) SatHub.setPreview(l.id, l.stripOn, false, l.stripOn)
    }

    private fun onRec() {
        if (PodRec.active != null) {
            AlertDialog.Builder(this).setTitle(tx("إيقاف التسجيل؟", "Stop recording?"))
                .setPositiveButton(tx("أوقف", "Stop")) { _, _ -> PodRec.stop(this) }.setNegativeButton(tx("استمر", "Keep recording"), null).show()
            return
        }
        val setup = PodSetup.loadDefault(this)
        val miss = PodRec.check(setup)
        val go = {
            val sid = PodRec.start(this, setup)
            getSharedPreferences("reaction_podcast", MODE_PRIVATE).edit().putString("lastSid", sid).apply()
        }
        if (miss.isEmpty()) go() else AlertDialog.Builder(this).setTitle(tx("تحقّق قبل التسجيل", "Check before recording")).setMessage(miss.joinToString("\n"))
            .setPositiveButton(tx("سجّل على أي حال", "Record anyway")) { _, _ -> go() }.setNegativeButton(tx("إلغاء", "Cancel"), null).show()
    }

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 300)
        }
    }

    private fun refresh() {
        val rec = PodRec.active != null
        val links = SatHub.links.values.sortedBy { it.name }
        val s = links.joinToString("|") { it.id + it.role } + rec
        if (s != sig) {
            sig = s
            build(links)
            for (l in links) if (l.role == "both") SatHub.setLightPreview(l.id, true, if (rec) 1000 else 500, 240) else SatHub.setPreview(l.id, false, false, true)
        }
        val now = SystemClock.elapsedRealtime()
        for (l in links) {
            val tl = tiles[l.id] ?: continue
            val f = l.frame
            if (f != null && tl.seen != l.frameAt) { tl.img.setImageBitmap(f); tl.seen = l.frameAt }
            tl.lvl.progress = if (l.connected) (l.level * 100 / 32767).coerceIn(0, 100) else 0
            tl.badge.text = when { !l.connected -> "⚪"; l.recording -> "🔴"; else -> "🟢" }
            val parts = ArrayList<String>()
            if (!l.connected) parts += tx("غير متصل — التسجيل يستمر عليه إن كان بدأ", "Offline — keeps recording if it had started")
            else {
                parts += if (l.recording) tx("يسجّل", "Recording") else tx("جاهز", "Ready")
                if (l.battery >= 0) parts += "🔋${l.battery}%"
                if (l.freeMb >= 0) parts += "💾" + String.format(Locale.US, "%.1fGB", l.freeMb / 1024f)
                if (l.transfer.isNotEmpty()) parts += "⬆ ${l.transfer}"
                if (rec && l.role == "both" && l.snapAt > 0 && now - l.snapAt < 15_000) parts += "📸 " + tx("صورة تأكيد وصلت", "confirmation frame received")
            }
            tl.st.text = parts.joinToString("  •  ")
        }
        recBtn.text = if (rec) "■  " + tx("إيقاف التسجيل", "Stop recording") else "●  " + tx("ابدأ التسجيل", "Start recording")
        recBtn.background = UiKit.bg(if (rec) "#7A1F1A" else UiKit.RED, 24, this)
        markRow.visibility = if (rec) View.VISIBLE else View.GONE
        if (rec) { val sec = PodRec.elapsedSec(this); timeTv.text = "🔴 " + String.format(Locale.US, "%d:%02d", sec / 60, sec % 60); timeTv.visibility = View.VISIBLE }
        else timeTv.visibility = View.GONE
    }

    private fun build(links: List<SatHub.Link>) {
        grid.removeAllViews(); tiles.clear()
        if (links.isEmpty()) {
            grid.addView(UiKit.text(this, tx("لا أجهزة متصلة بعد. من شاشة الحوار ← الأجهزة ← أضف جهازًا.", "No devices yet. From the podcast screen ← Devices ← Add a device."), 13f, UiKit.SUB))
            return
        }
        var row: LinearLayout? = null
        for ((i, l) in links.withIndex()) {
            if (i % 2 == 0) { row = LinearLayout(this); grid.addView(row, UiKit.full(this, row, 8)) }
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8))
                background = UiKit.bg(UiKit.CARD, 14, this@MonitorActivity)
                setOnClickListener { startActivity(Intent(this@MonitorActivity, StudioActivity::class.java).putExtra("dev", l.id)) }
            }
            val fr = FrameLayout(this)
            val img = ImageView(this).apply { setBackgroundColor(Color.BLACK); scaleType = ImageView.ScaleType.FIT_CENTER }
            fr.addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            if (l.role != "both") fr.addView(UiKit.text(this, "🎤", 34f).apply { gravity = Gravity.CENTER }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            val badge = UiKit.text(this, "⚪", 14f).apply { setPadding(dp(6), dp(4), dp(6), dp(4)) }
            fr.addView(badge, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))
            cell.addView(fr, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(150)))
            val name = UiKit.text(this, l.name, 13.5f, UiKit.TEXT, true).apply { setPadding(0, dp(6), 0, 0) }
            cell.addView(name)
            val lvl = UiKit.level(this)
            cell.addView(lvl, UiKit.full(this, lvl, 4, 6))
            val st = UiKit.text(this, "", 11f, UiKit.SUB)
            cell.addView(st)
            tiles[l.id] = Tile(img, name, st, lvl, badge)
            row!!.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i % 2 == 0) marginEnd = dp(8) })
        }
        if (links.size % 2 == 1) row?.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
    }
}
