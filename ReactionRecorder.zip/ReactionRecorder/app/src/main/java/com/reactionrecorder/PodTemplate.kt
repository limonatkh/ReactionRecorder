package com.reactionrecorder

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * قالب مونتاج: "كيف" بيظهر الفيديو (المونتاج التلقائي بيقرر "مين" و"إمتى").
 * المربع العائم، الشاشة المقسومة، الإطار المضيء، أسماء الأشخاص، الثابتين، الكتابة، والإيقاع.
 * الأماكن بإحداثيات الفيديو (يسار/يمين حقيقي، مش حسب لغة الواجهة).
 */
class PodTemplate {
    var id = "default"
    var name = tx("افتراضي", "Default")
    var builtIn = false
    /** episode = الحلقة الكاملة (بالعرض غالبًا)، reel = ريلز (بالطول) */
    var kind = "episode"

    // ── الإيقاع والقرارات (بتنسخ للمشروع لما تختار القالب)
    var intensity = "balanced"
    /** اللي بيقاطع أو بيرد رد قصير بمربع عائم (وإلا شاشة مقسومة) */
    var pip = true
    var fade = false
    var fadeMs = 300
    /** اتجاه الإخراج: auto = حسب الكاميرات، h، v، both */
    var orient = "auto"
    /** auto = الكاميرا بتلحق اللي بيحكي، grid = الكل ظاهر طول الوقت */
    var layout = "auto"
    /** كسر الملل: كل كم ثانية كلام متصل لشخص واحد بنعمل لقطة قصيرة (0 = مطفي) */
    var breakEvery = 0
    /** auto / listener (المستمع) / wide (الكاميرا العامة) / zoom (تقريب على نفس الشخص) */
    var breakTo = "auto"
    var breakLen = 2.5f
    /** الكاميرا العامة بعد صمت: 0 = حسب الإيقاع، -1 = أبدًا، غير هيك ثواني */
    var wideAfter = 0f

    // ── باقي إعدادات المونتاج (كلها بتتطبق على المشروع إلا اللي عدّلته بإيدك فيه)
    var style = "auto"
    var frame = "smart"
    var fill = "other"
    var flipFill = "freeze"
    var zoomMode = "off"
    var zoomMax = 1.12f
    var faces = false
    var silence = "off"
    var captions = false
    var highlight = true
    var titleOn = false

    // ── المربع العائم
    /** br, bl, tr, tl, custom */
    var pipPos = "br"
    var pipX = 0.80f
    var pipY = 0.78f
    /** fixed = نفس المكان دايمًا، person = حسب الشخص (الثاني بالجهة المقابلة)، alternate = بالتناوب يمين/يسار */
    var pipPlace = "fixed"
    /** عرض المربع كنسبة من عرض الفيديو (بالعرض؛ بالطول بيكبر تلقائيًا) */
    var pipSize = 0.28f
    /** rect, rounded, circle, alternate (مرة دائري ومرة زوايا دائرية) */
    var pipShape = "rounded"
    var pipRadius = 0.10f
    /** سماكة الإطار كنسبة من ارتفاع الفيديو (0 = بدون) */
    var pipBorder = 0.006f
    var pipBorderColor = 0xFFFFFFFF.toInt()
    var pipShadow = true
    /** cut, fade, slide, zoom */
    var pipAnim = "cut"
    var pipAnimMs = 250
    var pipMargin = 0.04f
    /** المربع العائم مقصوص على وجه الشخص (بتحليل الوجوه) */
    var pipFace = false
    var faceZoom = 1.6f
    /** square أو portrait */
    var faceAspect = "square"
    /** المربع ما بيغطي وجه اللي بيحكي: بينزاح عالجهة الثانية */
    var avoidFace = false

    // ── لما يحكوا مع بعض
    /** split أو boxes */
    var multi = "split"
    /** auto, side, stack */
    var splitDir = "auto"
    var gap = 0.004f
    var gapColor = 0xFF000000.toInt()
    var bgColor = 0xFF1B1D24.toInt()
    var boxRadius = 0.035f

    // ── اللي بيحكي
    var glow = false
    var glowColor = 0xFFFFD60A.toInt()
    var glowWidth = 0.018f

    // ── أسماء الأشخاص: never, first, switch
    var names = "never"
    /** bl, bc, br, tl, tr */
    var namePos = "bl"
    var nameColor = 0xFF3D8BFF.toInt()

    // ── الأشخاص الثابتين: tl, tr, bl, br
    var pinPos = "tl"
    var pinSize = 0.20f
    var pinShape = "rounded"

    // ── الكتابة على الفيديو: bottom, middle, top
    var capPos = "bottom"
    var capSize = 1f
    var capColor = 0xFFFFFFFF.toInt()

    fun copy(): PodTemplate = fromJson(toJson()).also { it.builtIn = false }

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("name", name).put("bi", builtIn).put("kind", kind)
        .put("lay", layout).put("brk", breakEvery).put("brkTo", breakTo).put("brkLen", breakLen.toDouble()).put("wa", wideAfter.toDouble())
        .put("style", style).put("frame", frame).put("fill", fill).put("flip", flipFill).put("zm", zoomMode).put("zx", zoomMax.toDouble())
        .put("faces", faces).put("sil", silence).put("cap", captions).put("hl", highlight).put("title", titleOn)
        .put("pFace", pipFace).put("fZoom", faceZoom.toDouble()).put("fAsp", faceAspect).put("avoid", avoidFace)
        .put("int", intensity).put("pip", pip).put("fade", fade).put("fadeMs", fadeMs).put("orient", orient)
        .put("pPos", pipPos).put("pX", pipX.toDouble()).put("pY", pipY.toDouble()).put("pPlace", pipPlace).put("pSize", pipSize.toDouble())
        .put("pShape", pipShape).put("pRad", pipRadius.toDouble()).put("pBord", pipBorder.toDouble()).put("pBordC", pipBorderColor)
        .put("pShadow", pipShadow).put("pAnim", pipAnim).put("pAnimMs", pipAnimMs).put("pMargin", pipMargin.toDouble())
        .put("multi", multi).put("sDir", splitDir).put("gap", gap.toDouble()).put("gapC", gapColor).put("bg", bgColor).put("boxR", boxRadius.toDouble())
        .put("glow", glow).put("glowC", glowColor).put("glowW", glowWidth.toDouble())
        .put("names", names).put("nPos", namePos).put("nC", nameColor)
        .put("pinPos", pinPos).put("pinSize", pinSize.toDouble()).put("pinShape", pinShape)
        .put("capPos", capPos).put("capSize", capSize.toDouble()).put("capC", capColor)

    companion object {
        fun fromJson(o: JSONObject): PodTemplate = PodTemplate().apply {
            id = o.optString("id", id); name = o.optString("name", name); builtIn = o.optBoolean("bi", false); kind = o.optString("kind", kind)
            layout = o.optString("lay", layout); breakEvery = o.optInt("brk", breakEvery); breakTo = o.optString("brkTo", breakTo)
            breakLen = o.optDouble("brkLen", breakLen.toDouble()).toFloat(); wideAfter = o.optDouble("wa", wideAfter.toDouble()).toFloat()
            style = o.optString("style", style); frame = o.optString("frame", frame); fill = o.optString("fill", fill); flipFill = o.optString("flip", flipFill)
            zoomMode = o.optString("zm", zoomMode); zoomMax = o.optDouble("zx", zoomMax.toDouble()).toFloat(); faces = o.optBoolean("faces", faces)
            silence = o.optString("sil", silence); captions = o.optBoolean("cap", captions); highlight = o.optBoolean("hl", highlight); titleOn = o.optBoolean("title", titleOn)
            pipFace = o.optBoolean("pFace", pipFace); faceZoom = o.optDouble("fZoom", faceZoom.toDouble()).toFloat()
            faceAspect = o.optString("fAsp", faceAspect); avoidFace = o.optBoolean("avoid", avoidFace)
            intensity = o.optString("int", intensity); pip = o.optBoolean("pip", pip); fade = o.optBoolean("fade", fade); fadeMs = o.optInt("fadeMs", fadeMs); orient = o.optString("orient", orient)
            pipPos = o.optString("pPos", pipPos); pipX = o.optDouble("pX", pipX.toDouble()).toFloat(); pipY = o.optDouble("pY", pipY.toDouble()).toFloat()
            pipPlace = o.optString("pPlace", pipPlace); pipSize = o.optDouble("pSize", pipSize.toDouble()).toFloat()
            pipShape = o.optString("pShape", pipShape); pipRadius = o.optDouble("pRad", pipRadius.toDouble()).toFloat()
            pipBorder = o.optDouble("pBord", pipBorder.toDouble()).toFloat(); pipBorderColor = o.optInt("pBordC", pipBorderColor)
            pipShadow = o.optBoolean("pShadow", pipShadow); pipAnim = o.optString("pAnim", pipAnim); pipAnimMs = o.optInt("pAnimMs", pipAnimMs)
            pipMargin = o.optDouble("pMargin", pipMargin.toDouble()).toFloat()
            multi = o.optString("multi", multi); splitDir = o.optString("sDir", splitDir); gap = o.optDouble("gap", gap.toDouble()).toFloat()
            gapColor = o.optInt("gapC", gapColor); bgColor = o.optInt("bg", bgColor); boxRadius = o.optDouble("boxR", boxRadius.toDouble()).toFloat()
            glow = o.optBoolean("glow", glow); glowColor = o.optInt("glowC", glowColor); glowWidth = o.optDouble("glowW", glowWidth.toDouble()).toFloat()
            names = o.optString("names", names); namePos = o.optString("nPos", namePos); nameColor = o.optInt("nC", nameColor)
            pinPos = o.optString("pinPos", pinPos); pinSize = o.optDouble("pinSize", pinSize.toDouble()).toFloat(); pinShape = o.optString("pinShape", pinShape)
            capPos = o.optString("capPos", capPos); capSize = o.optDouble("capSize", capSize.toDouble()).toFloat(); capColor = o.optInt("capC", capColor)
        }

        /** قوالب جاهزة (ما بتنحذف؛ بتقدر تعمل منها نسخة وتعدّلها) */
        fun builtIns(): List<PodTemplate> = listOf(
            PodTemplate().apply { id = "default"; name = tx("افتراضي", "Default"); builtIn = true },
            PodTemplate().apply {
                id = "bi_circle"; name = tx("دائري بالتناوب", "Alternating circles"); builtIn = true
                pipShape = "alternate"; pipPlace = "alternate"; pipAnim = "zoom"; glow = true; pipBorder = 0.008f; names = "first"
            },
            PodTemplate().apply {
                id = "bi_split"; name = tx("كلاسيكي مقسوم", "Classic split"); builtIn = true
                pip = false; intensity = "calm"; fade = true; gap = 0.008f; gapColor = 0xFF121316.toInt(); names = "switch"; namePos = "bc"
            },
            PodTemplate().apply {
                id = "bi_lively"; name = tx("حيوي مربعات", "Lively boxes"); builtIn = true
                intensity = "lively"; multi = "boxes"; pipPlace = "person"; pipAnim = "slide"; pipShape = "rounded"; pipRadius = 0.2f; glow = true; glowColor = 0xFF3D8BFF.toInt()
            },
            PodTemplate().apply {
                id = "bi_face"; name = tx("مربع على الوجه", "Face box"); builtIn = true
                pipFace = true; avoidFace = true; pipShape = "rounded"; pipRadius = 0.16f; faces = true; breakEvery = 40; breakTo = "auto"; names = "first"
            },
            // ── ريلز (بالطول)
            PodTemplate().apply {
                id = "reel_default"; kind = "reel"; name = tx("ريل افتراضي", "Default reel"); builtIn = true
                orient = "v"; intensity = "lively"; silence = "balanced"; zoomMode = "auto"; captions = true; titleOn = true; zoomMax = 1.15f
            },
            PodTemplate().apply {
                id = "reel_calm"; kind = "reel"; name = tx("ريل هادئ", "Calm reel"); builtIn = true
                orient = "v"; intensity = "calm"; silence = "light"; zoomMode = "auto"; zoomMax = 1.08f; captions = true; fade = true; pip = false
            },
            PodTemplate().apply {
                id = "reel_fast"; kind = "reel"; name = tx("ريل سريع (قصّات)", "Fast reel (cuts)"); builtIn = true
                orient = "v"; intensity = "lively"; silence = "intense"; zoomMode = "auto"; zoomMax = 1.2f; captions = true; titleOn = true
                breakEvery = 15; breakTo = "zoom"; breakLen = 2f; pipAnim = "zoom"
            },
            PodTemplate().apply {
                id = "reel_stack"; kind = "reel"; name = tx("حوار فوق وتحت", "Top & bottom talk"); builtIn = true
                orient = "v"; layout = "grid"; splitDir = "stack"; glow = true; gap = 0.006f; silence = "balanced"; captions = true; capPos = "middle"; names = "first"
            },
            PodTemplate().apply {
                id = "reel_clip"; kind = "reel"; name = tx("كليب بودكاست", "Podcast clip"); builtIn = true
                orient = "v"; intensity = "balanced"; silence = "balanced"; zoomMode = "auto"; captions = true; titleOn = true
                pipFace = true; avoidFace = true; faces = true; pipShape = "circle"; pipAnim = "zoom"; names = "first"; namePos = "bc"
            },
            PodTemplate().apply {
                id = "reel_debate"; kind = "reel"; name = tx("نقاش حامي", "Heated debate"); builtIn = true
                orient = "v"; intensity = "lively"; style = "debate"; silence = "intense"; zoomMode = "auto"; zoomMax = 1.2f; captions = true
                glow = true; glowColor = 0xFFFF453A.toInt(); multi = "split"; splitDir = "stack"
            },
        )

        /** شرح بالأرقام لشو بيصير تلقائيًا بهالإيقاع (من نفس قواعد المونتاج) */
        fun pacingInfo(t: PodTemplate, hasWide: Boolean = true): List<String> {
            if (t.layout == "grid") return listOf(tx("الكل ظاهر طول الوقت بشاشة مقسومة — ما في تبديل كاميرات.", "Everyone on screen all the time in a split — no camera switching."))
            val out = pacingInfo(t.intensity, t.pip, hasWide && t.wideAfter >= 0f, if (t.wideAfter > 0f) t.wideAfter.toDouble() else null).toMutableList()
            fun s(v: Float) = String.format(java.util.Locale.US, "%.1f", v).removeSuffix(".0")
            val i = out.indexOfFirst { it.startsWith(tx("كلام طويل", "Long cont")) }
            if (t.breakEvery > 0 && i >= 0) {
                val to = when (t.breakTo) {
                    "listener" -> tx("على المستمع", "to the listener")
                    "wide" -> tx("على الكاميرا العامة", "to the wide camera")
                    "zoom" -> tx("تقريب على نفس الشخص", "a punch-in on the same person")
                    else -> tx("بالتناوب: المستمع، العامة، تقريب", "alternating: listener, wide, punch-in")
                }
                out[i] = tx("كسر الملل: إذا حدا حكى أكثر من ${t.breakEvery} ث متواصل، بتصير لقطة قصيرة ${s(t.breakLen)} ث ($to) وبترجع عليه. بتتكرر كل ${t.breakEvery} ث.",
                    "Break monotony: when someone talks over ${t.breakEvery} s straight, a short ${s(t.breakLen)} s shot ($to), then back. Repeats every ${t.breakEvery} s.")
            }
            if (!hasWide) out += tx("ما في كاميرا عامة بهالتصوير — لإضافتها: بشاشة التصوير، قسم الأشخاص، علّم جهاز كـ\"الكاميرا العامة\".", "No wide camera in this shoot — add one in the recording screen, People section, mark a device as \"Wide camera\".")
            if (t.pipFace) out += tx("المربع العائم بيكون مقرّب على وجه الشخص (بيحلل الوجوه تلقائيًا وقت التصدير).", "The floating box is zoomed on the person's face (faces analyzed automatically at export).")
            if (t.avoidFace) out += tx("المربع ما بيغطي وجه اللي بيحكي: إذا كان مكانه فوق الوجه بينتقل للجهة الثانية.", "The box never covers the speaker's face: it moves to the other side if needed.")
            return out
        }

        fun pacingInfo(intensity: String, pip: Boolean, hasWide: Boolean = true, wideAfter: Double? = null): List<String> {
            val r = PodEngine.rules(intensity)
            fun s(v: Double) = String.format(java.util.Locale.US, "%.1f", v).removeSuffix(".0")
            val out = ArrayList<String>()
            out += tx("الكاميرا بتنتقل على اللي بيحكي لما ياخد الدور فعلًا، وبتنتقل قبل ما يبلّش بـ ${s(r.lead)} ث.", "The camera moves to whoever really takes the turn, ${s(r.lead)} s before they start.")
            out += tx("أقصر لقطة: ${s(r.minShot)} ث — أي لقطة أقصر بتندمج باللي قبلها (إلا المربع العائم).", "Shortest shot: ${s(r.minShot)} s — anything shorter merges into the previous one (except the floating box).")
            out += tx("الردود القصيرة جدًا (آه، صح — أقل من ١٫٢ ث) ما بتغيّر الكاميرا أبدًا.", "Very short replies (uh-huh, right — under 1.2 s) never switch the camera.")
            out += if (pip && r.pipMax > 0) tx("رد قصير لحد ${s(r.pipMax)} ث بيطلع بمربع عائم فوق اللي بيحكي، وإذا كمّل بيصير هو بملء الشاشة.", "A short reply up to ${s(r.pipMax)} s shows in a floating box; if they keep talking they go full screen.")
                else tx("الردود القصيرة ما بتطلع بمربع بهالإيقاع — الكاميرا بتضل على اللي بيحكي.", "Short replies don't get a box at this pace — the camera stays on the speaker.")
            out += if (pip) tx("لما اتنين يحكوا مع بعض أكثر من نص ثانية: اللي كان بيحكي بيضل بملء الشاشة واللي قاطعه بمربع عائم.", "When two talk together for over half a second: the speaker stays full screen and the interrupter gets a floating box.")
                else tx("لما اتنين يحكوا مع بعض ثانية أو أكثر: الشاشة بتنقسم.", "When two talk together for a second or more: the screen splits.")
            out += tx("نقاش سريع: إذا صار ${r.pingCount} تنقّلات أو أكثر خلال ${s(r.pingWin)} ث، بتصير لقطة مشتركة للكل بدل التنطيط.", "Fast exchange: ${r.pingCount}+ switches within ${s(r.pingWin)} s become one shared shot instead of bouncing.")
            if (hasWide) out += tx("الكاميرا العامة (اللي بتجيب الكل): بتطلع بعد صمت ${s(wideAfter ?: r.silenceToWide)} ث، وبتضل لحد ما حدا يحكي.", "The wide camera (everyone): appears after ${s(wideAfter ?: r.silenceToWide)} s of silence and stays until someone speaks.")
            out += tx("كلام طويل متصل: ما في تبديل بمؤقت — الكاميرا بتضل على اللي بيحكي طول ما هو بيحكي.", "Long continuous talk: no timer switching — the camera stays on the speaker as long as they talk.")
            if (r.reactions || intensity == "lively") out += tx("لقطات رد فعل: ١٫٣ ث على اللي علّق، بس بلقطات أطول من ١٠ ث، وبينها ٢٠ ث على الأقل.", "Reaction shots: 1.3 s on whoever reacted, only in shots over 10 s, at least 20 s apart.")
            return out
        }
    }
}

/** حفظ القوالب على الجوال + القالب الافتراضي */
object TemplateStore {
    private const val P = "reaction_tpl"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(P, Context.MODE_PRIVATE)

    fun user(ctx: Context): List<PodTemplate> = try {
        val a = JSONArray(prefs(ctx).getString("list", "[]"))
        List(a.length()) { PodTemplate.fromJson(a.getJSONObject(it)).also { t -> t.builtIn = false } }
    } catch (_: Throwable) { emptyList() }

    fun all(ctx: Context): List<PodTemplate> = PodTemplate.builtIns() + user(ctx)

    /** قوالب نوع معيّن، والافتراضي أولها */
    fun ofKind(ctx: Context, kind: String): List<PodTemplate> {
        val def = defaultId(ctx, kind)
        val l = all(ctx).filter { it.kind == kind }
        return l.filter { it.id == def } + l.filter { it.id != def }
    }

    fun get(ctx: Context, id: String?): PodTemplate? = all(ctx).firstOrNull { it.id == id }

    fun defaultId(ctx: Context, kind: String = "episode"): String =
        if (kind == "reel") prefs(ctx).getString("def_reel", "reel_default") ?: "reel_default"
        else prefs(ctx).getString("def", "default") ?: "default"

    fun setDefault(ctx: Context, id: String) {
        val k = get(ctx, id)?.kind ?: "episode"
        prefs(ctx).edit().putString(if (k == "reel") "def_reel" else "def", id).apply()
    }

    /** القالب المطلوب، وإلا الافتراضي */
    fun resolve(ctx: Context, id: String?, kind: String = "episode"): PodTemplate {
        val t = if (!id.isNullOrBlank()) get(ctx, id) else null
        if (t != null && t.kind == kind) return t
        return get(ctx, defaultId(ctx, kind)) ?: PodTemplate.builtIns().first { it.kind == kind }
    }

    fun kindOf(p: PodProject) = if (p.kind == PodProject.REEL) "reel" else "episode"

    fun save(ctx: Context, t: PodTemplate) {
        if (t.builtIn) return
        val l = user(ctx).toMutableList()
        val i = l.indexOfFirst { it.id == t.id }
        if (i >= 0) l[i] = t else l.add(t)
        write(ctx, l)
    }

    fun delete(ctx: Context, id: String) {
        write(ctx, user(ctx).filter { it.id != id })
        if (defaultId(ctx) == id) prefs(ctx).edit().putString("def", "default").apply()
        if (defaultId(ctx, "reel") == id) prefs(ctx).edit().putString("def_reel", "reel_default").apply()
    }

    fun newId() = "t" + System.currentTimeMillis().toString(36)

    private fun write(ctx: Context, l: List<PodTemplate>) {
        val a = JSONArray()
        for (t in l) a.put(t.toJson())
        prefs(ctx).edit().putString("list", a.toString()).apply()
    }

    /** مفاتيح الإعدادات اللي بتيجي من القالب (لو عدّلتها بالمشروع بتنحفظ بـ st.ov وما بيغيرها القالب) */
    val KEYS = listOf("intensity", "pip", "fade", "glow", "capSize", "orient", "layout", "brk", "wideAfter", "style", "frame", "fill",
        "flipFill", "zoomMode", "zoomMax", "faces", "silence", "captions", "highlight", "titleOn")
    /** هدول بيغيروا اللقطات (لازم إعادة توليد) */
    private val PACING = setOf("intensity", "pip", "layout", "brk", "wideAfter", "style", "silence", "zoomMode", "zoomMax")

    /** قيمة كل مفتاح بالقالب وبالمشروع (للمقارنة والنسخ) */
    private fun tplVal(t: PodTemplate, k: String): Any = when (k) {
        "intensity" -> t.intensity; "pip" -> t.pip; "fade" -> t.fade; "glow" -> t.glow; "capSize" -> t.capSize; "orient" -> t.orient
        "layout" -> t.layout; "brk" -> "${t.breakEvery}|${t.breakTo}|${t.breakLen}"; "wideAfter" -> t.wideAfter; "style" -> t.style
        "frame" -> t.frame; "fill" -> t.fill; "flipFill" -> t.flipFill; "zoomMode" -> t.zoomMode; "zoomMax" -> t.zoomMax; "faces" -> t.faces || t.pipFace || t.avoidFace
        "silence" -> t.silence; "captions" -> t.captions; "highlight" -> t.highlight; else -> t.titleOn
    }

    private fun stVal(st: ProjSettings, k: String): Any = when (k) {
        "intensity" -> st.intensity; "pip" -> st.pip; "fade" -> st.fade; "glow" -> st.glow; "capSize" -> st.capSize; "orient" -> st.orient
        "layout" -> st.layout; "brk" -> "${st.brk}|${st.brkTo}|${st.brkLen}"; "wideAfter" -> st.wideAfter; "style" -> st.style
        "frame" -> st.frame; "fill" -> st.fill; "flipFill" -> st.flipFill; "zoomMode" -> st.zoomMode; "zoomMax" -> st.zoomMax; "faces" -> st.faces
        "silence" -> st.silence; "captions" -> st.captions; "highlight" -> st.highlight; else -> st.titleOn
    }

    private fun put(t: PodTemplate, st: ProjSettings, k: String) {
        when (k) {
            "intensity" -> st.intensity = t.intensity; "pip" -> st.pip = t.pip; "fade" -> st.fade = t.fade; "glow" -> st.glow = t.glow
            "capSize" -> st.capSize = t.capSize; "orient" -> if (t.orient != "auto") st.orient = t.orient
            "layout" -> st.layout = t.layout; "brk" -> { st.brk = t.breakEvery; st.brkTo = t.breakTo; st.brkLen = t.breakLen }
            "wideAfter" -> st.wideAfter = t.wideAfter; "style" -> st.style = t.style; "frame" -> st.frame = t.frame; "fill" -> st.fill = t.fill
            "flipFill" -> st.flipFill = t.flipFill; "zoomMode" -> st.zoomMode = t.zoomMode; "zoomMax" -> st.zoomMax = t.zoomMax
            "faces" -> st.faces = t.faces || t.pipFace || t.avoidFace; "silence" -> st.silence = t.silence; "captions" -> st.captions = t.captions
            "highlight" -> st.highlight = t.highlight; "titleOn" -> st.titleOn = t.titleOn
        }
    }

    /**
     * يخلي المشروع مطابق للقالب (كل شي ما عدّلته بإيدك بهالمشروع).
     * بيرجع true إذا تغيّر إشي بيأثر على اللقطات (لازم إعادة توليد).
     */
    fun sync(t: PodTemplate, st: ProjSettings, episode: Boolean = t.kind == "episode"): Boolean {
        // مشاريع قديمة (قبل هالنظام): القالب كان بينسخ ٦ إعدادات بس — الباقي اللي بيختلف بنعتبره تعديلك
        if (st.sv < 1) {
            val old = setOf("intensity", "pip", "fade", "glow", "capSize", "orient")
            for (k in KEYS) if (k !in old && k !in st.ov && stVal(st, k) != tplVal(t, k)) st.ov.add(k)
            st.sv = 1
        }
        st.tpl = t.id
        var pacing = false
        for (k in KEYS) {
            if (k in st.ov) continue
            if (k == "silence" && episode && t.silence != "off" && t.silence != "gaps") continue
            if (k == "orient" && t.orient == "auto") continue
            if (stVal(st, k) == tplVal(t, k)) continue
            put(t, st, k)
            if (k in PACING) pacing = true
        }
        return pacing
    }

    /** بعد تعديل يدوي بالمشروع: أي إعداد من إعدادات القالب تغيّر بيصير "تعديلك" وما بيرجع يتغيّر مع القالب */
    fun trackOverrides(before: ProjSettings, after: ProjSettings) {
        if (after.applied) { after.applied = false; return }
        if (before.tpl != after.tpl) return
        for (k in KEYS) if (stVal(before, k) != stVal(after, k)) after.ov.add(k)
    }

    /** أسماء التعديلات (للعرض) */
    fun keyName(k: String): String = when (k) {
        "intensity" -> tx("الأسلوب", "Style"); "pip" -> tx("المربع العائم", "Floating box"); "fade" -> tx("الانتقالات", "Transitions")
        "glow" -> tx("الإطار المضيء", "Glow"); "capSize" -> tx("حجم الكتابة", "Caption size"); "orient" -> tx("الاتجاه", "Orientation")
        "layout" -> tx("التخطيط", "Layout"); "brk" -> tx("كسر الملل", "Break monotony"); "wideAfter" -> tx("الكاميرا العامة", "Wide camera")
        "style" -> tx("طبيعة الحوار", "Conversation type"); "frame" -> tx("الكادر", "Framing"); "fill" -> tx("غياب الفيديو", "Missing video")
        "flipFill" -> tx("قلب الكاميرا", "Camera flip"); "zoomMode" -> tx("الزوم", "Zoom"); "zoomMax" -> tx("أقصى زوم", "Max zoom")
        "faces" -> tx("تتبع الوجه", "Face tracking"); "silence" -> tx("قص الصمت", "Silence cuts"); "captions" -> tx("الكتابة", "Captions")
        "highlight" -> tx("تمييز الكلمات", "Highlight"); else -> tx("العنوان", "Title")
    }

    /** يطبّق القالب على مشروع من جديد (بيلغي تعديلاتك عالإعدادات اللي بتيجي من القالب) */
    fun applyTo(t: PodTemplate, st: ProjSettings, vertical: Boolean? = null) {
        st.ov.clear()
        st.sv = 1
        sync(t, st)
        st.applied = true
    }
}
