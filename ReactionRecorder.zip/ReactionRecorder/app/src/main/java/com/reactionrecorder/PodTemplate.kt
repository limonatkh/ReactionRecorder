package com.reactionrecorder

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * قالب مونتاج: "كيف" بيظهر الفيديو (المونتاج التلقائي بيقرر "مين" و"إمتى").
 * المربع العائم، الشاشة المقسومة، الإطار المضيء، أسماء الأشخاص، الثابتين، الكتابة، والإيقاع.
 * الأماكن بإحداثيات الفيديو (يسار/يمين حقيقي، مش حسب لغة الواجهة).
 */
class PodTemplate {
    var id = "default"
    var name = tx("افتراضي", "Default")
    var builtIn = false

    // ── الإيقاع والقرارات (بتنسخ للمشروع لما تختار القالب)
    var intensity = "balanced"
    /** اللي بيقاطع أو بيرد رد قصير بمربع عائم (وإلا شاشة مقسومة) */
    var pip = true
    var fade = false
    var fadeMs = 300
    /** اتجاه الإخراج: auto = حسب الكاميرات، h، v، both */
    var orient = "auto"

    // ── المربع العائم
    /** br, bl, tr, tl, custom */
    var pipPos = "br"
    var pipX = 0.80f
    var pipY = 0.78f
    /** fixed = نفس المكان دايمًا، person = حسب الشخص (الثاني بالجهة المقابلة)، alternate = بالتناوب يمين/يسار */
    var pipPlace = "fixed"
    /** عرض المربع كنسبة من عرض الفيديو (بالعرض؛ بالطول بيكبر تلقائيًا) */
    var pipSize = 0.28f
    /** rect, rounded, circle, alternate (مرة دائري ومرة زوايا دائرية) */
    var pipShape = "rounded"
    var pipRadius = 0.10f
    /** سماكة الإطار كنسبة من ارتفاع الفيديو (0 = بدون) */
    var pipBorder = 0.006f
    var pipBorderColor = 0xFFFFFFFF.toInt()
    var pipShadow = true
    /** cut, fade, slide, zoom */
    var pipAnim = "cut"
    var pipAnimMs = 250
    var pipMargin = 0.04f

    // ── لما يحكوا مع بعض
    /** split أو boxes */
    var multi = "split"
    /** auto, side, stack */
    var splitDir = "auto"
    var gap = 0.004f
    var gapColor = 0xFF000000.toInt()
    var bgColor = 0xFF1B1D24.toInt()
    var boxRadius = 0.035f

    // ── اللي بيحكي
    var glow = false
    var glowColor = 0xFFFFD60A.toInt()
    var glowWidth = 0.018f

    // ── أسماء الأشخاص: never, first, switch
    var names = "never"
    /** bl, bc, br, tl, tr */
    var namePos = "bl"
    var nameColor = 0xFF3D8BFF.toInt()

    // ── الأشخاص الثابتين: tl, tr, bl, br
    var pinPos = "tl"
    var pinSize = 0.20f
    var pinShape = "rounded"

    // ── الكتابة على الفيديو: bottom, middle, top
    var capPos = "bottom"
    var capSize = 1f
    var capColor = 0xFFFFFFFF.toInt()

    fun copy(): PodTemplate = fromJson(toJson()).also { it.builtIn = false }

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("name", name).put("bi", builtIn)
        .put("int", intensity).put("pip", pip).put("fade", fade).put("fadeMs", fadeMs).put("orient", orient)
        .put("pPos", pipPos).put("pX", pipX.toDouble()).put("pY", pipY.toDouble()).put("pPlace", pipPlace).put("pSize", pipSize.toDouble())
        .put("pShape", pipShape).put("pRad", pipRadius.toDouble()).put("pBord", pipBorder.toDouble()).put("pBordC", pipBorderColor)
        .put("pShadow", pipShadow).put("pAnim", pipAnim).put("pAnimMs", pipAnimMs).put("pMargin", pipMargin.toDouble())
        .put("multi", multi).put("sDir", splitDir).put("gap", gap.toDouble()).put("gapC", gapColor).put("bg", bgColor).put("boxR", boxRadius.toDouble())
        .put("glow", glow).put("glowC", glowColor).put("glowW", glowWidth.toDouble())
        .put("names", names).put("nPos", namePos).put("nC", nameColor)
        .put("pinPos", pinPos).put("pinSize", pinSize.toDouble()).put("pinShape", pinShape)
        .put("capPos", capPos).put("capSize", capSize.toDouble()).put("capC", capColor)

    companion object {
        fun fromJson(o: JSONObject): PodTemplate = PodTemplate().apply {
            id = o.optString("id", id); name = o.optString("name", name); builtIn = o.optBoolean("bi", false)
            intensity = o.optString("int", intensity); pip = o.optBoolean("pip", pip); fade = o.optBoolean("fade", fade); fadeMs = o.optInt("fadeMs", fadeMs); orient = o.optString("orient", orient)
            pipPos = o.optString("pPos", pipPos); pipX = o.optDouble("pX", pipX.toDouble()).toFloat(); pipY = o.optDouble("pY", pipY.toDouble()).toFloat()
            pipPlace = o.optString("pPlace", pipPlace); pipSize = o.optDouble("pSize", pipSize.toDouble()).toFloat()
            pipShape = o.optString("pShape", pipShape); pipRadius = o.optDouble("pRad", pipRadius.toDouble()).toFloat()
            pipBorder = o.optDouble("pBord", pipBorder.toDouble()).toFloat(); pipBorderColor = o.optInt("pBordC", pipBorderColor)
            pipShadow = o.optBoolean("pShadow", pipShadow); pipAnim = o.optString("pAnim", pipAnim); pipAnimMs = o.optInt("pAnimMs", pipAnimMs)
            pipMargin = o.optDouble("pMargin", pipMargin.toDouble()).toFloat()
            multi = o.optString("multi", multi); splitDir = o.optString("sDir", splitDir); gap = o.optDouble("gap", gap.toDouble()).toFloat()
            gapColor = o.optInt("gapC", gapColor); bgColor = o.optInt("bg", bgColor); boxRadius = o.optDouble("boxR", boxRadius.toDouble()).toFloat()
            glow = o.optBoolean("glow", glow); glowColor = o.optInt("glowC", glowColor); glowWidth = o.optDouble("glowW", glowWidth.toDouble()).toFloat()
            names = o.optString("names", names); namePos = o.optString("nPos", namePos); nameColor = o.optInt("nC", nameColor)
            pinPos = o.optString("pinPos", pinPos); pinSize = o.optDouble("pinSize", pinSize.toDouble()).toFloat(); pinShape = o.optString("pinShape", pinShape)
            capPos = o.optString("capPos", capPos); capSize = o.optDouble("capSize", capSize.toDouble()).toFloat(); capColor = o.optInt("capC", capColor)
        }

        /** قوالب جاهزة (ما بتنحذف؛ بتقدر تعمل منها نسخة وتعدّلها) */
        fun builtIns(): List<PodTemplate> = listOf(
            PodTemplate().apply { id = "default"; name = tx("افتراضي", "Default"); builtIn = true },
            PodTemplate().apply {
                id = "bi_circle"; name = tx("دائري بالتناوب", "Alternating circles"); builtIn = true
                pipShape = "alternate"; pipPlace = "alternate"; pipAnim = "zoom"; glow = true; pipBorder = 0.008f; names = "first"
            },
            PodTemplate().apply {
                id = "bi_split"; name = tx("كلاسيكي مقسوم", "Classic split"); builtIn = true
                pip = false; intensity = "calm"; fade = true; gap = 0.008f; gapColor = 0xFF121316.toInt(); names = "switch"; namePos = "bc"
            },
            PodTemplate().apply {
                id = "bi_lively"; name = tx("حيوي مربعات", "Lively boxes"); builtIn = true
                intensity = "lively"; multi = "boxes"; pipPlace = "person"; pipAnim = "slide"; pipShape = "rounded"; pipRadius = 0.2f; glow = true; glowColor = 0xFF3D8BFF.toInt()
            },
        )

        /** شرح بالأرقام لشو بيصير تلقائيًا بهالإيقاع (من نفس قواعد المونتاج) */
        fun pacingInfo(intensity: String, pip: Boolean, hasWide: Boolean = true): List<String> {
            val r = PodEngine.rules(intensity)
            fun s(v: Double) = String.format(java.util.Locale.US, "%.1f", v).removeSuffix(".0")
            val out = ArrayList<String>()
            out += tx("الكاميرا بتنتقل على اللي بيحكي لما ياخد الدور فعلًا، وبتنتقل قبل ما يبلّش بـ ${s(r.lead)} ث.", "The camera moves to whoever really takes the turn, ${s(r.lead)} s before they start.")
            out += tx("أقصر لقطة: ${s(r.minShot)} ث — أي لقطة أقصر بتندمج باللي قبلها (إلا المربع العائم).", "Shortest shot: ${s(r.minShot)} s — anything shorter merges into the previous one (except the floating box).")
            out += tx("الردود القصيرة جدًا (آه، صح — أقل من ١٫٢ ث) ما بتغيّر الكاميرا أبدًا.", "Very short replies (uh-huh, right — under 1.2 s) never switch the camera.")
            out += if (pip && r.pipMax > 0) tx("رد قصير لحد ${s(r.pipMax)} ث بيطلع بمربع عائم فوق اللي بيحكي، وإذا كمّل بيصير هو بملء الشاشة.", "A short reply up to ${s(r.pipMax)} s shows in a floating box; if they keep talking they go full screen.")
                else tx("الردود القصيرة ما بتطلع بمربع بهالإيقاع — الكاميرا بتضل على اللي بيحكي.", "Short replies don't get a box at this pace — the camera stays on the speaker.")
            out += if (pip) tx("لما اتنين يحكوا مع بعض أكثر من نص ثانية: اللي كان بيحكي بيضل بملء الشاشة واللي قاطعه بمربع عائم.", "When two talk together for over half a second: the speaker stays full screen and the interrupter gets a floating box.")
                else tx("لما اتنين يحكوا مع بعض ثانية أو أكثر: الشاشة بتنقسم.", "When two talk together for a second or more: the screen splits.")
            out += tx("نقاش سريع: إذا صار ${r.pingCount} تنقّلات أو أكثر خلال ${s(r.pingWin)} ث، بتصير لقطة مشتركة للكل بدل التنطيط.", "Fast exchange: ${r.pingCount}+ switches within ${s(r.pingWin)} s become one shared shot instead of bouncing.")
            if (hasWide) out += tx("الكاميرا العامة (اللي بتجيب الكل): بتطلع بعد صمت ${s(r.silenceToWide)} ث، وبتضل لحد ما حدا يحكي.", "The wide camera (everyone): appears after ${s(r.silenceToWide)} s of silence and stays until someone speaks.")
            out += tx("كلام طويل متصل: ما في تبديل بمؤقت — الكاميرا بتضل على اللي بيحكي طول ما هو بيحكي.", "Long continuous talk: no timer switching — the camera stays on the speaker as long as they talk.")
            if (r.reactions || intensity == "lively") out += tx("لقطات رد فعل: ١٫٣ ث على اللي علّق، بس بلقطات أطول من ١٠ ث، وبينها ٢٠ ث على الأقل.", "Reaction shots: 1.3 s on whoever reacted, only in shots over 10 s, at least 20 s apart.")
            return out
        }
    }
}

/** حفظ القوالب على الجوال + القالب الافتراضي */
object TemplateStore {
    private const val P = "reaction_tpl"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(P, Context.MODE_PRIVATE)

    fun user(ctx: Context): List<PodTemplate> = try {
        val a = JSONArray(prefs(ctx).getString("list", "[]"))
        List(a.length()) { PodTemplate.fromJson(a.getJSONObject(it)).also { t -> t.builtIn = false } }
    } catch (_: Throwable) { emptyList() }

    fun all(ctx: Context): List<PodTemplate> = PodTemplate.builtIns() + user(ctx)

    fun get(ctx: Context, id: String?): PodTemplate? = all(ctx).firstOrNull { it.id == id }

    fun defaultId(ctx: Context): String = prefs(ctx).getString("def", "default") ?: "default"

    fun setDefault(ctx: Context, id: String) { prefs(ctx).edit().putString("def", id).apply() }

    /** القالب المطلوب، وإلا الافتراضي */
    fun resolve(ctx: Context, id: String?): PodTemplate = (if (!id.isNullOrBlank()) get(ctx, id) else null) ?: get(ctx, defaultId(ctx)) ?: PodTemplate.builtIns()[0]

    fun save(ctx: Context, t: PodTemplate) {
        if (t.builtIn) return
        val l = user(ctx).toMutableList()
        val i = l.indexOfFirst { it.id == t.id }
        if (i >= 0) l[i] = t else l.add(t)
        write(ctx, l)
    }

    fun delete(ctx: Context, id: String) {
        write(ctx, user(ctx).filter { it.id != id })
        if (defaultId(ctx) == id) setDefault(ctx, "default")
    }

    fun newId() = "t" + System.currentTimeMillis().toString(36)

    private fun write(ctx: Context, l: List<PodTemplate>) {
        val a = JSONArray()
        for (t in l) a.put(t.toJson())
        prefs(ctx).edit().putString("list", a.toString()).apply()
    }

    /** يطبّق قرارات القالب على إعدادات مشروع */
    fun applyTo(t: PodTemplate, st: ProjSettings, vertical: Boolean? = null) {
        st.tpl = t.id
        st.intensity = t.intensity
        st.pip = t.pip
        st.fade = t.fade
        st.glow = t.glow
        st.capSize = t.capSize
        if (t.orient != "auto") st.orient = t.orient
    }
}
