package com.reactionrecorder

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

/** لغة الواجهة (عربي / English) — تُحفظ على الجوال وتُطبَّق على كل الشاشات */
object L {
    @Volatile var lang = "ar"
        private set
    private var loaded = false

    val ar: Boolean get() = lang == "ar"

    fun init(ctx: Context) {
        if (loaded) return
        lang = ctx.getSharedPreferences("reaction_ui", Context.MODE_PRIVATE).getString("lang", "ar") ?: "ar"
        loaded = true
    }

    fun set(ctx: Context, l: String) {
        lang = if (l == "en") "en" else "ar"
        loaded = true
        ctx.getSharedPreferences("reaction_ui", Context.MODE_PRIVATE).edit().putString("lang", lang).apply()
    }

    /** للاختبارات */
    fun setForTest(l: String) { lang = l; loaded = true }
}

/** نص بحسب لغة الواجهة */
fun tx(ar: String, en: String): String = if (L.ar) ar else en

/**
 * أساس كل الشاشات: يطبّق اللغة واتجاه الكتابة (يمين لليسار للعربي)، وانتقالات ناعمة بين الشاشات.
 */
open class BaseActivity : AppCompatActivity() {
    override fun attachBaseContext(base: Context) {
        L.init(base)
        val loc = Locale(L.lang)
        val c = Configuration(base.resources.configuration)
        c.setLocale(loc)
        c.setLayoutDirection(loc)
        super.attachBaseContext(base.createConfigurationContext(c))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = if (L.ar) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
    }

    override fun startActivity(intent: android.content.Intent?) {
        super.startActivity(intent)
        @Suppress("DEPRECATION")
        overridePendingTransition(R.anim.enter_fwd, R.anim.exit_fwd)
    }

    override fun finish() {
        super.finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(R.anim.enter_back, R.anim.exit_back)
    }
}

/** ألوان وعناصر موحدة لكل الشاشات (هادئة، واضحة، بلون واحد للفعل الرئيسي) */
object UiKit {
    const val BG = "#101114"
    const val CARD = "#1A1C22"
    const val CARD2 = "#22252D"
    const val TEXT = "#ECEEF2"
    const val SUB = "#9AA1AF"
    const val RED = "#FF3B30"
    const val GREEN = "#34C759"
    const val ORANGE = "#FF9F0A"
    const val BLUE = "#0A84FF"

    fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    fun bg(color: String, radiusDp: Int, ctx: Context, stroke: String? = null) = GradientDrawable().apply {
        cornerRadius = dp(ctx, radiusDp).toFloat()
        setColor(Color.parseColor(color))
        if (stroke != null) setStroke(dp(ctx, 1), Color.parseColor(stroke))
    }

    /** صفحة قابلة للتمرير بعمود رئيسي؛ تعيد العمود */
    fun page(a: Activity, title: String? = null, sub: String? = null, back: Boolean = true): LinearLayout {
        val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(a, 16), dp(a, 8), dp(a, 16), dp(a, 28)) }
        val sv = ScrollView(a).apply { setBackgroundColor(Color.parseColor(BG)); isFillViewport = true; addView(col) }
        a.setContentView(sv)
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(sv) { v, insets ->
            val b = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, b.top, 0, b.bottom); insets
        }
        if (title != null) col.addView(header(a, title, sub, back))
        return col
    }

    fun header(a: Activity, title: String, sub: String? = null, back: Boolean = true): View {
        val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(a, 6), 0, dp(a, 10)) }
        val row = LinearLayout(a).apply { gravity = Gravity.CENTER_VERTICAL }
        if (back) {
            row.addView(TextView(a).apply {
                text = if (L.ar) "→" else "←"; textSize = 22f; setTextColor(Color.parseColor(TEXT))
                setPadding(dp(a, 4), dp(a, 4), dp(a, 14), dp(a, 4))
                contentDescription = tx("رجوع", "Back")
                setOnClickListener { a.finish() }
            })
        }
        row.addView(TextView(a).apply { text = title; textSize = 21f; setTextColor(Color.parseColor(TEXT)); typeface = Typeface.DEFAULT_BOLD },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        box.addView(row)
        if (!sub.isNullOrBlank()) box.addView(text(a, sub, 13f, SUB).apply { setPadding(0, dp(a, 4), 0, 0) })
        return box
    }

    fun text(ctx: Context, s: String, size: Float = 14f, color: String = TEXT, bold: Boolean = false) = TextView(ctx).apply {
        text = s; textSize = size; setTextColor(Color.parseColor(color))
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setLineSpacing(0f, 1.15f)
    }

    /** بطاقة بعنوان (اختياري) */
    fun card(ctx: Context, title: String? = null, parent: LinearLayout? = null): LinearLayout {
        val c = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(ctx, 14), dp(ctx, 12), dp(ctx, 14), dp(ctx, 12))
            background = bg(CARD, 16, ctx)
        }
        if (title != null) c.addView(text(ctx, title, 15f, TEXT, true).apply { setPadding(0, 0, 0, dp(ctx, 6)) })
        parent?.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(ctx, 10) })
        return c
    }

    /**
     * قسم قابل للطي: العنوان دائمًا ظاهر (مع ملخص صغير)، والمحتوى يظهر عند الضغط.
     * يعيد صندوق المحتوى. حالة الفتح تُحفظ باسم key.
     */
    fun section(ctx: Context, parent: LinearLayout, key: String, title: String, summary: String = "", openByDefault: Boolean = false): LinearLayout {
        val prefs = ctx.getSharedPreferences("reaction_ui", Context.MODE_PRIVATE)
        var open = prefs.getBoolean("sec_$key", openByDefault)
        val c = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; background = bg(CARD, 16, ctx) }
        val head = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(ctx, 14), dp(ctx, 13), dp(ctx, 14), dp(ctx, 13)) }
        val titles = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(text(ctx, title, 15f, TEXT, true))
        val sumTv = text(ctx, summary, 12f, SUB).apply { visibility = if (summary.isBlank()) View.GONE else View.VISIBLE }
        titles.addView(sumTv)
        head.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val arrow = text(ctx, if (open) "▴" else "▾", 18f, SUB)
        head.addView(arrow)
        val body = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(ctx, 14), 0, dp(ctx, 14), dp(ctx, 14))
            visibility = if (open) View.VISIBLE else View.GONE
            tag = sumTv
        }
        head.setOnClickListener {
            open = !open
            prefs.edit().putBoolean("sec_$key", open).apply()
            arrow.text = if (open) "▴" else "▾"
            body.visibility = if (open) View.VISIBLE else View.GONE
            if (open) body.startAnimation(AlphaAnimation(0f, 1f).apply { duration = 180; interpolator = DecelerateInterpolator() })
        }
        c.addView(head)
        c.addView(body)
        parent.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(ctx, 10) })
        return body
    }

    /** يغيّر ملخص قسم أنشأه section() */
    fun setSummary(body: LinearLayout, s: String) {
        (body.tag as? TextView)?.let { it.text = s; it.visibility = if (s.isBlank()) View.GONE else View.VISIBLE }
    }

    /** زر كبسولة؛ sel = مختار (أحمر) */
    fun chip(ctx: Context, label: String, sel: Boolean = false, run: () -> Unit): Button = Button(ctx).apply {
        text = label; isAllCaps = false; textSize = 13f
        minWidth = 0; minimumWidth = 0; minHeight = dp(ctx, 40); minimumHeight = dp(ctx, 40)
        setPadding(dp(ctx, 12), 0, dp(ctx, 12), 0)
        stateListAnimator = null
        style(this, sel)
        setOnClickListener { run() }
    }

    fun style(b: Button, sel: Boolean) {
        b.setTextColor(Color.WHITE)
        b.background = bg(if (sel) RED else CARD2, 20, b.context)
    }

    /** زر الفعل الرئيسي (عريض) */
    fun primary(ctx: Context, label: String, color: String = RED, run: () -> Unit): Button = Button(ctx).apply {
        text = label; isAllCaps = false; textSize = 16f; typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE); stateListAnimator = null
        background = bg(color, 24, ctx)
        setOnClickListener { run() }
    }

    fun row(ctx: Context, vararg v: View): LinearLayout = LinearLayout(ctx).apply {
        gravity = Gravity.CENTER_VERTICAL
        for ((i, x) in v.withIndex()) addView(x, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            if (i < v.size - 1) marginEnd = dp(ctx, 6)
            topMargin = dp(ctx, 4); bottomMargin = dp(ctx, 4)
        })
    }

    fun full(ctx: Context, v: View, topDp: Int = 8, hDp: Int = ViewGroup.LayoutParams.WRAP_CONTENT): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, if (hDp > 0) dp(ctx, hDp) else hDp).apply { topMargin = dp(ctx, topDp) }

    /** شريط مستوى رفيع */
    fun level(ctx: Context): ProgressBar = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }

    /** بطاقة كبيرة للشاشة الرئيسية: أيقونة + عنوان + وصف */
    fun bigCard(ctx: Context, icon: String, title: String, desc: String, accent: String, run: () -> Unit): LinearLayout =
        LinearLayout(ctx).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(ctx, 16), dp(ctx, 18), dp(ctx, 16), dp(ctx, 18))
            background = bg(CARD, 20, ctx)
            isClickable = true
            setOnClickListener { run() }
            addView(TextView(ctx).apply {
                text = icon; textSize = 26f; gravity = Gravity.CENTER
                background = bg(accent, 16, ctx)
            }, LinearLayout.LayoutParams(dp(ctx, 54), dp(ctx, 54)))
            val tcol = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(ctx, 14), 0, dp(ctx, 4), 0) }
            tcol.addView(text(ctx, title, 17f, TEXT, true))
            tcol.addView(text(ctx, desc, 12.5f, SUB).apply { setPadding(0, dp(ctx, 3), 0, 0) })
            addView(tcol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(text(ctx, if (L.ar) "‹" else "›", 22f, SUB))
        }

    /** نقطة حالة ملونة + نص */
    fun badge(ctx: Context, s: String, color: String): TextView = TextView(ctx).apply {
        text = s; textSize = 12f; setTextColor(Color.parseColor(color))
        setPadding(dp(ctx, 10), dp(ctx, 4), dp(ctx, 10), dp(ctx, 4))
        background = bg(CARD2, 12, ctx)
    }
}
