package com.reactionrecorder

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.Locale
import kotlin.math.max

/**
 * مسار "ريلز من الحوار": اقتراحات (حسب المعنى إن وُجد فهم للنص، وإلا من بنية الحوار)، إنشاء ريل يدوي،
 * وقائمة الريلز المحفوظة — لكل ريل مشروعه وإعداداته المستقلة عن الحلقة الكاملة.
 */
class PodcastShortsActivity : AppCompatActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var sid: String
    private var d: PodStudio.Data? = null
    private var target = 45.0
    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private lateinit var reelsBox: LinearLayout
    private lateinit var sugBox: LinearLayout
    private lateinit var optBox: LinearLayout
    private var lastDone = -1

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun fmt(t: Double): String { val s = max(0.0, t).toLong(); return "${s / 60}:${String.format(Locale.US, "%02d", s % 60)}" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        sid = intent.getStringExtra("session") ?: run { finish(); return }
        build()
        load()
        ui.post(tick)
    }

    override fun onResume() {
        super.onResume()
        if (d != null) renderReels()
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacks(tick)
    }

    private fun txt(t: String, size: Float = 13f, color: String = "#E6E8EE") = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.parseColor(color)); setPadding(0, dp(6), 0, dp(2))
    }

    private fun btn(label: String, sel: Boolean = false, run: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; setTextColor(Color.WHITE); textSize = 12f; minWidth = 0; minimumWidth = 0
        background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(Color.parseColor(if (sel) "#FF3B30" else "#2A2D36")) }
        setOnClickListener { run() }
    }

    private fun rowOf(vararg v: View) = LinearLayout(this).apply {
        for (x in v) addView(x, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
    }

    private fun cardView(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(10), dp(8), dp(10), dp(8))
        background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(Color.parseColor("#1B1D24")) }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) }
    }

    private fun build() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(24)) }
        val sv = ScrollView(this).apply { setBackgroundColor(Color.parseColor("#101114")); addView(col) }
        setContentView(sv)
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(sv) { v, insets ->
            val b = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, b.top, 0, b.bottom); insets
        }
        col.addView(txt("📱 ريلز من الحوار", 20f))
        status = txt("جارٍ التحميل…", 13f, "#FFD60A")
        col.addView(status)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        col.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(6)))
        col.addView(txt("ريلزك", 16f))
        reelsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(reelsBox)
        col.addView(rowOf(btn("✚ ريل يدوي") { manualReel() }))
        col.addView(txt("اقتراحات", 16f))
        optBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(optBox)
        sugBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(sugBox)
    }

    private fun load() {
        Thread {
            val dd = PodStudio.load(this, sid, { pr -> ui.post { status.text = "تحليل من يتكلم… ${(pr * 100).toInt()}%"; bar.progress = (pr * 100).toInt() } }, { isFinishing })
            ui.post {
                if (dd == null) { status.text = if (isFinishing) "" else "تعذر فتح الجلسة"; return@post }
                d = dd
                bar.progress = 100
                status.text = "مدة الحلقة ${fmt(dd.duration)}" + (if (dd.tr == null) " • بدون نص" else " • ${dd.tr.segs.size} جملة مفرّغة") +
                    (if (dd.sem != null) " • مفهومة المعنى" else "")
                renderReels()
                renderOpts()
                renderSuggestions()
            }
        }.start()
    }

    private fun renderReels() {
        val dd = d ?: return
        reelsBox.removeAllViews()
        val reels = ProjectStore.reels(this, sid)
        if (reels.isEmpty()) reelsBox.addView(txt("لا يوجد ريلز بعد — أنشئ من الاقتراحات أو يدويًا", 12f, "#AAB0BD"))
        for (r in reels) {
            val c = cardView()
            val out = PodStudio.keepSegs(dd, r).sumOf { it[1] - it[0] }
            c.addView(txt("${r.title.ifBlank { "ريل" }}  •  ${fmt(r.a)}→${fmt(r.end(dd.duration))}  •  بعد القص ${fmt(out)}", 14f))
            c.addView(rowOf(
                btn("✎ افتح", true) { open(r.id) },
                btn("⧉ نسخة") {
                    val cp = PodProject.fromJson(r.toJson().put("id", ProjectStore.newReelId()))
                    cp.title = r.title + " (نسخة)"
                    ProjectStore.save(this, sid, cp); renderReels()
                },
                btn("🗑") {
                    AlertDialog.Builder(this).setMessage("حذف مشروع هذا الريل؟ (الحلقة والتسجيل لا يتأثران)")
                        .setPositiveButton("حذف") { _, _ -> ProjectStore.delete(this, sid, r.id); renderReels() }.setNegativeButton("إلغاء", null).show()
                },
            ))
            reelsBox.addView(c)
        }
    }

    private fun renderOpts() {
        val dd = d ?: return
        optBox.removeAllViews()
        optBox.addView(txt("المدة المستهدفة (مرنة — لا يُقطع المعنى لأجلها)", 12f, "#AAB0BD"))
        optBox.addView(rowOf(*listOf(15.0, 30.0, 45.0, 60.0, 90.0).map { v -> btn("${v.toInt()}ث", target == v) { target = v; renderOpts(); renderSuggestions() } }.toTypedArray()))
        if (dd.tr == null) {
            optBox.addView(txt("الاقتراحات الآن من بنية الحوار فقط (سؤال وجوابه، كلام متصل يبدأ وينتهي عند وقفة، تبادل سريع). لاقتراحات حسب المعنى مع عناوين: فرّغ الكلام ثم افهم الحوار (خدمة خارجية اختيارية).", 11f, "#AAB0BD"))
            optBox.addView(rowOf(btn("🤖 الخدمة") { PodUi.aiDialog(this) }, btn("📝 فرّغ الكلام") { confirm(PodcastExportService.ACTION_TRANSCRIBE) }))
        } else if (dd.sem == null) {
            optBox.addView(txt("يوجد نص. افهم الحوار لاقتراحات بفكرة مكتملة وعنوان وسبب.", 11f, "#AAB0BD"))
            optBox.addView(rowOf(btn("🧠 افهم الحوار", true) { confirm(PodcastExportService.ACTION_SEMANTIC) }))
        } else {
            optBox.addView(rowOf(btn("🧠 أعد فهم الحوار") { confirm(PodcastExportService.ACTION_SEMANTIC) }))
        }
    }

    private fun renderSuggestions() {
        val dd = d ?: return
        sugBox.removeAllViews()
        val ai = dd.sem?.ideas.orEmpty()
        val local = PodEngine.suggestReels(dd.an, dd.names, dd.markers, target, 6)
        val list = if (ai.isNotEmpty()) ai.sortedBy { kotlin.math.abs((it.b - it.a) - target) }.take(8) else local
        if (ai.isNotEmpty()) sugBox.addView(txt("من فهم النص (${ai.size} فكرة)", 12f, "#7CFC9A"))
        else sugBox.addView(txt("من بنية الحوار — تقدير بدون فهم المعنى", 12f, "#FFB86B"))
        if (list.isEmpty()) sugBox.addView(txt("لا اقتراحات مناسبة لهذه المدة — جرّب مدة أخرى أو أنشئ ريلًا يدويًا", 12f, "#AAB0BD"))
        for (s in list) {
            val c = cardView()
            c.addView(txt("${s.title.ifBlank { "مقطع" }}", 15f))
            c.addView(txt("${fmt(s.a)} → ${fmt(s.b)}  •  ${(s.b - s.a).toInt()} ث", 12f, "#AAB0BD"))
            if (s.reason.isNotBlank()) c.addView(txt("لماذا: ${s.reason}", 12f))
            val stars = dd.markers.filter { it.t in s.a..s.b }
            if (stars.isNotEmpty()) c.addView(txt(stars.joinToString(" ") { if (it.kind == "star") "⭐ ${fmt(it.t)}" else "✖ ${fmt(it.t)}" }, 11f, "#FFD60A"))
            val text = dd.tr?.textIn(s.a, s.b)
            if (!text.isNullOrBlank()) c.addView(txt("«${text.take(220)}${if (text.length > 220) "…" else ""}»", 12f, "#CED4DA"))
            c.addView(rowOf(
                btn("✚ أنشئ ريل وافتحه", true) { create(s.a, s.b, s.title.ifBlank { "ريل ${fmt(s.a)}" }, s.reason) },
                btn("📖 النص كامل") { AlertDialog.Builder(this).setMessage(text ?: "لا يوجد نص").setPositiveButton("إغلاق", null).show() },
            ))
            sugBox.addView(c)
        }
    }

    private fun create(a: Double, b: Double, title: String, reason: String) {
        val dd = d ?: return
        Thread {
            val p = PodStudio.newReel(dd, a, b, title, reason, target.toFloat())
            ProjectStore.save(this, sid, p)
            ui.post { renderReels(); open(p.id) }
        }.start()
    }

    private fun manualReel() {
        val dd = d ?: return
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        val s0 = EditText(this).apply { hint = "البداية مثل 12:30"; setSingleLine() }
        val s1 = EditText(this).apply { hint = "النهاية مثل 13:20"; setSingleLine() }
        col.addView(s0); col.addView(s1)
        fun parse(x: String): Double? {
            val p = x.trim().split(':')
            return try { if (p.size >= 2) p[0].toDouble() * 60 + p[1].toDouble() else p[0].toDouble() } catch (_: Throwable) { null }
        }
        AlertDialog.Builder(this).setTitle("ريل يدوي").setView(col)
            .setPositiveButton("أنشئ") { _, _ ->
                val a = parse(s0.text.toString()); val b = parse(s1.text.toString())
                if (a == null || b == null || b - a < 3 || a < 0 || a >= dd.duration) { toast("وقت غير صحيح"); return@setPositiveButton }
                create(a, b, "ريل ${fmt(a)}", "اختيار يدوي")
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun open(id: String) = startActivity(Intent(this, PodcastEditActivity::class.java).putExtra("session", sid).putExtra("project", id))

    private fun confirm(action: String) {
        if (!PodAI.cfg(this).ok) { PodUi.aiDialog(this); return }
        val c = PodAI.cfg(this)
        val msg = if (action == PodcastExportService.ACTION_TRANSCRIBE) "سيُرفع صوت الحلقة (مخلوط، بدون فيديو) إلى ${c.base} للتفريغ بنموذج ${c.stt}. قد تُحتسب تكلفة على حسابك."
        else "سيُرسل النص المفرّغ فقط (بدون صوت) إلى ${c.base} لفهم الحوار واقتراح أفكار."
        AlertDialog.Builder(this).setTitle("موافقة على الإرسال").setMessage(msg)
            .setPositiveButton("موافق") { _, _ ->
                if (PodState.running) { toast("هناك عمل آخر قيد التنفيذ"); return@setPositiveButton }
                ContextCompat.startForegroundService(this, Intent(this, PodcastExportService::class.java).setAction(action).putExtra("session", sid).putExtra("target", target))
            }.setNegativeButton("إلغاء", null).show()
    }

    private val tick = object : Runnable {
        override fun run() {
            val mine = PodState.sid == sid
            if (PodState.running && mine) {
                status.text = "${PodState.stage} ${(PodState.progress * 100).toInt()}%"
                bar.progress = (PodState.progress * 100).toInt()
            } else if (mine && PodState.doneSeq != lastDone) {
                val first = lastDone == -1
                lastDone = PodState.doneSeq
                if (!first) {
                    status.text = PodState.error?.let { "⚠ $it" } ?: ("✓ " + (PodState.info ?: "تم"))
                    if (PodState.error == null) load()
                }
            } else if (lastDone == -1) lastDone = PodState.doneSeq
            ui.postDelayed(this, 500)
        }
    }
}
