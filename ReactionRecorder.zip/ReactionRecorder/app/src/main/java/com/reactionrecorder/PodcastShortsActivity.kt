package com.reactionrecorder

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/**
 * شورتس/ريلز من حلقة البودكاست: اقتراح لحظات حيوية، تعديل البداية والنهاية، ثم تصدير طولي 9:16
 * بمونتاج سريع وقص السكتات بين الكلمات.
 */
class PodcastShortsActivity : AppCompatActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var sid: String
    private var session: SessionInfo? = null
    private var setup = PodSetup()
    private var an: PodAnalysis? = null
    private val clips = ArrayList<DoubleArray>() // [بداية، نهاية، تقييم]
    private var len = 45.0
    private var cut = true
    private var gap = 0.3f
    private var fastPace = true
    private var vertical = true
    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private lateinit var optsBox: LinearLayout
    private lateinit var listBox: LinearLayout
    private lateinit var resultBox: LinearLayout
    private val thumbs = HashMap<String, Bitmap?>()
    private var lastResult: String? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sid = intent.getStringExtra("session") ?: run { finish(); return }
        build()
        load()
        ui.post(tick)
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacks(tick)
    }

    private fun txt(t: String, size: Float = 13f, color: String = "#E6E8EE") = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.parseColor(color)); setPadding(0, dp(6), 0, dp(2))
    }

    private fun btn(label: String, sel: Boolean = false, run: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; setTextColor(Color.WHITE); textSize = 12f; minWidth = 0; minimumWidth = 0
        background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(Color.parseColor(if (sel) "#FF3B30" else "#2A2D36")) }
        setOnClickListener { run() }
    }

    private fun rowOf(vararg v: View) = LinearLayout(this).apply {
        for (x in v) addView(x, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, 0, dp(4), 0) })
    }

    private fun fmt(t: Double): String { val s = t.toLong(); return "${s / 60}:${String.format(Locale.US, "%02d", s % 60)}" }

    private fun build() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(24)) }
        val sv = ScrollView(this).apply { setBackgroundColor(Color.parseColor("#101114")); addView(col) }
        setContentView(sv)
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(sv) { v, insets ->
            val b = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, b.top, 0, b.bottom); insets
        }
        col.addView(txt("📱 Shorts / Reels", 20f))
        col.addView(txt("Suggested moments are picked from how lively the talk is (many turns, overlaps, little silence). Adjust them or add your own, then export.", 12f, "#AAB0BD"))
        status = txt("Loading…", 13f, "#FFD60A")
        col.addView(status)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        col.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8)))
        optsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(optsBox)
        resultBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(resultBox)
        col.addView(rowOf(
            btn("✨ Suggest moments", true) { suggest() },
            btn("➕ Add my own clip") { addManual() },
        ))
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(listBox)
    }

    private fun buildOpts() {
        optsBox.removeAllViews()
        optsBox.addView(txt("Clip length", 14f))
        optsBox.addView(rowOf(*listOf(15.0, 30.0, 45.0, 60.0, 90.0).map { v -> btn("${v.toInt()}s", len == v) { len = v; buildOpts() } }.toTypedArray()))
        optsBox.addView(CheckBox(this).apply {
            text = "Cut silences between words"; setTextColor(Color.WHITE); isChecked = cut
            setOnCheckedChangeListener { _, on -> cut = on; buildOpts() }
        })
        if (cut) optsBox.addView(rowOf(*listOf(0.2f to "Tight", 0.3f to "Normal", 0.5f to "Light").map { (g, n) -> btn(n, gap == g) { gap = g; buildOpts() } }.toTypedArray()))
        optsBox.addView(rowOf(
            btn("⚡ Fast edit", fastPace) { fastPace = true; buildOpts() },
            btn("Use my edit", !fastPace) { fastPace = false; buildOpts() },
        ))
        optsBox.addView(rowOf(
            btn("9:16 vertical", vertical) { vertical = true; buildOpts() },
            btn("16:9", !vertical) { vertical = false; buildOpts() },
        ))
    }

    private fun load() {
        Thread {
            val s = SessionStore.load(this, sid)
            if (s == null) { ui.post { status.text = "Session not found" }; return@Thread }
            session = s
            setup = PodcastAnalyzer.setupOf(s)
            val a = PodcastAnalyzer.loadAnalysis(this, sid)
                ?: PodcastAnalyzer.analyze(this, s, setup, { p -> ui.post { status.text = "Listening to who is talking… ${(p * 100).toInt()}%" } }, { isFinishing })
                    .also { if (!isFinishing) PodcastAnalyzer.saveAnalysis(this, sid, it) }
            if (isFinishing) return@Thread
            an = a
            val saved = loadClips()
            ui.post {
                gap = setup.silenceGap.coerceIn(0.2f, 0.5f)
                buildOpts()
                if (saved.isNotEmpty()) { clips.addAll(saved); renderList() } else suggest()
                status.text = "Episode length ${fmt(a.duration)}"
            }
        }.start()
    }

    private fun clipsFile() = File(SessionStore.dir(this, sid), "pod_shorts.json")

    private fun loadClips(): List<DoubleArray> = try {
        val f = clipsFile()
        if (!f.exists()) emptyList() else {
            val a = JSONArray(f.readText())
            List(a.length()) { i -> val o = a.getJSONObject(i); doubleArrayOf(o.optDouble("s"), o.optDouble("e"), o.optDouble("sc", 0.0)) }
        }
    } catch (_: Throwable) { emptyList() }

    private fun saveClips() {
        val a = JSONArray()
        for (c in clips) a.put(JSONObject().put("s", c[0]).put("e", c[1]).put("sc", c[2]))
        try { clipsFile().writeText(a.toString()) } catch (_: Throwable) {}
    }

    private fun suggest() {
        val a = an ?: return
        clips.clear()
        clips.addAll(PodcastAnalyzer.highlights(a, len, 6))
        clips.sortBy { it[0] }
        saveClips()
        renderList()
        if (clips.isEmpty()) toast("No suggestions — the episode may be too short")
    }

    private fun addManual() {
        val a = an ?: return
        val et = EditText(this).apply { hint = "start, e.g. 12:30"; inputType = InputType.TYPE_CLASS_TEXT; setSingleLine() }
        AlertDialog.Builder(this).setTitle("Clip start (minutes:seconds)").setView(et)
            .setPositiveButton("Add") { _, _ ->
                val p = et.text.toString().trim().split(':')
                val sec = try { if (p.size >= 2) p[0].toDouble() * 60 + p[1].toDouble() else p[0].toDouble() } catch (_: Throwable) { -1.0 }
                if (sec < 0 || sec >= a.duration) { toast("Invalid time"); return@setPositiveButton }
                clips.add(doubleArrayOf(sec, min(a.duration, sec + len), 0.0))
                clips.sortBy { it[0] }
                saveClips(); renderList()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun renderList() {
        listBox.removeAllViews()
        val a = an ?: return
        for ((i, c) in clips.withIndex()) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(8), dp(10), dp(8))
                background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(Color.parseColor("#1B1D24")) }
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) }
            }
            val head = LinearLayout(this)
            val iv = ImageView(this).apply { setBackgroundColor(Color.BLACK); scaleType = ImageView.ScaleType.CENTER_CROP }
            head.addView(iv, LinearLayout.LayoutParams(dp(72), dp(96)))
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
            info.addView(txt("Clip ${i + 1}:  ${fmt(c[0])} → ${fmt(c[1])}  (${(c[1] - c[0]).toInt()}s)", 14f))
            if (c[2] > 0) info.addView(txt("Liveliness " + "★".repeat(max(1, (c[2] * 5).toInt())), 12f, "#FFD60A"))
            info.addView(txt(whoTalks(a, c[0], c[1]), 11f, "#AAB0BD"))
            head.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            card.addView(head)
            card.addView(rowOf(
                btn("◀ 5s") { shift(i, -5.0) },
                btn("5s ▶") { shift(i, 5.0) },
                btn("− 5s") { resize(i, -5.0) },
                btn("+ 5s") { resize(i, 5.0) },
            ))
            card.addView(rowOf(
                btn("⬆ Export", true) { export(c) },
                btn("🗑") { clips.removeAt(i); saveClips(); renderList() },
            ))
            listBox.addView(card)
            loadThumb(iv, c)
        }
    }

    private fun whoTalks(a: PodAnalysis, s: Double, e: Double): String {
        val f0 = (s / a.frameSec).toInt().coerceAtLeast(0)
        val f1 = (e / a.frameSec).toInt().coerceAtMost(a.frames)
        val parts = setup.people.indices.mapNotNull { p ->
            val row = a.active.getOrNull(p) ?: return@mapNotNull null
            var n = 0
            for (f in f0 until f1) if (row[f]) n++
            if (n == 0) null else "${setup.people[p].name} ${(n * 100 / max(1, f1 - f0))}%"
        }
        return if (parts.isEmpty()) "Mostly silence" else "Talking: " + parts.joinToString(", ")
    }

    private fun shift(i: Int, d: Double) {
        val a = an ?: return
        val c = clips[i]
        val l = c[1] - c[0]
        c[0] = (c[0] + d).coerceIn(0.0, max(0.0, a.duration - l))
        c[1] = c[0] + l
        saveClips(); renderList()
    }

    private fun resize(i: Int, d: Double) {
        val a = an ?: return
        val c = clips[i]
        c[1] = (c[1] + d).coerceIn(c[0] + 5.0, min(a.duration, c[0] + 180.0))
        saveClips(); renderList()
    }

    private fun loadThumb(iv: ImageView, c: DoubleArray) {
        val a = an ?: return
        val s = session ?: return
        // الشخص الأكثر كلامًا في المقطع
        val f0 = (c[0] / a.frameSec).toInt().coerceAtLeast(0)
        val f1 = (c[1] / a.frameSec).toInt().coerceAtMost(a.frames)
        var best = 0
        var bestN = -1
        for (p in setup.people.indices) {
            val row = a.active.getOrNull(p) ?: continue
            var n = 0
            for (f in f0 until f1) if (row[f]) n++
            if (n > bestN && setup.people[p].camDev.isNotEmpty()) { bestN = n; best = p }
        }
        val dev = setup.people.getOrNull(best)?.camDev ?: return
        if (dev.isEmpty()) return
        val key = "$dev:${c[0].toInt()}"
        if (thumbs.containsKey(key)) { iv.setImageBitmap(thumbs[key]); return }
        Thread {
            val bmp = try {
                val dd = SessionStore.devDir(this, sid, dev)
                val vm = JSONObject(File(dd, "meta.json").readText()).optJSONObject("video")
                val dv = s.devices[dev]
                if (vm == null || dv == null) null else {
                    val mid = (c[0] + c[1]) / 2
                    val ms = Finalizer.SatVideoTime(s, dv, vm.optLong("startBoot")).fileMs((mid * 1e9).toLong())
                    val r = MediaMetadataRetriever()
                    try {
                        r.setDataSource(File(dd, "video.mp4").absolutePath)
                        r.getScaledFrameAtTime((ms * 1000).toLong().coerceAtLeast(0L), MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 240, 240)
                    } finally { r.release() }
                }
            } catch (_: Throwable) { null }
            ui.post { thumbs[key] = bmp; iv.setImageBitmap(bmp) }
        }.start()
    }

    private fun export(c: DoubleArray) {
        if (PodState.running) { toast("An export is already running — wait for it to finish"); return }
        lastResult = null
        ContextCompat.startForegroundService(
            this,
            Intent(this, PodcastExportService::class.java).setAction(PodcastExportService.ACTION_EXPORT).putExtra("session", sid)
                .putExtra("orient", if (vertical) "v" else "h").putExtra("start", c[0]).putExtra("end", c[1])
                .putExtra("cut", cut).putExtra("gap", gap).putExtra("pace", if (fastPace) "fast" else "edit")
                .putExtra("label", "_short_" + c[0].toInt()),
        )
        toast("Exporting the clip…")
    }

    private val tick = object : Runnable {
        override fun run() {
            val mine = PodState.sid == sid
            if (PodState.running && mine) {
                bar.visibility = View.VISIBLE
                bar.progress = (PodState.progress * 100).toInt()
                status.text = "${PodState.stage} ${(PodState.progress * 100).toInt()}%"
            } else {
                bar.visibility = View.GONE
                if (mine && (PodState.results.isNotEmpty() || PodState.error != null)) {
                    val key = PodState.results.joinToString() + (PodState.error ?: "")
                    if (key != lastResult) {
                        lastResult = key
                        PodUi.results(this@PodcastShortsActivity, resultBox)
                        an?.let { status.text = "Episode length ${fmt(it.duration)}" }
                    }
                }
            }
            ui.postDelayed(this, 400)
        }
    }
}
