package com.reactionrecorder

import kotlin.math.max
import kotlin.math.min

/**
 * منهج المونتاج — محرّك واحد، قوانين ثابتة، وخيارات قليلة (كلها بالقالب ← الإيقاع):
 *
 * ١. كل لحظة (كل عُشر ثانية) بنحسب لكل شخص: قديش حكى بآخر W ثواني (W ≈ ١٫٦ × سرعة التقليب).
 *    • واحد حكيه أكثر من النص والباقي قليل → «الدور معه»: الكاميرا عليه.
 *    • اثنين على كاميرات مختلفة كل واحد ≥ ٣٥٪ → «بيحكوا مع بعض» (مقاطعة متبادلة، نقاش، تبادل سريع).
 *    • ولا حدا (أقل من ١٢٪) → «سكوت»: الكاميرا بتضل مكانها (أو العامة إذا السكوت طويل وفي كاميرا عامة).
 * ٢. التعليقات القصيرة (آه، صح، ضحكة) ما بتوصل للنسبة، فما بتقلب الكاميرا أبدًا.
 *    (اختياري: بتطلع بمربع عائم صغير فوق اللي ماسك الدور.)
 * ٣. القطع بيصير على بداية كلام الشخص الجديد (مش بعد ما نتأكد)، وأقل لقطة حسب السرعة.
 * ٤. الكاميرا هي الوحدة: شخصين على نفس الكاميرا → تبادل الدور بينهم ما بيقلب.
 * ٥. لما يحكوا مع بعض: يا بتضل على اللي كان، يا الاثنين مع بعض (تقسيم — بس للكاميرتين اللي بيحكوا)،
 *    يا الكاميرا العامة إذا موجودة.
 * ٦. كسر الملل (اختياري): بالكلام الطويل لقطة ٢٫٥ ث على المستمع كل N ثانية.
 * ٧. أول ظهور لكل كاميرا ببداية الفيديو بيطوّل (عشان الاسم ينقرا).
 */
object PodPlan {
    class Cfg(
        /** calm / balanced / lively */
        val pace: String = "balanced",
        /** stay / both / wide */
        val together: String = "stay",
        /** التعليقات القصيرة بمربع عائم */
        val commentBox: Boolean = false,
        /** كسر الملل كل كم ثانية (0 = مطفي) */
        val breakEvery: Int = 0,
        val breakLen: Double = 2.5,
        val firstHold: Double = 0.0,
    ) {
        val take: Double get() = when (pace) { "calm" -> 1.8; "lively" -> 0.8; else -> 1.2 }
        val minShot: Double get() = when (pace) { "calm" -> 2.5; "lively" -> 1.2; else -> 1.8 }
        val window: Double get() = (take * 1.6).coerceIn(1.2, 4.0)

        companion object {
            fun of(st: ProjSettings) = Cfg(
                pace = st.intensity,
                together = when (st.overlap) { "both", "split" -> "both"; "wide" -> "wide"; else -> "stay" },
                commentBox = st.pip,
                breakEvery = st.brk,
                breakLen = st.brkLen.toDouble(),
                firstHold = st.firstHold.toDouble(),
            )
        }
    }

    /** وصف شو بيعمل كل خيار (للشاشات): قانون واحد لكل خيار */
    private const val DT = 0.1

    /**
     * @param camOf لكل شخص: رقم كاميرته (أشخاص على نفس الجهاز = نفس الرقم)، أو -1 إذا ما إله كاميرا
     * @param hasWide في كاميرا عامة؟
     */
    fun plan(an: PodAnalysis, camOf: IntArray, hasWide: Boolean, cfg: Cfg, a: Double, b: Double): MutableList<PodShot> {
        val n = min(camOf.size, an.active.size)
        val out = ArrayList<PodShot>()
        if (b - a <= 0.05 || n == 0) return out
        val fs = an.frameSec
        // مجموع تراكمي لنشاط كل شخص (عشان «قديش حكى بآخر W ثانية» يكون سريع)
        val pre = Array(n) { p ->
            val row = an.active[p]
            IntArray(row.size + 1).also { c -> for (i in row.indices) c[i + 1] = c[i] + if (row[i]) 1 else 0 }
        }
        fun talk(p: Int, t0: Double, t1: Double): Double {
            val c = pre[p]
            val i0 = (t0 / fs).toInt().coerceIn(0, c.size - 1); val i1 = (t1 / fs).toInt().coerceIn(0, c.size - 1)
            return if (i1 <= i0) 0.0 else (c[i1] - c[i0]) * fs
        }
        fun activeAt(p: Int, t: Double): Boolean { val r = an.active[p]; val i = (t / fs).toInt(); return i in r.indices && r[i] }
        /** بداية كلام p المتصل لحد t (فراغات أقل من ٠٫٤ث ما بتقطع) */
        fun turnStart(p: Int, t: Double): Double {
            var x = t; var gap = 0.0
            while (x > a) {
                if (activeAt(p, x)) gap = 0.0 else { gap += fs; if (gap > 0.4) return x + gap }
                x -= fs
            }
            return a
        }
        val withCam = (0 until n).filter { camOf[it] >= 0 }
        if (withCam.isEmpty()) return out

        // ── شو المفروض يطلع بكل لحظة
        class View(val type: Int, val main: Int, val others: IntArray) {
            fun same(o: View) = type == o.type && (if (type == PodShot.FULL) camOf[main] == camOf[o.main] else if (type == PodShot.MULTI) others.map { camOf[it] }.toSet() == o.others.map { camOf[it] }.toSet() else true)
        }
        val W = cfg.window
        var cur: View? = null
        var curStart = a
        var cand: View? = null
        var candSince = a
        var silentSince = -1.0
        var t = a
        while (t < b) {
            val shares = withCam.associateWith { talk(it, max(a, t - W), t) / max(DT, min(W, t - a + DT)) }
            val ranked = withCam.sortedByDescending { shares[it] ?: 0.0 }
            val d = ranked[0]; val sd = shares[d] ?: 0.0
            // التاني الأقوى على كاميرا ثانية
            val q = ranked.drop(1).firstOrNull { camOf[it] != camOf[d] }
            val sq = q?.let { shares[it] } ?: 0.0
            var want: View? = null
            if (sd < 0.12) {
                if (silentSince < 0) silentSince = t
                if (hasWide && t - silentSince > 4.0) want = View(PodShot.WIDE, 0, IntArray(0))
            } else {
                silentSince = -1.0
                want = if (q != null && sq >= 0.35 && sd >= 0.35) {
                    when {
                        cfg.together == "wide" && hasWide -> View(PodShot.WIDE, 0, IntArray(0))
                        cfg.together == "both" || cfg.together == "wide" -> View(PodShot.MULTI, min(d, q), intArrayOf(d, q).sortedBy { camOf[it] }.toIntArray())
                        // بتضل على اللي كان (إذا اللي كان واحد منهم)، وإلا على الأقوى
                        else -> cur?.takeIf { it.type == PodShot.FULL && (camOf[it.main] == camOf[d] || camOf[it.main] == camOf[q]) } ?: View(PodShot.FULL, d, IntArray(0))
                    }
                } else View(PodShot.FULL, d, IntArray(0))
            }
            if (cur == null) {
                cur = want ?: View(PodShot.FULL, d, IntArray(0)); curStart = a
            } else if (want != null && !want.same(cur)) {
                if (cand == null || !cand.same(want)) { cand = want; candSince = t }
                // تأكدنا (ربع W) ومرّت أقل لقطة → قطع
                if (t - candSince >= W * 0.25 && t - curStart >= cfg.minShot) {
                    var cut = if (want.type == PodShot.FULL) turnStart(want.main, t) - 0.15 else candSince - W * 0.3
                    cut = cut.coerceIn(curStart + cfg.minShot, t)
                    out.add(PodShot(curStart, cut, cur.type, cur.main, cur.others.copyOf()))
                    cur = want; curStart = cut; cand = null
                }
            } else cand = null
            t += DT
        }
        out.add(PodShot(curStart, b, cur!!.type, cur.main, cur.others.copyOf()))
        var res: MutableList<PodShot> = merge(out)

        // ── التعليقات القصيرة بمربع عائم (اختياري)
        if (cfg.commentBox && withCam.map { camOf[it] }.distinct().size >= 2) {
            val tops = ArrayList<PodShot>()
            val ts = PodEngine.turns(an, n)
            for (tn in ts) {
                if (camOf.getOrElse(tn.p) { -1 } < 0 || tn.dur < 0.35 || tn.dur >= cfg.take) continue
                if (tn.a < a + 3.0 || tn.b > b) continue
                val host = res.firstOrNull { (tn.a + tn.b) / 2 >= it.start && (tn.a + tn.b) / 2 < it.end } ?: continue
                if (host.type != PodShot.FULL || camOf[host.main] == camOf[tn.p]) continue
                val s0 = max(host.start, tn.a - 0.1); val s1 = min(host.end, tn.b + 1.0)
                if (s1 - s0 < 0.8) continue
                if (tops.lastOrNull()?.let { s0 < it.end + 1.0 } == true) continue
                tops.add(PodShot(s0, s1, PodShot.PIP, host.main, intArrayOf(tn.p)).also { it.tag = "short" })
            }
            if (tops.isNotEmpty()) res = PodEngine.overlay(res, tops)
        }
        // ── كسر الملل (اختياري): لقطة على المستمع بالكلام الطويل
        if (cfg.breakEvery > 0) {
            val tops = ArrayList<PodShot>()
            for (sh in res) {
                if (sh.type != PodShot.FULL || sh.dur < cfg.breakEvery * 1.3) continue
                val listener = withCam.firstOrNull { camOf[it] != camOf[sh.main] } ?: continue
                var x = sh.start + cfg.breakEvery
                while (x + cfg.breakLen < sh.end - cfg.minShot) {
                    tops.add(PodShot(x, x + cfg.breakLen, PodShot.FULL, listener, IntArray(0)).also { it.tag = "break" })
                    x += cfg.breakEvery + cfg.breakLen
                }
            }
            if (tops.isNotEmpty()) res = PodEngine.overlay(res, tops)
        }
        // ── أول ظهور ببداية الفيديو
        if (cfg.firstHold > 0) res = PodEngine.firstHold(res, cfg.firstHold)
        return PodEngine.tidy(merge(res))
    }

    /** لقطات ورا بعض لنفس الكاميرا (حتى لو شخص ثاني على نفس الكاميرا) = لقطة وحدة */
    private fun merge(list: List<PodShot>): MutableList<PodShot> {
        val res = ArrayList<PodShot>()
        for (x in list.sortedBy { it.start }) {
            if (x.end - x.start <= 1e-4) continue
            val l = res.lastOrNull()
            if (l != null && l.same(x) && l.tag == x.tag && kotlin.math.abs(l.end - x.start) < 1e-3) { l.end = x.end; continue }
            res.add(x.copy())
        }
        return res
    }

    /** رقم الكاميرا لكل شخص من الإعداد (نفس الجهاز = نفس الرقم) */
    fun camOf(setup: PodSetup, hasCam: (Int) -> Boolean): IntArray {
        val devs = ArrayList<String>()
        return IntArray(setup.people.size) { i ->
            val dev = setup.people[i].camDev
            if (dev.isEmpty() || !hasCam(i)) -1 else { var k = devs.indexOf(dev); if (k < 0) { devs.add(dev); k = devs.size - 1 }; k }
        }
    }
}
