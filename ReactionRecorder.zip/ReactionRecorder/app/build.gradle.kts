plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.reactionrecorder"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.reactionrecorder"
        // 29 = أول إصدار يدعم AudioPlaybackCapture (التقاط صوت التطبيقات الأخرى)
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // التوقيع بمفتاح debug كي يكون الـ APK قابلًا للتثبيت مباشرة
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = false
    }
}

val cameraxVersion = "1.3.4"

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.camera:camera-core:$cameraxVersion")
    implementation("androidx.camera:camera-camera2:$cameraxVersion")
    implementation("androidx.camera:camera-lifecycle:$cameraxVersion")
    implementation("androidx.camera:camera-view:$cameraxVersion")
    // الكاميرا تعمل داخل Foreground Service كي تستمر أثناء وجود المستخدم في تطبيق آخر
    implementation("androidx.lifecycle:lifecycle-service:2.8.4")
}
