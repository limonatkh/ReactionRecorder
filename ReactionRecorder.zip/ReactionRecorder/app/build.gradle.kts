plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.reactionrecorder"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.reactionrecorder"
        // 29 = أول إصدار يدعم AudioPlaybackCapture (التقاط صوت التطبيقات الأخرى)
        minSdk = 29
        targetSdk = 34
        versionCode = 37
        versionName = "3.7.1"
        // الجوالات الحقيقية فقط (ARM): يحذف مكتبات المحاكيات x86 ويصغّر الحجم كثيرًا
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }

    // ضغط المكتبات الأصلية داخل الـ APK (تنزيل أصغر بكثير)
    packaging {
        jniLibs { useLegacyPackaging = true }
    }

    // مفتاح توقيع ثابت داخل المشروع: كل بناء جديد يثبَّت فوق القديم دون حذف
    signingConfigs {
        create("fixed") {
            storeFile = file("rr-debug.keystore")
            storePassword = "android"
            keyAlias = "rrkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("fixed")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixed")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    testOptions {
        unitTests.isReturnDefaultValues = true
    }
    androidResources {
        noCompress += "tflite"
    }
    buildFeatures {
        viewBinding = false
    }
}

val cameraxVersion = "1.3.4"

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    // قفل صاحب التطبيق بالبصمة (أو قفل الشاشة)
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("androidx.camera:camera-core:$cameraxVersion")
    implementation("androidx.camera:camera-camera2:$cameraxVersion")
    implementation("androidx.camera:camera-lifecycle:$cameraxVersion")
    implementation("androidx.camera:camera-view:$cameraxVersion")
    // الكاميرا تعمل داخل Foreground Service كي تستمر أثناء وجود المستخدم في تطبيق آخر
    implementation("androidx.lifecycle:lifecycle-service:2.8.4")
    // مشغّل الفيديو الداخلي (وضع Video file)
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.4.1")
    // عزل الشخص تلقائيًا (نموذج مدمج، يعمل بدون إنترنت)
    implementation("com.google.mlkit:segmentation-selfie:16.0.0-beta6")
    // باركود الاقتران: توليد (ZXing) وقراءة (ML Kit مدمج، بدون إنترنت)
    implementation("com.google.zxing:core:3.5.3")
    implementation("com.google.mlkit:barcode-scanning:17.3.0")
    // تتبع الوجه (اختياري) لتأطير الريلز والزوم
    implementation("com.google.mlkit:face-detection:16.1.7")
    // تمييز الأصوات (كلام / سعال / عطس / ضحك / دق) — YAMNet على الجهاز بدون إنترنت
    implementation("com.google.mediapipe:tasks-audio:0.10.14")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
}
