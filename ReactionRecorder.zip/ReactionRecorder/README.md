# Reaction Recorder — تسجيل Reaction / Commentary بدون مونتاج

تطبيق Android (Kotlin) لـ Samsung Galaxy M13: يسجّل **شاشة الهاتف (فيديو المصدر) + الكاميرا + الميكروفون + صوت الفيديو** ويدمجها **أثناء التسجيل** في ملف `Reaction_YYYY-MM-DD_HH-mm-ss.mp4` جاهز للنشر، يُحفظ في `Movies/ReactionRecorder/` ويظهر مباشرة في Gallery.

> **حالة الكود:** كُتب بالكامل لكنه **لم يُترجَم ولم يُختبر على جهاز** (بيئة العمل التي كتبته فيها لا تصل إلى Android SDK/Maven). عند أول بناء قد تظهر أخطاء ترجمة بسيطة — أرسلها لي وأصلحها فورًا. أما الاختبار الفعلي على M13 فلا بدّ منه (انظر آخر الملف).

---

## كيف تحصل على الـ APK (الأسهل أولًا)

### الطريقة 1 — GitHub Actions (بدون تثبيت أي شيء)
1. أنشئ مستودعًا خاصًا على GitHub وارفع محتوى هذا المجلد كما هو (يتضمن `.github/workflows/build-apk.yml`).
2. افتح تبويب **Actions → Build APK → Run workflow**.
3. بعد دقائق نزّل الـ artifact باسم `ReactionRecorder-apk` وفيه `app-release.apk` (موقَّع بمفتاح debug، قابل للتثبيت مباشرة).

### الطريقة 2 — Android Studio
1. افتح المجلد بـ Android Studio (Koala أو أحدث) وانتظر Gradle Sync.
2. **Build → Build Bundle(s)/APK(s) → Build APK(s)**، أو من الطرفية: `gradle :app:assembleDebug`.
3. الملف: `app/build/outputs/apk/debug/app-debug.apk`.

### التثبيت على M13
انسخ الـ APK للهاتف → افتحه → اسمح بالتثبيت من "مصادر غير معروفة" لتطبيق الملفات.

---

## تحليل القيود التقنية (ما يسمح به Android وما لا يسمح)

| السؤال | الجواب |
|---|---|
| هل يمكن التقاط **إطارات YouTube** مباشرة بدل تسجيل الشاشة؟ | **لا.** YouTube يعمل في عملية أخرى، ومخرجات فك الترميز لا تُكشف لتطبيق آخر (وبعضها محمي بـ DRM/`FLAG_SECURE`). لا يوجد API رسمي لذلك، ولم أستعمل أي التفاف. |
| إذن ما الحل؟ | **MediaProjection الرسمي**، لكن بمسار مُحسَّن: الشاشة تُرسَم مباشرة داخل `SurfaceTexture` (GPU) → Shader → المُرمِّز. **لا Bitmap، لا ByteBuffer على الـ CPU، ولا ملف شاشة وسيط**. التقاط الشاشة نفسه يُقلَّص إلى ≤1920px للضلع الطويل لتخفيف الحمل. |
| صوت الفيديو؟ | `AudioPlaybackCapture` (رسمي من Android 10). التطبيقات التي تمنع الالتقاط (أو المحتوى المحمي) تعطي صمتًا — هذا قيد من النظام ولا نتجاوزه. الحالة تظهر في التطبيق. |
| الصدى؟ | الميكروفون يلتقط السماعة. **السماعات الخارجية هي الحل الأفضل.** خيار Echo suppression يستخدم `VOICE_COMMUNICATION` + AEC/NS إن وُجدا. |
| أزرار عائمة فوق YouTube؟ | تحتاج صلاحية `SYSTEM_ALERT_WINDOW` فلم أطلبها. التحكم أثناء التسجيل من **إشعار التسجيل**: Stop / Pause / Mute. |
| Android 14+ | يطلب موافقة الالتقاط في كل جلسة؛ اختر **Entire screen** (وليس تطبيقًا واحدًا) كي يظهر YouTube. |

## Architecture

```
CameraX Preview ──► SurfaceTexture(OES) ─┐
                                          ├─► GL ES 2.0 Compositor ─► EGL window = MediaCodec input Surface ─► H.264/H.265
MediaProjection ──► SurfaceTexture(OES) ─┘     (crop/fit، دائرة/مدوّر/إطار داخل الـ Shader)                         │
                                                                                                                      ▼
Mic ─► AudioRecord ──┐                                                                                          MuxerHolder ─► MediaStore
Source audio (AudioPlaybackCapture) ┴► Mixer (gain/mute/clip) ─► AAC-LC ────────────────────────────────────────────┘
```

- **ساعة واحدة:** كل الـ PTS من `System.nanoTime()`؛ الصوت يُؤرَّخ بعدّ العيّنات مع تصحيح للأمام عند أي فجوة، والإيقاف المؤقت يُطرح من المسارين.
- **معدل إطارات ثابت:** الرسم بإيقاع fps ثابت حتى لو كانت الشاشة ثابتة.
- **الكاميرا والتسجيل داخل Foreground Service** (`mediaProjection|camera|microphone`) كي يستمر التسجيل وأنت داخل YouTube.
- **أمان الملف:** الـ Muxer لا يبدأ إلا بعد وصول كل المسارات (العيّنات المبكرة تُخزَّن)، والحفظ عبر `MediaStore (IS_PENDING)`، ومراقبة المساحة كل 5 ثوانٍ مع إيقاف آمن إذا امتلأ التخزين.

## الإعدادات الافتراضية لـ M13
9:16 • 1080×1920 • 30fps • H.264 • CBR ≈ 8 Mbps • كاميرا 720p. يتحقق التطبيق من قدرات المُرمِّز: إن لم يدعم الدقة/الـ FPS ينزل تلقائيًا ويُعلمك. 60fps خيار موجود لكنه موسوم ⚠.

## الميزات في الـ MVP
- Layouts جاهزة: Video+Cam (زاوية)، 70/30، Side by Side، Top/Bottom، Cam Full — مع **Custom** (اسحب/غيّر حجم كل من مربع الكاميرا ومربع الفيديو، وقرصة بإصبعين لتكبير الكاميرا) ومزلاج نسبة الفيديو للـ Presets المقسومة.
- شكل الكاميرا: Rectangle / Rounded / Circle + سمك الإطار + نصف القطر — **مدموجة في الناتج النهائي** (داخل الـ Shader) وليست Overlay.
- Portrait 9:16 و Landscape 16:9، تدوير الشاشة أثناء التسجيل مدعوم (تُعاد تهيئة حجم الالتقاط).
- كاميرا أمامية/خلفية، Mirror، دقة الكاميرا، Zoom، Exposure، Torch (تبديل الكاميرا أثناء التسجيل مُتاح).
- Mic/Source ON/OFF وVolume لكل منهما، Mute أثناء التسجيل، Pause/Resume.
- Countdown (Off/3/5/10)، عرض المساحة المتاحة والوقت المقدَّر وتحذير قبل التسجيل.
- شاشة النتيجة: Play / Share / Save / Delete.

## ما لم أنفّذه عمدًا (للاستقرار)
تركيز الكاميرا اليدوي (التركيز التلقائي المستمر يعمل)، اختيار FPS للكاميرا (يُترك للجهاز = 30)، أزرار عائمة، تسجيل بدون MediaProjection. أي ميزة قد تخاطر بتلف الملف أُجّلت.

## اختبارات مهمة على الجهاز (بالترتيب)
1. تسجيل 30 ثانية بلا صوت المصدر → هل الفيديو يُفتح وكل الأجزاء ظاهرة؟
2. تسجيل مع YouTube وسماعات → هل يظهر صوت الفيديو وصوتك؟ هل المزامنة جيدة؟
3. تسجيل 10 دقائق → راقب الحرارة وإسقاط الإطارات.
4. Pause/Resume، تدوير الهاتف، تبديل الكاميرا.
5. أرسل لي أي سلوك غريب ومعه وصفه وسأعدّل الكود.

## What's new (v1.1)

- **Two sources**: 📱 Screen (MediaProjection, e.g. to react to YouTube) or 🎞 Video file (plays a video from your phone, or a direct https link, *inside* the app — no screen capture; shown live while recording).
- YouTube links are refused in Video-file mode (no access to protected streams). Use Screen mode for those.
- **Source: Fit / Fill / Stretch** chip. Screen mode defaults to Fill (no black bars), Video mode to Fit.
- Camera orientation fix in the recorded output (auto-detect). If it is still sideways: Settings → "Camera rotation fix".
- Video mode settings: stop when the video ends, video audio delay (sync). Use headphones.
- The APK is now signed with a fixed key (`app/rr-debug.keystore`). **Uninstall the previous build once**; later updates install over it.
