package com.reactionrecorder

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private lateinit var cfg: RecordConfig
    private lateinit var editor: LayoutEditorView
    private lateinit var infoText: TextView
    private lateinit var statusText: TextView
    private lateinit var noteText: TextView
    private lateinit var recBtn: TextView
    private lateinit var flipChip: TextView
    private lateinit var pauseChip: TextView
    private lateinit var presetRow: LinearLayout
    private lateinit var quickRow: LinearLayout
    private lateinit var ratioRow: LinearLayout
    private lateinit var ratioLabel: TextView
    private lateinit var ratioSeek: SeekBar
    private val presetChips = ArrayList<TextView>()
    private lateinit var orientChip: TextView
    private lateinit var resChip: TextView
    private lateinit var fpsChip: TextView
    private lateinit var micChip: TextView
    private lateinit var srcChip: TextView
    private lateinit var shapeChip: TextView
    private lateinit var fitChip: TextView
    private lateinit var modeScreenChip: TextView
    private lateinit var modeVideoChip: TextView
    private lateinit var pickChip: TextView
    private lateinit var listChip: TextView
    private lateinit var linkChip: TextView
    private lateinit var modeRow: LinearLayout

    // اللوحة الحيّة أثناء التسجيل
    private lateinit var liveBox: LinearLayout
    private lateinit var transportScroll: View
    private lateinit var seekRow: LinearLayout
    private lateinit var seekBar: SeekBar
    private lateinit var timeText: TextView
    private lateinit var endedRow: LinearLayout
    private lateinit var endedText: TextView
    private lateinit var nextBtn: TextView
    private lateinit var playChip: TextView
    private lateinit var loopChip: TextView
    private lateinit var standbyChip: TextView
    private lateinit var camChip: TextView
    private lateinit var gestureChip: TextView
    private lateinit var fullChip: TextView
    private lateinit var fitLiveChip: TextView
    private lateinit var micLiveChip: TextView
    private lateinit var srcLiveChip: TextView
    private lateinit var allMuteChip: TextView
    private lateinit var silentChip: TextView
    private var seeking = false
    private var importAutoStandby = false
    private var standbyLabelView: TextView? = null
    private var videoThumb: android.graphics.Bitmap? = null
    private var videoAspect = 16f / 9f

    private val ui = Handler(Looper.getMainLooper())
    private var camera: Camera? = null
    private var wasBusy = false
    private val stateListener: () -> Unit = { onStateChanged() }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
        if (hasCamera()) bindPreview()
    }
    private val pickMultiLauncher = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        onFilesPicked(uris ?: emptyList(), false)
    }
    private val pickOneLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        onFilesPicked(if (uri != null) listOf(uri) else emptyList(), true)
    }
    private val standbyPickLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onStandbyPicked(uri)
    }
    private val projLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            val i = Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_START)
                .putExtra(RecorderService.EXTRA_CODE, r.resultCode).putExtra(RecorderService.EXTRA_DATA, data)
            ContextCompat.startForegroundService(this, i)
        } else {
            toast("Screen capture permission is required to record the video source")
            bindPreview()
        }
    }

    // ───────────────────────── lifecycle ─────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = ConfigStore.load(this)
        Playlist.load(this)
        buildUi()
        if (cfg.mode == SourceMode.VIDEO) loadVideoInfoAsync()
        requestPermissionsIfNeeded()
        RecorderState.addListener(stateListener)
        render()
    }

    override fun onResume() {
        super.onResume()
        render()
        if (!RecorderState.isBusy) bindPreview()
        handleResult()
        ui.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(ticker)
        ConfigStore.save(this, cfg)
    }

    override fun onDestroy() {
        super.onDestroy()
        RecorderState.removeListener(stateListener)
    }

    private val ticker = object : Runnable {
        override fun run() {
            updateStatus()
            updateLive()
            ui.postDelayed(this, if (RecorderState.isBusy) 250L else 500L)
        }
    }

    // ───────────────────────── permissions ─────────────────────────

    private fun hasCamera() = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    private fun hasMic() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun requestPermissionsIfNeeded() {
        val need = ArrayList<String>()
        if (!hasCamera()) need += Manifest.permission.CAMERA
        if (!hasMic()) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) permLauncher.launch(need.toTypedArray())
    }

    // ───────────────────────── camera preview (قبل التسجيل فقط) ─────────────────────────

    private fun bindPreview() {
        if (!hasCamera() || RecorderState.isBusy) return
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            try {
                if (RecorderState.isBusy) return@addListener
                val p = f.get()
                p.unbindAll()
                val pv = Preview.Builder().build()
                pv.setSurfaceProvider(editor.previewView.surfaceProvider)
                val sel = if (cfg.frontCamera) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                val cam = p.bindToLifecycle(this, sel, pv)
                camera = cam
                editor.previewView.scaleX = if (cfg.frontCamera && !cfg.mirrorFront) -1f else 1f
                applyCameraControls()
            } catch (t: Throwable) {
                statusText.text = "Camera error: ${t.message}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun unbindPreview() {
        try { ProcessCameraProvider.getInstance(this).get().unbindAll() } catch (_: Throwable) {}
        camera = null
    }

    private fun applyCameraControls() {
        val c = camera ?: return
        try {
            val zs = c.cameraInfo.zoomState.value
            if (zs != null) c.cameraControl.setZoomRatio(cfg.zoom.coerceIn(zs.minZoomRatio, zs.maxZoomRatio))
            c.cameraControl.setExposureCompensationIndex(cfg.exposureIndex)
            c.cameraControl.enableTorch(cfg.torch && c.cameraInfo.hasFlashUnit())
        } catch (_: Throwable) {}
    }

    // ───────────────────────── UI building ─────────────────────────

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun chip(text: String, onClick: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER
        setPadding(dp(12), dp(8), dp(12), dp(8))
        minWidth = dp(48)
        setOnClickListener { onClick() }
        setChipSelected(this, false)
    }

    private fun setChipSelected(v: TextView, sel: Boolean) {
        v.background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            setColor(if (sel) Color.parseColor("#FF3B30") else Color.parseColor("#2A2D36"))
        }
    }

    private fun lp(w: Int, h: Int, l: Int = 0, r: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply { setMargins(dp(l), 0, dp(r), 0) }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#101114"))
            setPadding(dp(10), dp(8), dp(10), dp(10))
        }
        setContentView(root)
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            v.setPadding(dp(10), b.top + dp(8), dp(10), b.bottom + dp(10)); insets
        }

        // الصف العلوي: التخزين + الإعدادات
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        infoText = TextView(this).apply { setTextColor(Color.parseColor("#AAB0BD")); textSize = 12f }
        top.addView(infoText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(chip("⚙ Settings") { showSettings() })
        root.addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // اختيار المصدر: تصوير الشاشة أو ملف/رابط فيديو
        modeRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        modeScreenChip = chip("📱 Screen") { setMode(SourceMode.SCREEN) }
        modeVideoChip = chip("🎞 Video file") { setMode(SourceMode.VIDEO) }
        pickChip = chip("📂 Add") { pickMultiLauncher.launch(arrayOf("video/*", "image/*")) }
        listChip = chip("📋 List") { showPlaylistDialog() }
        linkChip = chip("🔗 Link") { showLinkDialog() }
        for (c in listOf(modeScreenChip, modeVideoChip, pickChip, listChip, linkChip)) modeRow.addView(c, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 6))
        val modeScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(modeRow) }
        root.addView(modeScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6); bottomMargin = dp(6) })

        // المحرر/المعاينة
        editor = LayoutEditorView(this).apply {
            this.cfg = this@MainActivity.cfg
            onChanged = { ConfigStore.save(this@MainActivity, this@MainActivity.cfg); renderPresets() }
            onLiveEdit = { RecorderState.scene?.applyLayout(this@MainActivity.cfg.layout) }
        }
        root.addView(editor, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // Presets
        presetRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        for (i in 0 until 5) {
            val c = chip(Presets.names[i]) { applyPreset(i + 1) }
            presetChips += c
            presetRow.addView(c, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 6))
        }
        val presetScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(presetRow) }
        root.addView(presetScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })

        // نسبة الفيديو/الكاميرا (للـ Presets المقسومة)
        ratioRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        ratioLabel = TextView(this).apply { setTextColor(Color.parseColor("#AAB0BD")); textSize = 12f }
        ratioSeek = SeekBar(this).apply {
            max = 50 // 30%..80%
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    val id = cfg.layout.presetId
                    if (id !in 2..4) return
                    Presets.build(id, cfg.portrait, (30 + p) / 100f, cfg.layout)
                    ratioLabel.text = "Video ${30 + p}%"
                    editor.refresh()
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) { ConfigStore.save(this@MainActivity, cfg) }
            })
        }
        ratioRow.addView(ratioLabel, LinearLayout.LayoutParams(dp(80), ViewGroup.LayoutParams.WRAP_CONTENT))
        ratioRow.addView(ratioSeek, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(ratioRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // أزرار سريعة: الاتجاه، الدقة، FPS، الصوت، الشكل
        quickRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        orientChip = chip("9:16") {
            cfg.portrait = !cfg.portrait
            val id = if (cfg.layout.presetId in 1..5) cfg.layout.presetId else 1
            cfg.layout = Presets.build(id, cfg.portrait, cfg.layout.ratio, cfg.layout)
            changed(true)
        }
        resChip = chip("1080p") { cfg.shortSide = if (cfg.shortSide == 1080) 720 else 1080; changed(false) }
        fpsChip = chip("30 fps") { cfg.fps = when (cfg.fps) { 30 -> 24; 24 -> 60; else -> 30 }; changed(false) }
        micChip = chip("Mic ON") { cfg.micOn = !cfg.micOn; changed(false) }
        srcChip = chip("Source audio ON") { cfg.srcAudioOn = !cfg.srcAudioOn; changed(false) }
        shapeChip = chip("Rounded") {
            cfg.layout.shape = CamShape.values()[(cfg.layout.shape.ordinal + 1) % 3]
            if (cfg.layout.presetId in 1..5) Presets.build(cfg.layout.presetId, cfg.portrait, cfg.layout.ratio, cfg.layout)
            changed(true)
        }
        fitChip = chip("Fit") {
            cfg.sourceFit = SourceFit.values()[(cfg.sourceFit.ordinal + 1) % 3]
            changed(true)
        }
        for (c in listOf(fitChip, orientChip, resChip, fpsChip, micChip, srcChip, shapeChip)) quickRow.addView(c, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 6))
        val quickScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(quickRow) }
        root.addView(quickScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })

        buildLiveBox(root)

        statusText = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER; typeface = Typeface.MONOSPACE }
        root.addView(statusText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        noteText = TextView(this).apply { setTextColor(Color.parseColor("#8A90A0")); textSize = 11f; gravity = Gravity.CENTER }
        root.addView(noteText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // شريط التحكم: تبديل الكاميرا | Record | Pause/Mute
        val ctl = LinearLayout(this).apply { gravity = Gravity.CENTER }
        flipChip = chip("⟲ Flip") { flipCamera() }
        recBtn = TextView(this).apply {
            text = "REC"; setTextColor(Color.WHITE); textSize = 16f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setOnClickListener { onRecordClicked() }
        }
        pauseChip = chip("⏸ Pause") { onPauseClicked() }
        ctl.addView(flipChip, lp(dp(96), ViewGroup.LayoutParams.WRAP_CONTENT, 0, 14))
        ctl.addView(recBtn, LinearLayout.LayoutParams(dp(84), dp(84)))
        ctl.addView(pauseChip, lp(dp(96), ViewGroup.LayoutParams.WRAP_CONTENT, 14, 0))
        root.addView(ctl, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
    }

    // ───────────────────────── render ─────────────────────────

    private fun changed(layoutChanged: Boolean) {
        ConfigStore.save(this, cfg)
        render()
        if (layoutChanged) editor.refresh()
    }

    private fun applyPreset(id: Int) {
        Presets.build(id, cfg.portrait, cfg.layout.ratio, cfg.layout)
        changed(true)
    }

    private fun renderPresets() {
        val id = cfg.layout.presetId
        for ((i, c) in presetChips.withIndex()) setChipSelected(c, id == i + 1)
        ratioRow.visibility = if (id in 2..4 && !RecorderState.isBusy) View.VISIBLE else View.GONE
        if (id in 2..4) {
            val pct = (cfg.layout.ratio * 100).toInt().coerceIn(30, 80)
            ratioSeek.progress = pct - 30
            ratioLabel.text = "Video $pct%"
        }
    }

    private fun render() {
        if (!::editor.isInitialized) return
        editor.cfg = cfg
        val dm = resources.displayMetrics
        val sh = min(dm.widthPixels, dm.heightPixels).toFloat(); val lo = max(dm.widthPixels, dm.heightPixels).toFloat()
        val videoMode = cfg.mode == SourceMode.VIDEO
        editor.screenAspect = if (videoMode) videoAspect else if (cfg.portrait) sh / lo else lo / sh
        val busy = RecorderState.isBusy
        val ph = RecorderState.phase
        val liveNow = videoMode && (ph == RecorderState.Phase.RECORDING || ph == RecorderState.Phase.PAUSED)
        editor.live = liveNow
        editor.locked = busy && !liveNow
        if (!liveNow) editor.gestureMode = 0
        editor.monitor = busy && videoMode
        editor.sourceThumb = if (videoMode) videoThumb else null
        val curItem = Playlist.current()
        editor.sourceLabel = if (!videoMode) "VIDEO / SCREEN" else if (curItem == null) "Choose a video" else (if (curItem.image) "🖼 " else "🎞 ") + curItem.name
        editor.invalidate()

        setChipSelected(modeScreenChip, !videoMode); setChipSelected(modeVideoChip, videoMode)
        pickChip.visibility = if (videoMode) View.VISIBLE else View.GONE
        listChip.visibility = if (videoMode) View.VISIBLE else View.GONE
        listChip.text = "📋 List (${Playlist.items.size})"
        linkChip.visibility = if (videoMode) View.VISIBLE else View.GONE
        (modeRow.parent as View).visibility = if (busy) View.GONE else View.VISIBLE
        fitChip.text = when (cfg.sourceFit) { SourceFit.FIT -> "Source: Fit"; SourceFit.FILL -> "Source: Fill"; SourceFit.STRETCH -> "Source: Stretch" }
        srcChip.text = if (videoMode) (if (cfg.srcAudioOn) "Video audio ON" else "Video audio OFF") else (if (cfg.srcAudioOn) "Source audio ON" else "Source audio OFF")

        orientChip.text = if (cfg.portrait) "9:16" else "16:9"
        resChip.text = if (cfg.shortSide == 1080) "1080p" else "720p"
        fpsChip.text = if (cfg.fps == 60) "60 fps ⚠" else "${cfg.fps} fps"
        micChip.text = if (cfg.micOn) "Mic ON" else "Mic OFF"
        shapeChip.text = when (cfg.layout.shape) { CamShape.RECT -> "Rectangle"; CamShape.ROUNDED -> "Rounded"; CamShape.CIRCLE -> "Circle" }
        setChipSelected(micChip, cfg.micOn); setChipSelected(srcChip, cfg.srcAudioOn)
        renderPresets()

        presetRow.parent.let { (it as View).visibility = if (busy) View.GONE else View.VISIBLE }
        quickRow.parent.let { (it as View).visibility = if (busy) View.GONE else View.VISIBLE }

        val phase = RecorderState.phase
        when (phase) {
            RecorderState.Phase.IDLE -> {
                recBtn.text = "REC"; styleRec(false); pauseChip.visibility = View.INVISIBLE
                flipChip.text = "⟲ Flip"; flipChip.visibility = View.VISIBLE
            }
            RecorderState.Phase.STARTING, RecorderState.Phase.COUNTDOWN -> {
                recBtn.text = "CANCEL"; styleRec(true); pauseChip.visibility = View.INVISIBLE; flipChip.visibility = View.INVISIBLE
            }
            RecorderState.Phase.RECORDING, RecorderState.Phase.PAUSED -> {
                recBtn.text = "■ STOP"; styleRec(true)
                pauseChip.visibility = View.VISIBLE; pauseChip.text = if (phase == RecorderState.Phase.PAUSED) "▶ Resume" else "⏸ Pause"
                flipChip.visibility = View.VISIBLE; flipChip.text = "⟲ Flip"
            }
            RecorderState.Phase.FINISHING -> {
                recBtn.text = "…"; styleRec(true); pauseChip.visibility = View.INVISIBLE; flipChip.visibility = View.INVISIBLE
            }
        }
        editor.overlayText = if (phase == RecorderState.Phase.COUNTDOWN && RecorderState.countdownLeft > 0) RecorderState.countdownLeft.toString() else ""
        updateStatus()
        updateLive()
    }

    private fun styleRec(active: Boolean) {
        recBtn.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (active) Color.parseColor("#7A1F1A") else Color.parseColor("#FF3B30"))
            setStroke(dp(4), Color.WHITE)
        }
    }

    private fun updateStatus() {
        if (!::statusText.isInitialized) return
        val phase = RecorderState.phase
        when (phase) {
            RecorderState.Phase.IDLE -> {
                val rv = try { CodecSupport.resolve(cfg) } catch (_: Throwable) { null }
                val br = rv?.bitrate ?: cfg.effectiveBitrate()
                val est = StorageUtil.estimateSeconds(br, cfg.micOn || cfg.srcAudioOn)
                infoText.text = "Free ${StorageUtil.formatBytes(StorageUtil.freeBytes())} • ≈ ${StorageUtil.formatDuration(est)} at " +
                    "${rv?.w ?: cfg.outW}x${rv?.h ?: cfg.outH} ${rv?.fps ?: cfg.fps}fps"
                statusText.text = "Ready"
                noteText.text = if (cfg.mode == SourceMode.VIDEO)
                    "The video plays inside this app and is recorded with your camera — no screen capture. Use headphones."
                else "When Android asks, choose “Entire screen”, then open YouTube. Use headphones to avoid echo."
            }
            RecorderState.Phase.STARTING -> { statusText.text = "Preparing…"; noteText.text = "" }
            RecorderState.Phase.COUNTDOWN -> { statusText.text = "Starting in ${RecorderState.countdownLeft}…"; noteText.text = "You can switch to your video app now." }
            RecorderState.Phase.RECORDING, RecorderState.Phase.PAUSED -> {
                val s = RecorderState.elapsedMs() / 1000
                val t = String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
                statusText.text = (if (phase == RecorderState.Phase.PAUSED) "⏸ " else "● ") + t +
                    (if (RecorderState.micMuted) "  🎤✕" else "") + (if (RecorderState.srcMuted) "  🔊✕" else "") +
                    (if (RecorderState.scene?.standby == true) "  ⏸ standby" else "")
                infoText.text = RecorderState.resolvedInfo
                noteText.text = RecorderState.notes.joinToString("\n")
            }
            RecorderState.Phase.FINISHING -> { statusText.text = "Finishing video…"; noteText.text = "Please wait — do not close the app" }
        }
    }

    // ───────────────────────── actions ─────────────────────────

    private fun serviceCmd(action: String) {
        startService(Intent(this, RecorderService::class.java).setAction(action))
    }

    private fun flipCamera() {
        if (RecorderState.isBusy) { serviceCmd(RecorderService.ACTION_SWITCH_CAMERA); return }
        cfg.frontCamera = !cfg.frontCamera
        ConfigStore.save(this, cfg)
        bindPreview()
    }

    private fun onPauseClicked() {
        serviceCmd(if (RecorderState.phase == RecorderState.Phase.PAUSED) RecorderService.ACTION_RESUME else RecorderService.ACTION_PAUSE)
    }

    private fun onRecordClicked() {
        if (RecorderState.isBusy) {
            if (RecorderState.phase != RecorderState.Phase.FINISHING) serviceCmd(RecorderService.ACTION_STOP)
            return
        }
        if (!hasCamera() || (cfg.micOn && !hasMic())) {
            toast("Camera and microphone permissions are required")
            requestPermissionsIfNeeded(); return
        }
        if (cfg.mode == SourceMode.VIDEO && Playlist.items.isEmpty()) {
            toast("Add a video, an image or a link first")
            return
        }
        ConfigStore.save(this, cfg)
        val rv = CodecSupport.resolve(cfg)
        val est = StorageUtil.estimateSeconds(rv.bitrate, cfg.micOn || cfg.srcAudioOn)
        val free = StorageUtil.freeBytes()
        if (free < 300L * 1024 * 1024) {
            AlertDialog.Builder(this).setTitle("Not enough storage")
                .setMessage("Only ${StorageUtil.formatBytes(free)} free. Free some space before recording.")
                .setPositiveButton("OK", null).show()
            return
        }
        if (est < 10 * 60) {
            AlertDialog.Builder(this).setTitle("Low storage")
                .setMessage("Free space allows only about ${StorageUtil.formatDuration(est)} of recording at this quality. Continue?")
                .setPositiveButton("Record") { _, _ -> echoCheckThen { launchCapture() } }
                .setNegativeButton("Cancel", null).show()
            return
        }
        echoCheckThen { launchCapture() }
    }

    private fun launchCapture() {
        unbindPreview() // الخدمة ستفتح الكاميرا
        if (cfg.mode == SourceMode.VIDEO) { // لا حاجة لإذن تصوير الشاشة
            ContextCompat.startForegroundService(this, Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_START))
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projLauncher.launch(mpm.createScreenCaptureIntent())
    }

    // ───────────────────────── مصدر الفيديو + قائمة التشغيل ─────────────────────────

    private fun setMode(m: SourceMode) {
        if (RecorderState.isBusy) return
        cfg.mode = m
        ConfigStore.save(this, cfg)
        if (m == SourceMode.VIDEO) {
            if (Playlist.items.isEmpty()) pickMultiLauncher.launch(arrayOf("video/*", "image/*")) else loadVideoInfoAsync()
        }
        render(); editor.refresh()
    }

    /** نتيجة اختيار ملفات (قبل التسجيل أو أثناءه). showNow = اعرض أول ملف جديد مباشرة */
    private fun onFilesPicked(uris: List<Uri>, showNow: Boolean) {
        val newItems = uris.map { u ->
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Throwable) {}
            val type = contentResolver.getType(u) ?: ""
            PlayItem(u.toString(), queryName(u) ?: "file", type.startsWith("image/"))
        }
        val sc = RecorderState.scene
        if (RecorderState.isBusy && sc != null) {
            if (newItems.isNotEmpty()) sc.addItems(newItems, showNow)
            if (importAutoStandby) {
                importAutoStandby = false
                if (sc.standby) sc.exitStandby(true)
            }
            render()
            return
        }
        if (newItems.isEmpty()) return
        val first = Playlist.items.size
        Playlist.items.addAll(newItems)
        if (showNow || first == 0) Playlist.index = first
        Playlist.save(this)
        cfg.mode = SourceMode.VIDEO
        ConfigStore.save(this, cfg)
        loadVideoInfoAsync()
        render(); editor.refresh()
    }

    private fun queryName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    } catch (_: Throwable) { null }

    /** يقرأ أبعاد العنصر الحالي ولقطة مصغّرة في خيط خلفي ليعرضها المحرر كمعاينة */
    private fun loadVideoInfoAsync() {
        val cur = Playlist.current()
        if (cur == null) { videoThumb = null; videoAspect = 16f / 9f; return }
        val u = cur.uri
        Thread {
            var thumb: android.graphics.Bitmap? = null
            var aspect = 16f / 9f
            if (cur.image) {
                thumb = ImageLoader.load(applicationContext, u, 640)
                if (thumb != null) aspect = thumb.width.toFloat() / thumb.height
            } else {
                val info = VideoProbe.probe(applicationContext, u, true)
                if (info != null) { thumb = info.thumb; aspect = info.width.toFloat() / info.height }
            }
            runOnUiThread {
                if (Playlist.current()?.uri == u) {
                    videoThumb = thumb
                    videoAspect = aspect
                    render(); editor.refresh()
                }
            }
        }.start()
    }

    private fun showLinkDialog() {
        val input = android.widget.EditText(this).apply {
            hint = "https://example.com/video.mp4"
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine(true)
        }
        val box = LinearLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)) }
        fun add(showNow: Boolean) {
            val t = input.text.toString().trim()
            val host = try { Uri.parse(t).host?.lowercase() ?: "" } catch (_: Throwable) { "" }
            when {
                !t.startsWith("https://") -> toast("The link must start with https://")
                host.contains("youtube.com") || host.contains("youtu.be") || host.contains("youtube-nocookie.com") -> showYoutubeDialog()
                else -> {
                    val item = PlayItem(t, Uri.parse(t).lastPathSegment ?: "link", false)
                    val sc = RecorderState.scene
                    if (RecorderState.isBusy && sc != null) {
                        sc.addItems(listOf(item), showNow)
                    } else {
                        val first = Playlist.items.size
                        Playlist.items.add(item)
                        if (showNow || first == 0) Playlist.index = first
                        Playlist.save(this)
                        cfg.mode = SourceMode.VIDEO
                        ConfigStore.save(this, cfg)
                        loadVideoInfoAsync()
                        render(); editor.refresh()
                    }
                }
            }
        }
        AlertDialog.Builder(this)
            .setTitle("Direct video link")
            .setMessage("Paste a direct https link to a video file (for example …/clip.mp4). Only use videos you have the right to use.")
            .setView(box)
            .setPositiveButton("Add to list") { _, _ -> add(false) }
            .setNeutralButton("Show now") { _, _ -> add(true) }
            .setNegativeButton("Cancel", null).show()
    }

    /** رسالة من التطبيق (ليست من يوتيوب): لماذا لا نشغّل يوتيوب داخل التطبيق، والبديل الرسمي */
    private fun showYoutubeDialog() {
        val b = AlertDialog.Builder(this).setTitle("YouTube can't be played inside this app")
            .setMessage("This message comes from Reaction Recorder, not from YouTube.\n\n" +
                "YouTube does not give other apps access to its video stream, so a YouTube link can't be played and mixed here.\n\n" +
                "To react to a YouTube video use Screen mode: open YouTube, and this app records your screen with your camera. " +
                "In Settings you can crop and zoom the screen so the video fills the whole frame.")
            .setPositiveButton("OK", null)
        if (!RecorderState.isBusy) b.setNeutralButton("Switch to Screen mode") { _, _ -> setMode(SourceMode.SCREEN) }
        b.show()
    }

    private fun showPlaylistDialog() {
        val sc = RecorderState.scene
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(6), dp(8), dp(6)) }
        var dlg: AlertDialog? = null
        fun reopen() { dlg?.dismiss(); showPlaylistDialog() }
        val list = Playlist.items
        if (list.isEmpty()) {
            col.addView(TextView(this).apply { text = "The list is empty. Tap “Add files”."; setTextColor(Color.parseColor("#AAB0BD")); setPadding(dp(8), dp(12), dp(8), dp(12)) })
        }
        for ((i, item) in list.withIndex()) {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            val isCur = i == Playlist.index
            val label = TextView(this).apply {
                text = (if (isCur) "▶ " else "    ") + "${i + 1}. " + (if (item.image) "🖼 " else "🎞 ") + item.name
                setTextColor(if (isCur) Color.parseColor("#FF6B63") else Color.WHITE)
                textSize = 14f; maxLines = 2; ellipsize = TextUtils.TruncateAt.END
                setPadding(dp(6), dp(10), dp(6), dp(10))
                setOnClickListener {
                    if (sc != null) sc.jump(i)
                    else { Playlist.index = i; Playlist.save(this@MainActivity); loadVideoInfoAsync(); render() }
                    dlg?.dismiss()
                }
            }
            row.addView(label, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(chip("▲") {
                if (sc != null) sc.moveItem(i, -1) else { Playlist.move(i, -1); Playlist.save(this) }
                reopen()
            }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 2, 2))
            row.addView(chip("▼") {
                if (sc != null) sc.moveItem(i, 1) else { Playlist.move(i, 1); Playlist.save(this) }
                reopen()
            }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 2, 2))
            row.addView(chip("✕") {
                if (sc != null) sc.removeItem(i) else { Playlist.remove(i); Playlist.save(this); loadVideoInfoAsync() }
                reopen()
            }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 2, 0))
            col.addView(row)
        }
        val sv = ScrollView(this).apply { addView(col) }
        val d = AlertDialog.Builder(this).setTitle("Playlist (plays only when you choose)").setView(sv)
            .setPositiveButton("＋ Add files") { _, _ -> pickMultiLauncher.launch(arrayOf("video/*", "image/*")) }
            .setNeutralButton("🔗 Add link") { _, _ -> showLinkDialog() }
            .setNegativeButton("Close") { _, _ -> render() }
            .create()
        dlg = d
        d.show()
    }

    // ───────────────────────── اللوحة الحيّة أثناء التسجيل ─────────────────────────

    private fun scrollOf(vararg chips: TextView): HorizontalScrollView {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        for (c in chips) row.addView(c, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 6))
        return HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }
    }

    private fun buildLiveBox(root: LinearLayout) {
        liveBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }

        // شريط التشغيل (وضع الفيديو فقط)
        playChip = chip("▶") { RecorderState.scene?.playPause() }
        loopChip = chip("🔁") { RecorderState.scene?.toggleLoop(); updateLive() }
        val transport = scrollOf(
            chip("⏮") { RecorderState.scene?.prev() },
            chip("⏪ 10") { RecorderState.scene?.seekBy(-10_000L) },
            playChip,
            chip("10 ⏩") { RecorderState.scene?.seekBy(10_000L) },
            chip("⏭") { RecorderState.scene?.next() },
            chip("⟳ 90°") { RecorderState.scene?.rotate90() },
            loopChip,
        )
        transportScroll = transport
        liveBox.addView(transport)

        seekRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        timeText = TextView(this).apply { setTextColor(Color.parseColor("#AAB0BD")); textSize = 11f; typeface = Typeface.MONOSPACE }
        seekBar = SeekBar(this).apply {
            max = 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) { if (fromUser) timeText.text = fmtTime(p.toLong()) + " / " + fmtTime(s.max.toLong()) }
                override fun onStartTrackingTouch(s: SeekBar) { seeking = true }
                override fun onStopTrackingTouch(s: SeekBar) { RecorderState.scene?.seekAbs(s.progress.toLong()); seeking = false }
            })
        }
        seekRow.addView(timeText, LinearLayout.LayoutParams(dp(92), ViewGroup.LayoutParams.WRAP_CONTENT))
        seekRow.addView(seekBar, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        liveBox.addView(seekRow)

        // انتهى الفيديو → زر التالي (لا يشتغل تلقائيًا)
        endedRow = LinearLayout(this).apply { gravity = Gravity.CENTER; visibility = View.GONE }
        endedText = TextView(this).apply { setTextColor(Color.parseColor("#FFB86B")); textSize = 13f; text = "Video ended" }
        nextBtn = chip("▶ Play next") { RecorderState.scene?.playNextAfterEnd() }
        endedRow.addView(endedText, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10))
        endedRow.addView(nextBtn)
        liveBox.addView(endedRow)

        // صف المشهد: استيراد، قائمة، انتظار، كاميرا، تحريك، صوت
        standbyChip = chip("⏸ Standby") { RecorderState.scene?.toggleStandby(); updateLive() }
        camChip = chip("📷 Camera") { showCameraMenu() }
        gestureChip = chip("🎞 Move video") {
            editor.gestureMode = if (editor.gestureMode == 0) 1 else 0
            editor.invalidate(); updateLive()
        }
        fullChip = chip("⛶ 100%") {
            val sc = RecorderState.scene
            if (sc != null) {
                sc.resetView()
                cfg.layout.source = NRect(0f, 0f, 1f, 1f); cfg.layout.presetId = 6
                sc.applyLayout(cfg.layout)
                editor.refresh()
            }
        }
        fitLiveChip = chip("Fit") { RecorderState.scene?.cycleFit(); updateLive() }
        micLiveChip = chip("🎤 ON") { RecorderState.scene?.let { it.setMicMuted(!RecorderState.micMuted) }; updateLive() }
        srcLiveChip = chip("🔊 ON") { RecorderState.scene?.let { it.setSrcMuted(!RecorderState.srcMuted) }; updateLive() }
        allMuteChip = chip("🔇 Mute all") { RecorderState.scene?.let { it.muteAll(!it.allMuted) }; updateLive() }
        silentChip = chip("🔈 Speaker") { RecorderState.scene?.toggleSilent(); updateLive() }
        liveBox.addView(
            scrollOf(chip("＋ Import") { showImportMenu() }, standbyChip, camChip, gestureChip, fullChip, fitLiveChip),
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) },
        )
        liveBox.addView(
            scrollOf(micLiveChip, srcLiveChip, allMuteChip, silentChip, chip("📋 List") { showPlaylistDialog() }),
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) },
        )
        root.addView(liveBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
    }

    private fun fmtTime(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0L)
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }

    /** يحدّث أزرار اللوحة الحيّة من حالة المشهد (يُستدعى 4 مرات في الثانية أثناء التسجيل) */
    private fun updateLive() {
        if (!::liveBox.isInitialized) return
        val sc = RecorderState.scene
        val phase = RecorderState.phase
        val liveNow = sc != null && (phase == RecorderState.Phase.RECORDING || phase == RecorderState.Phase.PAUSED)
        liveBox.visibility = if (liveNow) View.VISIBLE else View.GONE
        if (!liveNow || sc == null) return
        val vm = sc.videoMode
        transportScroll.visibility = if (vm) View.VISIBLE else View.GONE
        seekRow.visibility = if (vm) View.VISIBLE else View.GONE
        gestureChip.visibility = if (vm) View.VISIBLE else View.GONE
        fullChip.visibility = if (vm) View.VISIBLE else View.GONE
        fitLiveChip.visibility = if (vm) View.VISIBLE else View.GONE
        silentChip.visibility = if (vm) View.VISIBLE else View.GONE

        playChip.text = if (sc.playing) "⏸" else "▶"
        setChipSelected(loopChip, sc.loop)
        if (vm && !seeking) {
            val dur = sc.durationMs
            val pos = sc.positionMs
            seekBar.max = if (dur > 0L) dur.toInt() else 1
            seekBar.progress = if (dur > 0L) pos.coerceIn(0L, dur).toInt() else 0
            seekBar.isEnabled = dur > 0L && !sc.standby
            timeText.text = if (sc.currentIsImage) "image" else fmtTime(pos) + " / " + fmtTime(dur)
        }
        val showEnded = vm && sc.ended && !sc.standby
        endedRow.visibility = if (showEnded) View.VISIBLE else View.GONE
        nextBtn.visibility = if (sc.hasNext) View.VISIBLE else View.GONE
        endedText.text = if (sc.hasNext) "Video ended" else "Video ended — last item"

        standbyChip.text = if (sc.standby) "▶ Exit standby" else "⏸ Standby"
        setChipSelected(standbyChip, sc.standby)
        camChip.text = if (!sc.cameraVisible) "📷 Camera (hidden)" else if (sc.dualActive) "📷📷 Camera" else "📷 Camera"
        setChipSelected(camChip, !sc.cameraVisible || sc.dualActive)
        gestureChip.text = if (editor.gestureMode == 1) "✥ Move boxes" else "🎞 Move video"
        setChipSelected(gestureChip, editor.gestureMode == 1)
        fitLiveChip.text = when (sc.fit) { SourceFit.FIT -> "Fit"; SourceFit.FILL -> "Fill"; SourceFit.STRETCH -> "Stretch" }
        micLiveChip.text = if (RecorderState.micMuted) "🎤 OFF" else "🎤 ON"
        setChipSelected(micLiveChip, RecorderState.micMuted)
        srcLiveChip.text = if (RecorderState.srcMuted) "🔊 OFF" else "🔊 ON"
        setChipSelected(srcLiveChip, RecorderState.srcMuted)
        setChipSelected(allMuteChip, sc.allMuted)
        silentChip.text = if (sc.silent) "🔈 Speaker OFF" else "🔈 Speaker ON"
        setChipSelected(silentChip, sc.silent)
        editor.dualOn = sc.dualActive
    }

    private fun showCameraMenu() {
        val sc = RecorderState.scene ?: return
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        labels += "⟲ Flip camera (now: ${if (sc.camFront) "front" else "back"})"; acts.add { sc.flipCamera() }
        labels += "↔ Mirror: ${if (sc.mirror) "ON" else "OFF"} (front camera)"; acts.add { sc.toggleMirror() }
        labels += if (sc.cameraVisible) "🙈 Hide camera (cover something)" else "👁 Show camera"; acts.add { sc.toggleCameraVisible() }
        if (sc.dualAvailable) {
            labels += "📷📷 Front + back together: ${if (sc.dualActive) "ON" else "OFF"}"
            acts.add {
                sc.setDual(!sc.dualActive) { ok ->
                    runOnUiThread { if (!ok) toast("Could not change dual camera mode"); updateLive() }
                }
            }
        } else {
            labels += "📷📷 Front + back together (not supported on this phone)"
            acts.add { toast("This phone does not allow two cameras at the same time") }
        }
        AlertDialog.Builder(this).setTitle("Camera")
            .setItems(labels.toTypedArray()) { _, i -> acts[i](); updateLive() }
            .setNegativeButton("Close", null).show()
    }

    private fun showImportMenu() {
        val sc = RecorderState.scene ?: return
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        if (sc.videoMode) {
            labels += "📂 Add videos / images to the list…"; acts.add { startImport(false) }
            labels += "▶ Choose a file and show it now…"; acts.add { startImport(true) }
            labels += "🔗 Add a video link…"; acts.add { showLinkDialog() }
            labels += "📋 Open the playlist…"; acts.add { showPlaylistDialog() }
        }
        labels += if (sc.standby) "▶ Leave the standby screen" else "⏸ Show the standby screen"; acts.add { sc.toggleStandby(); updateLive() }
        AlertDialog.Builder(this).setTitle("Import / scene")
            .setItems(labels.toTypedArray()) { _, i -> acts[i]() }
            .setNegativeButton("Close", null).show()
    }

    /** يفتح منتقي الملفات أثناء التسجيل. إن فُعّل الخيار نعرض شاشة الانتظار أثناء التصفّح */
    private fun startImport(showNow: Boolean) {
        val sc = RecorderState.scene
        if (sc != null && cfg.autoStandbyOnImport && !sc.standby) {
            sc.enterStandby()
            importAutoStandby = true
        }
        if (showNow) pickOneLauncher.launch(arrayOf("video/*", "image/*"))
        else pickMultiLauncher.launch(arrayOf("video/*", "image/*"))
    }

    private fun onStandbyPicked(uri: Uri) {
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Throwable) {}
        val type = contentResolver.getType(uri) ?: ""
        cfg.standbyUri = uri.toString()
        cfg.standbyName = queryName(uri) ?: "file"
        cfg.standbyIsVideo = type.startsWith("video/")
        ConfigStore.save(this, cfg)
        standbyLabelView?.text = standbyDesc()
    }

    private fun standbyDesc(): String =
        if (cfg.standbyUri.isEmpty()) "Text screen: “${cfg.standbyText}”"
        else (if (cfg.standbyIsVideo) "🎞 " else "🖼 ") + cfg.standbyName

    // ───────────────────────── صدى: سماعات الرأس ─────────────────────────

    private fun hasHeadphones(): Boolean {
        return try {
            val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
            am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS).any { d ->
                when (d.type) {
                    android.media.AudioDeviceInfo.TYPE_WIRED_HEADSET,
                    android.media.AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
                    android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
                    android.media.AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
                    android.media.AudioDeviceInfo.TYPE_USB_HEADSET -> true
                    else -> d.type == 26 // TYPE_BLE_HEADSET
                }
            }
        } catch (_: Throwable) {
            true
        }
    }

    private fun echoCheckThen(run: () -> Unit) {
        val risky = cfg.warnEcho && cfg.micOn && cfg.srcAudioOn && !hasHeadphones()
        if (!risky) { run(); return }
        val video = cfg.mode == SourceMode.VIDEO
        val b = AlertDialog.Builder(this).setTitle("No headphones detected")
            .setMessage(
                if (video) "Without headphones the microphone picks up the video's sound from the speaker (echo).\n\n" +
                    "Best: plug in headphones.\nOr use “Silent playback”: the video's sound is recorded cleanly but you won't hear it from the speaker."
                else "Without headphones the microphone picks up the sound of the video you are reacting to (echo). Plug in headphones for a clean recording."
            )
            .setPositiveButton("Record anyway") { _, _ -> run() }
            .setNegativeButton("Cancel", null)
        if (video) b.setNeutralButton("Silent playback") { _, _ ->
            cfg.silentPlayback = true
            ConfigStore.save(this, cfg)
            run()
        }
        b.show()
    }

    // ───────────────────────── state / result ─────────────────────────

    private fun onStateChanged() {
        val busy = RecorderState.isBusy
        render()
        if (wasBusy && !busy) { bindPreview(); handleResult() }
        wasBusy = busy
    }

    private fun handleResult() {
        val uri = RecorderState.lastUri
        val err = RecorderState.lastError
        if (RecorderState.isBusy) return
        if (uri != null) {
            RecorderState.lastUri = null
            RecorderState.lastError = null
            showReady(uri, err)
        } else if (err != null) {
            RecorderState.lastError = null
            AlertDialog.Builder(this).setTitle("Recording problem").setMessage(err).setPositiveButton("OK", null).show()
        }
    }

    private fun showReady(uri: Uri, warning: String?) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(4)) }
        box.addView(TextView(this).apply {
            text = "Saved to Movies/ReactionRecorder — it is already in your Gallery." + if (warning != null) "\n\n$warning" else ""
            setTextColor(Color.parseColor("#E6E8EE")); textSize = 14f
        })
        val d = AlertDialog.Builder(this).setTitle("Video Ready ✓").setView(box).setCancelable(true).create()
        fun btn(label: String, run: () -> Unit) = Button(this).apply {
            text = label; isAllCaps = false
            setOnClickListener { run(); }
        }
        box.addView(btn("▶  Play") {
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        })
        box.addView(btn("↗  Share") {
            val s = Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(s, "Share video"))
        })
        box.addView(btn("✓  Save") { toast("Saved in Movies/ReactionRecorder"); d.dismiss() })
        box.addView(btn("🗑  Delete") {
            AlertDialog.Builder(this).setTitle("Delete this video?")
                .setPositiveButton("Delete") { _, _ -> StorageUtil.delete(this, uri); toast("Deleted"); d.dismiss() }
                .setNegativeButton("Cancel", null).show()
        })
        d.show()
    }

    // ───────────────────────── settings dialog ─────────────────────────

    private fun showSettings() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(10), dp(18), dp(10)) }
        fun label(t: String) = TextView(this).apply { text = t; setTextColor(Color.parseColor("#E6E8EE")); textSize = 13f; setPadding(0, dp(12), 0, dp(2)) }
        fun spinnerRow(title: String, items: List<String>, sel: Int, onSel: (Int) -> Unit) {
            col.addView(label(title))
            val sp = android.widget.Spinner(this)
            sp.adapter = android.widget.ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
            sp.setSelection(sel)
            sp.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                var first = true
                override fun onItemSelected(p: android.widget.AdapterView<*>?, v: View?, pos: Int, id: Long) { if (first) { first = false; return }; onSel(pos) }
                override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
            }
            col.addView(sp)
        }
        fun switchRow(title: String, on: Boolean, onChange: (Boolean) -> Unit) {
            col.addView(Switch(this).apply { text = title; isChecked = on; setOnCheckedChangeListener { _, v -> onChange(v) } },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        }
        fun seekRow(title: String, maxV: Int, cur: Int, fmt: (Int) -> String, onChange: (Int) -> Unit) {
            val tv = label("$title: ${fmt(cur)}")
            col.addView(tv)
            col.addView(SeekBar(this).apply {
                max = maxV; progress = cur
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { tv.text = "$title: ${fmt(p)}"; if (u) onChange(p) }
                    override fun onStartTrackingTouch(s: SeekBar) {}
                    override fun onStopTrackingTouch(s: SeekBar) {}
                })
            })
        }

        val brs = listOf(0f, 4f, 6f, 8f, 10f, 12f)
        spinnerRow("Bitrate", brs.map { if (it == 0f) "Auto (recommended)" else "${it.toInt()} Mbps" }, brs.indexOf(cfg.bitrateMbps).coerceAtLeast(0)) { cfg.bitrateMbps = brs[it] }
        val hevcOk = CodecSupport.hevcSupported()
        spinnerRow("Codec", listOf("H.264 (recommended)", if (hevcOk) "H.265 / HEVC" else "H.265 (not supported)"), if (cfg.hevc && hevcOk) 1 else 0) { cfg.hevc = (it == 1) && hevcOk }
        val cds = listOf(0, 3, 5, 10)
        spinnerRow("Countdown", cds.map { if (it == 0) "Off" else "$it sec" }, cds.indexOf(cfg.countdown).coerceAtLeast(0)) { cfg.countdown = cds[it] }

        seekRow("Microphone volume", 200, (cfg.micVol * 100).toInt(), { "$it%" }) { cfg.micVol = it / 100f }
        seekRow("Source volume", 200, (cfg.srcVol * 100).toInt(), { "$it%" }) { cfg.srcVol = it / 100f }
        switchRow("Echo suppression (VOICE mode; headphones are still best)", cfg.echoSuppress) { cfg.echoSuppress = it }

        val camRes = listOf(640, 1280, 1920)
        spinnerRow("Camera resolution", listOf("360p (lightest)", "720p (recommended)", "1080p"), camRes.indexOf(cfg.cameraLong).coerceAtLeast(1)) { cfg.cameraLong = camRes[it]; ConfigStore.save(this, cfg); if (!RecorderState.isBusy) bindPreview() }
        switchRow("Mirror front camera", cfg.mirrorFront) { cfg.mirrorFront = it; ConfigStore.save(this, cfg); editor.previewView.scaleX = if (cfg.frontCamera && !cfg.mirrorFront) -1f else 1f }
        seekRow("Zoom", 30, ((cfg.zoom - 1f) * 10).toInt(), { String.format(Locale.US, "%.1fx", 1f + it / 10f) }) { cfg.zoom = 1f + it / 10f; applyCameraControls() }
        seekRow("Exposure", 8, cfg.exposureIndex + 4, { "${it - 4}" }) { cfg.exposureIndex = it - 4; applyCameraControls() }
        switchRow("Flash / torch (back camera)", cfg.torch) { cfg.torch = it; applyCameraControls() }

        switchRow("Video file mode: stop recording when the last item ends", cfg.autoStop) { cfg.autoStop = it }
        seekRow("Video audio delay (fix sync)", 500, cfg.videoAudioDelayMs, { "$it ms" }) { cfg.videoAudioDelayMs = it }
        switchRow("Silent playback (record the video's sound cleanly, no speaker sound → no echo)", cfg.silentPlayback) { cfg.silentPlayback = it }
        switchRow("Warn me when no headphones are connected", cfg.warnEcho) { cfg.warnEcho = it }

        // شاشة الانتظار
        col.addView(label("Standby screen — shown (and recorded) when you tap ⏸ Standby during recording"))
        val sbLabel = TextView(this).apply { text = standbyDesc(); setTextColor(Color.parseColor("#AAB0BD")); textSize = 12f }
        standbyLabelView = sbLabel
        col.addView(sbLabel)
        val sbRow = LinearLayout(this)
        sbRow.addView(chip("Choose image / video") { standbyPickLauncher.launch(arrayOf("image/*", "video/*")) }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8))
        sbRow.addView(chip("Use text") {
            cfg.standbyUri = ""; cfg.standbyName = ""; cfg.standbyIsVideo = false
            ConfigStore.save(this, cfg); sbLabel.text = standbyDesc()
        })
        col.addView(sbRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
        val sbText = android.widget.EditText(this).apply {
            setText(cfg.standbyText); hint = "Standby text"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setSingleLine(false); maxLines = 4
            doAfterTextChanged { cfg.standbyText = it?.toString() ?: ""; if (cfg.standbyUri.isEmpty()) sbLabel.text = standbyDesc() }
        }
        col.addView(sbText)
        switchRow("Mute the microphone while standby is on", cfg.standbyMuteMic) { cfg.standbyMuteMic = it }
        switchRow("Show standby automatically while I pick a file during recording", cfg.autoStandbyOnImport) { cfg.autoStandbyOnImport = it }

        // قص/تكبير الشاشة الملتقطة (وضع Screen)
        col.addView(label("Screen mode — crop / zoom the captured screen (so a video, like YouTube, fills the frame)"))
        seekRow("Screen zoom", 300, ((cfg.scrZoom - 1f) * 100).toInt(), { "${100 + it}%" }) { cfg.scrZoom = 1f + it / 100f }
        seekRow("Screen move left / right", 200, (cfg.scrPanX * 100).toInt() + 100, { "${it - 100}" }) { cfg.scrPanX = (it - 100) / 100f }
        seekRow("Screen move up / down", 200, (cfg.scrPanY * 100).toInt() + 100, { "${it - 100}" }) { cfg.scrPanY = (it - 100) / 100f }
        val rots = listOf(0, 90, 180, 270)
        spinnerRow("Camera rotation fix (if the camera looks sideways)", listOf("0° (auto)", "90°", "180°", "270°"), rots.indexOf(cfg.camRotAdjust).coerceAtLeast(0)) { cfg.camRotAdjust = rots[it] }
        seekRow("Camera border", 30, (cfg.layout.borderFrac * 1000).toInt(), { "${it / 10f}" }) { cfg.layout.borderFrac = it / 1000f; editor.refresh() }
        seekRow("Corner radius", 50, (cfg.layout.radiusFrac * 100).toInt(), { "$it%" }) { cfg.layout.radiusFrac = it / 100f; editor.refresh() }

        col.addView(TextView(this).apply {
            text = "Notes: 60 fps and 1080p may overheat or drop frames on Galaxy M13 — 1080p/30 is the stable default. " +
                "Source audio can only be captured from apps that allow it (Android rule); protected content stays silent. " +
                "If a screen-capture app blocks video, Android shows black — that is expected."
            setTextColor(Color.parseColor("#9AA0AA")); textSize = 11f; setPadding(0, dp(14), 0, 0)
        })

        val sv = ScrollView(this).apply { addView(col) }
        AlertDialog.Builder(this).setTitle("Settings").setView(sv)
            .setPositiveButton("Done") { _, _ -> ConfigStore.save(this, cfg); render() }
            .setOnDismissListener {
                standbyLabelView = null
                ConfigStore.save(this, cfg); render()
                RecorderState.scene?.applyLayout(cfg.layout)
            }
            .show()
    }
}
